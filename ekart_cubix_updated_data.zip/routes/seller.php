<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
 */

use Illuminate\Support\Facades\Route;

Route::group(['namespace' => 'Seller', 'prefix' => 'seller', 'as' => 'seller.'], function () {

    /*authentication*/
    Route::group(['namespace' => 'Auth', 'prefix' => 'auth', 'as' => 'auth.'], function () {
        Route::get('login', 'LoginController@login')->name('login');
        Route::post('login', 'LoginController@submit');
        Route::get('logout', 'LoginController@logout')->name('logout');

        Route::get('forgot-password', 'ForgotPasswordController@forgot_password')->name('forgot-password');
        Route::post('forgot-password', 'ForgotPasswordController@reset_password_request');
        Route::get('reset-password', 'ForgotPasswordController@reset_password_index')->name('reset-password');
        Route::post('reset-password', 'ForgotPasswordController@reset_password_submit');
        Route::get('payment/{id}/{password?}', 'PaymentController@paymentView')->name('payment');
        Route::post('payment-process', 'PaymentController@payment_process')->name('payment-process');
        Route::get('onetime-change-password/{string}', 'LoginController@onetime_change_password')->name('onetime-change-password');
        Route::post('reset-one-time-password', 'LoginController@reset_one_time_password')->name('reset-one-time-password');
    });

    /*authenticated*/
    Route::group(['middleware' => ['seller']], function () {
        //dashboard routes
        Route::group(['prefix' => 'dashboard', 'as' => 'dashboard.'], function () {
            Route::get('dashboard', 'DashboardController@dashboard');
            Route::get('/', 'DashboardController@dashboard')->name('index');
            Route::post('order-stats', 'DashboardController@order_stats')->name('order-stats');
            Route::post('business-overview', 'DashboardController@business_overview')->name('business-overview');
        });

        Route::group(['prefix' => 'plan', 'as' => 'plan.'], function () {
            Route::get('plan-window', 'PlanController@getAllPlans')->name('plan-window');;
            Route::post('purchase-plan', 'PlanController@purchasePlan')->name('purchase-plan');
        });

        Route::group(['prefix' => 'discount', 'as' => 'discount.'], function () {
            Route::get('/','DiscountController@discount_page')->name('index');
            Route::get('create-discount','DiscountController@create')->name('discount-create');
            Route::post('store','DiscountController@store')->name('store');
            Route::post('update','DiscountController@update')->name('update');
            Route::post('get-variant','DiscountController@get_vairants')->name('get-variant');
            Route::post('update-status','DiscountController@update_status')->name('update-status');
            Route::post('update-hidden','DiscountController@update_hidden')->name('update-hidden');
            Route::post('delete-discount','DiscountController@delete_discount')->name('delete-discount');
            Route::get('edit-discount','DiscountController@edit_discount')->name('edit-discount');
            Route::get('copy-discount','DiscountController@copy_discount')->name('copy-discount');
            Route::post('selection-category','DiscountController@selectionCategorySearch')->name('selection.cat');
            Route::post('product-selection','DiscountController@get_product_selection')->name('products.selection');
            Route::post('variations-discount','DiscountController@get_variations_discount')->name('variations.products');
            Route::get('hidden-discount','DiscountController@get_discount_hiddens')->name('hide.discounts');
        });

        Route::group(['prefix' => 'product', 'as' => 'product.'], function () {
            Route::post('image-upload', 'ProductController@imageUpload')->name('image-upload');
            Route::get('remove-image', 'ProductController@remove_image')->name('remove-image');
            //code identify on 01_05_2022
            Route::get('add-new', 'ProductController@add_new')->name('add-new');
            Route::post('add-new', 'ProductController@store')->name('add-new-product');
             //code identify on 01_05_2022
            Route::post('status-update', 'ProductController@status_update')->name('status-update');
            Route::post('status-update-variant', 'ProductController@status_update_variant')->name('status-update-variant');
            Route::get('categories','ProductController@categories')->name('categories');
            Route::get('categories/{id}','ProductController@editCategories')->name('categories.id');
            Route::get('get-category-datalist','ProductController@get_categories_datalist')->name('get-category-datalist');

            Route::post('active-inactive','ProductController@active_inactive_selected')->name('active-inactive');
            Route::post('delete-selected','ProductController@delete_selected')->name('delete-selected');
            Route::post('export-selected','ProductController@export_selected')->name('export-selected');


            Route::get('units','ProductController@units_page')->name('units-page');
            Route::get('attributes','ProductController@attribute_function')->name('attributes');
            Route::post('add-seller-unit','ProductController@add_unit_seller')->name('add-seller-unit');
            Route::post('add-seller-attribute','ProductController@add_attribute_seller')->name('add-seller-attribute');
            Route::post('update-seller-unit','ProductController@update_unit_seller')->name('update-seller-unit');
            Route::post('add-brand-excel','ProductController@add_brand_excel')->name('add-brand-excel');
            Route::post('add-unit-excel','ProductController@add_unit_excel')->name('add-unit-excel');
            Route::post('add-category-excel','ProductController@excel_categories_upload')->name('add-category-excel');
            Route::get('brands','ProductController@brands_function')->name('brands');
            Route::post('brands','ProductController@brands_function')->name('brands');
            Route::get('update-brand/{id}','ProductController@brands_update')->name('update-brand');

            Route::post('update-brand/{id}','ProductController@update_brand_data')->name('updated-brand-data');
            Route::post('delete-brand','ProductController@delete_brand_data')->name('delete-brand');
            Route::get('add-brand','ProductController@add_brandPage')->name('add-brand');
            Route::post('add-new-brand','ProductController@add_brand_new')->name('add-new-brand');
            Route::get('add-category','ProductController@create_category')->name('add-category');
            Route::get('add-category/{id}','ProductController@create_category')->name('add-category.id');
            Route::post('createSellerCat','ProductController@createSellerCat')->name('create-category');
            Route::post('create-category-ajax','ProductController@create_category_ajax')->name('create-category-ajax');
            Route::get('get-brand-with-ajax','ProductController@getBrandAjax')->name('get-brand-with-ajax');


            Route::post('add-new-unit-ajax','ProductController@create_unit_ajax')->name('add-new-unit-ajax');
            Route::get('get-unit-with-ajax','ProductController@getUnitAjax')->name('get-unit-with-ajax');

            Route::post('add-new-attributes-ajax','ProductController@create_attributes_ajax')->name('add-new-attributes-ajax');
            Route::get('get-attributes-with-ajax','ProductController@getAttributesAjax')->name('get-attributes-with-ajax');

            Route::post('add-new-brand-ajax','ProductController@create_brand_ajax')->name('add-new-brand-ajax');
            Route::post('updateParentCategory','ProductController@updateParentCategory')->name('update-parent-category');
            Route::post('seller-seleted-brand','ProductController@seller_selected_brand')->name('seller-seleted-brand');
            Route::post('seller-seleted-units','ProductController@seller_selected_units')->name('seller-seleted-units');
            Route::post('seller-seleted-attributes','ProductController@seller_selected_attributes')->name('seller-seleted-attributes');
            Route::post('editSellerCat','ProductController@editSellerCat')->name('edit-category');
            Route::get('delete-catgory/{id}','ProductController@deletecategorydata');
            Route::get('list', 'ProductController@list')->name('list');
            Route::get('stock-limit-list/{type}', 'ProductController@stock_limit_list')->name('stock-limit-list');
            Route::get('get-variations', 'ProductController@get_variations')->name('get-variations');
            Route::post('update-quantity', 'ProductController@update_quantity')->name('update-quantity');
            Route::get('edit/{id}', 'ProductController@edit')->name('edit');
            Route::get('variant/{id}', 'ProductController@variant')->name('variant');
            Route::post('update/{id}', 'ProductController@update')->name('update');
            Route::post('update-variant/{id}', 'ProductController@update_variant')->name('update-variant');
            Route::post('sku-combination', 'ProductController@sku_combination')->name('sku-combination');
            
            Route::post('edit-sku-combination', 'ProductController@edit_sku_combination')->name('edit-sku-combination');

            Route::get('get-categories', 'ProductController@get_categories')->name('get-categories');
            

            Route::get('stock-update','ProductController@stock_update_page')->name('stock-update');

            Route::delete('delete/{id}', 'ProductController@delete')->name('delete');

            Route::get('view/{id}', 'ProductController@view')->name('view');
            Route::get('bulk-import', 'ProductController@bulk_import_index')->name('bulk-import');
            Route::post('bulk-import', 'ProductController@bulk_import_data');
            Route::post('bulk-import-stock-update', 'ProductController@bulk_import_stock_update_data')->name('bulk-import-stock-update');


            Route::get('bulk-export', 'ProductController@bulk_export_data')->name('bulk-export');

             // new code 13_05_22 start     
            Route::get('brand-export', 'ProductController@brand_export')->name('brand-export'); 
            Route::get('category-export', 'ProductController@category_export')->name('category-export');    
            Route::get('sub-category-export', 'ProductController@sub_category_export')->name('sub-category-export');    
            Route::get('sub-sub-category-export', 'ProductController@sub_sub_category_export')->name('sub-sub-category-export');

            Route::get('seller-guide', 'ProductController@seller_guide')->name('seller-guide');    
        //end

            Route::post('block-ids', 'ProductController@block_ids')->name('block-ids');
            Route::post('get-child', 'ProductController@get_child')->name('get-child');
            
            Route::post('selected-brands', 'ProductController@selected_brands')->name('selected-brands');
            //----------------new route for unit 09/06/2022 start----------------------------
             Route::post('selected-units', 'ProductController@selected_units')->name('selected-units');
              //----------------new route for unit 09/06/2022 end-----------------------------
            Route::get('units/{unit}', 'ProductController@units')->name('units');
            Route::get('brand-duplicate/{brand}', 'ProductController@checkbrandsduplicate')->name('brand-duplicate');
            Route::get('get-latestbrand', 'ProductController@getlatestbrand')->name('get-latestbrand');
             Route::get('get-unit', 'ProductController@getunit')->name('get-unit');
            Route::get('get-seller-cat-data', 'ProductController@getSellerCatdata')->name('get-seller-cat-data');

            Route::post('check-variant-exist', 'ProductController@checkVariantExist')->name('check-variant-exist');
            Route::post('check-variant-exist-on-edit', 'ProductController@checkVariantExistOnEdit')->name('check-variant-exist-on-edit');
            Route::post('get-all-color', 'ProductController@get_all_color')->name('get-all-color');

        });

        Route::group(['prefix' => 'sub-category', 'as' => 'sub-category.'], function () {
            Route::post('sub-category-store', 'SubCategoryController@store')->name('sub-category-store');
        });

        Route::group(['prefix' => 'sub-sub-category', 'as' => 'sub-sub-category.'], function () {
            Route::post('sub-category-store', 'SubSubCategoryController@store')->name('sub-sub-category-store');
            Route::post('get-sub-category', 'SubSubCategoryController@getSubCategory')->name('getSubCategory');
            Route::get('get-category', 'SubSubCategoryController@getCategory')->name('get-category');
        });
// new route 10/06/2022
 
  Route::group(['prefix' => 'unit', 'as' => 'unit.'], function () {
           Route::post('add-unit', 'UnitController@store')->name('add-unit');;
        });
        //end route 10/06/2022
        Route::group(['prefix' => 'brand', 'as' => 'brand.'], function () {
            Route::post('add-new', 'BrandController@store')->name('add-brand');
        });

 // added 16/05/22
        Route::post('add-discount', 'ProductDiscountController@store')->name('add-discount');
        Route::post('delete-discount', 'ProductDiscountController@delete')->name('delete-discount');
        // Route::group(['prefix' => 'sub-sub-category', 'as' => 'sub-sub-category.'], function () {
        //     Route::get('view', 'SubSubCategoryController@index')->name('view');
        //     Route::post('store', 'SubSubCategoryController@store')->name('store');
        //     Route::post('get-sub-category', 'SubSubCategoryController@getSubCategory')->name('getSubCategory');
        //     Route::post('get-unique-status', 'SubSubCategoryController@getUniqueStatus')->name('getUniqueStatus');

        //     Route::get('edit/{sscid}', 'SubSubCategoryController@edit')->name('edit');
        //     Route::post('update', 'SubSubCategoryController@update')->name('update');


        //     Route::post('delete', 'SubSubCategoryController@delete')->name('delete');
        // });

        Route::group(['prefix' => 'customers', 'as' => 'customers.'], function () {
            Route::get('list', 'CustomerController@customer_list')->name('list');
            Route::post('credit-permission-update', 'CustomerController@credit_permission_update')->name('credit-permission-update');
        });

        Route::group(['prefix' => 'orders', 'as' => 'orders.'], function () {
            Route::get('list/{status}', 'OrderController@list')->name('list');
            Route::get('details/{id}', 'OrderController@details')->name('details');
            Route::get('generate-invoice/{id}', 'OrderController@generate_invoice')->name('generate-invoice');
            Route::post('status', 'OrderController@status')->name('status');
            Route::post('productStatus', 'OrderController@productStatus')->name('productStatus');
            Route::post('payment-status', 'OrderController@payment_status')->name('payment-status');

            Route::get('add-delivery-man/{order_id}/{d_man_id}', 'OrderController@add_delivery_man')->name('add-delivery-man');
        });
        //Product Reviews

        Route::group(['prefix' => 'reviews', 'as' => 'reviews.'], function () {
            Route::get('list', 'ReviewsController@list')->name('list');

        });

        // Messaging
        Route::group(['prefix' => 'messages', 'as' => 'messages.'], function () {
            Route::get('/chat', 'ChattingController@chat')->name('chat');
            Route::get('/message-by-user', 'ChattingController@message_by_user')->name('message_by_user');
            Route::post('/seller-message-store', 'ChattingController@seller_message_store')->name('seller_message_store');
        });
        // profile

        Route::group(['prefix' => 'profile', 'as' => 'profile.'], function () {
            Route::get('view', 'ProfileController@view')->name('view');
            Route::get('update/{id}', 'ProfileController@edit')->name('update');
            Route::post('update/{id}', 'ProfileController@update');
            Route::post('settings-password', 'ProfileController@settings_password_update')->name('settings-password');

            Route::get('bank-edit/{id}', 'ProfileController@bank_edit')->name('bankInfo');
            Route::post('bank-update/{id}', 'ProfileController@bank_update')->name('bank_update');

        });
        Route::group(['prefix' => 'shop', 'as' => 'shop.'], function () {
            Route::get('view', 'ShopController@view')->name('view');
            Route::get('edit/{id}', 'ShopController@edit')->name('edit');
            Route::post('update/{id}', 'ShopController@update')->name('update');
        });

        Route::group(['prefix' => 'withdraw', 'as' => 'withdraw.'], function () {
            Route::post('request', 'WithdrawController@w_request')->name('request');
            Route::delete('close/{id}', 'WithdrawController@close_request')->name('close');
        });

        Route::group(['prefix' => 'business-settings', 'as' => 'business-settings.'], function () {

            Route::group(['prefix' => 'shipping-method', 'as' => 'shipping-method.'], function () {
                Route::get('add', 'ShippingMethodController@index')->name('add');
                Route::post('add', 'ShippingMethodController@store');
                Route::get('edit/{id}', 'ShippingMethodController@edit')->name('edit');
                Route::put('update/{id}', 'ShippingMethodController@update')->name('update');
                Route::post('delete', 'ShippingMethodController@delete')->name('delete');
                Route::post('status-update', 'ShippingMethodController@status_update')->name('status-update');
            });

            Route::group(['prefix' => 'withdraw', 'as' => 'withdraw.'], function () {
                Route::get('list', 'WithdrawController@list')->name('list');
                Route::get('cancel/{id}', 'WithdrawController@close_request')->name('cancel');
                Route::post('status-filter', 'WithdrawController@status_filter')->name('status-filter');
            });

        });

        Route::group(['prefix' => 'delivery-man', 'as' => 'delivery-man.'], function () {
            Route::get('add', 'DeliveryManController@index')->name('add');
            Route::post('store', 'DeliveryManController@store')->name('store');
            Route::get('list', 'DeliveryManController@list')->name('list');
            Route::get('preview/{id}', 'DeliveryManController@preview')->name('preview');
            Route::get('edit/{id}', 'DeliveryManController@edit')->name('edit');
            Route::post('update/{id}', 'DeliveryManController@update')->name('update');
            Route::delete('delete/{id}', 'DeliveryManController@delete')->name('delete');
            Route::post('search', 'DeliveryManController@search')->name('search');
            Route::post('status-update', 'DeliveryManController@status')->name('status-update');
        });
    });

});
