<?php

namespace App\Http\Controllers\Seller\Auth;

use App\CPU\ImageManager;
use App\Http\Controllers\Controller;
use App\Model\Seller;
use App\Model\Shop;
use App\Model\CountryCode;
use App\Model\CompanyType;
use App\Model\Currency;
use App\Model\SubscriptionPlan;
use Brian2694\Toastr\Facades\Toastr;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class RegisterController extends Controller
{
    public function create(Request $request, $planid=null)
    {
        if(empty($planid))
            $planid=0;
        $data['curr'] = Currency::all();
        $data['ccode'] = CountryCode::all();
        $data['CompanyType'] = CompanyType::where('status',1)->get();
        $plans = SubscriptionPlan::where('plan_status', 1)->get();
        $plan = SubscriptionPlan::where(['plan_status' => 1,'id' => $planid])->first();

            if(!empty($plan->validOffers))
            {
                foreach($plan->validOffers as $keys => $singleoffer)
                {
                    if(date('Y-m-d') <= $singleoffer->offer_enddate)
                    {
                        $plan->validOffers[$keys]->offdetails = 1;
                    }
                    else
                    {
                        $plan->validOffers[$keys]->offdetails = 0;
                    }
                }
            }

            $initailActiveOfferSttaus = 0;
            if(!empty($plan->validOffers))
            {
                foreach($plan->validOffers as $keys => $singleoffer)
                {
                    if(date('Y-m-d') <= $singleoffer->offer_enddate)
                    {
                        $initailActiveOfferSttaus = 1;
                        break;
                    }
                }
            }

            $initailActiveOfferSttaus;

            return view('seller-views.auth.register', compact('data','plans','plan','initailActiveOfferSttaus'));
    }

    public function getOffersOfSelectedPlan(Request $request)
    {
        $plan = SubscriptionPlan::where(['plan_status' => 1,'id' => $request->id])->first();
        $value = false;
        $offeroptions=array();
        $offeroptions[0] = '<option value="">--Select plan offer--</option>';
        if(!empty($plan->validOffers) && $plan->validOffers->count()>0){
            foreach($plan->validOffers as $keys => $singleoffer)
            {
                if(date('Y-m-d') <= $singleoffer->offer_enddate)
                {
                    $plan->validOffers[$keys]->offdetails = 1;
                }
                else
                {
                    $plan->validOffers[$keys]->offdetails = 0;
                }
            }

            
            foreach($plan->validOffers as $key => $off)
            {
                if($off->offdetails == 1)
                {
                    $offeroptions[$key+1]='<option 
                    data-offerplanDuration = "'.\App\CPU\BackEndHelper::set_plan_duration($plan->duration,$plan->duration_type).'" 
                    data-offerplanPrice="'.\App\CPU\BackEndHelper::set_plan_currency($plan->price,$plan->currency_id).'" 
                    data-offerplanNewPrice = "'.\App\CPU\BackEndHelper::set_plan_currency($off->new_ammount,$plan->currency_id).'"
                    value="'.$off->id.'">'.$off->offer_title.'</option>';  
                }
            }

            if(!empty($plan->validOffers))
            {
                foreach($plan->validOffers as $key => $off)
                {
                    if($off->offdetails == 1)
                    {
                        $value = true;
                        break;
                    }
                }
            }
        }

        return json_encode(array('result' => $offeroptions,'value' => $value));
    }

    public function store(Request $request)
    {

        $this->validate($request, [
            'email'             => 'required|unique:sellers',
            'shop_address'      => 'required',

            'bank_name'         => 'required',
            'ac_holder_name'    => 'required',
            'ac_number'         => 'required',
            //'swift_number' => 'required',

            'f_name'            => 'required',
            'l_name'            => 'required',
            'shop_name'         => 'required',
            'phone'             => 'required',
            'password'          => 'required|min:8',
        ]);

        DB::transaction(function ($r) use ($request) {
            $seller = new Seller();
            $seller->f_name = $request->f_name;
            $seller->l_name = $request->l_name;
            $seller->phone = $request->phone;
            $seller->email = $request->email;
            $seller->country_code = $request->country_code;
            $seller->seller_plan_request = $request->seller_plan_request;
            $seller->plan_offer_id = $request->plan_offer;

            //$seller->seller_currency = $request->seller_currency;
            $seller->seller_currency = $request->seller_transaction_currency;

            $seller->image = ImageManager::upload('seller/', 'png', $request->file('image'));
            $seller->password = bcrypt($request->password);
            $seller->status = "pending";
            $seller->save();

            $shop = new Shop();
            $shop->seller_id        = $seller->id;
            $shop->name             = $request->shop_name;
            $shop->shop_type        = $request->shop_type;
            $shop->address          = $request->shop_address;
            $shop->address2         = (!empty($request->shop_address2))?$request->shop_address2:NULL;
            $shop->address3         = (!empty($request->shop_address3))?$request->shop_address3:NULL;
            $shop->address4         = (!empty($request->shop_address4))?$request->shop_address4:NULL;
            $shop->address5         = (!empty($request->shop_address5))?$request->shop_address5:NULL;
            $shop->country          = $request->shop_country_code;
            $shop->reg_or_cr_number = $request->reg_or_cr_number;
            $shop->vat_no           = $request->vat_no;
            $shop->bank_name        = strtoupper($request->bank_name);
            $shop->ac_holder_name   = $request->ac_holder_name;
            $shop->ac_number        = $request->ac_number;
            $shop->swift_number     = (!empty($request->swift_number))?$request->swift_number:NULL;;
            $shop->iban_number      = $request->iban_number;

            // -- added at 26/3/22 (start)-- //
            $shop->bank_address     = $request->bank_address;
            $shop->branch           = $request->branch;
            // -- added at 26/3/22 (end)-- //
            
            $shop->contact          = $request->phone;
            $shop->image            = ImageManager::upload('shop/', 'png', $request->file('logo'));
            $shop->banner           = ImageManager::upload('shop/banner/', 'png', $request->file('banner'));
            $shop->save();

            DB::table('seller_wallets')->insert([
                'seller_id' => $seller['id'],
                'withdrawn' => 0,
                'commission_given' => 0,
                'total_earning' => 0,
                'pending_withdraw' => 0,
                'delivery_charge_earned' => 0,
                'collected_cash' => 0,
                'created_at' => now(),
                'updated_at' => now(),
            ]);

        });

        Toastr::success('Shop apply successfully!');
        return redirect()->route('seller.auth.login');

    }
}
