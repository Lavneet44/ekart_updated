<?php

namespace App\Http\Controllers\Seller\Auth;

use App\Http\Controllers\Controller;
use App\Model\Seller;
use App\Model\SellerPlan;
use App\Model\SellerWallet;
use Brian2694\Toastr\Facades\Toastr;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Gregwar\Captcha\CaptchaBuilder;
use App\CPU\Helpers;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Str;
use Hash;
use DateTime;
use Illuminate\Support\Facades\Mail;

class LoginController extends Controller
{
    public function __construct()
    {
        $this->middleware('guest:seller', ['except' => ['logout']]);
    }

    public function login()
    {
    // $messageBody = '<h1>Thi is body</h1>';
    //     Mail::raw($messageBody, function ($message) {
    //     $message->from('response@webbasaar.com', 'Learning Laravel');
    //     $message->to('tusharekart@gmail.com');
    //     $message->subject('Learning Laravel test email');
    // });
    
    // die('111');

    // check for failures
    if (Mail::failures()) {
        // return response showing failed emails
    }
        
       //  dd(config('mail'));
       //  $msgdata = array('subject'=>"email de test",'email'=>"response@webbasaar.com", 
       //  'name'=>"nameABC",'body'=>"my Body DEF");

       //  try {
       //      Mail::to('tusharekart@gmail.com')->send(new \App\Mail\OrderReceivedNotifySeller('ABC123'));
       //  }catch(Exception $e){
       //      // Log your exception
       //  }

       // die("123456");
                
        $custome_recaptcha = new CaptchaBuilder;
        $custome_recaptcha->build();
        Session::put('custome_recaptcha', $custome_recaptcha->getPhrase());
        return view('seller-views.auth.login', compact('custome_recaptcha'));
    }

    public function submit(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
            'password' => 'required|min:6'
        ]);
        //recaptcha validation
        $recaptcha = Helpers::get_business_settings('recaptcha');
        if (isset($recaptcha) && $recaptcha['status'] == 1) {
            try {
                $request->validate([
                    'g-recaptcha-response' => [
                        function ($attribute, $value, $fail) {
                            $secret_key = Helpers::get_business_settings('recaptcha')['secret_key'];
                            $response = $value;
                            $url = 'https://www.google.com/recaptcha/api/siteverify?secret=' . $secret_key . '&response=' . $response;
                            $response = \file_get_contents($url);
                            $response = json_decode($response);
                            if (!$response->success) {
                                $fail(\App\CPU\translate('ReCAPTCHA Failed'));
                            }
                        },
                    ],
                ]);
            } catch (\Exception $exception) {}
        } else if ($recaptcha['status'] == 0) {
            $builder = new CaptchaBuilder();
            $builder->setPhrase(session()->get('custome_recaptcha'));
            if (!$builder->testPhrase($request->custome_recaptcha)) {
                Toastr::error(\App\CPU\translate('ReCAPTCHA Failed'));
                return back();
            }
        }

        $se = Seller::with(['sellerpplan'])->where(['email' => $request['email']])->first();

        // echo "<pre>";
        // print_r($se->paidSeller->toArray());
        // print_r($se->registerSellerPlanRequest->toArray());
        if(!empty($se->paidSeller))
        {
            $durationstring = "";
            $durationnumber = "";
            if($se->registerSellerPlanRequest->duration_type == 1)
            {
                $durationstring = "days";
            }
            elseif($se->registerSellerPlanRequest->duration_type == 2)
            {
                $durationstring = "month";
            }
            elseif($se->registerSellerPlanRequest->duration_type == 3)
            {
                $durationstring = "year";
            }
            else{

            }
            $durationstring;
            $durationnumber = $se->registerSellerPlanRequest->duration;
            $planStartDate = $se->paidSeller->created_at;
            $validaty = date('Y-m-d H:i:s', strtotime($planStartDate."+".$durationnumber." ".$durationstring));
            $currentDate = date('Y-m-d H:i:s');
            $datetime1 = new DateTime($validaty);
            $datetime2 = new DateTime($currentDate);
            $interval = $datetime1->diff($datetime2);
            $elapsed = $interval->format('%a days %h hours %i minutes %s seconds');
            if((strtotime($validaty) <= strtotime($currentDate))){
                Toastr::warning('your plan validity is expired, please purchase new plan to resume services !');
                return back();
            }
        }
        

        //if (isset($se) && $se['status'] == 'active' && auth('seller')->attempt(['email' => $request->email, 'password' => $request->password], $request->remember)) {

        if (isset($se) && $se['new_seller_status'] == 'active' && auth('seller')->attempt(['email' => $request->email, 'password' => $request->password], $request->remember)) {

            if($se->one_time_login_status==0){
                $modify_str = $se->id."_".$se->email;
                $encrypted = Crypt::encryptString($modify_str);
                Toastr::info(\App\CPU\translate('Please reset One time Password with your Password'));
                auth()->guard('seller')->logout();
                return redirect()->route('seller.auth.onetime-change-password',['string' => $encrypted]);
            }
            Toastr::info('Welcome to your dashboard!');
            if (SellerWallet::where('seller_id', auth('seller')->id())->first() == false) {
                DB::table('seller_wallets')->insert([
                    'seller_id' => auth('seller')->id(),
                    'withdrawn' => 0,
                    'commission_given' => 0,
                    'total_earning' => 0,
                    'pending_withdraw' => 0,
                    'delivery_charge_earned' => 0,
                    'collected_cash' => 0,
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);
            }
            $plans = array();
            $SellerPlan = SellerPlan::where('seller_id', auth('seller')->id())->get();
            if(!empty($SellerPlan)){
                foreach($SellerPlan as $key =>$sp){
                    $plans[$key] = $sp->subscription_plan_id;
                } 
            }
            session()->put('PlanId', $plans);

            
            if($interval->format('%a') <= 5){
                Toastr::info('your plan will expir on '.date('d/m/Y', strtotime($validaty)).'.Please purchase new plan to resume services !');
            }
            return redirect()->route('seller.dashboard.index');
        } 
        elseif (isset($se) && $se['new_seller_status'] == 'pending') 
        {
            Toastr::info('Your account is not approved yet.');
            return redirect()->back()->withInput($request->only('email', 'remember'));
        } 
        elseif (isset($se) && $se['new_seller_status'] == 'approved') 
        {
            Toastr::info('Your account is approved. Please Pay to Continue.');
            return redirect()->back()->withInput($request->only('email', 'remember'));
        }
        elseif (isset($se) && $se['new_seller_status'] == 'paid') 
        {
            if($se->paidSeller->result=="success"){
                Toastr::info('Please Reset Your One Time Password.');
                return redirect()->route('seller.auth.payment',['id' => $se->id]);
            }
            Toastr::error('Please Check Your payment status.');
            return redirect()->back();
        } 
        elseif (isset($se) && $se['new_seller_status'] == 'hold') 
        {
            Toastr::info('Your account is on hold!.');
            return redirect()->back();
        } 
        elseif (isset($se) && $se['new_seller_status'] == 'suspended') 
        {
            Toastr::error('Your account has been suspended!.');
            return redirect()->back();
        }

        return redirect()->back()->withInput($request->only('email', 'remember'))
            ->withErrors(['Credentials does not match.']);
    }

    public function logout(Request $request)
    {
        auth()->guard('seller')->logout();
        $request->session()->invalidate();
        session_unset();
        return redirect()->route('seller.auth.login');
    }

    public function onetime_change_password($str=NULL)
    {
        $decrypt= Crypt::decryptString($str);
        $sellerdata = explode('_', $decrypt);
        $velidseller = DB::table('sellers')->where(['id' => $sellerdata[0], 'email' => $sellerdata[1],'one_time_login_status' => 0])->first();
        if(empty($velidseller)){
            Toastr::warning('Please again click the button.');
            return redirect()->back();
        }
        return view('seller-views.auth.onetime-password-change',compact('velidseller'));
    }

    public function reset_one_time_password(Request $request)
    {
        // $seller = DB::table('sellers')->where(['email' => $request->email,'id' => $request->id])->first();
        // $matchPassword = Hash::check($request->onetimepassword,$seller->password);
        // if(empty($matchPassword)){
        //     Toastr::warning('Please check the One time password');
        //     return redirect()->back();
        // }
        $seller = Seller::find($request->id);
        $seller->password = bcrypt($request->newpassword);
        $seller->one_time_login_status = 1;
        $seller->status = 'approved';
        $seller->save();
        auth()->guard('seller')->logout();
        Toastr::success('Your Password is updated successfully Now you can login.');
        return redirect()->route('seller.auth.login');
    }
}
