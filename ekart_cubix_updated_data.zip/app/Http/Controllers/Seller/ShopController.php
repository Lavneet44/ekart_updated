<?php

namespace App\Http\Controllers\Seller;

use App\CPU\ImageManager;
use App\Http\Controllers\Controller;
use App\Model\Shop;
use App\Model\Seller;
use App\Model\Currency;
use Brian2694\Toastr\Facades\Toastr;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class ShopController extends Controller
{
    public function view()
    {
        $shop = Shop::where(['seller_id' => auth('seller')->id()])->first();
        if (isset($shop) == false) {
            DB::table('shops')->insert([
                'seller_id' => auth('seller')->id(),
                'name' => auth('seller')->user()->f_name,
                'address' => '',
                'contact' => auth('seller')->user()->phone,
                'image' => 'def.png',
                'created_at' => now(),
                'updated_at' => now()
            ]);
            $shop = Shop::where(['seller_id' => auth('seller')->id()])->first();
        }

        return view('seller-views.shop.shopInfo', compact('shop'));
    }

    public function edit($id)
    {
        $shop = Shop::where(['seller_id' =>  auth('seller')->id()])->first();

        ($shop->seller->seller_currency)?$shop->shop_currency = $shop->seller->seller_currency:$shop->shop_currency = Null;
        $currency = Currency::where('status',1)->get();
        return view('seller-views.shop.edit', compact('shop','currency'));
    }

    public function update(Request $request, $id)
    {

        $shop = Shop::find($id);
        // $shop->name = $request->name;
        $shop->shop_type        = $request->shop_type;
        $shop->reg_or_cr_number = $request->reg_or_cr_number;
        $shop->group_vat        = $request->group_vat;
        $shop->division_vat     = $request->division_vat;
        $shop->vat_no           = $request->vat_no;
        $shop->telephone_number = $request->telephone_number;
        $shop->contact          = $request->contact;
        $shop->whatapp_number   = $request->whatapp_number;
        $shop->shop_email       = $request->shop_email;

        $shop->address          = $request->address;
        $shop->address2         = (!empty($request->address2))?$request->address2:NULL;
        $shop->address3         = (!empty($request->address3))?$request->address3:NULL;
        $shop->address4         = (!empty($request->address4))?$request->address4:NULL;
        $shop->address5         = (!empty($request->address5))?$request->address5:NULL;
        $shop->country          = $request->shop_country_code;
        
        if ($request->image) {
            $shop->image = ImageManager::update('shop/', $shop->image, 'png', $request->file('image'));
        }
        if ($request->banner) {
            $shop->banner = ImageManager::update('shop/banner/', $shop->banner, 'png', $request->file('banner'));
        }
        $shop->save();

        $seller = Seller::find($shop->seller_id);

        if(!empty($request->country_code))
        {
            $seller->country_code = $request->country_code;
        }
        //$seller->seller_currency = $request->seller_currency;
        $seller->save();

        // $sellercurrency = Currency::where(['id'=>$request->seller_currency])->first();
        // session()->put('seller_currency_id', $sellercurrency->id);
        // session(['sellercurrencycode' => $sellercurrency->code]);
        // session(['sellercurrencysymbol' => $sellercurrency->symbol]);

        Toastr::info('Shop updated successfully!');
        return redirect()->route('seller.shop.view');
    }

}
