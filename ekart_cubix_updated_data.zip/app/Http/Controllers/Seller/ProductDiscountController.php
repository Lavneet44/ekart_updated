<?php

namespace App\Http\Controllers\Seller;

use App\CPU\BackEndHelper;
use App\CPU\Convert;
use App\CPU\Helpers;
use App\CPU\ImageManager;
use App\Http\Controllers\Controller;
use App\Model\Brand;
use App\Model\Category;
use App\Model\Color;
use App\Model\DealOfTheDay;
use App\Model\FlashDealProduct;
use App\Model\Product;
use App\Model\Review;
use App\Model\Translation;
use Brian2694\Toastr\Facades\Toastr;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Rap2hpoutre\FastExcel\FastExcel;
use App\Model\Cart;
use App\Model\Unit;
use App\Model\CategoryBlock;
use App\Model\Brandallowe;
use App\Model\ProductDiscount;

class ProductDiscountController extends Controller
{
	public function store(Request $request)
    {
        $ranges = array();
        foreach ($request->all() as $key => $value) {
            foreach ($value as $key => $val) {
                if($val['std'] != 0 && $val['end'] !=0){
                    $ranges[] = array('start' => date('Y-m-d H:i:s', strtotime($val['std'])), 'end' => date('Y-m-d H:i:s', strtotime($val['end'])));
                }
            }
        }

        $checkoverlap = $this->checkOverlapInDateRanges($ranges);
        if(!empty($checkoverlap) && count($checkoverlap)>0){
            $status = 0;
            $message = "Please Assign Some other Dates For This Discount. This Date is Overlaped With Other Discount For the same Product";
            $data = array('status' => 0,'message' => $message,'proid' => $request->product_id);
            return response()->json($data);
        }
    }
 

	public function checkOverlapInDateRanges($ranges) {
	    $overlapp = [];
	    for($i = 0; $i < count($ranges); $i++){
	        for($j= ($i + 1); $j < count($ranges); $j++){

	            $start = \Carbon\Carbon::parse($ranges[$j]['start']);
	            $end = \Carbon\Carbon::parse($ranges[$j]['end']);

	            $start_first = \Carbon\Carbon::parse($ranges[$i]['start']);
	            $end_first = \Carbon\Carbon::parse($ranges[$i]['end']);

	            if(\Carbon\Carbon::parse($ranges[$i]['start'])->between($start, $end) || \Carbon\Carbon::parse($ranges[$i]['end'])->between($start, $end)){
	                $overlapp[] = $ranges[$j];
	                break;
	            }
	            if(\Carbon\Carbon::parse($ranges[$j]['start'])->between($start_first, $end_first) || \Carbon\Carbon::parse($ranges[$j]['end'])->between($start_first, $end_first)){
	                $overlapp[] = $ranges[$j];
	                break;
	            }
	        }
	    }
	    return $overlapp;
	}

	public function delete(Request $request)
    {
        $del = ProductDiscount::where('id', $request['discountId'])->update(['status' => 1]);
        if($del){
            $message = "Discount removed Successfully";
            $data = array('status' => 1,'message' => $message);
        }else{
            $message = "Please Try again !";
            $data = array('status' => 0,'message' => $message);
        }
        return response()->json($data);
    }

}