<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class SellerPlan extends Model
{
    protected $table = 'seller_plans';

    public function sellerPlan()
    {
        return $this->hasOne(SubscriptionPlan::class);
    }

}
