<?php

namespace App\CPU;

use App\Model\Admin;
use App\Model\BusinessSetting;
use App\Model\Category;
use App\Model\Color;
use App\Model\Coupon;
use App\Model\Currency;
use App\Model\Order;
use App\Model\Review;
use App\Model\Seller;
use App\Model\ShippingMethod;
use App\Model\ProductDiscount ;
use App\User;
use Carbon\Carbon;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;

class Helpers
{
    public static function status($id)
    {
        if ($id == 1) {
            $x = 'active';
        } elseif ($id == 0) {
            $x = 'in-active';
        }

        return $x;
    }

    public static function transaction_formatter($transaction)
    {
        if ($transaction['paid_by'] == 'customer') {
            $user = User::find($transaction['payer_id']);
            $payer = $user->f_name . ' ' . $user->l_name;
        } elseif ($transaction['paid_by'] == 'seller') {
            $user = Seller::find($transaction['payer_id']);
            $payer = $user->f_name . ' ' . $user->l_name;
        } elseif ($transaction['paid_by'] == 'admin') {
            $user = Admin::find($transaction['payer_id']);
            $payer = $user->name;
        }

        if ($transaction['paid_to'] == 'customer') {
            $user = User::find($transaction['payment_receiver_id']);
            $receiver = $user->f_name . ' ' . $user->l_name;
        } elseif ($transaction['paid_to'] == 'seller') {
            $user = Seller::find($transaction['payment_receiver_id']);
            $receiver = $user->f_name . ' ' . $user->l_name;
        } elseif ($transaction['paid_to'] == 'admin') {
            $user = Admin::find($transaction['payment_receiver_id']);
            $receiver = $user->name;
        }

        $transaction['payer_info'] = $payer;
        $transaction['receiver_info'] = $receiver;

        return $transaction;
    }

    public static function get_customer($request = null)
    {
        $user = null;
        if (auth('customer')->check()) {
            $user = auth('customer')->user(); // for web
        } elseif ($request != null && $request->user() != null) {
            $user = $request->user(); //for api
        } elseif (session()->has('customer_id')) {
            $user = User::find(session('customer_id'));
        }

        if ($user == null) {
            $user = 'offline';
        }

        return $user;
    }

    public static function coupon_discount($request)
    {
        $discount = 0;
        $user = Helpers::get_customer($request);
        $couponLimit = Order::where('customer_id', $user->id)
            ->where('coupon_code', $request['coupon_code'])->count();

        $coupon = Coupon::where(['code' => $request['coupon_code']])
            ->where('limit', '>', $couponLimit)
            ->where('status', '=', 1)
            ->whereDate('start_date', '<=', Carbon::parse()->toDateString())
            ->whereDate('expire_date', '>=', Carbon::parse()->toDateString())->first();

        if (isset($coupon)) {
            $total = 0;
            foreach (CartManager::get_cart(CartManager::get_cart_group_ids($request)) as $cart) {
                $product_subtotal = $cart['price'] * $cart['quantity'];
                $total += $product_subtotal;
            }
            if ($total >= $coupon['min_purchase']) {
                if ($coupon['discount_type'] == 'percentage') {
                    $discount = (($total / 100) * $coupon['discount']) > $coupon['max_discount'] ? $coupon['max_discount'] : (($total / 100) * $coupon['discount']);
                } else {
                    $discount = $coupon['discount'];
                }
            }
        }

        return $discount;
    }

    public static function default_lang()
    {
        if (strpos(url()->current(), '/api')) {
            $lang = App::getLocale();
        } elseif (session()->has('local')) {
            $lang = session('local');
        } else {
            $data = Helpers::get_business_settings('language');
            $code = 'en';
            $direction = 'ltr';
            foreach ($data as $ln) {
                if (array_key_exists('default', $ln) && $ln['default']) {
                    $code = $ln['code'];
                    if (array_key_exists('direction', $ln)) {
                        $direction = $ln['direction'];
                    }
                }
            }
            session()->put('local', $code);
            Session::put('direction', $direction);
            $lang = $code;
        }
        return $lang;
    }

    public static function rating_count($product_id, $rating)
    {
        return Review::where(['product_id' => $product_id, 'rating' => $rating])->count();
    }

    public static function get_business_settings($name)
    {
        $config = null;
        $check = ['currency_model', 'currency_symbol_position', 'system_default_currency', 'language', 'company_name'];

        if (in_array($name, $check) == true && session()->has($name)) {
            $config = session($name);
        } else {
            $data = BusinessSetting::where(['type' => $name])->first();
            if (isset($data)) {
                $config = json_decode($data['value'], true);
                if (is_null($config)) {
                    $config = $data['value'];
                }
            }

            if (in_array($name, $check) == true) {
                session()->put($name, $config);
            }
        }

        return $config;
    }

    public static function get_settings($object, $type)
    {
        $config = null;
        foreach ($object as $setting) {
            if ($setting['type'] == $type) {
                $config = $setting;
            }
        }
        return $config;
    }

    public static function get_shipping_methods($seller_id, $type)
    {
        return ShippingMethod::where(['status' => 1])->where(['creator_id' => $seller_id, 'creator_type' => $type])->get();
    }

    public static function get_image_path($type)
    {
        $path = asset('storage/app/public/brand');
        return $path;
    }

    public static function product_data_formatting($data, $multi_data = false)
    {
        $storage = [];
        if ($multi_data == true) {
            foreach ($data as $item) {
                $variation = [];
                $item['category_ids'] = json_decode($item['category_ids']);
                $item['images'] = json_decode($item['images']);
                $item['colors'] = Color::whereIn('code', json_decode($item['colors']))->get(['name', 'code']);
                $attributes = [];
                if (json_decode($item['attributes']) != null) {
                    foreach (json_decode($item['attributes']) as $attribute) {
                        array_push($attributes, (integer)$attribute);
                    }
                }
                $item['attributes'] = $attributes;
                $item['choice_options'] = json_decode($item['choice_options']);
                foreach (json_decode($item['variation'], true) as $var) {
                    array_push($variation, [
                        'type' => $var['type'],
                        'price' => (double)$var['price'],
                        'sku' => $var['sku'],
                        'qty' => (integer)$var['qty'],
                    ]);
                }
                $item['variation'] = $variation;
                array_push($storage, $item);
            }
            $data = $storage;
        } else {
            $variation = [];
            $data['category_ids'] = json_decode($data['category_ids']);
            $data['images'] = json_decode($data['images']);
            $data['colors'] = Color::whereIn('code', json_decode($data['colors']))->get(['name', 'code']);
            $attributes = [];
            if (json_decode($data['attributes']) != null) {
                foreach (json_decode($data['attributes']) as $attribute) {
                    array_push($attributes, (integer)$attribute);
                }
            }
            $data['attributes'] = $attributes;
            $data['choice_options'] = json_decode($data['choice_options']);
            foreach (json_decode($data['variation'], true) as $var) {
                array_push($variation, [
                    'type' => $var['type'],
                    'price' => (double)$var['price'],
                    'sku' => $var['sku'],
                    'qty' => (integer)$var['qty'],
                ]);
            }
            $data['variation'] = $variation;
        }

        return $data;
    }

    public static function units()
    {
        $x = ['kg', 'pc', 'gms', 'ltrs'];
        return $x;
    }

    public static function remove_invalid_charcaters($str)
    {
        return str_ireplace(['\'', '"', ',', ';', '<', '>', '?'], ' ', $str);
    }

    public static function saveJSONFile($code, $data)
    {
        ksort($data);
        $jsonData = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        file_put_contents(base_path('resources/lang/en/messages.json'), stripslashes($jsonData));
    }

    public static function combinations($arrays)
    {
        $result = [[]];
        foreach ($arrays as $property => $property_values) {
            $tmp = [];
            foreach ($result as $result_item) {
                foreach ($property_values as $property_value) {
                    $tmp[] = array_merge($result_item, [$property => $property_value]);
                }
            }
            $result = $tmp;
        }
        return $result;
    }

    public static function error_processor($validator)
    {
        $err_keeper = [];
        foreach ($validator->errors()->getMessages() as $index => $error) {
            array_push($err_keeper, ['code' => $index, 'message' => $error[0]]);
        }
        return $err_keeper;
    }

    public static function currency_load()
    {
        $default = Helpers::get_business_settings('system_default_currency');
        $current = \session('system_default_currency_info');
        if (session()->has('system_default_currency_info') == false || $default != $current['id']) {
            $id = Helpers::get_business_settings('system_default_currency');
            $currency = Currency::find($id);
            session()->put('system_default_currency_info', $currency);
            session()->put('currency_code', $currency->code);
            session()->put('currency_symbol', $currency->symbol);
            session()->put('currency_exchange_rate', $currency->exchange_rate);
            session()->put('currency_formate', $currency->currency_formate);
        }
    }

    public static function currency_converter($amount)
    {
        $currency_model = Helpers::get_business_settings('currency_model');
        if ($currency_model == 'multi_currency') {
            if (session()->has('usd')) {
                $usd = session('usd');
            } else {
                $usd = Currency::where(['code' => 'USD'])->first()->exchange_rate;
                session()->put('usd', $usd);
            }
            $my_currency = \session('currency_exchange_rate');
            $rate = $my_currency / $usd;
        } else {
            $rate = 1;
        }
        $finalresult = floatval($amount) * floatval($rate);
        return Helpers::set_symbol(round($finalresult, 2));
    }

    // ---xxx May be this function is not in use(start) xxx--- //
    public static function currency_converter_modefied($amount)
    {
        $currency_model = Helpers::get_business_settings('currency_model');
        if ($currency_model == 'multi_currency') {
            if (session()->has('usd')) {
                $usd = session('usd');
            } else {
                $usd = Currency::where(['code' => 'USD'])->first()->exchange_rate;
                session()->put('usd', $usd);
            }
            $my_currency = \session('currency_exchange_rate');
            $rate = $usd / $my_currency;
        } else {
            $rate = 1;
        }

        return Helpers::set_symbol(round($amount * $rate, 2));
    }
    // ---xxx May be this function is not in use(end) xxx--- //

    // ---- to convert the currency according to requested currecy from front start ----//
    public static function currency_converter_forfront($amount,$requestedcurrencyId)
    {
        $currency_model = Helpers::get_business_settings('currency_model');
        if ($currency_model == 'multi_currency') {
            $rate = \session('currency_exchange_rate');
        } else {
            $rate = 1;
        }
        if(empty($requestedcurrencyId))
        {
            $requestedcurrencyId = Helpers::get_business_settings('system_default_currency');
        }
        //return Helpers::set_symbol(round($amount * $rate, 2)); currency_formate
        if(session()->has('currency_formate'))
        {
            $formatevalue = session()->get('currency_formate');
        }
        else
        {
            $formatevalue = 2;
        }
        return Helpers::common_currency_formate(round($amount * $rate,$formatevalue ), $requestedcurrencyId);
    }

    // ---- to convert the currency according to requested currecy from front end ----//


    // --- replacement of set_symbol(), to formate the currency ---//
    public static function common_currency_formate($amount,$currencyID)
    {
        $position = Helpers::get_business_settings('currency_symbol_position');
        $selectedCurrencyInfo = Currency::where('id', $currencyID)->first();
        if (!is_null($position) && $position == 'left') {
            $string = currency_symbol() . ' ' . number_format($amount, $selectedCurrencyInfo->currency_formate);
        } else {
            $string = number_format($amount, $selectedCurrencyInfo->currency_formate) . ' ' . currency_symbol();
        }
        return $string;
    }


    // --this piece of code is used to show from DB to backend user like seller (like product price) --//
    public static function currency_converter_forbackend($amount,$no_format=null)
    {
        $currency_model = Helpers::get_business_settings('currency_model');
        if ($currency_model == 'multi_currency') 
        {
            if (session()->has('seller_currency_info')) {
                $selected_currency = ['id' => session()->get('seller_currency_info')->id];
            } else {
                $selected_currency = ['default_currency' => 1];
            }

            $selectedCurrency = Currency::where($selected_currency)->first();
            if(!empty($selectedCurrency))
            {
                $exchangeRete = $selectedCurrency->exchange_rate;
                $amount = $amount * $exchangeRete;
                if(empty($selectedCurrency->code))
                {
                    $currency_code = '';
                }
                else
                {
                    $currency_code = $selectedCurrency->code;
                }
                if(empty($selectedCurrency->currency_formate))
                {
                    $currency_formate = 2;
                }
                else
                {
                    $currency_formate = $selectedCurrency->currency_formate;
                }
                if(empty($no_format))
                {
                    $position = Helpers::get_business_settings('currency_symbol_position');
                    if (!is_null($position) && $position == 'left') {
                        $amount = $currency_code . ' ' . number_format(round($amount, $currency_formate),$currency_formate);
                    } else {
                        $amount = number_format(round($amount, $currency_formate),$currency_formate) . ' ' . $currency_code;
                    }
                }
                else
                {
                    $amount = round($amount, $currency_formate);
                }
            }

            return $amount;

        }
    }

    public static function language_load()
    {
        if (\session()->has('language_settings')) {
            $language = \session('language_settings');
        } else {
            $language = BusinessSetting::where('type', 'language')->first();
            \session()->put('language_settings', $language);
        }
        return $language;
    }

    public static function tax_calculation($price, $tax, $tax_type)
    {
        $amount = ($price / 100) * $tax;
        return $amount;
    }

    /* commented as the currency_converter() function replaced by another one
    public static function get_price_range($product)
    {
        $lowest_price = $product->unit_price;
        $highest_price = $product->unit_price;

        foreach (json_decode($product->variation) as $key => $variation) {
            if ($lowest_price > $variation->price) {
                $lowest_price = round($variation->price, 2);
            }
            if ($highest_price < $variation->price) {
                $highest_price = round($variation->price, 2);
            }
        }

        $lowest_price = Helpers::currency_converter($lowest_price - Helpers::get_product_discount($product, $lowest_price));
        $highest_price = Helpers::currency_converter($highest_price - Helpers::get_product_discount($product, $highest_price));
        
        if ($lowest_price == $highest_price) {
            return $lowest_price;
        }
        return $lowest_price . ' - ' . $highest_price;
    }*/

    public static function get_price_range($product)
    {
        $lowest_price = $product->unit_price;
        $highest_price = $product->unit_price;

        foreach (json_decode($product->variation) as $key => $variation) {
            if ($lowest_price > $variation->price) {
                $lowest_price = round($variation->price, 2);
            }
            if ($highest_price < $variation->price) {
                $highest_price = round($variation->price, 2);
            }
        }

        $lowest_price = Helpers::currency_converter_forfront($lowest_price - Helpers::get_product_discount($product, $lowest_price),session('requested_currency_id'));
        $highest_price = Helpers::currency_converter_forfront($highest_price - Helpers::get_product_discount($product, $highest_price),session('requested_currency_id'));
        
        if ($lowest_price == $highest_price) {
            return $lowest_price;
        }
        return $lowest_price . ' - ' . $highest_price;
    }

    // public static function get_product_discount($product, $price)
    // {
    //     $discount = 0;
    //     if ($product->discount_type == 'percent') {
    //         $discount = ($price * $product->discount) / 100;
    //     } elseif ($product->discount_type == 'flat') {
    //         $discount = $product->discount;
    //     }

    //     return floatval($discount);
    // }

    public static function color_name_to_hex($color_name)
    {
        // standard 147 HTML color names
        $colors  =  array(
            'aliceblue'=>'F0F8FF',
            'antiquewhite'=>'FAEBD7',
            'aqua'=>'00FFFF',
            'aquamarine'=>'7FFFD4',
            'azure'=>'F0FFFF',
            'beige'=>'F5F5DC',
            'bisque'=>'FFE4C4',
            'black'=>'000000',
            'blanchedalmond '=>'FFEBCD',
            'blue'=>'0000FF',
            'blueviolet'=>'8A2BE2',
            'brown'=>'A52A2A',
            'burlywood'=>'DEB887',
            'cadetblue'=>'5F9EA0',
            'chartreuse'=>'7FFF00',
            'chocolate'=>'D2691E',
            'coral'=>'FF7F50',
            'cornflowerblue'=>'6495ED',
            'cornsilk'=>'FFF8DC',
            'crimson'=>'DC143C',
            'cyan'=>'00FFFF',
            'darkblue'=>'00008B',
            'darkcyan'=>'008B8B',
            'darkgoldenrod'=>'B8860B',
            'darkgray'=>'A9A9A9',
            'darkgreen'=>'006400',
            'darkgrey'=>'A9A9A9',
            'darkkhaki'=>'BDB76B',
            'darkmagenta'=>'8B008B',
            'darkolivegreen'=>'556B2F',
            'darkorange'=>'FF8C00',
            'darkorchid'=>'9932CC',
            'darkred'=>'8B0000',
            'darksalmon'=>'E9967A',
            'darkseagreen'=>'8FBC8F',
            'darkslateblue'=>'483D8B',
            'darkslategray'=>'2F4F4F',
            'darkslategrey'=>'2F4F4F',
            'darkturquoise'=>'00CED1',
            'darkviolet'=>'9400D3',
            'deeppink'=>'FF1493',
            'deepskyblue'=>'00BFFF',
            'dimgray'=>'696969',
            'dimgrey'=>'696969',
            'dodgerblue'=>'1E90FF',
            'firebrick'=>'B22222',
            'floralwhite'=>'FFFAF0',
            'forestgreen'=>'228B22',
            'fuchsia'=>'FF00FF',
            'gainsboro'=>'DCDCDC',
            'ghostwhite'=>'F8F8FF',
            'gold'=>'FFD700',
            'goldenrod'=>'DAA520',
            'gray'=>'808080',
            'green'=>'008000',
            'greenyellow'=>'ADFF2F',
            'grey'=>'808080',
            'honeydew'=>'F0FFF0',
            'hotpink'=>'FF69B4',
            'indianred'=>'CD5C5C',
            'indigo'=>'4B0082',
            'ivory'=>'FFFFF0',
            'khaki'=>'F0E68C',
            'lavender'=>'E6E6FA',
            'lavenderblush'=>'FFF0F5',
            'lawngreen'=>'7CFC00',
            'lemonchiffon'=>'FFFACD',
            'lightblue'=>'ADD8E6',
            'lightcoral'=>'F08080',
            'lightcyan'=>'E0FFFF',
            'lightgoldenrodyellow'=>'FAFAD2',
            'lightgray'=>'D3D3D3',
            'lightgreen'=>'90EE90',
            'lightgrey'=>'D3D3D3',
            'lightpink'=>'FFB6C1',
            'lightsalmon'=>'FFA07A',
            'lightseagreen'=>'20B2AA',
            'lightskyblue'=>'87CEFA',
            'lightslategray'=>'778899',
            'lightslategrey'=>'778899',
            'lightsteelblue'=>'B0C4DE',
            'lightyellow'=>'FFFFE0',
            'lime'=>'00FF00',
            'limegreen'=>'32CD32',
            'linen'=>'FAF0E6',
            'magenta'=>'FF00FF',
            'maroon'=>'800000',
            'mediumaquamarine'=>'66CDAA',
            'mediumblue'=>'0000CD',
            'mediumorchid'=>'BA55D3',
            'mediumpurple'=>'9370D0',
            'mediumseagreen'=>'3CB371',
            'mediumslateblue'=>'7B68EE',
            'mediumspringgreen'=>'00FA9A',
            'mediumturquoise'=>'48D1CC',
            'mediumvioletred'=>'C71585',
            'midnightblue'=>'191970',
            'mintcream'=>'F5FFFA',
            'mistyrose'=>'FFE4E1',
            'moccasin'=>'FFE4B5',
            'navajowhite'=>'FFDEAD',
            'navy'=>'000080',
            'oldlace'=>'FDF5E6',
            'olive'=>'808000',
            'olivedrab'=>'6B8E23',
            'orange'=>'FFA500',
            'orangered'=>'FF4500',
            'orchid'=>'DA70D6',
            'palegoldenrod'=>'EEE8AA',
            'palegreen'=>'98FB98',
            'paleturquoise'=>'AFEEEE',
            'palevioletred'=>'DB7093',
            'papayawhip'=>'FFEFD5',
            'peachpuff'=>'FFDAB9',
            'peru'=>'CD853F',
            'pink'=>'FFC0CB',
            'plum'=>'DDA0DD',
            'powderblue'=>'B0E0E6',
            'purple'=>'800080',
            'red'=>'FF0000',
            'rosybrown'=>'BC8F8F',
            'royalblue'=>'4169E1',
            'saddlebrown'=>'8B4513',
            'salmon'=>'FA8072',
            'sandybrown'=>'F4A460',
            'seagreen'=>'2E8B57',
            'seashell'=>'FFF5EE',
            'sienna'=>'A0522D',
            'silver'=>'C0C0C0',
            'skyblue'=>'87CEEB',
            'slateblue'=>'6A5ACD',
            'slategray'=>'708090',
            'slategrey'=>'708090',
            'snow'=>'FFFAFA',
            'springgreen'=>'00FF7F',
            'steelblue'=>'4682B4',
            'tan'=>'D2B48C',
            'teal'=>'008080',
            'thistle'=>'D8BFD8',
            'tomato'=>'FF6347',
            'turquoise'=>'40E0D0',
            'violet'=>'EE82EE',
            'wheat'=>'F5DEB3',
            'white'=>'FFFFFF',
            'whitesmoke'=>'F5F5F5',
            'yellow'=>'FFFF00',
            'yellowgreen'=>'9ACD32');

        $color_name = str_replace(' ', '-', $color_name);
        $color_name = preg_replace('/[^A-Za-z0-9\-]/', '', $color_name);
        if (in_array($color_name,$colors))
        {
            return array_search($color_name, $colors);
        }
        else
        {
            return ($color_name);
        }
    }

    public static function variantDiscountStatus($varStaDate = null, $varEndDate = null)
    {
        $sDt = "";$eDt = "";$cDt = "";
        $cDt = strtotime(date('Y-m-d H:i:s'));

        if($varStaDate != "0000-00-00 00:00:00")
        {
            $sDt = strtotime($varStaDate);
        }
        if($varEndDate != "0000-00-00 00:00:00")
        {
            $eDt = strtotime($varEndDate);
        }
        
        if($sDt <= $cDt)
        {
            if(empty($eDt))
            {
                return true;
            }
            else
            {
                if($cDt <= $eDt)
                {
                    return true;
                }
            }
        }
        return false;
    }

    public static function discountD_checkAllStartDateLessthanCurrentDate($discounts = null)
    {
        $cDt = strtotime(date('Y-m-d H:i:s'));
        $startdate_lesscurrent = [];
        $discount_array = [];
        if(!empty($discounts))
        {
            foreach($discounts as $key => $discount)
            {
                $discount_array[$discount->id]=$discount->toArray();
                $sDt = strtotime(date($discount->startDuration));
                if($sDt <= $cDt)
                {
                    $startdate_lesscurrent[$discount->id] = $discount->startDuration;
                }
            }
        }
        return array('DiscountStartWithIdIndex' => $startdate_lesscurrent, 'processedDiscountArray' => $discount_array);
    }

    public static function getDiscountsWith_No_Enddate($discounts = null,$discountsarray)
    {
        $cDt = strtotime(date('Y-m-d H:i:s'));
        $startend_dat_dis = [];
        if(!empty($discounts))
        {
            foreach($discounts as $sIndex => $startDateDisId)
            {
                $eDt = strtotime(date($discountsarray[$sIndex]['endDuration']));
                if($cDt <= $eDt)
                {
                    $startend_dat_dis[$discountsarray[$sIndex]['id']] = strtotime(date($discountsarray[$sIndex]['startDuration']));
                }
            }
        }

        return  Helpers::idOfDiscount($startend_dat_dis);
    }

    public static function getDiscountsWithEnddate($discounts = null,$discountsarray)
    {
        $cDt = strtotime(date('Y-m-d H:i:s'));
        $start_dat_dis = [];
        if(!empty($discounts))
        { 
            foreach($discounts as $sIndex => $onlyStartdate)
            {
                if($discountsarray[$sIndex]['endDuration'] == '0000-00-00 00:00:00')
                {
                    $sDt = strtotime(date($discountsarray[$sIndex]['startDuration']));
                    if($sDt <= $cDt)
                    {
                        $start_dat_dis[$discountsarray[$sIndex]['id']] = strtotime(date($discountsarray[$sIndex]['startDuration']));
                    }
                }
            }
        }

        return Helpers::idOfDiscount($start_dat_dis);
    }

    public static function idOfDiscount($inputArray = null)
    {
        $discount = '';
        $topPriorityDisId = '';
        if(!empty($inputArray))
        {
            arsort($inputArray);
            $topPriorityDisId = array_key_first($inputArray);
        }
        return $topPriorityDisId;
    }

    public static function discountDetail($product_id,$variant_id =null)
    {
        $product = \App\Model\Product::active()->where('id', $product_id)->first();
        $discount = [];
        $discount_id = "";
        $discountIdWithEnddate = '';
        $discountIdWithNoEnddate = '';
        if($product->discount_flag)
        {
            if($product->variant_product)
            {
                // discount when variant
                $discount_array = \App\Model\ProductVariant::where(['id' => $variant_id,'isEnable' => 1])->first();
                if(!empty($discount_array))
                {
                    $discountStatus = Helpers::variantDiscountStatus($discount_array->startDuration, $discount_array->endDuration);

                    if($discountStatus)
                    {
                        $discount = $discount_array->toArray();
                    }
                }
            }
            else
            {
                // discount when no variant
                $discount_array = ProductDiscount::where(['product_id' => $product->id,'status' => 0])->get();
                $discounts = Helpers::discountD_checkAllStartDateLessthanCurrentDate($discount_array);
                $discountIdWithEnddate = Helpers::getDiscountsWithEnddate($discounts['DiscountStartWithIdIndex'],$discounts['processedDiscountArray']);
                $discountIdWithNoEnddate = Helpers::getDiscountsWith_No_Enddate($discounts['DiscountStartWithIdIndex'],$discounts['processedDiscountArray']);

                if(!empty($discountIdWithEnddate))
                {    
                    $discount_id = $discountIdWithEnddate;
                }
                else
                {
                    $discount_id = $discountIdWithNoEnddate;
                }

                $dis = \App\Model\ProductDiscount::where(['id' => $discount_id,'status' => 0])->first();
                $discount = $dis->toArray();

            }
        }

        return $discount;
    }
    // for single product multiple discount-- (singleDiscountForProduct) and (get_product_discount($product, $price=null)) are almost same, modify code to convert this two in a single initiy nad remove (new_get_product_discount_detail) as of no use but check before remove
    public static function singleDiscountForProduct($productid = null)
    {
        $discountStartDateArray = [];
        $product = \App\Model\Product::active()->with(['reviews','productDiscount'])->where('id', $productid)->first();
        $newdiscountStartDateArray = ProductDiscount::whereDate('startDuration', '<=', Carbon::now()->format('Y-m-d'))->where(['product_id' => $product->id,'status' => 0])->get()->toArray();
        foreach($newdiscountStartDateArray as $ind1 => $sDate)
        {
            if($sDate['endDuration'] == '0000-00-00 00:00:00')
            {
                array_push($discountStartDateArray,$sDate);
            }
        }

        $discountArray = ProductDiscount::where(['product_id' => $product->id,'status' => 0])->whereDate('startDuration', '<=', Carbon::now()->format('Y-m-d'))->whereDate('endDuration', '>=', Carbon::now()->format('Y-m-d'))->get()->toArray();

        $product = [];
        $getDateTimeAsInt=[];
        if(!empty($discountStartDateArray) || !empty($discountArray))
         {
            if(!empty($discountArray))
            {
                $processDateTimeAsInt = $discountArray;
                foreach ($processDateTimeAsInt as $key => $value) {
                    if( (strtotime($value['startDuration'])<=strtotime(date('Y-m-d H:i:s'))) && (strtotime($value['endDuration'])>=strtotime(date('Y-m-d H:i:s'))) )
                        $product = $value;
                }


                if(!empty($product))
                    $discountStartDateArray = array();
            }
            if(!empty($discountStartDateArray))
            {
                $processDateTimeAsInt = $discountStartDateArray;
                foreach ($processDateTimeAsInt as $key => $value) {
                    if(strtotime($value['startDuration']) <= strtotime(date('Y-m-d H:i:s')))
                    $getDateTimeAsInt[] = strtotime($value['startDuration']);
                }
                if(!empty($getDateTimeAsInt))
                {
                    $h = max($getDateTimeAsInt);
                    foreach ($discountStartDateArray as $key => $value) {
                        if(strtotime($value['startDuration']) == $h)
                        {
                            $product = $value;
                        }

                    }
                }
            }
         }
         else
         {
            $product = array();
         }


        $discount = 0;
        if(!empty($product))
        { 
             if ($product['type'] == 'percent') {
                $discount = ($price * $product['discount']) / 100;
            } elseif ($product['type'] == 'flat') {
                $discount = $product['discount'];
            }
        }
        $product['proDiscount'] = $discount;
        $discount = $product['proDiscount'];
        return floatval($discount);
    }
    // for single product multiple discount-- (singleDiscountForProduct) and (get_product_discount($product, $price=null)) are almost same, modify code to convert this two in a single initiy nad remove (new_get_product_discount_detail) as of no use but check before remove
    public static function get_product_discount($product, $price=null)
    {
        $discountStartDateArray = [];
        $newdiscountStartDateArray = ProductDiscount::whereDate('startDuration', '<=', Carbon::now()->format('Y-m-d'))->where(['product_id' => $product->id,'status' => 0])->get()->toArray();
        foreach($newdiscountStartDateArray as $ind1 => $sDate)
        {
            if($sDate['endDuration'] == '0000-00-00 00:00:00')
            {
                array_push($discountStartDateArray,$sDate);
            }
        }

        $discountArray = ProductDiscount::where(['product_id' => $product->id,'status' => 0])->whereDate('startDuration', '<=', Carbon::now()->format('Y-m-d'))->whereDate('endDuration', '>=', Carbon::now()->format('Y-m-d'))->get()->toArray();

        $product = [];
        $getDateTimeAsInt=[];
        if(!empty($discountStartDateArray) || !empty($discountArray))
         {
            if(!empty($discountArray))
            {
                $processDateTimeAsInt = $discountArray;
                foreach ($processDateTimeAsInt as $key => $value) {
                    if( (strtotime($value['start_date'])<=strtotime(date('Y-m-d H:i:s'))) && (strtotime($value['end_date'])>=strtotime(date('Y-m-d H:i:s'))) )
                        $product = $value;
                }


                if(!empty($product))
                    $discountStartDateArray = array();
            }
            if(!empty($discountStartDateArray))
            {
                $processDateTimeAsInt = $discountStartDateArray;
                foreach ($processDateTimeAsInt as $key => $value) {
                    if(strtotime($value['start_date']) <= strtotime(date('Y-m-d H:i:s')))
                    $getDateTimeAsInt[] = strtotime($value['start_date']);
                }
                if(!empty($getDateTimeAsInt))
                {
                    $h = max($getDateTimeAsInt);
                    foreach ($discountStartDateArray as $key => $value) {
                        if(strtotime($value['start_date']) == $h)
                        {
                            $product = $value;
                        }

                    }
                }
            }
         }
         else
         {
            $product = array();
         }


        $discount = 0;
        if(!empty($product))
        { 
             if ($product['type'] == 'percent') {
                $discount = ($price * $product['discount']) / 100;
            } elseif ($product['type'] == 'flat') {
                $discount = $product['discount'];
            }
        }
        $product['proDiscount'] = $discount;
        $discount = $product['proDiscount'];
        return floatval($discount);
    }
    // for single product multiple discount-- (singleDiscountForProduct) and (get_product_discount($product, $price=null)) are almost same, modify code to convert this two in a single initiy nad remove (new_get_product_discount_detail) as of no use but check before remove
    public static function new_get_product_discount_detail($product, $price)
    {
        $discountStartDateArray = ProductDiscount::WhereNull('end_date')->whereDate('start_date', '<=', Carbon::now()->format('Y-m-d'))->where(['product_id' => $product->id,'status' => 0])->get()->toArray();

        $discountArray = ProductDiscount::where(['product_id' => $product->id,'status' => 0])->whereDate('start_date', '<=', Carbon::now()->format('Y-m-d'))->whereDate('end_date', '>=', Carbon::now()->format('Y-m-d'))->get()->toArray();

        $product = [];
        $getDateTimeAsInt=[];
        if(!empty($discountStartDateArray) || !empty($discountArray))
         {
            if(!empty($discountArray))
            {
                $processDateTimeAsInt = $discountArray;
                foreach ($processDateTimeAsInt as $key => $value) {
                    if( (strtotime($value['start_date'])<=strtotime(date('Y-m-d H:i:s'))) && (strtotime($value['end_date'])>=strtotime(date('Y-m-d H:i:s'))) )
                        $product = $value;
                }


                if(!empty($product))
                    $discountStartDateArray = array();
            }
            if(!empty($discountStartDateArray))
            {
                $processDateTimeAsInt = $discountStartDateArray;
                foreach ($processDateTimeAsInt as $key => $value) {
                    if(strtotime($value['start_date']) <= strtotime(date('Y-m-d H:i:s')))
                    $getDateTimeAsInt[] = strtotime($value['start_date']);
                }
                if(!empty($getDateTimeAsInt))
                {
                    $h = max($getDateTimeAsInt);
                    foreach ($discountStartDateArray as $key => $value) {
                        if(strtotime($value['start_date']) == $h)
                        {
                            $product = $value;
                        }

                    }
                }
            }
         }
         else
         {
            $product = array();
         }

        $discount = 0;
        if(!empty($product))
        { 
             if ($product['type'] == 'percent') {
                $discount = ($price * $product['discount']) / 100;
            } elseif ($product['type'] == 'flat') {
                $discount = $product['discount'];
            }
            $product['proDiscount'] = $discount;
        }
        
        return $product;
    }

    public static function module_permission_check($mod_name)
    {
        $permission = auth('admin')->user()->role->module_access;
        if (isset($permission) && in_array($mod_name, (array)json_decode($permission)) == true) {
            return true;
        }

        if (auth('admin')->user()->admin_role_id == 1) {
            return true;
        }
        return false;
    }

    public static function convert_currency_to_usd($price)
    {
        $currency_model = Helpers::get_business_settings('currency_model');
        if ($currency_model == 'multi_currency') {
            Helpers::currency_load();
            $code = session('currency_code') == null ? 'USD' : session('currency_code');
            $currency = Currency::where('code', $code)->first();
            $price = floatval($price) / floatval($currency->exchange_rate);
        } else {
            $price = floatval($price);
        }

        return $price;
    }

    public static function order_status_update_message($status)
    {
        if ($status == 'pending') {
            $data = BusinessSetting::where('type', 'order_pending_message')->first()->value;
        } elseif ($status == 'confirmed') {
            $data = BusinessSetting::where('type', 'order_confirmation_msg')->first()->value;
        } elseif ($status == 'processing') {
            $data = BusinessSetting::where('type', 'order_processing_message')->first()->value;
        } elseif ($status == 'out_for_delivery') {
            $data = BusinessSetting::where('type', 'out_for_delivery_message')->first()->value;
        } elseif ($status == 'delivered') {
            $data = BusinessSetting::where('type', 'order_delivered_message')->first()->value;
        } elseif ($status == 'returned') {
            $data = BusinessSetting::where('type', 'order_returned_message')->first()->value;
        } elseif ($status == 'failed') {
            $data = BusinessSetting::where('type', 'order_failed_message')->first()->value;
        } elseif ($status == 'delivery_boy_delivered') {
            $data = BusinessSetting::where('type', 'delivery_boy_delivered_message')->first()->value;
        } elseif ($status == 'del_assign') {
            $data = BusinessSetting::where('type', 'delivery_boy_assign_message')->first()->value;
        } elseif ($status == 'ord_start') {
            $data = BusinessSetting::where('type', 'delivery_boy_start_message')->first()->value;
        } else {
            $data = '{"status":"0","message":""}';
        }

        $res = json_decode($data, true);

        if ($res['status'] == 0) {
            return 0;
        }
        return $res['message'];
    }

    public static function send_push_notif_to_device($fcm_token, $data)
    {
        $key = BusinessSetting::where(['type' => 'push_notification_key'])->first()->value;
        $url = "https://fcm.googleapis.com/fcm/send";
        $header = array("authorization: key=" . $key . "",
            "content-type: application/json"
        );

        if (isset($data['order_id']) == false) {
            $data['order_id'] = null;
        }

        $postdata = '{
            "to" : "' . $fcm_token . '",
            "data" : {
                "title" :"' . $data['title'] . '",
                "body" : "' . $data['description'] . '",
                "image" : "' . $data['image'] . '",
                "order_id":"' . $data['order_id'] . '",
                "is_read": 0
              },
              "notification" : {
                "title" :"' . $data['title'] . '",
                "body" : "' . $data['description'] . '",
                "image" : "' . $data['image'] . '",
                "order_id":"' . $data['order_id'] . '",
                "title_loc_key":"' . $data['order_id'] . '",
                "is_read": 0,
                "icon" : "new",
                "sound" : "default"
              }
        }';

        $ch = curl_init();
        $timeout = 120;
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);

        // Get URL content
        $result = curl_exec($ch);
        // close handle to release resources
        curl_close($ch);

        return $result;
    }

    public static function send_push_notif_to_topic($data)
    {
        $key = BusinessSetting::where(['type' => 'push_notification_key'])->first()->value;

        $url = "https://fcm.googleapis.com/fcm/send";
        $header = ["authorization: key=" . $key . "",
            "content-type: application/json",
        ];

        $image = asset('storage/app/public/notification') . '/' . $data['image'];
        $postdata = '{
            "to" : "/topics/sixvalley",
            "data" : {
                "title":"' . $data->title . '",
                "body" : "' . $data->description . '",
                "image" : "' . $image . '",
                "is_read": 0
              },
              "notification" : {
                "title":"' . $data->title . '",
                "body" : "' . $data->description . '",
                "image" : "' . $image . '",
                "title_loc_key":"' . $data['order_id'] . '",
                "is_read": 0,
                "icon" : "new",
                "sound" : "default"
              }
        }';

        $ch = curl_init();
        $timeout = 120;
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);

        // Get URL content
        $result = curl_exec($ch);
        // close handle to release resources
        curl_close($ch);

        return $result;
    }

    public static function get_seller_by_token($request)
    {
        $data = '';
        $success = 0;

        $token = explode(' ', $request->header('authorization'));
        if (count($token) > 1 && strlen($token[1]) > 30) {
            $seller = Seller::where(['auth_token' => $token['1']])->first();
            if (isset($seller)) {
                $data = $seller;
                $success = 1;
            }
        }

        return [
            'success' => $success,
            'data' => $data
        ];
    }

    public static function remove_dir($dir)
    {
        if (is_dir($dir)) {
            $objects = scandir($dir);
            foreach ($objects as $object) {
                if ($object != "." && $object != "..") {
                    if (filetype($dir . "/" . $object) == "dir") Helpers::remove_dir($dir . "/" . $object); else unlink($dir . "/" . $object);
                }
            }
            reset($objects);
            rmdir($dir);
        }
    }

    public static function currency_code()
    {
        Helpers::currency_load();
        if (session()->has('currency_symbol')) {
            $symbol = session('currency_symbol');
            $code = Currency::where(['symbol' => $symbol])->first()->code;
        } else {
            $system_default_currency_info = session('system_default_currency_info');
            $code = $system_default_currency_info->code;
        }
        return $code;
    }

    public static function get_language_name($key)
    {
        $values = Helpers::get_business_settings('language');
        foreach ($values as $value) {
            if ($value['code'] == $key) {
                $key = $value['name'];
            }
        }

        return $key;
    }

    public static function setEnvironmentValue($envKey, $envValue)
    {
        $envFile = app()->environmentFilePath();
        $str = file_get_contents($envFile);
        $oldValue = env($envKey);
        if (strpos($str, $envKey) !== false) {
            $str = str_replace("{$envKey}={$oldValue}", "{$envKey}={$envValue}", $str);
        } else {
            $str .= "{$envKey}={$envValue}\n";
        }
        $fp = fopen($envFile, 'w');
        fwrite($fp, $str);
        fclose($fp);
        return $envValue;
    }

    public static function requestSender()
    {
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt_array($curl, array(
            CURLOPT_URL => route(base64_decode('YWN0aXZhdGlvbi1jaGVjaw==')),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
        ));
        $response = curl_exec($curl);
        $data = json_decode($response, true);
        return $data;
    }

    public static function sales_commission($order)
    {
        $order_summery = OrderManager::order_summary($order);
        $order_total = $order_summery['subtotal'] - $order_summery['total_discount_on_product'] - $order['discount_amount'];
        $commission_amount = 0;

        if ($order['seller_is'] == 'seller') {
            $seller = Seller::find($order['seller_id']);
            if (isset($seller) && $seller['sales_commission_percentage'] !== null) {
                $commission = $seller['sales_commission_percentage'];
            } else {
                $commission = Helpers::get_business_settings('sales_commission');
            }
            $commission_amount = (($order_total / 100) * $commission);
        }
        return $commission_amount;
    }

    public static function categoryName($id)
    {
        return Category::select('name')->find($id)->name;
    }

    public static function set_symbol($amount)
    {
        $position = Helpers::get_business_settings('currency_symbol_position');
        if (!is_null($position) && $position == 'left') {
            $string = currency_symbol() . '' . number_format($amount, 2);
        } else {
            $string = number_format($amount, 2) . '' . currency_symbol();
        }
        return $string;
    }

    public static function pagination_limit()
    {
        $pagination_limit = BusinessSetting::where('type', 'pagination_limit')->first();
        if ($pagination_limit != null) {
            return $pagination_limit->value;
        } else {
            return 25;
        }

    }

    public static function gen_mpdf($view, $file_prefix, $file_postfix)
    {
        $mpdf = new \Mpdf\Mpdf(['default_font' => 'FreeSerif', 'mode' => 'utf-8', 'format' => [190, 250]]);
       /* $mpdf->AddPage('XL', '', '', '', '', 10, 10, 10, '10', '270', '');*/
        $mpdf->autoScriptToLang = true;
        $mpdf->autoLangToFont = true;

        $mpdf_view = $view;
        $mpdf_view = $mpdf_view->render();
        $mpdf->WriteHTML($mpdf_view);
        $mpdf->Output($file_prefix . $file_postfix . '.pdf', 'D');
    }
}


if (!function_exists('currency_symbol')) {
    function currency_symbol()
    {
        Helpers::currency_load();
        if (\session()->has('currency_symbol')) {
            $symbol = \session('currency_symbol');
        } else {
            $system_default_currency_info = \session('system_default_currency_info');
            $symbol = $system_default_currency_info->symbol;
        }
        return $symbol;
    }
}
//formats currency
if (!function_exists('format_price')) {
    function format_price($price)
    {
        return number_format($price, 2) . currency_symbol();
    }
}

function translate($key)
{
    $local = Helpers::default_lang();
    App::setLocale($local);

    $lang_array = include(base_path('resources/lang/' . $local . '/messages.php'));
    $processed_key = ucfirst(str_replace('_', ' ', Helpers::remove_invalid_charcaters($key)));

    if (!array_key_exists($key, $lang_array)) {
        $lang_array[$key] = $processed_key;
        $str = "<?php return " . var_export($lang_array, true) . ";";
        file_put_contents(base_path('resources/lang/' . $local . '/messages.php'), $str);
        $result = $processed_key;
    } else {
        $result = __('messages.' . $key);
    }
    return $result;
}
