@extends('layouts.back-end.app')

@section('title', $seller->shop? $seller->shop->name : \App\CPU\translate("Shop Name"))

@push('css_or_js')
<style type="text/css">
.widthmax{
    width: 150%;
}
</style>
@endpush

@section('content')
<div class="content container-fluid">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{route('admin.dashboard.index')}}">{{\App\CPU\translate('Dashboard')}}</a>
                </li>
                <li class="breadcrumb-item" aria-current="page">{{\App\CPU\translate('Seller_Details')}}</li>
            </ol>
        </nav>

        <!-- Page Heading -->
        <div class="flex-between d-sm-flex row align-items-center justify-content-between mb-2 mx-1">
            <div>
                <a href="{{route('admin.sellers.seller-list')}}" class="btn btn-primary mt-3 mb-3">{{\App\CPU\translate('Back_to_seller_list')}}</a>
            </div>
            <div>
                    <div class="mt-4 pr-2 float-{{Session::get('direction') === "rtl" ? 'left' : 'right'}}">
                        <div class="flex-start">
                            <h4 class="mx-1"><i class="tio-shop-outlined"></i></h4>
                            <div><h4>{{\App\CPU\translate('Seller_request_for_open_a_shop.')}}</h4></div>
                        </div>
                        <div class="text-center">
                            @if($seller->new_seller_status=="approved" || $seller->new_seller_status=="active")
                                <!-- @if(!empty($seller->paidSeller))
                                    @if($seller->paidSeller->result!='success')
                                    <form class="d-inline-block" action="{{route('admin.sellers.updateStatus')}}" method="POST">
                                        @csrf
                                        <input type="hidden" name="id" value="{{$seller->id}}">
                                        <input type="hidden" name="status" value="approved">
                                        <button type="submit" class="btn btn-primary 123">{{\App\CPU\translate('Approve And Pay Again')}}</button>
                                    </form>
                                    @endif
                                @endif -->
                            @else
                                <form class="d-inline-block" action="{{route('admin.sellers.updateStatus')}}" method="POST">
                                    @csrf
                                    <input type="hidden" name="id" value="{{$seller->id}}">
                                    <input type="hidden" name="status" value="approved">
                                    <button type="submit" class="btn btn-primary 123">{{\App\CPU\translate('Allow the seller to pay')}}</button>
                                </form>
                            @endif
                            @if($seller->new_seller_status!="suspended")
                            <form class="d-inline-block" action="{{route('admin.sellers.updateStatus')}}" method="POST">
                                @csrf
                                <input type="hidden" name="id" value="{{$seller->id}}">
                                <input type="hidden" name="status" value="suspended">
                                <button type="submit" class="btn btn-danger">{{\App\CPU\translate('reject')}}</button>
                            </form>
                            @endif
                            @if($seller->new_seller_status!="hold")
                            <form class="d-inline-block" action="{{route('admin.sellers.updateStatus')}}" method="POST">
                                @csrf
                                <input type="hidden" name="id" value="{{$seller->id}}">
                                <input type="hidden" name="status" value="hold">
                                <button type="submit" class="btn btn-warning">{{\App\CPU\translate('hold')}}</button>
                            </form>
                            @endif
                        </div>
                        <!-- D Fr plantabInvoice -->
                        <div class="text-center mt-3">
                            @if(!empty($seller->paidSeller))
                                @if($seller->paidSeller->result=='success')
                                <button style="border-radius: 30px 20px;" type="button" class="btn btn-outline-success"><b>{{\App\CPU\translate('PAID')}}</b></button>
                                @else
                                <button style="border-radius: 30px 20px;" type="button" class="btn btn-outline-danger"><b>{{\App\CPU\translate('UNPAID')}}</b></button>
                                @endif
                            @else
                                <button style="border-radius: 30px 20px;" type="button" class="btn btn-outline-danger"><b>{{\App\CPU\translate('UNPAID')}}</b></button>
                            @endif
                        </div>
                    </div>
            </div>
        </div>
        <!-- Page Header -->
    @if($seller->new_seller_status=="approved")
    <div class="flex-between d-sm-flex row align-items-center justify-content-between mb-2 mx-1">
        <div>
            Seller is Approved with this Link :- <span class="text-warning">{{route('seller.auth.payment',['id' => $seller->id])}}</span>
        </div>
    </div>
    @endif
    <div class="page-header">
        <div class="flex-between row mx-1">
            <div>
                <h1 class="page-header-title">{{ $seller->shop? $seller->shop->name : "Shop Name : Update Please" }}</h1>
            </div>
        </div>
        <!-- Nav Scroller -->
        <div class="js-nav-scroller hs-nav-scroller-horizontal">
            <!-- Nav -->
            @if($seller->new_seller_status=="approved" || $seller->new_seller_status=="active")
            <ul class="nav nav-tabs page-header-tabs">
                <li class="nav-item">
                        <a class="nav-link active" href="{{ route('admin.sellers.view',$seller->id) }}">{{\App\CPU\translate('Shop')}}</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link"
                           href="{{ route('admin.sellers.view',['id'=>$seller->id, 'tab'=>'order']) }}">{{\App\CPU\translate('Order')}}</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link"
                           href="{{ route('admin.sellers.view',['id'=>$seller->id, 'tab'=>'product']) }}">{{\App\CPU\translate('Product')}}</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link"
                           href="{{ route('admin.sellers.view',['id'=>$seller->id, 'tab'=>'setting']) }}">{{\App\CPU\translate('Setting')}}</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link"
                           href="{{ route('admin.sellers.view',['id'=>$seller->id, 'tab'=>'transaction']) }}">{{\App\CPU\translate('Transaction')}}</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link"
                           href="{{ route('admin.sellers.view',['id'=>$seller->id, 'tab'=>'review']) }}">{{\App\CPU\translate('Review')}}</a>
                    </li>

            </ul>
            @endif
            <!-- End Nav -->
        </div>
        <!-- End Nav Scroller -->
    </div>
        <!-- End Page Header -->
        <div class="card mb-3">
            <div class="card-body">
                <div class=" gx-2 gx-lg-3 mb-2">
                    <div>
                        <h4><i style="font-size: 30px"
                               class="tio-wallet"></i>{{\App\CPU\translate('seller_wallet')}}</h4>
                    </div>
                    <div class="row gx-2 gx-lg-3" id="order_stats">
                        <div class="flex-between" style="width: 100%">
                            <div class="mb-3 mb-lg-0" style="width: 18%">
                                <div class="card card-body card-hover-shadow h-100 text-white text-center" style="background-color: #22577A;">
                                    <h1 class="p-2 text-white">{{ $seller->wallet ? \App\CPU\BackEndHelper::set_symbol(\App\CPU\BackEndHelper::usd_to_currency($seller->wallet->commission_given)) : 0}}</h1>
                                    <div class="text-uppercase">{{\App\CPU\translate('commission_given')}}</div>
                                </div>
                            </div>

                            <div class="mb-3 mb-lg-0" style="width: 18%">
                                <div class="card card-body card-hover-shadow h-100 text-white text-center" style="background-color: #595260;">
                                    <h1 class="p-2 text-white">{{ $seller->wallet ? \App\CPU\BackEndHelper::set_symbol(\App\CPU\BackEndHelper::usd_to_currency($seller->wallet->pending_withdraw)) : 0}}</h1>
                                    <div class="text-uppercase">{{\App\CPU\translate('pending_withdraw')}}</div>
                                </div>
                            </div>

                            <div class="mb-3 mb-lg-0" style="width: 18%">
                                <div class="card card-body card-hover-shadow h-100 text-white text-center" style="background-color: #a66f2e;">
                                    <h1 class="p-2 text-white">{{ $seller->wallet ? \App\CPU\BackEndHelper::set_symbol(\App\CPU\BackEndHelper::usd_to_currency($seller->wallet->delivery_charge_earned)) : 0}}</h1>
                                    <div class="text-uppercase">{{\App\CPU\translate('delivery_charge_earned')}}</div>
                                </div>
                            </div>

                            <div class="mb-3 mb-lg-0" style="width: 18%">
                                <div class="card card-body card-hover-shadow h-100 text-white text-center" style="background-color: #6E85B2;">
                                    <h1 class="p-2 text-white">{{ $seller->wallet ? \App\CPU\BackEndHelper::set_symbol(\App\CPU\BackEndHelper::usd_to_currency($seller->wallet->collected_cash)) : 0}}</h1>
                                    <div class="text-uppercase">{{\App\CPU\translate('collected_cash')}}</div>
                                </div>
                            </div>

                            <div class="mb-3 mb-lg-0" style="width: 18%">
                                <div class="card card-body card-hover-shadow h-100 text-white text-center" style="background-color: #6D9886;">
                                    <h1 class="p-2 text-white">{{ $seller->wallet ? \App\CPU\BackEndHelper::set_symbol(\App\CPU\BackEndHelper::usd_to_currency($seller->wallet->total_tax_collected)) : 0}}</h1>
                                    <div class="text-uppercase">{{\App\CPU\translate('total_collected_tax')}}</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                    <!-- Earnings (Monthly) Card Example -->
                    <div class="col-xl-6 for-card col-md-6 mt-4">
                        <div class="card for-card-body-2 shadow h-100  badge-primary"
                             style="background: #362222!important;">
                            <div class="card-body text-light">
                                <div class="flex-between row no-gutters align-items-center">
                                    <div>
                                        <div class="font-weight-bold text-uppercase for-card-text mb-1">
                                            {{\App\CPU\translate('Withdrawable_balance')}}
                                        </div>
                                        <div
                                            class="for-card-count">{{ $seller->wallet ? \App\CPU\BackEndHelper::set_symbol(\App\CPU\BackEndHelper::usd_to_currency($seller->wallet->total_earning)) : 0 }}</div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Earnings (Monthly) Card Example -->
                    <div class="col-xl-6 for-card col-md-6 mt-4" style="cursor: pointer">
                        <div class="card  shadow h-100 for-card-body-3 badge-info"
                             style="background: #171010!important;">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div
                                            class=" font-weight-bold for-card-text text-uppercase mb-1">{{\App\CPU\translate('withdrawn')}}</div>
                                        <div
                                            class="for-card-count">{{$seller->wallet ? \App\CPU\BackEndHelper::set_symbol(\App\CPU\BackEndHelper::usd_to_currency($seller->wallet->withdrawn)) : 0}}</div>
                                    </div>
                                    <div class="col-auto for-margin">
                                        <i class="tio-money-vs"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                </div>

            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header text-capitalize">
                        {{\App\CPU\translate('Seller')}} {{\App\CPU\translate('Account')}} <br>
                        @if($seller->new_seller_status=='approved')
                            <form class="d-inline-block" action="{{route('admin.sellers.updateStatus')}}" method="POST">
                                @csrf
                                <input type="hidden" name="id" value="{{$seller->id}}">
                                <input type="hidden" name="status" value="suspended">
                                <button type="submit"
                                        class="btn btn-outline-danger">{{\App\CPU\translate('suspend')}}</button>
                            </form>
                        @elseif($seller->new_seller_status=='rejected' || $seller->new_seller_status=='suspended')
                            <form class="d-inline-block" action="{{route('admin.sellers.updateStatus')}}" method="POST">
                                @csrf
                                <input type="hidden" name="id" value="{{$seller->id}}">
                                <input type="hidden" name="status" value="approved">
                                <button type="submit"
                                        class="btn btn-outline-success">{{\App\CPU\translate('activate')}}</button>
                            </form>
                        @endif
                    </div>
                    <div class="card-body">
                        <div class="card-body" style="text-align: {{Session::get('direction') === "rtl" ? 'right' : 'left'}};">
                            <div class="flex-start">
                                <div><h4>Status : </h4></div>
                                <div class="mx-1"><h4>
                                            @if($seller->new_seller_status=='pending')
                                            <label class="badge badge-warning">Pending</label>
                                            @elseif($seller->new_seller_status=='approved')
                                            <label class="badge badge-success">Approved</label>
                                            @elseif($seller->new_seller_status=='paid')
                                            <label class="badge badge-info">Paid</label>
                                            @elseif($seller->new_seller_status=='hold')
                                            <label class="badge badge-warning">Hold</label>
                                            @elseif($seller->new_seller_status=='suspended')
                                            <label class="badge badge-danger">Canceled</label>
                                            @elseif($seller->new_seller_status=='active')
                                            <label class="badge badge-success">Active</label>
                                            @endif</h4></div>
                            </div>
                            <div class="flex-start">
                                <div><h5>{{\App\CPU\translate('name')}} : </h5></div>
                                <div class="mx-1"><h5>{{$seller->f_name}} {{$seller->l_name}}</h5></div>
                            </div>
                            <div class="flex-start">
                                <div><h5>{{\App\CPU\translate('Email')}} : </h5></div>
                                <div class="mx-1"><h5>{{$seller->email}}</h5></div>
                            </div>
                            <div class="flex-start">
                                <div><h5>{{\App\CPU\translate('Phone')}} : </h5></div>
                                <div class="mx-1"><h5>{{$seller->phone}}</h5></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            @if($seller->shop)
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            {{\App\CPU\translate('Shop')}} {{\App\CPU\translate('info')}}
                        </div>
                        <div class="card-body" style="text-align: {{Session::get('direction') === "rtl" ? 'right' : 'left'}};">
                            <div class="flex-start">
                                <div><h5>{{\App\CPU\translate('Shop')}} {{\App\CPU\translate('Name')}}: </h5></div>
                                <div class="mx-1"><h5>{{$seller->shop->name}}</h5></div>
                            </div>
                            <div class="flex-start">
                                <div><h5>{{\App\CPU\translate('Shop')}} {{\App\CPU\translate('Type')}}: </h5></div>
                                <div class="mx-1">
                                    <h5>
                                        @php
                                        if(!empty($seller->shop->shop_type))
                                        {
                                            $shopType = \App\Model\CompanyType::find($seller->shop->shop_type);
                                            echo $shopType->company_type;
                                        }
                                        else
                                        {
                                            echo "N/A";
                                        }
                                        @endphp
                                    </h5>
                                </div>
                            </div>
                            <div class="flex-start">
                                <div><h5>{{\App\CPU\translate('Reg')}} {{\App\CPU\translate('No')}}. : </h5></div>
                                <div class="mx-1"><h5>{{$seller->shop->reg_or_cr_number}}</h5></div>
                            </div>
                            <div class="flex-start">
                                <div><h5>{{\App\CPU\translate('mobile_number')}} : </h5></div>
                                <div class="mx-1"><h5>{{$seller->shop->contact}}</h5></div>
                            </div>
                            <div class="flex-start">
                                <div><h5>{{\App\CPU\translate('whatapp_number')}} : </h5></div>
                                <div class="mx-1"><h5>{{$seller->shop->whatapp_number}}</h5></div>
                            </div>
                            <div class="flex-start">
                                <div><h5>{{\App\CPU\translate('telephone_number')}} : </h5></div>
                                <div class="mx-1"><h5>{{$seller->shop->telephone_number}}</h5></div>
                            </div>
                            <div class="flex-start">
                                <div><h5>{{\App\CPU\translate('shop_email')}} : </h5></div>
                                <div class="mx-1"><h5>{{$seller->shop->shop_email}}</h5></div>
                            </div>
                            <div class="flex-start">
                                <div><h5>{{\App\CPU\translate('Vat')}} {{\App\CPU\translate('Number')}}: </h5></div>
                                <div class="mx-1"><h5>{{($seller->shop->vat_no)?$seller->shop->vat_no:'N/A'}}</h5></div>
                            </div>
                            <div class="flex-start">
                                <div><h5>{{\App\CPU\translate('address')}} : </h5></div>
                                <div class="mx-1">
                                    <h5>
                                        @if(!empty($seller->shop->address) || !empty($seller->shop->address2) ||  !empty($seller->shop->address3) ||  !empty($seller->shop->address4) ||  !empty($seller->shop->address5) )
                                        {{$seller->shop->address}} {{($seller->shop->address2)?$seller->shop->address2:NULL}} {{($seller->shop->address3)?$seller->shop->address3:NULL}} {{($seller->shop->address4)?$seller->shop->address4:NULL}} {{($seller->shop->address5)?$seller->shop->address5:NULL}}
                                        @else
                                        "N/A"
                                        @endif
                                    </h5>
                                </div>
                            </div>
                            <div class="flex-start">
                                <div><h5>{{\App\CPU\translate('country')}} : </h5></div>
                                <div class="mx-1">
                                    <h5>
                                        {{($seller->shop->country)?\App\Model\CountryCode::find($seller->shop->country,'name')->name:'N/A'}}
                                    </h5>
                                </div>
                            </div>

                            <div class="flex-start">
                                <div><h5>{{\App\CPU\translate('seller_transaction_currency')}} : </h5></div>
                                <div class="mx-1">
                                    <h5>
                                        {{$seller->SellerCurrency->name}}
                                    </h5>
                                </div>
                            </div>
                            <div class="flex-start">
                                <div><h5>{{\App\CPU\translate('currency_symbol')}} : </h5></div>
                                <div class="mx-1">
                                    <h5>
                                        {{$seller->SellerCurrency->symbol}}
                                    </h5>
                                </div>
                            </div>
                            <div class="flex-start">
                                <div><h5>{{\App\CPU\translate('currency_code')}} : </h5></div>
                                <div class="mx-1">
                                    <h5>
                                        {{$seller->SellerCurrency->code}}
                                    </h5>
                                </div>
                            </div>
                            @if($seller->new_seller_status=="approved" || $seller->new_seller_status=="active")
                            <br>
                            <div class="flex-start">
                                @php $seurl = $seller->id.'/setting'; @endphp
                                <div><a class="btn-primary btn-sm" href="{{$seurl}}">{{\App\CPU\translate('update_currency')}}</a></div>
                            </div>
                            @endif
                        </div>
                    </div>
                </div>
            @endif

            <div class="col-md-6 mt-3">
                <div class="card">
                    <div class="card-header">
                        {{\App\CPU\translate('bank_info')}}
                    </div>
                    <div class="card-body" style="text-align: {{Session::get('direction') === "rtl" ? 'right' : 'left'}};">
                        <div class="col-md-8 mt-2">
                            <div class="flex-start">
                                <div><h4>{{\App\CPU\translate('bank_name')}} : </h4></div>
                                <div class="mx-1"><h4>{{$seller->shop->bank_name ? $seller->shop->bank_name : 'No Data found'}}</h4></div>
                            </div>
                            <div class="flex-start">
                                <div><h4>{{\App\CPU\translate('ac_holder_name')}} : </h4></div>
                                <div class="mx-1"><h4>{{$seller->shop->ac_holder_name ? $seller->shop->ac_holder_name : 'No Data found'}}</h4></div>
                            </div>
                            <div class="flex-start">
                                <div><h4>{{\App\CPU\translate('ac_number')}} : </h4></div>
                                <div class="mx-1"><h4>{{$seller->shop->ac_number ? $seller->shop->ac_number : 'No Data found'}}</h4></div>
                            </div>
                            <div class="flex-start">
                                <div><h4>{{\App\CPU\translate('swift_number')}} : </h4></div>
                                <div class="mx-1"><h4>{{$seller->shop->swift_number ? $seller->shop->swift_number : 'No Data found'}}</h4></div>
                            </div>

                            <div class="flex-start">
                                <div><h4>{{\App\CPU\translate('iban_number')}} : </h4></div>
                                <div class="mx-1"><h4>{{$seller->shop->iban_number ? $seller->shop->iban_number : 'No Data found'}}</h4></div>
                            </div>

                            <div class="flex-start">
                                <div><h4>{{\App\CPU\translate('bank_address')}} : </h4></div>
                                <div class="mx-1"><h4>{{$seller->shop->bank_address ? $seller->shop->bank_address : 'No Data found'}}</h4></div>
                            </div>

                            <div class="flex-start">
                                <div><h4>{{\App\CPU\translate('branch')}} : </h4></div>
                                <div class="mx-1"><h4>{{$seller->shop->branch ? $seller->shop->branch : 'No Data found'}}</h4></div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-6 mt-3">
                <div class="card">
                    <div class="card-header">
                        {{\App\CPU\translate('Requested_plan_info')}}
                    </div>
                    <div class="card-body" style="text-align: {{Session::get('direction') === "rtl" ? 'right' : 'left'}};">
                        <div class="col-md-8 mt-2">
                            <div class="flex-start widthmax">
                                <div><h4>{{\App\CPU\translate('plan_name')}} : </h4></div>
                                <div class="mx-1"><h4>{{(!empty($seller->registerSellerPlan->title)) ? $seller->registerSellerPlan->title : 'No Data found'}}</h4></div>
                            </div>
                            <div class="flex-start widthmax">
                                <div><h4>{{\App\CPU\translate('plan_duration')}} : </h4></div>
                                <div class="mx-1"><h4>{{(!empty($seller->registerSellerPlan->duration) && !empty($seller->registerSellerPlan->duration_type) ) ? \App\CPU\BackEndHelper::set_plan_duration($seller->registerSellerPlan->duration,$seller->registerSellerPlan->duration_type) : 'No Data found'}}</h4></div>
                            </div>


                            <div class="flex-start widthmax">
                                <div><h4>{{\App\CPU\translate('plan_price')}} : </h4></div>
                                <div class="mx-1">

                                    @if(!empty($seller->registerSellerPlanRequestOffer))
                                    <h4>
                                        <strong style="color:red;">{{(!empty($seller->registerSellerPlanRequestOffer->new_ammount) && !empty($seller->registerSellerPlan->currency_id) ) ? \App\CPU\BackEndHelper::set_plan_currency($seller->registerSellerPlanRequestOffer->new_ammount,$seller->registerSellerPlan->currency_id) : 0}}</strong><sub><s>{{(!empty($seller->registerSellerPlan->price) && !empty($seller->registerSellerPlan->currency_id) ) ? \App\CPU\BackEndHelper::set_plan_currency($seller->registerSellerPlan->price,$seller->registerSellerPlan->currency_id) : 0}}</s></sub>
                                        <sub class="text-info">{{\App\CPU\translate('off')}}</sub>
                                    </h4>
                                    @else
                                    <h4 style="color:red;">
                                        {{(!empty($seller->registerSellerPlan->price) && !empty($seller->registerSellerPlan->currency_id) ) ? \App\CPU\BackEndHelper::set_plan_currency($seller->registerSellerPlan->price,$seller->registerSellerPlan->currency_id) : 'No Data found'}}
                                    </h4>
                                    @endif
                                </div>
                            </div>

                            <div class="flex-start widthmax">
                                <div><h4>{{\App\CPU\translate('allowed_number_of_products')}} : </h4></div>
                                <div class="mx-1"><h4>{{(!empty($seller->registerSellerPlan->allowed_products)) ? $seller->registerSellerPlan->allowed_products : 'No Data found'}}</h4></div>
                            </div>
                            <div class="flex-start widthmax">
                                <div><h4>{{\App\CPU\translate('allowed_no')}}. {{\App\CPU\translate('of_invoices_per_month')}} : </h4></div>
                                <div class="mx-1"><h4>{{(!empty($seller->registerSellerPlan->allowed_invoice)) ? \App\CPU\BackEndHelper::set_plan_currency($seller->registerSellerPlan->allowed_invoice,$seller->registerSellerPlan->currency_id) : 'No Data found'}}</h4></div>
                            </div>
                            
                            <div class="flex-start widthmax">
                                <div><h4>{{\App\CPU\translate('expected_volume_of_business')}} : </h4></div>
                                <div class="mx-1">
                                    <h4>
                                    {{(!empty($seller->registerSellerPlan->expected_volume_of_business)) ? \App\CPU\BackEndHelper::set_plan_currency($seller->registerSellerPlan->expected_volume_of_business,$seller->registerSellerPlan->currency_id):'No Data found'}}
                                    </h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {{-- <div class="col-md-6 mt-3">
                <form action="{{route('admin.sellers.sales-commission-update',[$seller['id']])}}" method="post">
                    @csrf
                    <div class="card">
                        <div class="card-header">
                            <label> Sales Commission : </label>
                            <label class="switch ml-3">
                                <input type="checkbox" name="status"
                                       class="status"
                                       value="1" {{$seller['sales_commission_percentage']!=null?'checked':''}}>
                                <span class="slider round"></span>
                            </label>
                        </div>
                        <div class="card-body">
                            <small class="badge badge-soft-danger mb-3">
                                If sales commission is disabled here, the system default commission will be applied.
                            </small>
                            <div class="form-group">
                                <label>Commission ( % )</label>
                                <input type="number" value="{{$seller['sales_commission_percentage']}}"
                                       class="form-control" name="commission">
                            </div>
                            <button type="submit" class="btn btn-primary">Update</button>
                        </div>
                    </div>
                </form>
            </div> --}}
        </div>
</div>
@endsection

@push('script')

@endpush
