@extends('layouts.back-end.app')

@section('title', \App\CPU\translate('Seller List'))

@push('css_or_js')
<style type="text/css">
      body{
      padding: 0;
      margin: 0;
      }
      .modal-header{
      background: #1B4F72;
      color: #fff;
      }
      h5{
      padding-top: 10px;
      padding-bottom: 10px;
      font-size: 30px;
      display: block;
      margin: 0 auto;
      }
      .modal-header .close{
      height: 50px;
      width:50px;
      background: #fff;
      border-radius: 50%;
      font-size: 30px;
      padding: 0;
      position: absolute;
      left: auto;
      right: -5px;
      top: -5px;
      }
      .btn-custom{
      background: #1B4F72;
      border-radius: 30px;
      color: #fff;
      padding: 5px 10px;
      margin: 20px auto;
      display: block;
      font-size: 10px;
      font-weight: 700;
      }
      .btn-custom:hover{
      color: #fff;
      }
      h3{
      text-align: center;
      font-size: 40px;
      padding-top: 20px;
      letter-spacing: 2px;
      line-height: 40px;
      }
      .fa-ul{
        padding-top: 20px;
      }
      p{
      text-align: center;
      font-size: 20px;
      padding-top: 20px;
      margin: 0;
      }
      .card-body h1 {
        font-size: 1.5rem;
      }
      .shadow-lg{
        box-shadow: 0 1.5rem 1.525rem -0.400rem rgb(0 0 0 / 40%) !important;
      }
      @media(max-width: 575px){
      .modal-dialog{
      margin: 1.5rem;
      }
      h5{
      padding-top: 20px;
      padding-bottom: 20px;
      font-size: 50px;
      }
      h3{
      font-size: 45px;
      }
      }
    </style>

@endpush

@section('content')
    <div class="content container-fluid">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{route('admin.dashboard.index')}}">{{\App\CPU\translate('Dashboard')}}</a>
                </li>
                <li class="breadcrumb-item" aria-current="page">{{\App\CPU\translate('Sellers')}}</li>
            </ol>
        </nav>

        <div class="row mt-4">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="row row justify-content-between align-items-center flex-grow-1 mx-1">
                            <div class="flex-between">
                                <div><h5>{{\App\CPU\translate('seller_table')}}</h5></div>
                                <div class="mx-1"><h5 style="color: red;">({{ $sellers->total() }})</h5></div>
                            </div>
                            <div style="width: 40vw">
                                <!-- Search -->
                                <form action="{{ url()->current() }}" method="GET">
                                    <div class="input-group input-group-merge input-group-flush">
                                        <div class="input-group-prepend">
                                            <div class="input-group-text">
                                                <i class="tio-search"></i>
                                            </div>
                                        </div>
                                        <input id="datatableSearch_" type="search" name="search" class="form-control"
                                            placeholder="{{\App\CPU\translate('Search by Name or Phone or Email')}}" aria-label="Search orders" value="{{ $search }}" required>
                                        <button type="submit" class="btn btn-primary">{{\App\CPU\translate('search')}}</button>
                                    </div>
                                </form>
                                <!-- End Search -->
                            </div>
                        </div>
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table
                                style="text-align: {{Session::get('direction') === "rtl" ? 'right' : 'left'}};"
                                class="table table-borderless table-thead-bordered table-nowrap table-align-middle card-table">
                                <thead class="thead-light">
                                <tr>
                                    <th scope="col">{{\App\CPU\translate('SL#')}}</th>
                                    <th scope="col">{{\App\CPU\translate('name')}}</th>
                                    <th scope="col">{{\App\CPU\translate('Phone')}}</th>
                                    <th scope="col">{{\App\CPU\translate('Email')}}</th>
                                    <th scope="col">{{\App\CPU\translate('requested_plan')}}</th>
                                    <th scope="col">{{\App\CPU\translate('status')}}</th>
                                    <th scope="col">{{\App\CPU\translate('orders')}}</th>
                                    <th scope="col">{{\App\CPU\translate('Products')}}</th>
                                    <th scope="col" style="width: 50px">{{\App\CPU\translate('action')}}</th>
                                </tr>
                                </thead>
                                <tbody>
                                @foreach($sellers as $key=>$seller)
                                    <tr>
                                        <td scope="col">{{$sellers->firstItem()+$key}}</td>
                                        <td scope="col">{{$seller->f_name}} {{$seller->l_name}}</td>
                                        <td scope="col">{{$seller->phone}}</td>
                                        <td scope="col">{{$seller->email}}</td>
                                        <td scope="col">
                                            <!-- model Button start-->
                                            <button type="button" class="btn btn-custom" data-toggle="modal" data-target="#exampleModal_{{$seller->id}}">{{\App\CPU\translate('requested_plan')}}
                                            </button>
                                            <!-- model Button end-->
                                            <!-- model start-->
                                            <div class="modal fade" id="exampleModal_{{$seller->id}}" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                              <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                  <div class="modal-header">
                                                    <h5 style="color:white;" class="modal-title text-center" id="exampleModalLabel">{{$seller->registerSellerPlanRequest->title}}</h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                    </button>
                                                  </div>
                                                  <div class="modal-body">
                                                    <h1 class="card-price text-center">
                                                        @if(!empty($seller->registerSellerPlanRequestOffer))
                                                        ({{\App\CPU\translate('offer')}}) <span style="color:red;">{{\App\CPU\BackEndHelper::set_plan_currency($seller->registerSellerPlanRequestOffer->new_ammount,$seller->registerSellerPlanRequest->currency_id)}}</span><sub><del>{{\App\CPU\BackEndHelper::set_plan_currency($seller->registerSellerPlanRequest->price,$seller->registerSellerPlanRequest->currency_id)}}</del></sub>
                                                        @else

                                                        {{\App\CPU\BackEndHelper::set_plan_currency($seller->registerSellerPlanRequest->price,$seller->registerSellerPlanRequest->currency_id)}}

                                                        @endif
                                                        /{{\App\CPU\BackEndHelper::set_plan_duration($seller->registerSellerPlanRequest->duration,$seller->registerSellerPlanRequest->duration_type)}}
                                                        
                                                    </h1>
                                                    <hr>
                                                    <ul class="fa-ul">
                                                      <li><span class="fa-li"><i class="fa fa-check"></i></span>Allowed Number Products:- <b>{{$seller->registerSellerPlanRequest->allowed_products}}</b></li>
                                                      <li><span class="fa-li"><i class="fa fa-check"></i></span>Allowed Number Invoices Per Month:- <b>
                                                        {{\App\CPU\BackEndHelper::set_plan_currency($seller->registerSellerPlanRequest->allowed_invoice,$seller->registerSellerPlanRequest->currency_id)}}</b></li>
                                                      <li><span class="fa-li"><i class="fa fa-check"></i></span>{{\App\CPU\translate('expected_volume_of_business')}}:- 
                                                        <b>
                                                        {{\App\CPU\BackEndHelper::set_plan_currency($seller->registerSellerPlanRequest->expected_volume_of_business,$seller->registerSellerPlanRequest->currency_id)}}
                                                        </b></li>

                                                    </ul>
                                                  </div>
                                                </div>
                                              </div>
                                            </div>
                                            <!-- model end-->

                                        </td>
                                        <td scope="col">
                                            <!-- @if($seller->new_seller_status=='pending')
                                            <label class="badge badge-warning">Pending</label>
                                            @elseif($seller->new_seller_status=='approved')
                                            <label class="badge badge-success">Approved</label>
                                            @elseif($seller->new_seller_status=='paid')
                                            <label class="badge badge-info">Paid</label>
                                            @elseif($seller->new_seller_status=='hold')
                                            <label class="badge badge-warning">Hold</label>
                                            @elseif($seller->new_seller_status=='suspended')
                                            <label class="badge badge-danger">Canceled</label>
                                            @elseif($seller->new_seller_status=='active')
                                            <label class="badge badge-success">Active</label>
                                            @endif -->

                                            @if($seller->new_seller_status=='pending')
                                            <label class="badge badge-warning">Pending</label>
                                            @elseif($seller->new_seller_status=='approved')
                                            <label class="badge badge-success">Approved</label>
                                            @elseif($seller->new_seller_status=='active')
                                                @if($seller->status=='pending')
                                                    @if($seller->paidSeller->result=='success')
                                                        <label class="badge badge-success">Paid</label>
                                                    @endif
                                                    @if($seller->paidSeller->result=='fail')
                                                        <label class="badge badge-danger">Payment Fail</label>
                                                    @endif
                                                @endif
                                                @if($seller->status=='approved' && $seller->paidSeller->result=='success')
                                                        <label class="badge badge-success">Active</label>
                                                @endif
                                            @elseif($seller->new_seller_status=='hold')
                                            <label class="badge badge-warning">Hold</label>
                                            @elseif($seller->new_seller_status=='suspended')
                                            <label class="badge badge-danger">Canceled</label>
                                            @endif
                                        </td>
                                        <td scope="col">
                                            <a href="{{route('admin.sellers.order-list',[$seller['id']])}}"
                                               class="btn btn-outline-primary btn-block">
                                                <i class="tio-shopping-cart-outlined"></i>( {{$seller->orders->count()}}
                                                )
                                            </a>
                                        </td>
                                        <td scope="col">
                                            <a href="{{route('admin.sellers.product-list',[$seller['id']])}}"
                                               class="btn btn-outline-primary btn-block">
                                                <i class="tio-premium-outlined mr-1"></i>( {{$seller->product->count()}}
                                                )
                                            </a>
                                        </td>
                                        <td>
                                            <a class="btn btn-primary"
                                               href="{{route('admin.sellers.view',$seller->id)}}">
                                                {{\App\CPU\translate('View')}}
                                            </a>
                                        </td>
                                    </tr>
                                @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="card-footer">
                        {!! $sellers->links() !!}
                    </div>
                    @if(count($sellers)==0)
                        <div class="text-center p-4">
                            <img class="mb-3" src="{{asset('public/assets/back-end')}}/svg/illustrations/sorry.svg" alt="Image Description" style="width: 7rem;">
                            <p class="mb-0">{{\App\CPU\translate('No data to show')}}</p>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
@endsection

@push('script')

@endpush
