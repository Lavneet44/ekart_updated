@extends('layouts.back-end.app')

@section('title', 'Add Offer')

@push('css_or_js')
<link href="{{asset('public/assets/back-end/css/tags-input.min.css')}}" rel="stylesheet">
@endpush

<style type="text/css">
.parent {
  align-items: center;
  border: 1px solid black;
  display: flex;
  justify-content: center;
  height: 250px;
  width: 250px;
}

.child {
  border: 1px solid black;
  height: 50px;
  width: 50px;
}
</style>
@section('content')
<div class="content container-fluid">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{route('admin.dashboard.index')}}">{{\App\CPU\translate('Dashboard')}}</a>
                </li>
                <li class="breadcrumb-item"><a href="{{route('admin.plan.plan-list')}}">{{\App\CPU\translate('seller_plans')}}</a>
                </li>
                <li class="breadcrumb-item" aria-current="page">{{\App\CPU\translate('add_offer')}}</li>
            </ol>
        </nav>

        <!-- Page Heading -->
    
        <!-- Page Header -->
   
        <!-- End Page Header -->
        <div class="row">
            <div class="col-md-12 mt-3">
                <form action="" method="post" id="addoffer">
                    @csrf
                    <div class="card">
                        <div class="card-header">
                            <h5>Add Offer</h5>
                        </div>
                        <div class="card-body">
                            <div class="input-group">
                                <div class="form-group  col-md-12">
                                    <label>Title</label> <span class="text-danger">*</span>
                                    <input type="text" class="form-control" name="offer_title" style="width:100%;">
                                </div>
                                <div class="form-group col-md-6">
                                    <label>Plans</label> <span class="text-danger">*</span>
                                    <select class="form-control selectcurrencyy" onchange="getPlanPriceAndCurrency();" name="plan_id" style="width:100%;">
                                        <option value="">--Select Plan--</option>
                                        @foreach($Plans as $pl)
                                        <option data-price="{{$pl->price}}" data-currency="{{$pl->planCurrency->symbol}}" value="{{$pl->id}}">{{$pl->title}}</option>
                                        @endforeach
                                    </select>
                                </div>
                                
                                <div class="form-group  col-md-6" >
                                    <label>Plan Price</label> <span class="text-danger">*</span>
                                    <input disabled type="text" id="plan_price" class="form-control" style="width:100%;" autocomplete="off">
                                </div>
                            <div class="input-group offeritems">
                                <div class="form-group  col-md-6">
                                    <label>Offer Amount</label> <span class="text-danger">*</span>
                                    <input type="text" class="form-control" name="offer_ammount" style="width:100%;">
                                </div>
                                <div class="form-group  col-md-6" >
                                    <label>Offer Start Date</label> <span class="text-danger">*</span>
                                    <input type="text" id="datepicker" class="form-control" name="offer_startdate" style="width:100%;" autocomplete="off">
                                </div>
                            </div>
                            </div>
                            <div class="input-group">
                                <div class="form-group  col-md-6">
                                    <label>Offer End Date</label>
                                    <input type="text" id="offerenddatepicker" class="form-control" name="offer_enddate" style="width:100%;" autocomplete="off">
                                </div>
                                <div class="col-md-6">
                                    <div class="input-group">
                                    <small class="badge badge-soft-danger mb-3">
                                        Click at Enable, To Hold <b>Offer</b> For This Plan.
                                    </small>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="input-group">
                                        <div class="form-group  col-md-3">
                                        <label>Hold Offer :</label>
                                        </div>
                                        <div class="form-group  col-md-2">
                                        <label class="switch ml-3">
                                            <input type="checkbox" id="offer_hold" name="offer_hold"
                                                   class="status"
                                                   value="1">
                                            <span class="slider round"></span>
                                        </label>
                                        </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="input-group">
                                <div class="form-group  col-md-12">
                                    <label class="input-label">{{\App\CPU\translate('description')}} </label>
                                    <textarea class="form-control" name="note" id="editorid" class="editor textarea" cols="30" rows="10" required>{{old('note')}}</textarea>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary">Create</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script>
    function getPlanPriceAndCurrency(){
        var price = $('.selectcurrencyy').find(':selected').attr('data-price');
        var curr = $('.selectcurrencyy').find(':selected').attr('data-currency');
        $('#plan_price').val(curr+' '+price);
    }

    $(document).ready(function () {
         
         var start_d=$('#datepicker');
         var end_d=$('#offerenddatepicker');
         start_d.datepicker({
            dateFormat: 'dd/mm/yy',
            minDate: 0,
            onSelect: function (selectedDate){
                console.log(selectedDate);
                var from = $('#datepicker').val().split('/');
                var d = new Date(from[2],from[1]-1,from[0]);
                var day = d.getDate();
                var month = d.getMonth()+1;
                var year = d.getFullYear();
                end_d.datepicker("destroy");
                end_d.datepicker({
                    dateFormat: 'dd/mm/yy',
                    minDate: new Date(month+"-"+day+"-"+year)
                });
                console.log(end_d);
            }
        });

        $('#offerenddatepicker').on('click', function (selected) {
              if ($("#datepicker").val()=='') {
                toastr.error('Please Select Start Date first')
                $('#offerenddatepicker').val('');
                $('#datepicker').focus();
                return false;
              }
        });


        $("#addoffer").validate({
                rules: {
                        offer_title: {
                            required: true,
                        },
                        offer_ammount: {
                            required: true,
                            digits: true
                        },
                        plan_id: {
                            required: true,
                        },
                        offer_startdate: {
                            required: true,
                        }
                },
                messages: {
                     offer_title:{
                      required: function() { toastr.error('Please Fill offer Title') },
                      },
                     offer_ammount:{
                      required: function() { toastr.error('Please Fill offer Title') },
                      number: function() { toastr.error('Price should be in Number Formate') },
                      },
                     plan_id:{
                      required: function() { toastr.error('Please select a plan') },
                      },
                     offer_startdate:{
                      required: function() { toastr.error('Please select offer start date') },
                      },
                },
                submitHandler: function(form){
                  var form_data = new FormData(form);
                  // form_data.append('note', CKEDITOR.instances['editorid'].getData());
                  $.ajax({
                    url: '{{url("admin/plan/add-offer")}}',
                    type: 'POST',
                    processData: false,
                    contentType: false,
                    data: form_data,
                    success: function(result){
                        console.log(result);
                      var res = $.parseJSON(result);
                      console.log(res);
                      var message = res.message;;
                            if(res.message == true){
                              toastr.success('{{\App\CPU\translate('Plan updated successfully!')}}', {
                                CloseButton: true,
                                ProgressBar: true
                              });
                                window.location.replace('{{url("admin/plan/offer-list")}}');
                            }else{
                              toastr.error('{{\App\CPU\translate('Oops Something went wrong!')}}', {
                                CloseButton: true,
                                ProgressBar: true
                              });
                              window.location.replace('{{url("admin/plan/offer-list")}}');
                            }
                        }
                    });
                }
                         
        });

    });
</script>

{{--ck editor--}}
<!-- <script src="{{asset('/')}}vendor/ckeditor/ckeditor/ckeditor.js"></script>
<script src="{{asset('/')}}vendor/ckeditor/ckeditor/adapters/jquery.js"></script>
<script>
    $('.textarea').ckeditor({
        contentsLangDirection : '{{Session::get('direction')}}',
    });
</script> -->
{{--ck editor--}}


@endsection

@push('script')

@endpush
