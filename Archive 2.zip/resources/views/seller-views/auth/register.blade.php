@extends('layouts.front-end.app')

@section('title',\App\CPU\translate('Seller Apply'))

@push('css_or_js')
<link href="{{asset('public/assets/back-end')}}/css/select2sellerfront.min.css" rel="stylesheet"/>
<link href="{{asset('public/assets/back-end/css/croppie.css')}}" rel="stylesheet">
<meta name="csrf-token" content="{{ csrf_token() }}">
<style type="text/css">
    .mmyy {
        height: 35px;
    }
</style>
@endpush


@section('content')

<div class="container main-card rtl" style="text-align: {{Session::get('direction') === "rtl" ? 'right' : 'left'}};">

    <div class="card o-hidden border-0 shadow-lg my-4">
        <div class="card-body ">
            <!-- Nested Row within Card Body -->
            <div class="row" >
                <div class="col-lg-12" style="display: flex;align-items: left;justify-content: left">
                    <div class="p-5">
                        <div class="text-center mb-2 ">
                            <h3 class="" > {{\App\CPU\translate('Shop')}} {{\App\CPU\translate('Application')}}</h3>
                            <hr>
                        </div>
                        <form class="user" action="{{route('shop.apply')}}" method="post" enctype="multipart/form-data">
                            @csrf

                            <h5 class="black">{{\App\CPU\translate('Company')}}/{{\App\CPU\translate('Seller')}} {{\App\CPU\translate('Info')}}</h5>


                            <div class="form-group row">
                                <div class="col-sm-12 mb-3 mb-sm-0 ">
                                    <input type="text" class="form-control form-control-user" id="shop_name" name="shop_name" placeholder="{{\App\CPU\translate('shop_name')}}" value="{{old('shop_name')}}" required>
                                </div>
                            </div>  
                            <div class="form-group row">
                                <div class="col-sm-4 mb-sm-0">
                                    <small class="text-info">( * {{\App\CPU\translate('Reg.')}} {{\App\CPU\translate('No.')}}, {{\App\CPU\translate('system generated')}}, {{\App\CPU\translate('not editable')}}.)</small>
                                </div>
                                <div class="col-sm-4 mb-sm-0">
                                    <small class="text-info">( * {{\App\CPU\translate('Please enter the nation of the store.')}} )</small>
                                </div>
                                <div class="col-sm-4 mb-sm-0">
                                    <small class="text-info">( * {{\App\CPU\translate('Please select a shop type.')}} )</small>
                                </div>
                                <div class="col-sm-4 mb-3 mb-sm-0 ">
                                    <input type="text" class="form-control form-control-user" id="reg_no" name="reg_or_cr_number" placeholder="{{\App\CPU\translate('shop_name')}}" value="{{sprintf('%06s',App\Model\Seller::get()->count()+1)}}" readonly required>
                                </div>
                                <div class="col-sm-4 mb-3 mb-sm-0 ">
                                    <select class="js-example-basic-multiple js-states js-example-responsive form-control" name="shop_country_code" id="shop_country_code" required >
                                    <option value="">--{{\App\CPU\translate('select nation of the store')}}--</option>
                                        @foreach($data['ccode'] as $code)
                                            <option {{ (old('shop_country_code') == $code->id) ? 'selected' : '' }}  value="{{$code->id}}">
                                                ({{$code->iso}}) - {{$code->phonecode}}--{{$code->name}}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="col-sm-4 mb-3 mb-sm-0 ">
                                    <select class="js-example-basic-multiple js-states js-example-responsive form-control" name="shop_type" id="shop_type" required>
                                    <option value="">--{{\App\CPU\translate('select shop type')}}--</option>
                                        @foreach($data['CompanyType'] as $ct)
                                            <option {{ (old('shop_type') == $ct->id) ? 'selected' : '' }} value="{{$ct->id}}">
                                                {{$ct->company_type}}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row address" id="1">

                                <div class="col-sm-12 mb-3 mb-sm-0">
                                    <small class="text-info">( * Shop Address)</small>
                                </div>
                                <div class="col-sm-12 mb-3 mb-sm-0 ">
                                    <input type="text" class="form-control form-control-user" name="shop_address" placeholder="{{\App\CPU\translate('shop_address_1')}}" value="{{old('shop_address')}}" required>
                                </div>
                            </div>
                            <div class="form-group row address" id="2">
                                <div class="col-sm-12 mb-3 mb-sm-0 ">
                                    <input type="text" class="form-control form-control-user" id="shop_address2" name="shop_address2" placeholder="{{\App\CPU\translate('shop_address_2')}}" value="{{old('shop_address2')}}">
                                </div>
                            </div>
                            <div class="form-group row address" id="3">
                                <div class="col-sm-12 mb-3 mb-sm-0 ">
                                    <input type="text" class="form-control form-control-user" id="shop_address3" name="shop_address3" placeholder="{{\App\CPU\translate('shop_address_3')}}" value="{{old('shop_address3')}}">
                                </div>
                            </div>
                            <div class="form-group row address" id="4">
                                <div class="col-sm-12 mb-3 mb-sm-0 ">
                                    <input type="text" class="form-control form-control-user" id="shop_address4" name="shop_address4" placeholder="{{\App\CPU\translate('shop_address_4')}}" value="{{old('shop_address4')}}">
                                </div>
                            </div>
                            <div class="form-group row address" id="5">
                                <div class="col-sm-12 mb-3 mb-sm-0 ">
                                    <input type="text" class="form-control form-control-user" id="shop_address5" name="shop_address5" placeholder="{{\App\CPU\translate('shop_address_5')}}" value="{{old('shop_address5')}}">
                                </div>
                                <!-- <div class="col-sm-6">
                                    <textarea name="shop_address" class="form-control" id="shop_address"rows="1" placeholder="{{\App\CPU\translate('shop_address')}}">{{old('shop_address')}}</textarea>
                                </div> -->
                            </div>
                            <div class="form-group">
                                <div>
                                    <a href="javascript:void(0)" class="btn btn-outline-info" onclick="showMoreAddress(this);" data-lastIndex="1" id="buttshow">Add Address</a>
                                    <a href="javascript:void(0)" class="btn btn-outline-info" onclick="removeMoreAddress(this);" data-lastIndex="1" id="butthide">Remove</a>
                                </div>
                            </div>
                            <!-- <div class="form-group row">
                                <div class="col-sm-6 mb-3 mb-sm-0 ">
                                    <input type="number" class="form-control form-control-user" id="vat_no" name="vat_no" placeholder="{{\App\CPU\translate('vat')}} {{\App\CPU\translate('number')}}" value="{{old('vat_no')}}" required>
                                </div>
                            </div> -->

                            <div class="form-group row">

                                <div class="col-sm-6 mb-3 mb-sm-0">
                                    <small class="text-info">( * Only Numeric Value )</small>
                                </div>
                                <div class="col-sm-6 mb-3 mb-sm-0">
                                    <small class="text-info">( * {{\App\CPU\translate('Please_select_seller_transaction_currency')}} )</small>
                                </div>
                                <div class="col-sm-6 mb-3 mb-sm-0 ">
                                    <input type="number" class="form-control form-control-user" id="vat_no" name="vat_no" placeholder="{{\App\CPU\translate('vat')}} {{\App\CPU\translate('number')}}" value="{{old('vat_no')}}" required>
                                </div>
                                <div class="col-sm-6 mb-3 mb-sm-0">
                                    <select class="js-example-basic-multiple js-states js-example-responsive form-control" name="seller_transaction_currency" id="seller_transaction_currency" required>
                                            <option value="{{old('seller_transaction_currency')}}">--{{\App\CPU\translate('select_seller_currency')}}--</option>
                                        @foreach($data['curr'] as $c)
                                            <option {{ (old('seller_transaction_currency') == $c->id) ? 'selected' : '' }}  value="{{$c->id}}">{{$c->code}} ({{$c->symbol}})--({{$c->name}})</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>

                            <div class="input-group" style="border: 0.5px solid #dae1e7;padding-top: 15px;padding-bottom: 15px;margin-bottom: 15px;border-radius: 5px;">

                                <div class="form-group col-md-6">
                                    <div class="custom-file" style="text-align: left">
                                        <input type="file" name="logo" id="LogoUpload" class="custom-file-input"
                                            accept=".jpg, .png, .jpeg, .gif, .bmp, .tif, .tiff|image/*">
                                        <label class="custom-file-label" for="LogoUpload">{{\App\CPU\translate('Upload')}} {{\App\CPU\translate('logo')}}</label>
                                    </div>
                                </div>
                                <div class="pb-1 col-md-6">
                                    <center>
                                        <img style="width: auto;border: 1px solid; border-radius: 10px; max-height:200px;" id="viewerLogo"
                                            src="{{asset('public\assets\back-end\img\400x400\img2.jpg')}}" alt="banner image"/>
                                    </center>
                                </div>
                            </div>

                            <div class="input-group" style="border: 0.5px solid #dae1e7;padding-top: 15px;padding-bottom: 15px;margin-bottom: 15px;border-radius: 5px;">

                                <div class="form-group col-md-6">
                                    <div class="custom-file" style="text-align: left">
                                        <input type="file" name="banner" id="BannerUpload" class="custom-file-input"
                                               accept=".jpg, .png, .jpeg, .gif, .bmp, .tif, .tiff|image/*" style="overflow: hidden; padding: 2%">
                                        <label class="custom-file-label" for="BannerUpload">{{\App\CPU\translate('Upload')}} {{\App\CPU\translate('Banner')}}</label>
                                    </div>
                                </div>
                                <div class="pb-1 col-md-6">
                                    <center>
                                        <img style="width: auto;border: 1px solid; border-radius: 10px; max-height:200px;" id="viewerBanner"
                                             src="{{asset('public\assets\back-end\img\400x400\img2.jpg')}}" alt="banner image"/>
                                    </center>
                                </div>
                            </div>
                            <br/>
                            <hr>
                            <br/>

                            <h5 class="black">{{\App\CPU\translate('Contact')}} {{\App\CPU\translate('Info')}} </h5>
                            <div class="form-group row">

                                <div class="col-sm-6 mb-3 mb-sm-0">
                                    <small class="text-info">( * First Name)</small>
                                </div>

                                <div class="col-sm-6 mb-3 mb-sm-0">
                                    <small class="text-info">( * Last Name)</small>
                                </div>
                                <div class="col-sm-6 mb-3 mb-sm-0">
                                    <input type="text" class="form-control form-control-user" id="exampleFirstName" name="f_name" value="{{old('f_name')}}" placeholder="{{\App\CPU\translate('first_name')}}" required>
                                </div>
                                <div class="col-sm-6">
                                    <input type="text" class="form-control form-control-user" id="exampleLastName" name="l_name" value="{{old('l_name')}}" placeholder="{{\App\CPU\translate('last_name')}}" required>
                                </div>
                            </div>
                            <div class="form-group row">

                                <div class="col-sm-6 mb-3 mb-sm-0">
                                    <small class="text-info">( * Email Should be Unique.)</small>
                                </div>

                                <div class="col-sm-3">
                                    <small class="text-info">( * Country Code)</small>
                                </div>

                                <div class="col-sm-3">
                                    <small class="text-info">( * Phone)</small>
                                </div>
                                <div class="col-sm-6 mb-3 mb-sm-0">
                                    <input type="email" class="form-control form-control-user" id="exampleInputEmail" name="email" value="{{old('email')}}" placeholder="{{\App\CPU\translate('email_address')}}" required>
                                </div>
                                <div class="col-sm-3">
                                    <select class="js-example-basic-multiple js-states js-example-responsive form-control" name="country_code" id="country_code" required>
                                    <option value="">--{{\App\CPU\translate('select-country-code')}}--</option>
                                        @foreach($data['ccode'] as $code)
                                            <option {{ (old('country_code') == $code->id) ? 'selected' : '' }}  value="{{$code->id}}">
                                                ({{$code->iso}}) - {{$code->phonecode}}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="col-sm-3">
                                    <input type="number" class="form-control form-control-user" id="exampleInputPhone" name="phone" value="{{old('phone')}}" placeholder="{{\App\CPU\translate('phone_number')}}" required>
                                </div>
                            </div>
                            <div class="form-group row">

                                <div class="col-sm-6 mb-3 mb-sm-0">
                                    <small class="text-info">( * Password should have 8 characters.)</small>
                                </div>

                                <div class="col-sm-6 mb-3 mb-sm-0">
                                    <small class="text-info">( * Password and Repeat Password Should be Same.)</small>
                                </div>
                                <div class="col-sm-6 mb-3 mb-sm-0">
                                    <input type="password" class="form-control form-control-user" minlength="6" id="exampleInputPassword" name="password" placeholder="{{\App\CPU\translate('password')}}" required>
                                </div>
                                <div class="col-sm-6">
                                    <input type="password" class="form-control form-control-user" minlength="6" id="exampleRepeatPassword" placeholder="{{\App\CPU\translate('repeat_password')}}" required>
                                    <div class="pass invalid-feedback">{{\App\CPU\translate('Repeat')}}  {{\App\CPU\translate('password')}} {{\App\CPU\translate('not match')}} .</div>
                                </div>
                            </div>
                            <div class="input-group" style="border: 0.5px solid #dae1e7;padding-top: 15px;padding-bottom: 15px;margin-bottom: 15px;border-radius: 5px;">

                                <div class="form-group col-md-6">
                                    <div class="custom-file" style="text-align: left">
                                        <input type="file" name="image" id="customFileUpload" class="custom-file-input"
                                            accept=".jpg, .png, .jpeg, .gif, .bmp, .tif, .tiff|image/*">
                                        <label class="custom-file-label" for="customFileUpload">{{\App\CPU\translate('Upload')}} {{\App\CPU\translate('image')}}</label>
                                    </div>
                                </div>
                                <div class="pb-1 col-md-6">
                                    <center>
                                        <img style="width: auto;border: 1px solid; border-radius: 10px; max-height:200px;" id="viewer"
                                            src="{{asset('public\assets\back-end\img\400x400\img2.jpg')}}" alt="banner image"/>
                                    </center>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-sm-12 mb-3 mb-sm-0">
                                    <small class="text-info">( * {{\App\CPU\translate('you_can_change_your_selected_plan')}} )</small>
                                </div>
                                <div class="col-sm-6 mb-3 mb-sm-0"></div>
                                <!-- @php
                                $plan_currency_id = 0;
                                if(!empty($plan))
                                {
                                    $plan_currency_id = $plan->currency_id;
                                }
                                @endphp -->
                                <!-- <div class="col-sm-6 mb-3 mb-sm-0">
                                    <select class="form-control form-control-user" name="seller_currency" id="seller_currency" required>
                                            <option value="">--{{\App\CPU\translate('currency_of_plan')}}--</option>
                                        @foreach($data['curr'] as $c)
                                            <option  value="{{$c->id}}" {{($plan_currency_id==$c->id)?'selected':''}}>{{$c->code}} ({{$c->symbol}})--({{$c->name}}) asdfjkhsdjkfh</option>
                                        @endforeach
                                    </select>
                                </div> -->
                                <div class="col-sm-12 mb-3 mb-sm-0">
                                    <select class="form-control form-control-user" name="seller_plan_request" id="seller_plan_request" required>
                                        <option value="">--{{\App\CPU\translate('select_plan')}}--</option>
                                        @foreach($plans as $p)
                                        @if(!empty($plan) && $plan->count()>0)
                                        <option {{ (old('seller_plan_request') == $p->id) ? 'selected' : '' }}
                                        value="{{$p->id}}" 
                                        data-plancurrencyid="{{$p->currency_id}}" 
                                        data-planprice="{{\App\CPU\BackEndHelper::set_plan_currency($p->price,$p->currency_id)}}" data-planduration="{{\App\CPU\BackEndHelper::set_plan_duration($p->duration,$p->duration_type)}}" {{($p->id==$plan->id)?"selected":""}}>
                                        {{$p->title}} 
                                        </option>
                                        @else
                                        <option {{ (old('seller_plan_request') == $p->id) ? 'selected' : '' }}
                                        value="{{$p->id}}" 
                                        data-plancurrencyid="{{$p->currency_id}}" 
                                        data-planprice="{{\App\CPU\BackEndHelper::set_plan_currency($p->price,$p->currency_id)}}" data-planduration="{{\App\CPU\BackEndHelper::set_plan_duration($p->duration,$p->duration_type)}}">
                                        {{$p->title}} 
                                        </option>
                                        @endif
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row" id="if_offer_exists">
                                <div class="col-sm-6 mb-3 mb-sm-0"></div>
                                <div class="col-sm-6 mb-3 mb-sm-0">
                                    <small class="text-info" id="if_offer_pre_plan_detail">* {{\App\CPU\translate('plan_detail')}}</small>
                                </div>
                                <div class="col-sm-6 mb-3 mb-sm-0">
                                    <select class="form-control form-control-user" name="plan_offer" id="offer" required>
                                        <option value="{{old('plan_offer')}}">--{{\App\CPU\translate('select_plan_offer')}}--</option>

                                        @if(!empty($plan) && $plan->count()>0 && !empty($plan->validOffers))
                                        @foreach($plan->validOffers as $off)
                                        @if($off->offdetails==1)
                                        <option {{ (old('plan_offer') == $off->id) ? 'selected' : '' }}
                                        data-offerplanDuration = "{{\App\CPU\BackEndHelper::set_plan_duration($plan->duration,$plan->duration_type)}}"
                                        data-offerplanPrice = "{{\App\CPU\BackEndHelper::set_plan_currency($plan->price,$plan->currency_id)}}"
                                        data-offerplanNewPrice = "{{\App\CPU\BackEndHelper::set_plan_currency($off->new_ammount,$plan->currency_id)}}" 
                                        value="{{$off->id}}">{{$off->offer_title}}
                                        </option>
                                        @endif
                                        @endforeach
                                        @endif
                                    </select>
                                </div>
                                <div class="col-sm-6 mb-3 mb-sm-0">
                                    <input type="text" class="form-control form-control-user" id="offered_price"  placeholder="{{\App\CPU\translate('Offered_price')}}">
                                </div>
                            </div>
                            <div class="form-group row" id="if_offer_doesnot_exists">
                                <div class="col-sm-6 mb-3 mb-sm-0">
                                    <small class="text-info plan_detail">(* {{\App\CPU\translate('Plan_price')}})
                                    </small>
                                </div>
                                <div class="col-sm-6 mb-3 mb-sm-0">
                                    <small class="text-info plan_detail">(* {{\App\CPU\translate('Plan_duration')}})
                                    </small>
                                </div>
                                <div class="col-sm-6 mb-3 mb-sm-0">
                                    <input type="text" id="plan_pri" class="form-control form-control-user" value="" placeholder="{{\App\CPU\translate('Plan_price')}}">
                                </div>
                                <div class="col-sm-6 mb-3 mb-sm-0">
                                    <input type="text"  id="plan_dur" class="form-control form-control-user" value="" placeholder="{{\App\CPU\translate('Plan_duration')}}">
                                </div>
                                
                            </div>
                            <br/>
                            <hr>
                            <br/>

                            <h5 class="black">{{\App\CPU\translate('Bank')}} {{\App\CPU\translate('Details')}}</h5>
                            <div class="form-group row">

                                <div class="col-sm-6 mb-3 mb-sm-0">
                                    <small class="text-info">( * Bank Name )</small>
                                </div>

                                <div class="col-sm-6 mb-3 mb-sm-0">
                                    <small class="text-info">( * A\C Holder Name )</small>
                                </div>
                                <div class="col-sm-6 mb-3 mb-sm-0 ">
                                    <input type="text" class="form-control form-control-user" id="bank_name" name="bank_name" placeholder="{{\App\CPU\translate('bank')}} {{\App\CPU\translate('name')}}" value="{{old('bank_name')}}" required >
                                </div>
                                <div class="col-sm-6 mb-3 mb-sm-0 ">
                                    <input type="text" class="form-control form-control-user" id="ac_holder_name" name="ac_holder_name" placeholder="{{\App\CPU\translate('A/C')}} {{\App\CPU\translate('holder')}} {{\App\CPU\translate('name')}}" value="{{old('ac_holder_name')}}" required>
                                </div>
                            </div>
                            <div class="form-group row">

                                <div class="col-sm-6 mb-3 mb-sm-0">
                                    <small class="text-info">( * Only Numeric Value )</small>
                                </div>

                                <div class="col-sm-6 mb-3 mb-sm-0">
                                    <small class="text-info"></small>
                                </div>
                                <div class="col-sm-6 mb-3 mb-sm-0 ">
                                    <input type="number" class="form-control form-control-user" id="ac_number" name="ac_number" placeholder="{{\App\CPU\translate('A/C')}} {{\App\CPU\translate('number')}}" value="{{old('ac_number')}}" required>
                                </div>
                                <div class="col-sm-6 mb-3 mb-sm-0 ">
                                    <input type="text" class="form-control form-control-user" id="swift_number" name="swift_number" placeholder="{{\App\CPU\translate('swift')}} {{\App\CPU\translate('number')}}" value="{{old('swift_number')}}">
                                </div>
                            </div>
                            <div class="form-group row">

                                <div class="col-sm-6 mb-3 mb-sm-0">
                                    <small class="text-info">( * IBAN Number )</small>
                                </div>
                                <div class="col-sm-6 mb-3 mb-sm-0">
                                    <small class="text-info">( * Bank Address )</small>
                                </div>
                                <div class="col-sm-6 mb-3 mb-sm-0 ">
                                    <input type="text" class="form-control form-control-user" id="iban_number" name="iban_number" placeholder="{{\App\CPU\translate('IBAN')}} {{\App\CPU\translate('number')}}" value="{{old('iban_number')}}" required>
                                </div>
                                <div class="col-sm-6 mb-3 mb-sm-0 ">
                                    <input type="text" class="form-control form-control-user" id="bank_address" name="bank_address" placeholder="{{\App\CPU\translate('bank')}} {{\App\CPU\translate('address')}}" value="{{old('bank_address')}}" required>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="text-info">( * {{\App\CPU\translate('branch_name')}} )</label>
                                <input type="text" class="form-control form-control-user" id="branch" name="branch" placeholder="{{\App\CPU\translate('branch')}} {{\App\CPU\translate('name')}}" value="{{old('branch')}}" required>
                            </div>
                            
                            <button type="submit" class="btn btn-primary btn-user btn-block" id="apply">{{\App\CPU\translate('Apply')}} {{\App\CPU\translate('Shop')}} </button>
                        </form>
                        <hr>
                        <div class="text-center">
                            <a class="small"  href="{{route('seller.auth.login')}}">{{\App\CPU\translate('already_have_an_account?_login.')}}</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
@push('script')
 <script src="{{ asset('public/assets/select2/js/select2.min.js')}}"></script>
@if ($errors->any())
    <script>
        @foreach($errors->all() as $error)
        toastr.error('{{$error}}', Error, {
            CloseButton: true,
            ProgressBar: true
        });
        @endforeach
    </script>
@endif
<script>
    $('.address').not('#1').hide();

    function showMoreAddress(that)
    {
        var toBeactive = parseInt($(that).attr("data-lastIndex")) + 1;
        if(toBeactive < 6 )
        {
            $("#"+toBeactive).show();
            $("#butthide").attr("data-lastIndex",toBeactive)
            $("#buttshow").attr("data-lastIndex",toBeactive)
        }
        else
        {
            toastr.info('{{\App\CPU\translate('Address Fields are no longer available.')}}');
        }
    }

    function removeMoreAddress(that)
    {
        var toBeRemove = parseInt($(that).attr("data-lastIndex"))
        if(toBeRemove != 1)
        {
            $("#"+toBeRemove).hide();
            $("#butthide").attr("data-lastIndex",toBeRemove-1)
            $("#buttshow").attr("data-lastIndex",toBeRemove-1)

        }
        else
        {
            toastr.info('{{\App\CPU\translate('There must be at least one address field.')}}');
        }
    }

    $(".js-example-theme-single").select2({
        theme: "classic"
    });

    $(".js-example-responsive").select2({
        width: 'resolve'
    });
        
    $('#seller_currency').attr('disabled',true);
    // --logic when initaially plan with valid offer come start-- //
    $(document).ready(function () {
        var offstatus = '{{$initailActiveOfferSttaus}}';
        if(offstatus==1){
            $('#if_offer_exists').show().find('#offer').attr('disabled',false);
            $('#if_offer_doesnot_exists').hide();
        }else{
            $('#if_offer_exists').hide().find('#offer').attr('disabled',true);
            $('#if_offer_doesnot_exists').show();
            generatePlanDetailsOnNoOffer();
        }
    });

    function generatePlanDetailsOnNoOffer() {
        var planPrice = $("#seller_plan_request").find(':selected').attr('data-planprice');
        var planDuration = $("#seller_plan_request").find(':selected').attr('data-planduration');
        $('#plan_pri').val(planPrice).attr('disabled',true);
        $('#plan_dur').val(planDuration).attr('disabled',true);
    }
    // --logic when initaially plan with valid offer come end-- //

    $('#offer').change(getOfferDetails);

    function getOfferDetails(){
        $("#offered_price").val('');
        if($('#offer option:selected').val()){

            var offeredPrice = $("#offer").find(':selected').attr('data-offerplanNewPrice');
            var planprice = $("#offer").find(':selected').attr('data-offerplanPrice');
            var planDuration = $("#offer").find(':selected').attr('data-offerplanDuration');

            $("#offered_price").val(offeredPrice).attr('disabled',true);
            $("#if_offer_pre_plan_detail").html('* Plan details ' +planprice+' for '+planDuration);  
        }else{
            $("#if_offer_pre_plan_detail").html('* Plan details');
            $("#offered_price").val('').attr('disabled',false);
        }
    }

    // -this will trigger when you select new plan, then it bring offer of that plan start- //
    $("#seller_plan_request").change(generateOffer);

    function generateOffer(){
        var plancurrency = $("#seller_plan_request").find(':selected').attr('data-plancurrencyid');
        $('#seller_currency').val(plancurrency).attr('disabled',true);
        var id = $('#seller_plan_request option:selected').val();
         $.ajax({
              type: "POST",
              data: { "_token": "{{ csrf_token() }}","id": id },
              url: '{{url("shop/get-offers-of-selected-plan")}}',
              dataType: 'json',
              success: function (result){
                  if(result.value==true)
                  {
                    $('#if_offer_exists').show().find('#offer').attr('disabled',false);
                    $('#if_offer_doesnot_exists').hide();
                    getOfferDetails();
                  }
                  else
                  {
                    $('#if_offer_exists').hide().find('#offer').attr('disabled',true);
                    $('#if_offer_doesnot_exists').show();
                    generatePlanDetailsOnNoOffer();
                  }
                  $("#if_offer_pre_plan_detail").html('* Plan details');
                  $("#offered_price").val('').attr('disabled',false);
                  $('#offer').html(result.result);
                  $('#seller_currency').val(plancurrency);
              }
        });
    }
    // -this will trigger when you select new plan, then it bring offer of that plan end- //

    $(document).ready(function () {

        function colorCodeSelect(state) {
                var colorCode = $(state.element).val();
                if (!colorCode) return state.text;
                return "<span class='color-preview' style='background-color:" + colorCode + ";'></span>" + state.text;
            }
    });

    $('#exampleInputPassword ,#exampleRepeatPassword').on('keyup',function () {
        var pass = $("#exampleInputPassword").val();
        var passRepeat = $("#exampleRepeatPassword").val();
        if (pass==passRepeat){
            $('.pass').hide();
        }
        else{
            $('.pass').show();
        }
    });
    $('#apply').on('click',function () {

        var image = $("#image-set").val();
        if (image=="")
        {
            $('.image').show();
            return false;
        }
        var pass = $("#exampleInputPassword").val();
        var passRepeat = $("#exampleRepeatPassword").val();
        if (pass!=passRepeat){
            $('.pass').show();
            return false;
        }


    });

    $('#shop_name').on('change',function () {
        var shopName = $("#shop_name").val();
        $("#ac_holder_name").val(shopName);
    });

    function Validate(file) {
        var x;
        var le = file.length;
        var poin = file.lastIndexOf(".");
        var accu1 = file.substring(poin, le);
        var accu = accu1.toLowerCase();
        if ((accu != '.png') && (accu != '.jpg') && (accu != '.jpeg')) {
            x = 1;
            return x;
        } else {
            x = 0;
            return x;
        }
    }

    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#viewer').attr('src', e.target.result);
            }

            reader.readAsDataURL(input.files[0]);
        }
    }

    $("#customFileUpload").change(function () {
        readURL(this);
    });

    function readlogoURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#viewerLogo').attr('src', e.target.result);
            }

            reader.readAsDataURL(input.files[0]);
        }
    }

    function readBannerURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#viewerBanner').attr('src', e.target.result);
            }

            reader.readAsDataURL(input.files[0]);
        }
    }

    $("#LogoUpload").change(function () {
        readlogoURL(this);
    });
    $("#BannerUpload").change(function () {
        readBannerURL(this);
    });
</script>
@endpush
