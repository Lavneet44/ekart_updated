

<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required Meta Tags Always Come First -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Title -->
    <title>{{\App\CPU\translate('one_time_change_password')}}</title>

    <!-- Favicon -->
    <link rel="shortcut icon" href="favicon.ico">

    <!-- Font -->
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&amp;display=swap" rel="stylesheet">
    <!-- CSS Implementing Plugins -->
    <link rel="stylesheet" href="{{asset('public/assets/back-end')}}/css/vendor.min.css">
    <link rel="stylesheet" href="{{asset('public/assets/back-end')}}/vendor/icon-set/style.css">
    <!-- CSS Front Template -->
    <link rel="stylesheet" href="{{asset('public/assets/back-end')}}/css/theme.minc619.css?v=1.0">
    <link rel="stylesheet" href="{{asset('public/assets/back-end')}}/css/toastr.css">
</head>

<body>
<!-- ========== MAIN CONTENT ========== -->
<main id="content" role="main" class="main">
    <div class="position-fixed top-0 right-0 left-0 bg-img-hero"
         style="height: 32rem; background-image: url({{asset('public/assets/admin')}}/svg/components/abstract-bg-4.svg);">
        <!-- SVG Bottom Shape -->
        <figure class="position-absolute right-0 bottom-0 left-0">
            <svg preserveAspectRatio="none" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 1921 273">
                <polygon fill="#fff" points="0,273 1921,273 1921,0 "/>
            </svg>
        </figure>
        <!-- End SVG Bottom Shape -->
    </div>

    <!-- Content -->
    <div class="container py-5 py-sm-7">
        @php($e_commerce_logo=\App\Model\BusinessSetting::where(['type'=>'company_web_logo'])->first()->value)
        <a class="d-flex justify-content-center mb-5" href="javascript:">
            <img class="z-index-2"  src="{{asset("storage/app/public/company/".$e_commerce_logo)}}" alt="Logo"
                 onerror="this.src='{{asset('public/assets/back-end/img/400x400/img2.jpg')}}'"
                 style="width: 8rem;">
        </a>

        <div class="row justify-content-center">
            <div class="col-lg-8 col-md-10">
                <h2 class="h3 mb-4">{{\App\CPU\translate('one_time_change_password')}}</h2>
                <p class="font-size-md">{{\App\CPU\translate('follow_steps')}}</p>
                <ol class="list-unstyled font-size-md">
                    <li><span class="text-primary mr-2">1.</span>{{\App\CPU\translate('please_reset_one_time_password_with_your_own_password')}}.</li>
                </ol>
                <div class="card py-2 mt-4">
                    <form class="card-body needs-validation" id="onetimepassword" action="{{route('seller.auth.reset-one-time-password')}}"
                          method="post">
                        @csrf    
                        <input class="form-control" type="hidden" name="email" id="email" value="{{$velidseller->email}}">
                        <input class="form-control" type="hidden" name="id" value="{{$velidseller->id}}">
                      <div class="form-row">
                        <div class="col-12">
                            <label for="recover-email">{{\App\CPU\translate('Your Email ID')}}</label>
                            <input class="form-control" type="email" value="{{$velidseller->email}}" disabled>
                        </div>
                        <!-- <div class="col-12 mt-2">
                            <label for="recover-email">{{\App\CPU\translate('Enter your one time password')}}</label>
                            <input class="form-control pass" type="password" name="onetimepassword" id="onetimepassword" required>
                        </div> -->
                        <div class="col-sm-6 mt-2">
                            <label for="recover-email">{{\App\CPU\translate('Enter new password')}}</label>
                            <input class="form-control pass" type="password" name="newpassword" id="newpassword" required>
                        </div>
                        <div class="col-6 mt-2">
                            <label for="recover-email">{{\App\CPU\translate('Enter confirm password')}}</label>
                            <input class="form-control pass" type="password" name="conformpassword" id="conformpassword" required>
                        </div>
                        <div class="invalid-feedback">{{\App\CPU\translate('Please provide valid email address')}}.</div>
                        <div class="col-2 mt-6">
                            <button class="btn btn-primary btn-lg" id="resetpassword" type="submit">{{\App\CPU\translate('Reset password')}}</button>
                        </div>
                        <div class="col-8 mt-2"></div>
                        <div class="col-1 mt-10">
                            <button class="btn btn-outline-secondary show" type="button" value="show" id="toggle-password">{{\App\CPU\translate('SHOW')}}</button>
                        </div>
                      </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- End Content -->
</main>
<!-- ========== END MAIN CONTENT ========== -->


<!-- JS Implementing Plugins -->
<script src="{{asset('public/assets/back-end')}}/js/vendor.min.js"></script>

<!-- JS Front -->
<script src="{{asset('public/assets/back-end')}}/js/theme.min.js"></script>
<script src="{{asset('public/assets/back-end')}}/js/toastr.js"></script>
{!! Toastr::message() !!}

@if ($errors->any())
    <script>
        @foreach($errors->all() as $error)
        toastr.error('{{$error}}', Error, {
            CloseButton: true,
            ProgressBar: true
        });
        @endforeach
    </script>
@endif

<!-- JS Plugins Init. -->
<script>
    $(document).on('click', '#toggle-password', function() {
        $(this).text(function(i, text){
          return text === "SHOW" ? "HIDE" : "SHOW";
        });
        $('.pass').map(function() {
            $(this).attr('type') === 'password' ? $(this).attr('type','text') : $(this).attr('type','password')
        });
    });

    $(document).on('ready', function () {
        $("#onetimepassword").validate({
        rules: {
                // onetimepassword: {
                //     required: true,
                // },
                newpassword: {
                    required: true,
                },
                conformpassword: {
                    required: true,
                },
        },
        messages: {
             // onetimepassword:{
             //    required: function() { toastr.error('Please Enter One Time Password available at your mail.') },
             //  },
             newpassword:{
                required: function() { toastr.error('Please Enter New-Password.') },
              },
             conformpassword:{
                required: function() { toastr.error('Please Enter Confirm-Password.') },
              },
        },
        submitHandler: function(form){
          form.submit();
        }
                 
        });
    });

    $('#conformpassword').on('change', function () {
        var conformpassword = $('#conformpassword').val();
        var newpassword = $('#newpassword').val();
        if(newpassword != conformpassword)
        {
            $('#resetpassword').attr('disabled', true);
             $("#onetimepassword").submit(function(e){
                e.preventDefault();
            });
            toastr.error('Please enter the same new password as confirm-password.')
        }
        else
        {
            $('#resetpassword').attr('disabled', false);
        }
    });
    $(document).on('ready', function () {
        // INITIALIZATION OF SHOW PASSWORD
        // =======================================================
        $('.js-toggle-password').each(function () {
            new HSTogglePassword(this).init()
        });

        // INITIALIZATION OF FORM VALIDATION
        // =======================================================
        $('.js-validate').each(function () {
            $.HSCore.components.HSValidation.init($(this));
        });
    });
</script>

<!-- IE Support -->
<script>
    if (/MSIE \d|Trident.*rv:/.test(navigator.userAgent)) document.write('<script src="{{asset('public/assets/admin')}}/vendor/babel-polyfill/polyfill.min.js"><\/script>');
</script>
</body>
</html>

