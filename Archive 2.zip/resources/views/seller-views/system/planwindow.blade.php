@extends('layouts.back-end.app-seller-plan')

@section('title', \App\CPU\translate('seller_plans'))

@push('css_or_js')
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <style>
        .grid-card {
            border: 2px solid #00000012;
            border-radius: 10px;
            padding: 10px;
        }

        .label_1 {
            /*position: absolute;*/
            font-size: 10px;
            background: #FF4C29;
            color: #ffffff;
            width: 80px;
            padding: 2px;
            font-weight: bold;
            border-radius: 6px;
            text-align: center;
        }

        .center-div {
            text-align: center;
            border-radius: 6px;
            padding: 6px;
            border: 2px solid #8080805e;
        }

    </style>

    <style type="text/css">
        section.pricing {
          background: #007bff;
          background: linear-gradient(to right, #0062E6, #33AEFF);
        }

        .pricing .card {
          border: none;
          border-radius: 1rem;
          transition: all 0.2s;
          box-shadow: 0 0.5rem 1rem 0 rgba(0, 0, 0, 0.1);
        }

        .pricing hr {
          margin: 1.5rem 0;
        }

        .pricing .card-title {
          margin: 0.5rem 0;
          font-size: 0.9rem;
          letter-spacing: .1rem;
          font-weight: bold;
        }

        .pricing .card-price {
          font-size: 1rem;
          margin: 0;
        }

        .pricing .card-price .period {
          font-size: 0.8rem;
        }

        .pricing ul li {
          margin-bottom: 1rem;
        }

        .pricing .text-muted {
          opacity: 0.7;
        }

        .pricing .btn {
          font-size: 80%;
          border-radius: 5rem;
          letter-spacing: .1rem;
          font-weight: bold;
          padding: 1rem;
          opacity: 0.7;
          transition: all 0.2s;
        }

        /* Hover Effects on Card */

        @media (min-width: 992px) {
          .pricing .card:hover {
            margin-top: -.25rem;
            margin-bottom: .25rem;
            box-shadow: 0 0.5rem 1rem 0 rgba(0, 0, 0, 0.3);
          }

          .pricing .card:hover .btn {
            opacity: 1;
          }
        }
    </style>

@endpush

@section('content')

    <div class="content container-fluid">
        <!-- Page Heading -->
        <div class="page-header pb-0" style="border-bottom: 0!important">
            <div class="flex-between row align-items-center mx-1">
                <h1 class="page-header-title">{{\App\CPU\translate('plans')}}</h1>
            </div>
        </div>


        <div class="card mb-3">
            <div class="card-body">
                <div class="flex-between row gx-2 gx-lg-3 mb-2">
                    <div style="{{Session::get('direction') === "rtl" ? 'margin-right:2px' : ''}};">
                        <h4>{{\App\CPU\translate('please_select_a_plan_to_continue')}}</h4>
                    </div>
                    <!-- <div style="width: 20vw">
                        <select class="custom-select" name="statistics_type" onchange="order_stats_update(this.value)">
                            <option
                                value="overall" {{session()->has('statistics_type') && session('statistics_type') == 'overall'?'selected':''}}>
                                {{\App\CPU\translate('Overall Statistics')}}
                            </option>
                            <option
                                value="today" {{session()->has('statistics_type') && session('statistics_type') == 'today'?'selected':''}}>
                                {{\App\CPU\translate('Todays Statistics')}}
                            </option>
                            <option
                                value="this_month" {{session()->has('statistics_type') && session('statistics_type') == 'this_month'?'selected':''}}>
                                {{\App\CPU\translate('This Months Statistics')}}
                            </option>
                        </select>
                    </div> -->
                </div>
                <div class="row gx-2 gx-lg-3" id="order_stats">
                <section class="pricing py-5" style="width: 100%;border-radius: 40px;">
                  <div class="container">
                    <div class="row">
                      <!-- Free Tier -->
                      @if(!empty($data['plan']) && count($data['plan'])>0)
                          @foreach($data['plan'] as $key => $p)
                          <div class="col-lg-4" style="margin-top: 10px;margin-bottom: 10px;">
                            <div class="card mb-5 mb-lg-0">
                              <div class="card-body">
                                <h5 class="card-title text-muted text-uppercase text-center">{{$p->title}}</h5>
                                <h1 class="card-price text-center">{{\App\CPU\BackEndHelper::set_plan_currency($p['price'],$p['currency_id'])}}/{{\App\CPU\BackEndHelper::set_plan_duration($p['duration'],$p['duration_type'])}}</h1>
                                <hr>
                                <ul class="fa-ul">
                                  <li><span class="fa-li"><i class="fas fa-check"></i></span>Allowed Products:- <b>{{$p->allowed_products}}</b></li>
                                  <li><span class="fa-li"><i class="fas fa-check"></i></span>Allowed Invoice:- <b>{{$p->allowed_invoice}}</b></li>
                                </ul>
                                <h1 class="card-price text-center">
                                    @if($p->offer_hold==1 && !empty($p->offer_startdate))
                                    <span>Offer Started From {{$p->offer_startdate}}</span>
                                    @endif
                                </h1>
                                <br/>
                                <div class="d-grid">
                                    @php $userPlan = session()->get('PlanId'); @endphp

                                    @if(in_array($p->id,$userPlan))
                                        <button type="button" class="btn btn-primary text-uppercase">Your Subscripted Plan</button>
                                    @else
                                        <a href="javascript:void(0)" data-plan-id="{{$p->id}}" onclick="buyPlan(this);" class="btn btn-primary text-uppercase">Button</a>
                                    @endif
                                </div>
                              </div>
                            </div>
                          </div>
                          @endforeach
                      @else
                          <div class="col-lg-12" style="margin-top: 10px;margin-bottom: 10px;">
                            <div class="card mb-5 mb-lg-0">
                              <div class="card-body">
                                <h5 class="card-title text-muted text-uppercase text-center">No Seller Plan available now...</h5>
                              </div>
                            </div>
                          </div>
                      @endif
                    </div>
                  </div>
                </section>
                </div>

            </div>
        </div>
    </div>

@endsection

@push('script')
    <script src="{{asset('public/assets/back-end')}}/vendor/chart.js/dist/Chart.min.js"></script>
    <script src="{{asset('public/assets/back-end')}}/vendor/chart.js.extensions/chartjs-extensions.js"></script>
    <script
        src="{{asset('public/assets/back-end')}}/vendor/chartjs-plugin-datalabels/dist/chartjs-plugin-datalabels.min.js"></script>
@endpush

@push('script_2')
    <script>
        // INITIALIZATION OF CHARTJS
        // =======================================================
        Chart.plugins.unregister(ChartDataLabels);

        $('.js-chart').each(function () {
            $.HSCore.components.HSChartJS.init($(this));
        });

        var updatingChart = $.HSCore.components.HSChartJS.init($('#updatingData'));
    </script>

    <script>
        function call_duty() {
            toastr.warning('{{\App\CPU\translate('Update your bank info first!')}}', '{{\App\CPU\translate('Warning')}}!', {
                CloseButton: true,
                ProgressBar: true
            });
        }
    </script>

    <script>
        function order_stats_update(type) {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.post({
                url: '{{route('seller.dashboard.order-stats')}}',
                data: {
                    statistics_type: type
                },
                beforeSend: function () {
                    $('#loading').show()
                },
                success: function (data) {
                    $('#order_stats').html(data.view)
                },
                complete: function () {
                    $('#loading').hide()
                }
            });
        }

        function business_overview_stats_update(type) {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.post({
                url: '{{route('admin.dashboard.business-overview')}}',
                data: {
                    business_overview: type
                },
                beforeSend: function () {
                    $('#loading').show()
                },
                success: function (data) {
                    console.log(data.view)
                    $('#business-overview-board').html(data.view)
                },
                complete: function () {
                    $('#loading').hide()
                }
            });
        }

        function buyPlan(that){
            var planId = $(that).data('plan-id');
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.post({
                url: '{{route('seller.plan.purchase-plan')}}',
                data: {
                    pid: planId
                },
                success: function (data) {
                    if (data.success==0) {
                        toastr.error('{{\App\CPU\translate('Opps! something went wrong please try again')}}', {
                                CloseButton: true,
                                ProgressBar: true
                            });
                    } else {
                        toastr.success('{{\App\CPU\translate('Plan added successfully!')}}', {
                            CloseButton: true,
                            ProgressBar: true
                        });
                        setTimeout(function(){ window.location = "{{route('seller.plan.plan-window')}}"}, 2000);
                    }
                },
            });
        }

        $(document).ready(function() {
            $('.checkplan').on('click', function(e){
                @php (!empty(session()->get('PlanId')))?$ck = 1:$ck = 0; @endphp
                if(@php echo $ck; @endphp=='0'){
                    e.preventDefault();
                    toastr.info('{{\App\CPU\translate('Please Purchase a Plan')}}', {
                        CloseButton: true,
                        ProgressBar: true
                      });
                }
            });
        });

        $(document).ready(function() {
            @php (!empty(session()->get('PlanId')))?$ck = 1:$ck = 0; @endphp
            if(@php echo $ck; @endphp=='1'){
                $('#sidemenudashboard').attr('href','{{route('seller.dashboard.index')}}');
            }
        });
    </script>
@endpush
