
@extends('layouts.back-end.app-seller')
@section('title', \App\CPU\translate('Shop Edit'))
@push('css_or_js')
    <!-- Custom styles for this page -->
    <link href="{{asset('public/assets/back-end')}}/vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
     <!-- Custom styles for this page -->
     <link href="{{asset('public/assets/back-end/css/croppie.css')}}" rel="stylesheet">
     <link href="{{ asset('public/assets/select2/css/select2forplanadmin.min.css')}}" rel="stylesheet">
     <meta name="csrf-token" content="{{ csrf_token() }}">
@endpush
@section('content')
    <!-- Content Row -->
    <div class="content container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h1 class="h3 mb-0 ">{{\App\CPU\translate('Edit Shop Info')}}</h1>
                </div>
                <div class="card-body">
                    <form action="{{route('seller.shop.update',[$shop->id])}}" method="post"
                          style="text-align: {{Session::get('direction') === "rtl" ? 'right' : 'left'}};"
                          enctype="multipart/form-data">
                        @csrf
                        <h4 class="mt-3">{{\App\CPU\translate('shop_details')}}</h4><hr/>
                        <div class="row mt-2 mb-2">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="name">{{\App\CPU\translate('Shop Name')}} <span class="text-danger">*</span></label>
                                    <input type="text" name="name" value="{{$shop->name}}" class="form-control" id="name"
                                      disabled required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="name">{{\App\CPU\translate('Shop Type')}} <span class="text-danger">*</span></label>
                                    <select class="js-example-basic-multiple js-states js-example-responsive form-control" name="shop_type" id="shop_type" required>
                                    <option value="">--{{\App\CPU\translate('select shop type')}}--</option>
                                        @foreach(\App\Model\CompanyType::get() as $ct)
                                            <option {{(!empty($shop->shop_type) && $shop->shop_type==$ct->id)?'selected':''}}  value="{{$ct->id}}">
                                                {{$ct->company_type}}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="name">{{\App\CPU\translate('Reg/Cr')}} {{\App\CPU\translate('number')}}<small class="text-danger"> *</small></label>
                                    <input type="text" name="reg_or_cr_number" value="{{$shop->reg_or_cr_number}}" class="form-control" id="reg_or_cr_number" readonly 
                                            required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="name">{{\App\CPU\translate('group')}} {{\App\CPU\translate('vat')}} {{\App\CPU\translate('number')}}<small class="text-danger"> *</small></label>
                                    <input type="number" name="group_vat" value="{{$shop->group_vat}}" class="form-control" id="group_vat"
                                            required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="name">{{\App\CPU\translate('division')}} {{\App\CPU\translate('vat')}} {{\App\CPU\translate('number')}}<small class="text-danger"> *</small></label>
                                    <input type="text" name="division_vat" value="{{$shop->division_vat}}" class="form-control" id="division_vat"
                                            required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="name">{{\App\CPU\translate('vat')}} {{\App\CPU\translate('number')}}<small class="text-danger"> *</small></label>
                                    <input type="text" name="vat_no" value="{{$shop->vat_no}}" class="form-control" 
                                    id="vat_no"
                                            required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="name">{{\App\CPU\translate('seller_currency')}}<small class="text-danger"> *</small></label>
                                    <select class="form-control form-control-user"  id="seller_currency" required>
                                        <option value="">--{{\App\CPU\translate('select_seller_currency')}}--</option>
                                        @foreach($currency as $c)
                                        <option {{($shop->seller->seller_currency==$c->id)?'selected':''}} value="{{$c->id}}">{{$c->code}} ({{$c->symbol}})--({{$c->name}})</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                        </div>
                        <input type="hidden" name="seller_currency" value="{{$shop->seller->seller_currency}}">
                        <h4 class="mt-3">{{\App\CPU\translate('shop_contact_details')}}</h4><hr/>
                        <div class="row mt-2 mb-2">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="name">{{\App\CPU\translate('telephone_number')}} </label>
                                    <input type="number" name="telephone_number" value="{{$shop->telephone_number}}" class="form-control" id="telephone_number">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="name">{{\App\CPU\translate('country_code')}} <small class="text-danger"> *</small></label>
                                    <select class="form-control form-control-user" name="country_code"  required>
                                        <option value="">--{{\App\CPU\translate('select_country_code')}}--</option>
                                        @foreach(\App\Model\CountryCode::get() as $cc)
                                        <option {{($shop->seller->country_code==$cc->id)?'selected':''}} value="{{$cc->id}}">({{$cc->iso}}) {{$cc->phonecode}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="name">{{\App\CPU\translate('mobile_number')}}  <small class="text-danger"> *</small></label>
                                    <input type="number" name="contact" value="{{$shop->contact}}" class="form-control" id="mobile_number" required>
                                </div>
                            </div>
                        </div>
                        <div class="row mt-2 mb-2">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="name">{{\App\CPU\translate('whatapp_number')}}</label>
                                    <input type="number" name="whatapp_number" value="{{$shop->whatapp_number}}" class="form-control" id="whatapp_number">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="name">{{\App\CPU\translate('shop_email')}}</label>
                                    <input type="email" name="shop_email" value="{{$shop->shop_email}}" class="form-control" id="shop_email">
                                </div>
                            </div>
                        </div>
                        <h4 class="mt-3">{{\App\CPU\translate('shop_address_details')}}</h4><hr/>
                        <div class="row mt-2 mb-2">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="name">{{\App\CPU\translate('select nation of the store')}} <small class="text-danger"> *</small></label>
                                    <select class="js-example-basic-multiple js-states js-example-responsive form-control" name="shop_country_code" id="shop_country_code" required>
                                        <option value="">--{{\App\CPU\translate('select nation of the store')}}--</option>
                                        @foreach(\App\Model\CountryCode::all() as $code)
                                            <option {{($shop->country==$code->id)?'selected':''}} value="{{$code->id}}">

                                                ({{$code->iso}}) - {{$code->phonecode}} - {{$code->name}}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="name">{{\App\CPU\translate('Address 1')}} <small class="text-danger"> *</small></label>
                                    <input type="text" name="address" value="{{($shop->address)?$shop->address:''}}" class="form-control" id="name" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="name">{{\App\CPU\translate('Address 2')}}</label>
                                    <input type="text" name="address2" value="{{($shop->address2)?$shop->address2:''}}" class="form-control" id="address2">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="name">{{\App\CPU\translate('Address 3')}}</label>
                                    <input type="text" name="address3" value="{{($shop->address3)?$shop->address3:''}}" class="form-control" id="address3" >
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="name">{{\App\CPU\translate('Address 4')}}</label>
                                    <input type="text" name="address4" value="{{($shop->address4)?$shop->address4:''}}" class="form-control" id="address4" >
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="name">{{\App\CPU\translate('Address 5')}}</label>
                                    <input type="text" name="address5" value="{{($shop->address5)?$shop->address5:''}}" class="form-control" id="address5" >
                                </div>
                            </div>
                        </div>
                        <h4 class="mt-3">{{\App\CPU\translate('shop_logo_and_banner')}}</h4><hr/>
                        <div class="row mt-2 mb-2">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="name">{{\App\CPU\translate('Upload')}} {{\App\CPU\translate('image')}}</label>
                                    <div class="custom-file text-left">
                                        <input type="file" name="image" id="customFileUpload" class="custom-file-input"
                                            accept=".jpg, .png, .jpeg, .gif, .bmp, .tif, .tiff|image/*">
                                        <label class="custom-file-label" for="customFileUpload">{{\App\CPU\translate('choose')}} {{\App\CPU\translate('file')}}</label>
                                    </div>
                                </div>
                                <div class="text-center">
                                    <img style="width: auto;border: 1px solid; border-radius: 10px; max-height:200px;" id="viewer"
                                    onerror="this.src='{{asset('public/assets/front-end/img/image-place-holder.png')}}'"
                                    src="{{asset('storage/app/public/shop/'.$shop->image)}}" alt="Product thumbnail"/>
                                </div>
                            </div>
                            <div class="col-md-6 mb-4 mt-2">
                                <div class="form-group">
                                    <div class="flex-start">
                                        <div for="name">{{\App\CPU\translate('Upload')}} {{\App\CPU\translate('Banner')}} </div>
                                        <div class="mx-1" for="ratio"><small style="color: red">{{\App\CPU\translate('Ratio')}} : ( 6:1 )</small></div>
                                    </div>
                                    <div class="custom-file text-left">
                                        <input type="file" name="banner" id="BannerUpload" class="custom-file-input"
                                               accept=".jpg, .png, .jpeg, .gif, .bmp, .tif, .tiff|image/*">
                                        <label class="custom-file-label" for="BannerUpload">{{\App\CPU\translate('choose')}} {{\App\CPU\translate('file')}}</label>
                                    </div>
                                </div>
                                <div class="text-center">
                                    <img style="width: auto; height:auto; border: 1px solid; border-radius: 10px; max-height:200px" id="viewerBanner"
                                         onerror="this.src='{{asset('public/assets/front-end/img/image-place-holder.png')}}'"
                                         src="{{asset('storage/app/public/shop/banner/'.$shop->banner)}}" alt="Product thumbnail"/>
                                </div>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-primary" id="btn_update">{{\App\CPU\translate('Update')}}</button>
                        <a class="btn btn-danger" href="{{route('seller.shop.view')}}">{{\App\CPU\translate('Cancel')}}</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
    </div>
@endsection

@push('script')
<script src="{{ asset('public/assets/select2/js/select2.min.js')}}"></script>
   <script>
    $('#seller_currency').attr('disabled',true);
        $(document).ready(function () {
            $('#seller_currency').select2({
                theme: "classic"
            }).addClass("form-control");
        });
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#viewer').attr('src', e.target.result);
                }

                reader.readAsDataURL(input.files[0]);
            }
        }

        function readBannerURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#viewerBanner').attr('src', e.target.result);
                }

                reader.readAsDataURL(input.files[0]);
            }
        }

        $("#customFileUpload").change(function () {
            readURL(this);
        });

        $("#BannerUpload").change(function () {
            readBannerURL(this);
        });
   </script>

@endpush
