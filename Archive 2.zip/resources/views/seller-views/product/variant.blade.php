@extends('layouts.back-end.app-seller')
 
@push('css_or_js')
    <link href="{{asset('public/assets/back-end/css/tags-input.min.css')}}" rel="stylesheet">
    <link href="{{ asset('public/assets/select2/css/select2.min.css')}}" rel="stylesheet">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <style type="text/css">
        
    .showdanger {
        border-color: tomato;
    }
    .showclear {
        border-color: greenyellow;
    }
    </style>
@endpush

@section('content')


    <div class="content container-fluid">
        <!-- Page Heading -->
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{route('seller.dashboard.index')}}">{{\App\CPU\translate('Dashboard')}}</a></li>
                <li class="breadcrumb-item" aria-current="page"><a href="{{route('seller.product.list')}}">{{\App\CPU\translate('Product')}}</a>
                </li>
                <li class="breadcrumb-item" aria-current="page">{{ \App\CPU\translate('Edit')}}</li>
            </ol>
        </nav>

        <!-- Content Row -->
        <div class="row d-inline-flex p-3">
            <div class="col-md-12">
                <form class="product-form" action="{{route('seller.product.update-variant',$product->id)}}" method="post"
                      enctype="multipart/form-data"
                      id="product_form">
                    @csrf
                    <input type="hidden" name="productid" value="{{ $product->id }}">
                    <div class="card">
                        <div class="card-header">
                            <h4>Product Name : {{ $product->name }}</h4>
                            <!-- @php($language=\App\Model\BusinessSetting::where('type','pnc_language')->first())
                            @php($language = $language->value ?? null)
                            @php($default_lang = 'en')

                            @php($default_lang = json_decode($language)[0])
                            <ul class="nav nav-tabs mb-4">
                                @foreach(json_decode($language) as $lang)
                                    <li class="nav-item">
                                        <a class="nav-link lang_link {{$lang == $default_lang? 'active':''}}" href="#"
                                           id="{{$lang}}-link">{{\App\CPU\Helpers::get_language_name($lang).'('.strtoupper($lang).')'}}</a>
                                    </li>
                                @endforeach
                            </ul> -->
                        </div>

                        <div class="card-body">
                            @foreach(json_decode($language) as $lang)
                                <?php
                                if (count($product['translations'])) {
                                    $translate = [];
                                    foreach ($product['translations'] as $t) {

                                        if ($t->locale == $lang && $t->key == "name") {
                                            $translate[$lang]['name'] = $t->value;
                                        }
                                        if ($t->locale == $lang && $t->key == "description") {
                                            $translate[$lang]['description'] = $t->value;
                                        }

                                    }
                                }
                                ?>
                            @endforeach

                            <div class="form-group">
                                <div class="row">
                                    <div class="col-md-12 mb-5"><span class="text-danger">* <strong>Please reassign the variants after adding or removing any modifire.</strong></span></div>
                                    <div class="col-md-12 mb-2"><h3>Modifiers</h2></div>
                                    <div class="col-md-6">

                                        <label for="colors">
                                            {{\App\CPU\translate('Colors')}} :
                                        </label>
                                        <label class="switch">
                                            <input type="checkbox" class="status"
                                                   name="colors_active" {{count(json_decode($product['colors'])) > 0 ?'checked':''}}>
                                            <span class="slider round"></span>
                                        </label>
                                        <select
                                            class="js-example-basic-multiple js-states js-example-responsive form-control"
                                            name="colors[]" multiple="multiple"
                                            id="colors-selector" {{count(json_decode($product['colors'])) == 0?'':'disabled'}}>
                                            @foreach (\App\Model\Color::orderBy('name', 'asc')->get() as $key => $color)

                                                @if($product['colors']!='null')
                                                    <option value="{{ $color->code }}" {{in_array($color->code,json_decode($product['colors'],true))?'selected':''}}>{{$color['name']}}</option>
                                                @else
                                                    <option value="{{ $color['code']}}">{{$color['name']}}</option>
                                                @endif
                                            @endforeach
                                        </select>
                                    </div>

                                    <div class="col-md-6 d-flex flex-column">
                                        <label for="attributes" style="padding-bottom: 3px">
                                            {{\App\CPU\translate('Attributes')}} :
                                        </label>
                                        <select
                                           class="js-example-basic-multiple js-states js-example-responsive form-control"
                                            name="choice_attributes[]" id="choice_attributes" multiple="multiple">
                                            @foreach (\App\Model\Attribute::orderBy('name', 'asc')->get() as $key => $a)
                                                @if($product['attributes']!='null')
                                                    <option
                                                        value="{{ $a['id']}}" {{in_array($a->id,json_decode($product['attributes'],true))?'selected':''}}>
                                                        {{$a['name']}}
                                                    </option>
                                                @else
                                                    <option value="{{ $a['id']}}">{{$a['name']}}</option>
                                                @endif
                                            @endforeach
                                        </select>
                                    </div>

                                    <div class="col-md-12 mt-2 mb-2">
                                        <div class="customer_choice_options" id="customer_choice_options">
                                            @include('seller-views.product.partials._choices',['choice_no'=>json_decode($product['attributes']),'choice_options'=>json_decode($product['choice_options'],true),'sellerItems' => $sellerItems])
                                        </div>
                                    </div>

                                    <div class="col-md-12 mt-2 mb-2" style="display: flex;align-items: center;justify-content: center;">
                                        <a href="JavaScript:void(0);" class="btn btn-danger" onclick="conformAndCallUpdateSku();">To Confirm to variant modification, click here</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card mt-2 rest-part">
                        <div class="card-header">
                            <div class="col-md-6">
                                <h4>{{\App\CPU\translate('Product price & stock')}} </h4>
                            </div>
                            <div class="col-md-6">
                                <div id="quantity">
                                    <label class="control-label">{{\App\CPU\translate('total')}}{{\App\CPU\translate('Quantity')}} </label>

                                    <input type="number" min="0" id="current_stock" name="current_stock" value="{{$product->current_stock}}" step="1" placeholder="{{\App\CPU\translate('Quantity') }}" class="form-control" required>
                                </div>                                
                            </div>
                        </div>
                        <div class="card-body">
                                <div class="row">
                                    <div class=" pt-1 col-12 sku_combination pt-4" id="sku_combination">
                                            @include('seller-views.product.partials._edit_variant',['variantsObject'=>$variantsObject,'colors_active'=>$colors_active])
                                    </div>
                                </div>
                        </div>
                        <div class="card card-footer">
                            <input type="hidden" name="productId" value="{{ $product->id }}">
                            <div class="row">
                                <div class="col-md-12" style="padding-top: 20px">
                                    @if($product['request_status'] == 2)
                                        <button type="submit"  class="btn btn-primary">{{ \App\CPU\translate('resubmit') }}</button>
                                    @else
                                        <button type="submit"  class="btn btn-primary">{{ \App\CPU\translate('update') }}</button>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>

                </form>
            </div>
        </div>
      
@endsection

@push('script')
    <script src="{{asset('public/assets/back-end')}}/js/tags-input.min.js"></script>
    <script src="{{ asset('public/assets/select2/js/select2.min.js')}}"></script>
    <script src="{{asset('public/assets/back-end/js/spartan-multi-image-picker.js')}}"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/flatpickr/4.6.13/flatpickr.min.js" integrity="sha512-K/oyQtMXpxI4+K0W7H25UopjM8pzq0yrVdFdG21Fh5dBe91I40pDd9A4lzNlHPHBIP2cwZuoxaUSX0GJSObvGA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
      <script type="text/javascript">
        $(document).ready(function() {
            $('.js-example-basic-single').select2();
        }); 
        
        function toShow_OnVarified(index)
        {
            $('.topStatus_'+index).show();
            $('.correct_'+index).show();
            $('.verify_'+index).hide();
            $('.errorblock'+index).hide();
        }
        function toHide_OnVarified(index)
        {
            $('.topStatus_'+index).hide();
            $('.cross_'+index).hide();
            $('.correct_'+index).hide();
            $('.verify_'+index).show();
            $('.errorblock'+index).show();
        }

        function CheckValidations(index)
        {
            var rowNumber = Number(index) + 1;
            var commanNote = "At Row Index ("+ rowNumber +")";
            compStartDate="";compEndDate="";meg ="";
            var price = $('#price_'+index).val();
            var sku = $('#sku_'+index).val();
            var qty = $('#qty_'+index).val();

            var disAmmount = $('#discount_'+index).val();
            var staDat = $('#startdate_'+index).val();
            var staTim = $('#starttime_'+index).val();
            var endDat = $('#enddate_'+index).val();
            var endTim = $('#endtime_'+index).val();
            compStartDate = staDat+' '+staTim;
            compEndDate = endDat+' '+endTim;

            var buyquantity = $('#buyquantity_'+index).val();
            var freequantity = $('#freequantity_'+index).val();
            var item = $('#item_'+index).val();

            errorstatus = '0'
            $('.common').removeClass('showdanger');
            meg = meg + '<td colspan="5"><ul  style="font-size: 12px;padding-left: 13px;padding-top: 5px;color: #ff5e00c7; font-size: 12px;">';

            // price validation
            if (Number(price) == 0 || Number(price) < 0 || price =="") {
                meg = meg + "<li>"+commanNote+":-Price is required field and must be higher than 0.</li>";
                $('#price_'+index).val('').addClass('showdanger');
                errorstatus = '1'
            }

            // price sku
            if (sku =="") {
                meg = meg + "<li>"+commanNote+":-Sku is required field.</li>";
                $('#sku_'+index).val('').addClass('showdanger');
                errorstatus = '1'
            }

            // Quantity validation
            if (Number(qty) == 0 || qty < 0 || qty =="") {
                meg = meg + "<li>"+commanNote+":-Quantity is required field and must be higher than 0.</li>";
                $('#qty_'+index).val('').addClass('showdanger');
                errorstatus = '1'
            }

            // discount validation
            if(disAmmount != "")
            {
                if (Number(disAmmount) < 0) {
                    meg = meg + "<li>"+commanNote+":- The Discount Amount is a positive number with value, greater than 0.</li>";
                    $('#discount_'+index).val('').addClass('showdanger');
                    errorstatus = '1'
                }
                else if (Number(disAmmount) > Number(price)) {
                    meg = meg + "<li>"+commanNote+":-The discounted price should be equal to or less than the variant price.</li>";
                    $('#discount_'+index).val('').addClass('showdanger');
                    errorstatus = '1'
                }
                else if (staDat == '')
                {
                    meg = meg + "<li>"+commanNote+":-Please fill in the Discount Start Date and time for the Vatriant.</li>";
                    $('#startdate_'+index).addClass('showdanger');
                    errorstatus = '1'
                }
                else if(staTim == '')
                {
                    meg = meg + "<li>"+commanNote+":-Please enter the Discount Start Time.</li>";
                    $('#starttime_'+index).addClass('showdanger');
                    errorstatus = '1'
                }
            }

            // end-date, end-time, start-date, start-time validation
            if(endDat != '' || endTim != '' || staDat != '' || staTim != '')
            {
                if (Number(disAmmount) < 0 || disAmmount == '') {
                    meg = meg + "<li>"+commanNote+":- The Discount Amount is a positive number with value, greater than 0.</li>";
                    $('#discount_'+index).val('').addClass('showdanger');
                    errorstatus = '1'
                }
            }

            // end-time validation
            if(endTim != '')
            {
                if (staDat == '')
                {
                    meg = meg + "<li>"+commanNote+":-Please fill in the Discount Start Date and time for the Vatriant.</li>";
                    $('#startdate_'+index).addClass('showdanger');
                    errorstatus = '1'
                }

                if(staTim == '')
                {
                    meg = meg + "<li>"+commanNote+":-Please enter the Discount Start Time.</li>";
                    $('#starttime_'+index).addClass('showdanger');
                    errorstatus = '1'
                }

                if (endDat == '')
                {
                    meg = meg + "<li>"+commanNote+":-Please enter the end date and time also.</li>";
                    $('#enddate_'+index).addClass('showdanger');
                    errorstatus = 1;
                }
            }

            // end-date validation
            if(endDat != '')
            {

                if (staDat == '')
                {
                    meg = meg + "<li>"+commanNote+":-Please fill in the Discount Start Date and time for the Vatriant.</li>";
                    $('#startdate_'+index).addClass('showdanger');
                    errorstatus = '1'
                }

                if(staTim == '')
                {
                    meg = meg + "<li>"+commanNote+":-Please enter the Discount Start Time.</li>";
                    $('#starttime_'+index).addClass('showdanger');
                    errorstatus = '1'
                }

                if (endTim == '')
                {
                    meg = meg + "<li>"+commanNote+":-Please fill in the end time.</li>";
                    $('#endtime_'+index).addClass('showdanger');
                    errorstatus = 1;
                }
            }

            // start-time validation
            if(staTim != '')
            {
                if (staDat == '')
                {
                    meg = meg + "<li>"+commanNote+":-Please enter the start date and time also.</li>";
                    $('#startdate_'+index).addClass('showdanger');
                    errorstatus = 1;
                }
            }

            // start-date validation
            if(staDat != '')
            {
                if (staTim == '')
                {
                    meg = meg + "<li>"+commanNote+":-Please fill in the start time.</li>";
                    $('#starttime_'+index).addClass('showdanger');
                    errorstatus = 1;
                }
            }


            if(compEndDate.length>0){
                if ( new Date(compStartDate.replace(/-/g,'/')) >= new Date(compEndDate.replace(/-/g,'/')) ) {
                    meg = meg + "<li>"+commanNote+":-The End Date should be greater than the Start Date.</li>";
                    $('#enddate_'+index).val('').addClass('showdanger');
                    $('#endtime_'+index).val('').addClass('showdanger');
                    errorstatus = '1'
                }
            }

            if(buyquantity != ''){
                if ( Number(buyquantity) > Number(qty) ) {
                    meg = meg + "<li>"+commanNote+":-The Buy Quantity should be smaller than Quantity.</li>";
                    $('#buyquantity_'+index).val('').addClass('showdanger');
                    errorstatus = '1'
                }
            }

            if(freequantity != ''){
                if ( buyquantity == '' ) {
                    meg = meg + "<li>"+commanNote+":-Please Fill Quantity first.</li>";
                    $('#freequantity_'+index).val('').addClass('showdanger');
                    errorstatus = '1'
                }
            }

            if(item != ''){
                if ( buyquantity == '' || freequantity == '') {
                    meg = meg + "<li>"+commanNote+":-Please Fill Buy Quantity and Free Quantity first.</li>";
                    $('#item_'+index).val('').addClass('showdanger');
                    errorstatus = '1'
                }
            }

            meg = meg + '</ul></td>';
            if(errorstatus == '1')
            {
                $("#verify_status_"+index).val('0');
                toHide_OnVarified(index);
                $("#sku-table thead tr.errorblock").html('').html(meg).show();
            }
            else
            {
                $("#verify_status_"+index).val('1');
                toShow_OnVarified(index);
                $("#sku-table thead tr.errorblock").html('').hide();
                let Quantity = $('#qty_'+index).val();
                let current_stock = $('#current_stock').val();
                current_stock = Number(current_stock)+Number(Quantity);
                $('#current_stock').val(current_stock);
            }
        }


    function checkVariant(that,keyIndex)
    {
        // -- total number of table tr, to get value of each str for comparision
        var numRows = $('.checktr').length;
        var sku=[];var skutext=[];var arrayOfStr='';var matchStatus=0;

        // -- hit row index and total num coloumn to get the newly craeted str Start
        var col = $(that).attr('data-col');
        var row = $(that).attr('data-row');
        for (var i = 0; i < col; i++) {
            let selectboxvalue = $('#'+String(row)+String(i)+' option:selected').val();
            let selectboxtextvalue = $('#'+String(row)+String(i)+' option:selected').text();
            sku[i] = selectboxvalue;
            if(selectboxtextvalue != "None")
            {
                skutext[i] = selectboxtextvalue;
            }
        }
        // -- hit row index and total num coloumn to get the newly craeted str End
        //console.log({sku});

        // (newSkuString) for hex code color
        var filteredsku = sku.filter(function(el) { return el; });
        var newSkuString = filteredsku.join([separator = '-']);
        
        var filteredskutext = skutext.filter(function(el) { return el; });
        var newSkuStringetext = filteredskutext.join([separator = '-']);

        // --check for the match of new str with other in the first tr Start
        for (var i = 0; i < numRows; i++) {
            let str = $('#strInput_'+i).val();
            if(str == newSkuString)
            {
                matchStatus = 1;
            }
        }
        // --check for the match of new str with other in the first tr End

   
        if(matchStatus)
        {
            toastr.error("This variant already exists.", { CloseButton: true, ProgressBar: true });
            // -- get the orignal value and text to reset on match str, below
            var originalResetValue = $('#data_'+keyIndex).attr('data-orignalVal');
            var originalResetText = $('#data_'+keyIndex).attr('data-orignalText');
            //x

            // -- if match the assign the original str to the modified tr row Start
            arrayOfStr = originalResetValue.split('-');
            for (var i = 0; i < col; i++) {
                let id ='#'+String(row)+String(i);
                var matchValueOfEachSelectBox = '';
                $(id+" > option").each(function() {
                    let optionValues = this.value;
                    var indexxx = jQuery.inArray(optionValues, arrayOfStr);
                    if (jQuery.inArray(optionValues, arrayOfStr) !== -1) {
                      matchValueOfEachSelectBox = optionValues;
                    }
                });

                if(matchValueOfEachSelectBox!='')
                {
                    $(id).val(matchValueOfEachSelectBox);
                }
                else
                {
                   $(id).val(''); 
                }
            }
            // -- if match the assign the original str to the modified tr row End


            //--assign reset value to str and sku inputs
            $('#strShow_'+keyIndex).val(originalResetText);
            $('#data_'+keyIndex).val(originalResetValue);
            let productName = "{{ $product->name }}";
            if(productName != '')
            {
                let skuName = productName+'-'+originalResetText;
                $('#sku_'+keyIndex).val(skuName);
            }
            //x

        }
        else
        {
            //--asign new str and sku inputs
            $('#strShow_'+keyIndex).val(newSkuStringetext);
            $('#data_'+keyIndex).val(newSkuString);
            let productName = "{{ $product->name }}";
            if(productName != '')
            {
                let skuName = productName+'-'+newSkuStringetext;
                $('#sku_'+keyIndex).val(skuName);
            }
            //x
        }
        
        // now send this string in to  the databasce and check the existance 

    }

        $(document).ready(function(){
            $('#removeRow').hide();
            $(".disquality").prop('readonly', true);
            $(".disitem").prop('readonly', true);
            
            $('.navbar-vertical-aside-has-menu').click(function(){
                var className = $(this).attr("class");
                var RequiredClass = 'show';
                if(className.indexOf(RequiredClass) != -1){
                    $(this).removeClass(RequiredClass);
                }else{
                    $(this).addClass(RequiredClass);
                }
            });

            //--functionality of variant table start--//
            // $('.comman').hide();

            $('.comman').each(function(i) {
                var ver = $(this).attr('data-verfied');
                if(ver == 1){
                    $(this).css('display','block');
                }else{
                    $(this).css('display','none');
                }
            });

            $('.checkverified').each(function(i,obj) {
                $('.correct_'+i).hide();
                $('.cross_'+i).hide();
                let verify_status = $('#verify_status_'+i).val()
                if(verify_status == 1)
                {

                    toShow_OnVarified(i);
                }
                else
                {
                    toHide_OnVarified(i);
                }
            });

            $('.common').on('change', function (){

                var index = $(this).parent().parent().data('id');
                if($('#verify_status_'+index).val() == '1')
                {
                    $('#verify_status_'+index).val('0');
                    toastr.info("Please Verify again to log this Variant Discount Parameters", {
                        CloseButton: true,
                        ProgressBar: true
                    });

                    toHide_OnVarified(index);
                }
            });
            //--functionality of variant table end--//


            //--to check the validations on click verify button
            $('.checkParametersToVarify').on('click', function(){
                //get index from verify row
                var index = $(this).parent().parent().parent().data('verifyindex');
                CheckValidations(index);
                
            });
            
        });



        $(".js-example-theme-single").select2({
            theme: "classic"
        });

        $(".js-example-responsive").select2({
            width: 'resolve'
        });

    </script>

    <script>

        function conformAndCallUpdateSku()
        {
             Swal.fire({
                    title: "Please verify the variant's changes.",
                    showConfirmButton: true,
                    showCancelButton: true,
                    confirmButtonText: "OK",
                    cancelButtonText: "Cancel",
                    icon: 'warning'
                }
                ).then((result) => {
                    let isConfirmed = result.value;
                    /* Read more about isConfirmed, isDenied below */
                    if (isConfirmed) {
                        update_sku();
                    } else
                        Swal.fire(' Cancelled', '', 'error')
          
                });
        }
        $(document).ready(function() {
            $('input[name="colors_active"]').on('change', function () {
                if (!$('input[name="colors_active"]').is(':checked')) {
                    $('#colors-selector').prop('disabled', true);
                    //comman in add page//
                } else {
                    $('#colors-selector').prop('disabled', false);
                } 
            });

            $('#choice_attributes').on('change', function () {
                $('#customer_choice_options').html(null);
                $.each($("#choice_attributes option:selected"), function () {
                    add_more_customer_choice_option($(this).val(), $(this).text());
                });
            });

            // color select select2
            $('.color-var-select').select2({
                templateResult: colorCodeSelect,
                templateSelection: colorCodeSelect,
                escapeMarkup: function (m) {
                    return m;
                }
            });

            function colorCodeSelect(state) {
                var colorCode = $(state.element).val();
                if (!colorCode) return state.text;
                return "<span class='color-preview' style='background-color:" + colorCode + ";'></span>" + state.text;
            }
        });

        function add_more_customer_choice_option(i, name) {
            let n = name.split(' ').join('');
            $('#customer_choice_options').append('<div class="row"><div class="col-md-3"><input type="hidden" name="choice_no[]" value="' + i + '"><input type="text" class="form-control" name="choice[]" value="' + n + '" placeholder="{{\App\CPU\translate('Choice Title') }}" readonly></div><div class="col-lg-9"><input type="text" class="form-control choiceclass call-update-sku" name="choice_options_' + i + '[]" placeholder="{{\App\CPU\translate('Enter choice values') }}" data-role="tagsinput"></div></div>');
            $("input[data-role=tagsinput], select[multiple][data-role=tagsinput]").tagsinput();
        }

        $(function() {
            setInterval(function () {
                $('.call-update-sku').on('change', function (e) {
                    //--update_sku() function is diabled from here and shifted to conformAndCallUpdateSku() function as this part of code call update_sku multiple time//x

                    // update_sku();
                });
            }, 2000)

            $('#colors-selector').on('change', function (e) {
                //--update_sku() function is diabled from here and shifted to conformAndCallUpdateSku() function as this part of code call update_sku multiple time//x
                
                // update_sku();
            });
        });

        function update_sku() {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            $.ajax({
                type: "POST",
                url: '{{route('seller.product.edit-sku-combination')}}',
                data: $('#product_form').serialize(),
                success: function (data) {
                    console.log({data});
                    $('#sku_combination').html(data);
                    callOnUploadSkuModified();
                    if (data.length > 1) {
                        $('#quantity').show();
                    } else {
                        $('#quantity').hide();
                    }
                }
            });
        }

        function callOnUploadSkuModified()
        {
            $('#removeRow').hide();
            $(".disquality").prop('readonly', true);
            $(".disitem").prop('readonly', true);

            //--functionality of variant table start--//
            $('.comman').hide();

            $('.checkverified').each(function(i,obj) {
                $('.correct_'+i).hide();
                $('.cross_'+i).hide();
                let verify_status = $('#verify_status_'+i).val()
                if(verify_status == 1)
                {
                    toShow_OnVarified(i);
                }
                else
                {
                    toHide_OnVarified(i);
                }
            });

            $('.common').on('change', function (){

                var index = $(this).parent().parent().data('id');
                console.log('line902');
                console.log({index});
                if($('#verify_status_'+index).val() == '1')
                {
                    $('#verify_status_'+index).val('0');
                    toastr.info("Please Verify again to log this Variant Discount Parameters", {
                        CloseButton: true,
                        ProgressBar: true
                    });

                    toHide_OnVarified(index);
                }
            });
            //--functionality of variant table end--//


            //--to check the validations on click verify button
            $('.checkParametersToVarify').on('click', function(){
                //get index from verify row
                var index = $(this).parent().parent().parent().data('verifyindex');
                CheckValidations(index);
                
            });
        }

        $(document).ready(function () {

            // color select select2
            $('.color-var-select').select2({
                templateResult: colorCodeSelect,
                templateSelection: colorCodeSelect,
                escapeMarkup: function (m) {
                    return m;
                }
            });

            function colorCodeSelect(state) {
                var colorCode = $(state.element).val();
                if (!colorCode) return state.text;
                return "<span class='color-preview' style='background-color:" + colorCode + ";'></span>" + state.text;
            }
        });
    </script>

    {{--ck editor--}}
    <script src="{{asset('/')}}vendor/ckeditor/ckeditor/ckeditor.js"></script>
    <script src="{{asset('/')}}vendor/ckeditor/ckeditor/adapters/jquery.js"></script>

    <script>
        $('#product_form').submit(function(event){

            for(var i=1;i<=numItems;i++){
                let a =  $('#startdate_'+i).val();
                let endate =  $('#enddate_'+i).val();
                    if(endate.length==0){
                         for(var j=i+1;j<=numItems;j++){
                                let b =  $('#startdate_'+j).val();
                                if(a==b){
                                $('#startdate_'+j).val('');
                                 $('#startdate_'+j).focus();
                                 swal.fire({
                                    icon: 'error',
                                    html: '<h5 style="color:red">two or more start dates without end date can not be same please assign some other date</h5>'
                                });
                                  event.preventDefault();
                                 break;
                            }
                        }
                 }
            }

            for(var i=1;i<=numItems;i++){
                let a =  $('#startdate_'+i).val();
                let c =  $('#enddate_'+i).val();
                let b = $('#discoun_amt_'+i).val();
                if(a>=c && c.length>0){
                    $('#startdate_'+i).val('');
                    $('#enddate_'+i).val('');
                    $('#startdate_'+i).focus();
                    $('#enddate_'+i).focus();
                    event.preventDefault();
                }
                if(!a){
                    $('#startdate_'+i).focus();
                    event.preventDefault();
                }
                if(!b){
                    $('#discoun_amt_'+i).focus();
                    event.preventDefault();   
                }
            }
            for (instance in CKEDITOR.instances) {
                CKEDITOR.instances[instance].updateElement();
            }
            var formData = new FormData(document.getElementById('product_form'));
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.post({
                url: '{{route('seller.product.update',$product->id)}}',
                data: formData,
                contentType: false,
                processData: false,
                success: function (data) {
                    if(data.lenght>0){
                        if (data.errors) {
                            for (var i = 0; i < data.errors.length; i++) {
                                toastr.error(data.errors[i].message, {
                                    CloseButton: true,
                                    ProgressBar: true
                                });
                            }
                        } else {
                            toastr.success('{{\App\CPU\translate('product updated successfully!')}}', {
                                CloseButton: true,
                                ProgressBar: true
                            });
                            //$('#product_form').submit();
                        }
                    }
                }
            });
        });
    </script>

    <script type="text/javascript">
    // ---------------new code 25/05/2022--------------------------------

        function resetform(formid)
        {
            $("#"+formid+' #parent_id').html('');
        }
        // ---------------end code 25/05/2022----------------- //
    </script>

    <script>
        update_qty();

        function update_qty() {
            var total_qty = 0;
            var qty_elements = $('input[name^="qty_"]');
            for (var i = 0; i < qty_elements.length; i++) {
                total_qty += parseInt(qty_elements.eq(i).val());
            }
            if (qty_elements.length > 0) {
                $('input[name="current_stock"]').attr("readonly", true);
                $('input[name="current_stock"]').val(total_qty);
            } else {
                $('input[name="current_stock"]').attr("readonly", false);
            }
        }

        $('input[name^="qty_"]').on('keyup', function () {
            var total_qty = 0;
            var qty_elements = $('input[name^="qty_"]');
            for (var i = 0; i < qty_elements.length; i++) {
                total_qty += parseInt(qty_elements.eq(i).val());
            }
            $('input[name="current_stock"]').val(total_qty);
        });

        //--code related to variant table functionality start--//

        function showDiscountParameters(index,that)
        {
            console.log({index});
            console.log({that});
            console.log("line:-1073");
            if($('#verify_status_'+index).val() == '1')
            {
                $('#topStatus_'+index).show();
            }
            else
            {
                $('#topStatus_'+index).hide();
            }

            if (!$(that).is(':checked')) {
                $('.'+index).hide();
                $('#verify_status_'+index).val(0);
            } else {
                $('.'+index).show();
                $('#verify_status_'+index).val(1);


                var totalss = $('input[name="current_stock"]').val();
                var ss = 0;
                $('.active_dis_key').each(function(){
                    var key = $(this).attr('data-main');
                    if($(this).is(':checked')){
                        if(key != index){
                            var l = $('#qty_'+key).val();
                            if(l != ''){
                                ss += (parseInt(l));    
                            }
                        }
                    }
                });
                console.log('sdfsdf '+ss);
                if(ss < totalss || ss == totalss){
                    $('#qty_'+index).val(parseInt(totalss)-parseInt(ss));
                }
                flatpickr("#startdate_"+index,{
                    //enableTime: true,
                    dateFormat: "Y-m-d",
                    minDate: "{{(!empty($startDate))?$startDate:date('Y-m-d')}}",
                });

                flatpickr("#starttime_"+index,{
                    enableTime: true,
                    noCalendar: true,
                    dateFormat: "H:i",
                });

                flatpickr("#enddate_"+index,{           
                    //enableTime: true,
                    minDate: "{{(!empty($endDate))?$endDate:date('Y-m-d')}}",
                    dateFormat: "Y-m-d",
                });
                flatpickr("#endtime_"+index,{
                    enableTime: true,
                    noCalendar: true,
                    dateFormat: "H:i",
                });
            }
        }
        //--code related to variant table functionality end--//

    </script>

    <script>
        $(".lang_link").click(function (e) {
            e.preventDefault();
            $(".lang_link").removeClass('active');
            $(".lang_form").addClass('d-none');
            $(this).addClass('active');

            let form_id = this.id;
            let lang = form_id.split("-")[0];
            console.log(lang);
            $("#" + lang + "-form").removeClass('d-none');
            if (lang == '{{$default_lang}}') {
                $(".rest-part").removeClass('d-none');
            } else {
                $(".rest-part").addClass('d-none');
            }
        })
    </script>
@endpush
