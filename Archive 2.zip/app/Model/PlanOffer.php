<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class PlanOffer extends Model
{
    protected $table = 'plan_offers';

    public function offeredPlan()
    {
        return $this->hasOne(SubscriptionPlan::class,'id','plan_id');
    }

}