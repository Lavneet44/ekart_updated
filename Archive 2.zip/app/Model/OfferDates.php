<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class OfferDates extends Model
{
    protected $table = 'offer_dates';

}