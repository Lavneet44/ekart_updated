<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class CreditPermission extends Model
{

    protected $table = 'credit_permission';

    public function customer()
    {
        return $this->hasMany(User::class,'id','customer_id');
    }
    
}
