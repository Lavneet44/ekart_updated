<?php

namespace App\Http\Controllers\Web;


use App\CPU\CartManager;
use App\CPU\Helpers;
use App\Http\Controllers\Controller;
use App\Model\Cart;
use App\Model\Color;
use App\Model\Product;
use App\Model\ProductVariant;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class CartController extends Controller
{
    public function variant_price(Request $request)
    {
        $product = Product::find($request->id);
        $str = '';
        $quantity = 0;
        $price = 0;
        $strA = [];

        if ($request->has('color')) {
            $strShow = Color::where('code', $request['color'])->first()->name;
            $str = $request['color'];
        }

        foreach (json_decode(Product::find($request->id)->choice_options) as $key => $choice) {
            if ($str != null) {
                $str .= '-' . str_replace(' ', '', $request[$choice->name]);
                $strShow .= '-' . str_replace(' ', '', $request[$choice->name]);
            } else {
                $str .= str_replace(' ', '', $request[$choice->name]);
                $strShow .= str_replace(' ', '', $request[$choice->name]);
            }
        }
        $strA = explode('-',$str);
        $result = array_filter($strA);
        $str = implode('-',$result);

        $strShowA = explode('-',$strShow);
        $result = array_filter($strShowA);
        $strShow = implode('-',$result);

        $name = $product->name.'-'.$str;
        $tax = 0;
        $discount = 0;
        $price = 0;
        $quantity = 0; 
        $verifyStatus = 0;
        $originalPrice = 0;

        if ($str != null) {
            // $count = count(json_decode($product->variation));
            // for ($i = 0; $i < $count; $i++) {
            //     if (json_decode($product->variation)[$i]->type == $str) {
                    
            //         $name = ucfirst( json_decode($product->variation)[$i]->sku ) ;
            //         $tax = Helpers::tax_calculation(json_decode($product->variation)[$i]->price, $product['tax'], $product['tax_type']);

            //         // $discount = Helpers::new_get_product_discount_detail($product, json_decode($product->variation)[$i]->price);                  
            //         // print_r(json_decode($product->variation)[$i]->price);

            //         if(Helpers::variantDiscountStatus(json_decode($product->variation)[$i]->startDuration, json_decode($product->variation)[$i]->endDuration))
            //         {
            //             $discount =json_decode($product->variation)[$i]->discount;
            //         }
            //         else
            //         {
            //            $discount =0; 
            //         }
            //         // if (!empty($dis)) {
            //         //     $discount = $dis;
            //         // }
            //         // else{
            //         //     $discount = Helpers::get_product_discount($product, $product->unit_price);
            //         // }

            //         //$price = json_decode($product->variation)[$i]->price - $discount['discount'] + $tax;

            //         $price = json_decode($product->variation)[$i]->price - $discount + $tax;
            //         $quantity = json_decode($product->variation)[$i]->qty;
            //         $verifyStatus = json_decode($product->variation)[$i]->isverified_V_Discount;
            //         $originalPrice = json_decode($product->variation)[$i]->price;
            //     }
            // }

            $variation= array();
            $variation = ProductVariant::where(['type' => $str,'product_id' => $product->id])->first();
            if(!empty($variation))
            {
                $name = ucfirst( $variation->sku ) ;
                $tax = Helpers::tax_calculation($variation->price, $product['tax'], $product['tax_type']);
                if(Helpers::variantDiscountStatus($variation->startDuration, $variation->endDuration))
                {
                    $discount = $variation->discount;
                }
                else
                {
                   $discount = 0; 
                }
                $price = (float)$variation->price - (float)$discount + (float)$tax;
                $quantity = $variation->qty;
                $verifyStatus = $variation->isverified_V_Discount;
                $originalPrice = (float)$variation->price-(float)$discount; 
                $strShow = $strShow;
            }

        } else {
            $name = ucfirst($product->name);
            $tax = Helpers::tax_calculation($product->unit_price, $product['tax'], $product['tax_type']);
            $discount = Helpers::get_product_discount($product, $product->unit_price);
            $price = (float)$product->unit_price - (float)$discount + (float)$tax;
            $quantity = $product->current_stock;
            $verifyStatus = 1;
            $originalPrice = (float)$product->unit_price - (float)filter_var($discount, FILTER_SANITIZE_NUMBER_INT);
            $strShow = $strShow;
        }

        return [
            'originalprice' => \App\CPU\Helpers::currency_converter_forfront($originalPrice,session('requested_currency_id')),
            'verifyStatus' => $verifyStatus,
            'name'          => $name,
            'price'         => \App\CPU\Helpers::currency_converter_forfront($price * $request->quantity,session('requested_currency_id')),
            'discount'      => \App\CPU\Helpers::currency_converter_forfront($discount,session('requested_currency_id')),
            'tax'           => \App\CPU\Helpers::currency_converter_forfront($tax,session('requested_currency_id')),
            'quantity'      => $quantity,
            'strShow'       => $strShow
        ];
    }
    public function variant_detail(Request $request)
    {
        $productVar = ProductVariant::where(['product_id' => $request->id,'type' => $request->variantType,'isEnable' => 1])->first();
        $product = product::where(['id' => $request->id])->first();
        $selectedelements = [];
        if(!empty($product))
        {
            $typeArray = explode('-',$request->variantType);
            $result = array_filter($typeArray);
            $orignaltype = implode('-',$result);
            if(!empty($product->colors))
            {
                $colorArray = json_decode($product->colors);
                foreach($colorArray as $colorInd => $color)
                {
                    if($color == $result[0])
                    {
                        $colorid = $product->id.'-color-'.$colorInd;
                        array_push($selectedelements,$colorid);
                    }
                }
                foreach(json_decode($product->choice_options) as $optionInd => $option)
                {
                    if(!empty($option->options))
                    {
                        foreach($option->options as $optionOptionInd => $optopt)
                        {
                            $optopt = trim($optopt);
                            if(in_array($optopt,$result))
                            {
                                $optionids = $option->name.'-'.$optopt;
                                array_push($selectedelements,$optionids);
                            }
                        }
                    }
                }
            }
        }

        $type = "";
        $discountstatus = false;
        $additionalFreeQntStatus = 0;

        if($product->discount_flag == 1)
        {
            $item = '';
            if($product->variant_product == 1)
            {
                $productDiscount=Helpers::discountDetail($product->id, $productVar->id);
                // discount come from variant
                $discount = $productDiscount['discount'];
                $butThisMuch = $productDiscount['buyquantity'];
                $freeThatMuch = $productDiscount['freequantity'];
                if(!empty($productDiscount['item']))
                {
                    $itemName = Product::active()->where('id', $productDiscount['item'])->first();
                    if(!empty($itemName))
                    {
                        $item = $itemName->name;
                    } 
                }
            }
            else
            {
                $productDiscount=Helpers::discountDetail($product->id);
                // discount come from discount table
                $discount = $productDiscount['discount'];
                $butThisMuch = $productDiscount['buy'];
                $freeThatMuch = $productDiscount['quantity'];
                if(!empty($productDiscount['item']))
                {
                    $itemName = Product::active()->where('id', $productDiscount['item'])->first();
                    if(!empty($itemName))
                    {
                        $item = $itemName->name;
                    } 
                }
            }
            if((!empty($butThisMuch) && ($butThisMuch !=0)) && (!empty($freeThatMuch) && ($freeThatMuch !=0)))
            {
                $additionalFreeQntStatus = 1;
            }
            $discountstatus = true;
        }
        else
        {
            $discount = 0;
            $butThisMuch = "";
            $freeThatMuch = "";
            $item = "";
            $additionalFreeQntStatus = 0;
            $discountstatus = false;
        }

        if (!empty($productVar)) {
            $name = ucfirst( (!empty($productVar->sku))?$productVar->sku:"N/A" ) ;
            $type = (!empty($productVar->type))?$productVar->type:"N/A" ;
            $tax = Helpers::tax_calculation($productVar->price, $product['tax'], $product['tax_type']);
            
            $price = (float)$productVar->price - (float)$discount + (float)$tax;
            $quantity = $productVar->qty;
            $verifyStatus = $productVar->verify_status;
            $originalPrice = (float)$productVar->price - (float)$discount;
            $strikePrice  = $productVar->price;

        } else {
            $name = ucfirst($product->name);
            $tax = Helpers::tax_calculation($product->unit_price, $product['tax'], $product['tax_type']);
            //$discount = Helpers::get_product_discount($product, $product->unit_price);
            //$discount = Helpers::singleDiscountForProduct($product->id);
            $price = (float)$product->unit_price - (float)$discount + (float)$tax;
            $quantity = $product->current_stock;
            $verifyStatus = 1;
            $originalPrice = (float)$product->unit_price - (float)$discount;
            $strikePrice  = $product->unit_price;
        }
        return [
            'requestedVariantType'      => $request->variantType,
            'originalprice'             => \App\CPU\Helpers::currency_converter_forfront($originalPrice,session('requested_currency_id')),
            'verifyStatus'              => $verifyStatus,
            'name'                      => $name,
            'price'                     => \App\CPU\Helpers::currency_converter_forfront($price * $request->quantity,session('requested_currency_id')),
            'discount'                  => \App\CPU\Helpers::currency_converter_forfront($discount,session('requested_currency_id')),
            'tax'                       => \App\CPU\Helpers::currency_converter_forfront($tax,session('requested_currency_id')),
            'quantity'                  => $quantity,
            'selectedelements'          => $selectedelements,
            'strikePrice'               => \App\CPU\Helpers::currency_converter_forfront($strikePrice,session('requested_currency_id')),
            'discountstatus'            => $discountstatus,
            'additionalFreeQntStatus'   => $additionalFreeQntStatus,
            'butThisMuch'               => $butThisMuch,
            'freeThatMuch'              => $freeThatMuch,
            'item'                      => $item,
        ];
    }

    public function addToCart(Request $request)
    {
        $cart = CartManager::add_to_cart($request);
        session()->forget('coupon_code');
        session()->forget('coupon_discount');
        return response()->json($cart);
    }

    public function updateNavCart()
    {
        return response()->json(['data' => view('layouts.front-end.partials.cart')->render()]);
    }

    //removes from Cart
    public function removeFromCart(Request $request)
    {
        $user = Helpers::get_customer();
        if ($user == 'offline') {
            if (session()->has('offline_cart') == false) {
                session()->put('offline_cart', collect([]));
            }
            $cart = session('offline_cart');

            $new_collection = collect([]);
            foreach ($cart as $item) {
                if ($item['id'] !=  $request->key) {
                    $new_collection->push($item);
                }
            }

            session()->put('offline_cart', $new_collection);
            return response()->json($new_collection);
        } else {
            Cart::where(['id' => $request->key, 'customer_id' => auth('customer')->id()])->delete();
        }

        session()->forget('coupon_code');
        session()->forget('coupon_discount');
        session()->forget('shipping_method_id');
        session()->forget('order_note');

        return response()->json(['data' => view('layouts.front-end.partials.cart_details')->render()]);
    }

    //updated the quantity for a cart item
    public function updateQuantity(Request $request)
    {
        $response = CartManager::update_cart_qty($request);

        session()->forget('coupon_code');
        session()->forget('coupon_discount');

        if ($response['status'] == 0) {
            return response()->json($response);
        }

        return response()->json(view('layouts.front-end.partials.cart_details')->render());
    }
}
