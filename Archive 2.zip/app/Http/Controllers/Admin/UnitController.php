<?php

namespace App\Http\Controllers\Admin;

use App\CPU\Helpers;
use App\CPU\ImageManager;
use App\Http\Controllers\Controller;
use App\Model\Admin;
use App\Model\Unit;
use App\Model\Unitallowe;
use Brian2694\Toastr\Facades\Toastr;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Model\Translation;


class UnitController extends Controller
{
    public function store(Request $request)
    {
        foreach($request->lang as $index=>$key)
        {
            if($request->name[$index] && $key != 'en')
            {
                Translation::updateOrInsert(
                    ['translationable_type'  => 'App\Model\Unit',
                        'translationable_id'    => $unit->id,
                        'locale'                => $key,
                        'key'                   => 'name'],
                    ['value'                 => $request->name[$index]]
                );
            }
        }

        $unit = new Unit;
        $unit->name = $request->name;
        $unit->symbol = $request->symbol;
        $unit->status = 1;
        $r = $unit->save();
        //---------------------------------------------------
         $colId='';
         $colName='';

        $Unitallowe = new Unitallowe;
        if(!empty($request->addUnit_product_belong_to_user)&&!empty($request->addUnit_product_belong_to_usertype))
        {
         $colId = $request->addUnit_product_belong_to_user;
         $colName = $request->addUnit_product_belong_to_usertype.'_id';
        if(!empty($request->addUnit_product_belong_to_user) && $request->addUnit_product_belong_to_usertype == "admin")
        {
            $Unitallowe->admin_id = $colId;
        }
        else
        {
            $Unitallowe->seller_id = $colId;
        }
        }
        else
        {
            $Unitallowe->admin_id =  auth('admin')->id();
            $colId = auth('admin')->id();
            $colName = 'admin_id';
        }

        $Unitallowe->unit_id = $unit->id;
        $s = $Unitallowe->save();

        if($r && $s)
        {
            
            $allowedUnitIds = Unitallowe::where([$colName => $colId,'delete_status' => 0])->pluck('unit_id');
            if(!empty($allowedUnitIds)){
                $allowedUnitIds = $allowedUnitIds->toArray();
            }else{
                $allowedUnitIds = array();
            }
            $allUnit = unit::get();
            $i=0;
            $selectedUnit = array();
            foreach ($allUnit as $key => $item) {
                if (in_array($item->id, $allowedUnitIds))
                {
                    $selectedUnit[$i] = $item;
                    $i++;
                }
            }
            $data = array('status' => 1,'unit' => $selectedUnit, 'allowedUnitIds' => $allowedUnitIds,'allUnit' => $allUnit);
            return response()->json($data);  
        }
    }

}
