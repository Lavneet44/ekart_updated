<?php

namespace App\Http\Controllers\Admin;

use App\CPU\Convert;
use App\CPU\Helpers;
use App\CPU\ImageManager;
use App\CPU\BackEndHelper;
use App\Http\Controllers\Controller;
use App\Model\Currency;
use App\Model\Order;
use App\Model\OfferDates;
use App\Model\OrderDetail;
use App\Model\Product;
use App\Model\PlanOffer;
use App\Model\Seller;
use App\Model\WithdrawRequest;
use App\Model\SellerWallet;
use App\Model\SubscriptionPlan;
use Brian2694\Toastr\Facades\Toastr;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\Model\Review;
use App\Model\OrderTransaction;
use Illuminate\Support\Facades\Validator;
use function App\CPU\translate;

class PlanController extends Controller
{
    public function plan()
    {
        // $all = session()->has('withdraw_status_filter') && session('withdraw_status_filter') == 'all' ? 1 : 0;
        // $active = session()->has('withdraw_status_filter') && session('withdraw_status_filter') == 'approved' ? 1 : 0;
        // $denied = session()->has('withdraw_status_filter') && session('withdraw_status_filter') == 'denied' ? 1 : 0;
        // $pending = session()->has('withdraw_status_filter') && session('withdraw_status_filter') == 'pending' ? 1 : 0;

        $plan_req = SubscriptionPlan::with('validOffers')->where(['plan_status' => 1])->get();
        return view('admin-views.plan.plan', compact('plan_req'));

    }

    public function offer()
    {
        $PlanOffer = new PlanOffer();
        $offerWithPlan = array();
        $offers = $PlanOffer::with('offeredPlan')
            ->whereHas('offeredPlan', function($q){ $q->where('plan_status',1); })
            ->where('offer_delete',0)
            ->orderBy('id', 'desc')
            ->latest()
            ->paginate(Helpers::pagination_limit());
        return view('admin-views.plan.offer-list', compact('offers'));

    }

    public function create()
    {
        $Currency = Currency::all();
        return view('admin-views.plan.add-plan', compact('Currency'));
    }

    public function createPlanOffer()
    {
        $Plans = SubscriptionPlan::with('planCurrency')->where(['plan_status' => 1])->orderBy('id','ASC')->get();
        return view('admin-views.plan.add-offer', compact('Plans'));
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'title' => 'required',
            'currency_id' => 'required',
            'price' => 'required|numeric',
            'duration' => 'required',
            'duration_type' => 'required|numeric',
            'allowed_products' => 'required|numeric',
            'allowed_invoice' => 'required|numeric',
            'expected_volume_of_business' => 'required|numeric',
        ], [
            'title.required' => 'Title images is required!',
            'currency_id.required' => 'Currency thumbnail is required!',
            'price.required' => 'Price  is required!',
            'duration.required' => 'Duration  is required!',
            'duration_type.required' => 'Duration Type  is required!',
            'allowed_products.required' => 'Allowed Products  is required!',
            'allowed_invoice.required' => 'Allowed Invoice is required!',
            'expected_volume_of_business.required' => 'Expected Volume Of Business is required!',
        ]);

        $sp = new SubscriptionPlan();
        $sp->title = $request->title;
        $sp->currency_id = $request->currency_id;
        $sp->price = $request->price;
        $sp->duration = $request->duration;
        $sp->duration_type = $request->duration_type;
        $sp->allowed_products = $request->allowed_products;
        $sp->allowed_invoice = $request->allowed_invoice;
        $sp->expected_volume_of_business = $request->expected_volume_of_business;
        if($request->offer_status==1){
            $sp->offer_status = $request->offer_status;
            $sp->offer_startdate = date("Y-m-d", strtotime(str_replace('/', '-', $request->offer_startdate)));
        }else{
            $sp->offer_status = 0;
            $sp->offer_startdate = NULL;
        }
        $sp->save();
        $responce = array('message'=>true);
        echo json_encode($responce);
    }

    public function storeOffer(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'offer_ammount' => 'required|numeric',
            'plan_id' => 'required|numeric',
            'offer_startdate' => 'required',
        ], [
            'offer_ammount.required' => 'Offer Ammount is required!',
            'plan_id.required' => 'Plan is required!',
            'offer_startdate.required' => 'Offer Start Date  is required!',
        ]);

        $po = new PlanOffer();
        $po->offer_title = $request->offer_title;
        $po->new_ammount = $request->offer_ammount;
        $po->plan_id = $request->plan_id;
        $po->offer_startdate = date("Y-m-d", strtotime(str_replace('/', '-', $request->offer_startdate)));
        $po->offer_enddate = NULL;
        $po->hold = 0;
        if(!empty($request->offer_enddate)){
            $po->offer_enddate = date("Y-m-d", strtotime(str_replace('/', '-', $request->offer_enddate)));
        }
        if(!empty($request->offer_hold)){
            $po->hold = $request->offer_hold;
        }
        $po->note = (!empty($request->note))?$request->note:NULL;
        $po->save();
        if(!empty($po->id)){
            if(!empty($po->offer_startdate) && !empty($po->offer_enddate)){
                $rangArray = [];
                $OfferDates = new OfferDates();
                $OfferDates->plan_offer_id = $po->id;       
                $startDate = strtotime($po->offer_startdate);
                $endDate = strtotime($po->offer_enddate);
                $i=0;
                for ($currentDate = $startDate; $currentDate <= $endDate; $currentDate += (86400)) { 
                    $date = date('Y-m-d', $currentDate);
                    $rangArray[$i]['plan_offer_id'] = $po->id;
                    $rangArray[$i]['offer_dates'] = $date;
                    //$OfferDates->save();
                    $i++;
                }
                OfferDates::insert($rangArray);
            }
            
        }
        $responce = array('message'=>true);
        echo json_encode($responce);
    }

    public function view($id)
    {
        $SubscriptionPlan = SubscriptionPlan::with(['Currency'])->where(['id' => $id])->first();
        $Currency = Currency::all();
        return view('admin-views.plan.view', compact(['SubscriptionPlan','Currency']));
    }

    public function editOffer($id)
    {
        $offer = PlanOffer::where(['id' => $id])->first();
        $SubscriptionPlans = SubscriptionPlan::with('planCurrency')->get();
        return view('admin-views.plan.edit-offer', compact('offer','SubscriptionPlans'));
    }


    public function update(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'title' => 'required',
            'currency_id' => 'required',
            'price' => 'required|numeric',
            'duration' => 'required',
            'duration_type' => 'required|numeric',
            'allowed_products' => 'required|numeric',
            'allowed_invoice' => 'required|numeric',
            'expected_volume_of_business' => 'required|numeric',
        ], [
            'title.required' => 'Title images is required!',
            'currency_id.required' => 'Currency thumbnail is required!',
            'price.required' => 'Price  is required!',
            'duration.required' => 'Duration  is required!',
            'duration_type.required' => 'Duration Type  is required!',
            'allowed_products.required' => 'Allowed Products  is required!',
            'allowed_invoice.required' => 'Allowed Invoice is required!',
            'expected_volume_of_business.required' => 'Expected Volume Of Business is required!',
        ]);

        $sp = new SubscriptionPlan();
        $sp->title = $request->title;
        $sp->currency_id = $request->currency_id;
        $sp->price = $request->price;
        $sp->duration = $request->duration;
        $sp->duration_type = $request->duration_type;
        $sp->allowed_products = $request->allowed_products;
        $sp->allowed_invoice = $request->allowed_invoice;
        $sp->expected_volume_of_business = $request->expected_volume_of_business;
        if($request->offer_status==1){
            $sp->offer_hold = $request->offer_hold;
            $sp->offer_status = $request->offer_status;
            $sp->offer_startdate = date("Y-m-d", strtotime(str_replace('/', '-', $request->offer_startdate)));
        }else{
            $sp->offer_hold = 0;
            $sp->offer_status = 0;
            $sp->offer_startdate = NULL;
        }

        SubscriptionPlan::where('id',$request->plan_id)->update($sp->toArray());
        $responce = array('message'=>true);
        echo json_encode($responce);
    }

    public function updateOffer(Request $request)
    {
        // $validator = Validator::make($request->all(), [
        //     'offer_ammount' => 'required|numeric',
        //     'plan_id' => 'required|numeric',
        //     'offer_startdate' => 'required',
        // ], [
        //     'offer_ammount.required' => 'Offer Ammount is required!',
        //     'plan_id.required' => 'Plan is required!',
        //     'offer_startdate.required' => 'Offer Start Date  is required!',
        // ]);

        $planData = PlanOffer::where('id',$request->id_offer)->first();
        $upo = new PlanOffer();
        
        // $upo->offer_title = $request->offer_title;
        // $upo->new_ammount = $request->offer_ammount;
        // $upo->plan_id = $request->plan_id;
        // $upo->offer_startdate = date("Y-m-d", strtotime(str_replace('/', '-', $request->offer_startdate)));


        $upo->offer_title = $planData->offer_title;
        $upo->new_ammount = $planData->new_ammount;
        $upo->plan_id = $planData->plan_id;
        $upo->offer_startdate = date("Y-m-d", strtotime(str_replace('/', '-', $planData->offer_startdate)));



        $upo->offer_enddate = NULL;
        $upo->hold = 0;
        if(!empty($request->offer_enddate)){
            $upo->offer_enddate = date("Y-m-d", strtotime(str_replace('/', '-', $request->offer_enddate)));
        }
        if(!empty($request->offer_hold)){
            $upo->hold = $request->offer_hold;
        }
        $upo->note = (!empty($request->note))?$request->note:NULL;
        $upo->where('id',$request->id_offer)->update($upo->toArray());

        if(!empty($request->id_offer)){
            if(!empty($upo->offer_startdate) && !empty($upo->offer_enddate)){
                $OfferDates = new OfferDates();
                OfferDates::where('plan_offer_id',$request->id_offer)->update(['disable' => 1]);
                $rangArray = array();
                $OfferDates->plan_offer_id = $request->id_offer;       
                $startDate = strtotime($upo->offer_startdate);
                $endDate = strtotime($upo->offer_enddate);
                $i=0;
                for ($currentDate = $startDate; $currentDate <= $endDate; $currentDate += (86400)) { 
                $date = date('Y-m-d', $currentDate);
                $rangArray[$i]['plan_offer_id'] = $request->id_offer;
                $rangArray[$i]['offer_dates'] = $date;
                //$OfferDates->save();
                $i++;
                }
                OfferDates::insert($rangArray);
            }
            
        }
        $responce = array('message'=>true);
        echo json_encode($responce);
    }


    public function delete($deleteId)
    {
        $check = SubscriptionPlan::where('id',$deleteId)->first()->toArray();
        if(!empty($check)){
            $ups = SubscriptionPlan::where('id',$deleteId)->update(['plan_status'=>0]);
            if($ups){
                $responce = array('message'=>true);
            }else{
                $responce = array('message'=>false);
            }  
        }else{
            $responce = array('message'=>false);
        }
        echo json_encode($responce);
    }

    public function offerDelete($deleteId)
    {
        $check = PlanOffer::where('id',$deleteId)->first()->toArray();
        if(!empty($check)){
            $ups = PlanOffer::where('id',$deleteId)->update(['offer_delete'=>1]);
            if($ups){
                $responce = array('message'=>true);
            }else{
                $responce = array('message'=>false);
            }  
        }else{
            $responce = array('message'=>false);
        }
        echo json_encode($responce);
    }
}
