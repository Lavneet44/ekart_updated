<?php

namespace App\Http\Controllers\Admin;

use App\CPU\BackEndHelper;
use App\CPU\Convert;
use App\CPU\Helpers;
use App\CPU\ImageManager;
use App\Http\Controllers\BaseController;
use App\Http\Controllers\Controller;
use App\Model\Brand;
use App\Model\Category;
use App\Model\Color;
use App\Model\DealOfTheDay;
use App\Model\FlashDealProduct;
use App\Model\ProductDiscount;
use App\Model\Product;
use App\Model\Review;
use App\Model\Translation;
use App\Model\Wishlist;
use Brian2694\Toastr\Facades\Toastr;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Rap2hpoutre\FastExcel\FastExcel;
use function App\CPU\translate;
use App\Model\Cart;
use App\Model\Unit;
use App\Model\CategoryBlock;
use App\Model\Brandallowe;
use App\Model\Unitallowe;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Session;

class ProductController extends BaseController
{
    public function add_new()
    {

        $allowedIds = CategoryBlock::where(['admin_id' => auth('admin')->id(),'delete_status' => 0])->pluck('level0_id');
        if(!empty($allowedIds)){
            $allowedIds = $allowedIds->toArray();
        }else{
            $allowedIds = array();
        }

        $allCats = Category::get();       
        $br = Brand::orderBY('name', 'ASC')->get();

        $allowedBrandIds = Brandallowe::where(['admin_id' => auth('admin')->id(),'delete_status' => 0])->pluck('brand_id');
        if(!empty($allowedBrandIds)){
            $allowedBrandIds = $allowedBrandIds->toArray();
        }else{
            $allowedBrandIds = array();
        }

       $allowedUnitIds = unitallowe::where(['admin_id' => auth('admin')->id(),'delete_status' => 0])->pluck('unit_id');
        if(!empty($allowedUnitIds)){
            $allowedUnitIds = $allowedUnitIds->toArray();
        }else{
            $allowedUnitIds = array();
        }

        $unit = Unit::orderBY('id', 'ASC')->get();

        return view('admin-views.product.add-new', compact('allCats','br','unit','allowedIds','allowedBrandIds','allowedUnitIds'));
    }

    public function featured_status(Request $request)
    {
        $product = Product::find($request->id);
        $product->featured = ($product['featured'] == 0 || $product['featured'] == null) ? 1 : 0;
        $product->save();
        $data = $request->status;
        return response()->json($data);
    }

    public function approve_status(Request $request)
    {
        $product = Product::find($request->id);
        $product->request_status = ($product['request_status'] == 0) ? 1 : 0;
        $product->save();

        return redirect()->route('admin.product.list', ['seller', 'status' => $product['request_status']]);
    }

    public function deny(Request $request)
    {
        $product = Product::find($request->id);
        $product->request_status = 2;
        $product->denied_note = $request->denied_note;
        $product->save();

        return redirect()->route('admin.product.list', ['seller', 'status' => 2]);
    }

    public function view($id)
    {
        $product = Product::with(['reviews'])->where(['id' => $id])->first();
        $rt = Helpers::new_get_product_discount_detail($product,$product->unit_price);
        if(!empty($rt))
        {
            $product->proDiscount = $rt['proDiscount'];
            $DiscountInPer = ($product->proDiscount/$product->unit_price)*100;
            $product->proDiscountPer = $DiscountInPer;   
        }
        else
        {
            $product->proDiscount = 0;
            $product->proDiscountPer = 0;
        }
        $reviews = Review::where(['product_id' => $id])->paginate(Helpers::pagination_limit());
        return view('admin-views.product.view', compact('product', 'reviews'));
    }

    public static function generateCategoryTree($category)
    {
        $user_id = auth('seller')->id();
        $html = '';
        foreach ($category as $key => $value) {
            $html.="<tr>";
                $html.="<td>".$value->name."</td>";
                // $html.="<td><img src='".url('storage/app/public/category')."/".$value->icon."' style='width:50px;'</td>";
                $html.="<td>";
                $parent = Category::where('id',$value->parent_id)->first();
                if($parent != null){
                    $html.=$parent->name;
                }
                $html.="</td>";
                $html.="<td>
                            <a class='btn btn-primary btn-sm edit' style='cursor: pointer;'
                               href='".route('admin.category.edit',[$value->id])."'>
                                <i class='tio-edit'></i>Edit
                            </a>
                            <a class='btn btn-danger btn-sm delete' style='cursor: pointer;'
                               id='".$value->id."'>
                                <i class='tio-add-to-trash'></i>Delete
                            </a>
                        </td>";
            $html.="</tr>";

            if(count($value->childes) > 0){
                    $html.=(new static)->buildChild($value->childes,1);
            }
        }
        echo $html;
    }

    public function add_brand_excel(Request $request)
    {
        // print_r($request->file());die;
        try {
            $collections = (new FastExcel)->import($request->file('excel'));
        } catch (\Exception $exception) {
            Toastr::error('You have uploaded a wrong format file, please upload the right file.');
            return back();
        }
        if(!empty($collections)){
            foreach ($collections as $key => $value) {
                $brand = Brand::where('name',$value);
                if(!$brand){
                    $brand = new Brand;
                    $brand->name = $value->Brands;
                    $brand->save();
                }
            }
            Toastr::error('Successfully Uploaded');
        }
        return back();
    }

    public function add_unit_excel(Request $request)
    {
        // print_r($request->file());die;
        try {
            $collections = (new FastExcel)->import($request->file('excel'));
        } catch (\Exception $exception) {
            Toastr::error('You have uploaded a wrong format file, please upload the right file.');
            return back();
        }
        if(!empty($collections)){
            foreach ($collections as $key => $value) {
                $brand = Unit::where('name',$value);
                if(!$brand){
                    $brand = new Unit;
                    $brand->name = $value->Unit;
                    $brand->symbol = $value->Symbol;
                    $brand->save();
                }
            }
            Toastr::error('Successfully Uploaded');
        }
        return back();
    }

    public function excel_categories_upload(Request $request)
    {
        // print_r($request->file());die;
        try {
            $collections = (new FastExcel)->import($request->file('excel_categories'));
        } catch (\Exception $exception) {
            Toastr::error('You have uploaded a wrong format file, please upload the right file.');
            return back();
        }
        if(!empty($collections)){
            foreach ($collections as $key => $value) {
                $category = Category::where('name',$value['Categories'])->where('parent_id',0)->first();
                $va = array();
                if(!$category){
                    $ca = new Category;
                    $ca->name = $value['Categories'];
                    $ca->slug = Str::slug($value['Categories']);
                    $ca->parent_id = 0;
                    $ca->home_status = 1;
                    $ca->save();
                    $exp = explode(',', $value['Subcategories']);
                    $coun = count($exp);
                    for ($i=0; $i < $coun ; $i++) { 
                        if($i == 0){
                            $sub = Category::where(['name'=>$exp[$i],'parent_id'=>$ca->id])->first();
                            if(!$sub){
                                $su = new Category;
                                $su->name = $exp[$i];
                                $su->slug = Str::slug($exp[$i]);
                                $su->parent_id = $ca->id;
                                $su->home_status = 1;
                                $su->save();
                                array_push($va, $su->id);
                            }else{
                                array_push($va,$sub->id);
                            }
                        }else{
                            $sub = Category::where(['name'=>$exp[$i],'parent_id'=>end($va)])->first();
                            if(!$sub){
                                $su = new Category;
                                $su->name = $exp[$i];
                                $su->slug = Str::slug($exp[$i]);
                                $su->parent_id = end($va);
                                $su->home_status = 1;
                                $su->save();
                                array_push($va,$su->id);
                            }else{
                                array_push($va,$sub->id);
                            }
                        }
                    }
                }else{
                    $exp = explode(',', $value['Subcategories']);
                    $coun = count($exp);
                    for ($i=0; $i < $coun ; $i++) { 
                        if($i == 0){
                            $sub = Category::where(['name'=>$exp[$i],'parent_id'=>$category->id])->first();
                            if(!$sub){
                                $su = new Category; 
                                $su->name = $exp[$i];
                                $su->slug = Str::slug($exp[$i]);
                                $su->parent_id = $category->id;
                                $su->home_status = 1;
                                $su->save();
                                array_push($va,$su->id);
                            }else{
                                array_push($va,$sub->id);
                            }
                        }else{
                            $sub = Category::where(['name'=>$exp[$i],'parent_id'=>end($va)])->first();
                            if(!$sub){
                                $su = new Category;
                                $su->name = $exp[$i];
                                $su->slug = Str::slug($exp[$i]);
                                $su->parent_id = end($va);
                                $su->home_status = 1;
                                $su->save();
                                array_push($va,$su->id);
                            }else{
                                array_push($va,$sub->id);
                            }
                        }
                    }
                }
            }
            Toastr::error('Successfully Uploaded');
        }
        return back();
    }

    public static function buildChild($child,$par)
    {
        $html = '';
        $per = $par;
        foreach ($child as $key => $value) {
            $html.="<tr>";
                $html.="<td>";
                $check = 1;
                for ($i=0; $i < $per ; $i++) { 
                    $html.="---&nbsp;&nbsp;";
                    $check = $per+1;
                }
                $html.="".$value->name."</td>";
                // $html.="<td><img src='".url('storage/app/public/category')."/".$value->icon."' style='width:50px;'></td>";
                $html.="<td>";
                $parent = Category::where('id',$value->parent_id)->first();
                if($parent != null){
                    $html.=$parent->name;
                }
                $html.="</td><td>";
                if($value->parent_id!=0){
                    $html.="<a class='btn btn-primary btn-sm edit' style='cursor: pointer;'
                           href='".route('admin.category.edit',[$value->id])."'>
                                <i class='tio-edit'></i>Edit
                            </a>
                            <a class='btn btn-danger btn-sm delete' style='cursor: pointer;'
                               id='".$value->id."'>
                                <i class='tio-add-to-trash'></i>Delete
                            </a>";
                }
                $html.="</td>";
            $html.="</tr>";
            if(count($value->childes) > 0 && $value->childes->contains('id_of_creater',auth('seller')->id())){
                    
                    // $html.= "<ul id='item_".$value->id."' class='collapse' style='list-style:none;padding-left:0;'>";
                    $html.=(new static)->buildChild($value->childes,$check);
                    // $html.= "</ul>";
            }
        }
        return $html;
    }



    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            

            //'part_no' => 'unique:products,part_no',
            'part_no' => [
                Rule::unique('products')->where(function($query) {
                  $query->where('part_no', '!=', 'NULL');
              })
            ],

            // 'serial_no' => 'unique:products,serial_no',

             'serial_no' => [
                Rule::unique('products')->where(function($query) {
                  $query->where('serial_no', '!=', 'NULL');
              })
            ],

            'name.*' => 'required|unique:products,name',
            'item_code' => 'required|unique:products,item_code',
            'name' => 'required',
            'category_id' => 'required',
            'sub_category_id' => 'required',
            // 'brand_id' => 'required',
            // 'unit' => 'required',
            'images' => 'required',
            'image' => 'required',
            'tax' => 'required|min:0',
            'unit_price' => 'required|numeric|min:1',
            'purchase_price' => 'required|numeric|min:1',
        ], [
            'name.*.required' => 'Product name is required!',
            'name.*.unique' => 'Product name must be unique!',
            'item_code.required' => 'item code is required!',
            'category_id.required' => 'category  is required!',
            'sub_category_id.required' => 'sub category  is required!',
            'images.required' => 'Product images is required!',
            'image.required' => 'Product thumbnail is required!',
            // 'brand_id.required' => 'brand  is required!',
            // 'unit.required' => 'Unit  is required!',
        ]);

        if ($request['discount_type'] == 'percent') {
            $dis = ($request['unit_price'] / 100) * $request['discount'];
        } else {
            $dis = $request['discount'];
        }

        if ($request['unit_price'] <= $dis) {
            $validator->after(function ($validator) {
                $validator->errors()->add(
                    'unit_price', 'Discount can not be more or equal to the price!'
                );
            });
        }


        $p = new Product();
        $p->user_id = auth('admin')->id();
        $p->added_by = "admin";
        $p->name = $request->name[array_search('en', $request->lang)];
             $p->item_code = $request->item_code;
        $p->part_no = $request->part_no;
         $p->serial_no = $request->serial_no;
        $p->slug = Str::slug($request->name[array_search('en', $request->lang)], '-') . '-' . Str::random(6);

        $category = [];

        if ($request->category_id != null) {
            array_push($category, [
                'id' => $request->category_id,
                'position' => 0,
            ]);
        }
        if ($request->sub_category_id != null) {
            array_push($category, [
                'id' => $request->sub_category_id,
                'position' => 1,
            ]);
        }
        if ($request->sub_sub_category_id != null) {
            array_push($category, [
                'id' => $request->sub_sub_category_id,
                'position' => 2,
            ]);
        }

        $p->category_ids = json_encode($category);
        $p->brand_id = $request->brand_id;
        $p->unit = $request->unit;
        $p->details = $request->description[array_search('en', $request->lang)];

        if ($request->has('colors_active') && $request->has('colors') && count($request->colors) > 0) {
            $p->colors = json_encode($request->colors);
        } else {
            $colors = [];
            $p->colors = json_encode($colors);
        }
        $choice_options = [];
        if ($request->has('choice')) {
            foreach ($request->choice_no as $key => $no) {
                $str = 'choice_options_' . $no;
                $item['name'] = 'choice_' . $no;
                $item['title'] = $request->choice[$key];
                $item['options'] = explode(',', implode('|', $request[$str]));
                array_push($choice_options, $item);
            }
        }
        $p->choice_options = json_encode($choice_options);
        //combinations start
        $options = [];
        if ($request->has('colors_active') && $request->has('colors') && count($request->colors) > 0) {
            $colors_active = 1;
            array_push($options, $request->colors);
        }
        if ($request->has('choice_no')) {
            foreach ($request->choice_no as $key => $no) {
                $name = 'choice_options_' . $no;
                $my_str = implode('|', $request[$name]);
                array_push($options, explode(',', $my_str));
            }
        }
        //Generates the combinations of customer choice options

        $combinations = Helpers::combinations($options);

        $variations = [];
        $stock_count = 0;
        if (count($combinations[0]) > 0) {
            foreach ($combinations as $key => $combination) {
                $str = '';
                foreach ($combination as $k => $item) {
                    if ($k > 0) {
                        $str .= '-' . str_replace(' ', '', $item);
                    } else {
                        if ($request->has('colors_active') && $request->has('colors') && count($request->colors) > 0) {
                            $color_name = Color::where('code', $item)->first()->name;
                            $str .= $color_name;
                        } else {
                            $str .= str_replace(' ', '', $item);
                        }
                    }
                }
                $item = [];
                $item['type'] = $str;
                //*********no need to convert currency as the system is runing on BHD As per client//*********//
                //$item['price'] = BackEndHelper::currency_to_usd(abs($request['price_' . str_replace('.', '_', $str)]));
                $item['price'] = abs($request['price_' . str_replace('.', '_', $str)]);
                $item['sku'] = $request['sku_' . str_replace('.', '_', $str)];
                $item['qty'] = abs($request['qty_' . str_replace('.', '_', $str)]);
                $item['discount'] = abs($request['discount_' . str_replace('.','_',$str)]);
                array_push($variations, $item);
                $stock_count += $item['qty'];
            }
        } else {
            $stock_count = (integer)$request['current_stock'];
        }

        if ($validator->errors()->count() > 0) {
            return response()->json(['errors' => Helpers::error_processor($validator)]);
        }

        //combinations end
        $p->variation = json_encode($variations);
        $p->unit_price = Convert::converToUsd($request->unit_price);
        $p->purchase_price = Convert::converToUsd($request->purchase_price);
        $p->tax = $request->tax_type == 'flat' ? BackEndHelper::currency_to_usd($request->tax) : $request->tax;
        $p->tax_type = $request->tax_type;
        $p->discount = $request->discount_type == 'flat' ? BackEndHelper::currency_to_usd($request->discount) : $request->discount;
        $p->discount_type = $request->discount_type;
        $p->attributes = json_encode($request->choice_attributes);
        $p->current_stock = abs($stock_count);

        $p->video_provider = 'youtube';
        $p->video_url = $request->video_link;
        $p->request_status = 1;
        
        $checkdiscount = $request->discoun_amt;
        if(!empty($request->discoun_amt) && ($request->discoun_amt > 0))
        {
            $ProductDiscount = new ProductDiscount();
            $ProductDiscount->discount = Convert::converToUsd($request->discoun_amt);
            $ProductDiscount->start_date = $request->start_date;
            $ProductDiscount->start_time = $request->start_time;
            $ProductDiscount->end_date = $request->end_date;
            $ProductDiscount->end_time = $request->end_time;
            $ProductDiscount->quantity = $request->quantity;
            $ProductDiscount->buy = $request->buy;
            $ProductDiscount->Item = $request->item;
        }

        if ($request->ajax()) {
            return response()->json([], 200);
        } else {
            if ($request->file('images')) {
                foreach ($request->file('images') as $img) {
                    $product_images[] = ImageManager::upload('product/', 'png', $img);
                }
                $p->images = json_encode($product_images);
            }
            $p->thumbnail = ImageManager::upload('product/thumbnail/', 'png', $request->image);

            $p->meta_title = $request->meta_title;
            $p->meta_description = $request->meta_description;
            $p->meta_image = ImageManager::upload('product/meta/', 'png', $request->meta_image);

            $p->save();

             if(!empty($checkdiscount) && ($request->discoun_amt > 0))
            {   
                $ProductDiscount->product_id = $p->id;
                $ProductDiscount->save();
            }

            $data = [];
            foreach ($request->lang as $index => $key) {
                if ($request->name[$index] && $key != 'en') {
                    array_push($data, array(
                        'translationable_type' => 'App\Model\Product',
                        'translationable_id' => $p->id,
                        'locale' => $key,
                        'key' => 'name',
                        'value' => $request->name[$index],
                    ));
                }
                if ($request->description[$index] && $key != 'en') {
                    array_push($data, array(
                        'translationable_type' => 'App\Model\Product',
                        'translationable_id' => $p->id,
                        'locale' => $key,
                        'key' => 'description',
                        'value' => $request->description[$index],
                    ));
                }
            }
            Translation::insert($data);

            Toastr::success(translate('Product added successfully!'));
            return redirect()->route('admin.product.list', ['in_house']);
        }
    }

    function list(Request $request, $type)
    {
        $query_param = [];
        $search = $request['search'];
        if ($type == 'in_house') {
            $pro = Product::where(['added_by' => 'admin']);
        } else {
            $pro = Product::where(['added_by' => 'seller'])->where('request_status', $request->status);
        }

        if ($request->has('search')) {
            $key = explode(' ', $request['search']);
            $pro = $pro->where(function ($q) use ($key) {
                foreach ($key as $value) {
                    $q->Where('name', 'like', "%{$value}%");
                }
            });
            $query_param = ['search' => $request['search']];
        }

        $request_status = $request['status'];
        $pro = $pro->orderBy('id', 'DESC')->paginate(Helpers::pagination_limit())->appends(['status' => $request['status']])->appends($query_param);
        return view('admin-views.product.list', compact('pro', 'search', 'request_status', 'type'));
    }

    public function stock_limit_list(Request $request, $type)
    {
        $stock_limit = Helpers::get_business_settings('stock_limit');
        $sort_oqrderQty = $request['sort_oqrderQty'];
        $query_param = $request->all();
        $search = $request['search'];
        if ($type == 'in_house') {
            $pro = Product::where(['added_by' => 'admin']);
        } else {
            $pro = Product::where(['added_by' => 'seller'])->where('request_status', $request->status);
        }

        if ($request->has('search')) {
            $key = explode(' ', $request['search']);
            $pro = $pro->where(function ($q) use ($key) {
                foreach ($key as $value) {
                    $q->Where('name', 'like', "%{$value}%");
                }
            });
            $query_param = ['search' => $request['search']];
        }

        $request_status = $request['status'];

        $pro = $pro->withCount('order_details')->when($request->sort_oqrderQty == 'quantity_asc', function ($q) use ($request) {
            return $q->orderBy('current_stock', 'asc');
        })
            ->when($request->sort_oqrderQty == 'quantity_desc', function ($q) use ($request) {
                return $q->orderBy('current_stock', 'desc');
            })
            ->when($request->sort_oqrderQty == 'order_asc', function ($q) use ($request) {
                return $q->orderBy('order_details_count', 'asc');
            })
            ->when($request->sort_oqrderQty == 'order_desc', function ($q) use ($request) {
                return $q->orderBy('order_details_count', 'desc');
            })
            ->when($request->sort_oqrderQty == 'default', function ($q) use ($request) {
                return $q->orderBy('id');
            })->where('current_stock', '<', $stock_limit);

        $pro = $pro->orderBy('id', 'DESC')->paginate(Helpers::pagination_limit())->appends(['status' => $request['status']])->appends($query_param);
        return view('admin-views.product.stock-limit-list', compact('pro', 'search', 'request_status', 'sort_oqrderQty'));
    }

    public function update_quantity(Request $request)
    {
        $variations = [];
        $stock_count = $request['current_stock'];
        if ($request->has('type')){
            foreach ($request['type'] as $key => $str) {
                $item = [];
                $item['type'] = $str;
                //*********no need to convert currency as the system is runing on BHD As per client//*********//
                //$item['price'] = BackEndHelper::currency_to_usd(abs($request['price_' . str_replace('.', '_', $str)]));
                $item['price'] = abs($request['price_' . str_replace('.', '_', $str)]);
                $item['sku'] = $request['sku_' . str_replace('.', '_', $str)];
                $item['qty'] = abs($request['qty_' . str_replace('.', '_', $str)]);
                array_push($variations, $item);
            }
        }

        $product = Product::find($request['product_id']);
        if ($stock_count >= 0) {
            $product->current_stock = $stock_count;
            $product->variation = json_encode($variations);
            $product->save();
            Toastr::success(\App\CPU\translate('product_quantity_updated_successfully!'));
            return back();
        } else {
            Toastr::warning(\App\CPU\translate('product_quantity_can_not_be_less_than_0_!'));
            return back();
        }
    }

    public function status_update(Request $request)
    {
        $product = Product::where(['id' => $request['id']])->first();
        $success = 1;
        if ($request['status'] == 1) {
            if ($product->added_by == 'seller' && $product->request_status == 0) {
                $success = 0;
            } else {
                $product->status = $request['status'];
            }
        } else {
            $product->status = $request['status'];
        }
        $product->save();
        return response()->json([
            'success' => $success,
        ], 200);
    }

    public function get_categories(Request $request)
    {
        $cat = Category::where(['parent_id' => $request->parent_id])->get();
        $idArray = array();
        foreach ($cat as $key => $row) {
            if ($row->id == $request->sub_category) {
                $idArray[$key] = $row;
            } else {
                $idArray[$key] = $row;
            }  
        }
        return response()->json([
            'row' => $idArray
        ]);
    }

    public function sku_combination(Request $request)
    {
        $options = [];
        if ($request->has('colors_active') && $request->has('colors') && count($request->colors) > 0) {
            $colors_active = 1;
            array_push($options, $request->colors);
        } else {
            $colors_active = 0;
        }

        $unit_price = Convert::converToUsd($request->unit_price);
        $product_name = $request->name[array_search('en', $request->lang)];

        if ($request->has('choice_no')) {
            foreach ($request->choice_no as $key => $no) {
                $name = 'choice_options_' . $no;
                $my_str = implode('', $request[$name]);
                array_push($options, explode(',', $my_str));
            }
        }

        $combinations = Helpers::combinations($options);
        return response()->json([
            'view' => view('admin-views.product.partials._sku_combinations', compact('combinations', 'unit_price', 'colors_active', 'product_name'))->render(),
        ]);
    }

    public function get_variations(Request $request){
        $product=Product::find($request['id']);
        return response()->json([
            'view'=>view('admin-views.product.partials._update_stock',compact('product'))->render()
        ]);
    }

    public function edit($id)
    {
        $product = Product::withoutGlobalScopes()->with('translations')->find($id);
        // $product->unit_price =\App\CPU\Convert::default($product->unit_price);
        // $product->purchase_price =\App\CPU\Convert::default($product->purchase_price);

         $processedDiscountArray=[];
        $i=0;
        foreach ($product->productDiscount as $key => $value) {
            if($value->status!=1){
                $disPer = ($value->discount/$product->unit_price)*100;
                $processedDiscountArray[$i]['id'] = $value->id;
                $processedDiscountArray[$i]['discount'] = $value->discount;
                $processedDiscountArray[$i]['start_date'] = $value->start_date;
                $processedDiscountArray[$i]['start_time'] = $value->start_time;
                $processedDiscountArray[$i]['end_date'] = $value->end_date;
                $processedDiscountArray[$i]['end_time'] = $value->end_time;
                $processedDiscountArray[$i]['quantity'] = $value->quantity;
                $processedDiscountArray[$i]['buy'] = $value->buy;
                $processedDiscountArray[$i]['Item'] = $value->Item;
                $processedDiscountArray[$i]['status'] = $value->status;
                //$processedDiscountArray[$i]['calculatedDiscountPersent'] = convert::default($disPer);
                $processedDiscountArray[$i]['calculatedDiscountPersent'] = $disPer;
                $i++;
            }
        }

        $product_category = json_decode($product->category_ids);
        $elementCount  = count($product_category);
        $product->colors = json_decode($product->colors);
        $categories = Category::where(['parent_id' => 0])->get();
        $allCats = Category::get();      
        $unit = Unit::orderBY('id', 'ASC')->get();
        $br = Brand::orderBY('name', 'ASC')->get();

       
        $brand_original = $product->brand;
       

        $colId = $product->user_id;
        if(!empty($product->added_by) && $product->added_by == "admin")
        {
            $colName = 'admin_id';
        }
        else
        {
            $colName = 'seller_id';
        }

        $allowedIds = CategoryBlock::where([$colName => $colId,'delete_status' => 0])->pluck('level0_id');
        if(!empty($allowedIds)){
            $allowedIds = $allowedIds->toArray();
        }else{
            $allowedIds = array();
        }


        $allowedBrandIds = Brandallowe::where([$colName => $colId,'delete_status' => 0])->pluck('brand_id');
        if(!empty($allowedBrandIds)){
            $allowedBrandIds = $allowedBrandIds->toArray();
        }else{
            $allowedBrandIds = array();
        }

        $current_unit= unit::find($product->unit);
         $allowedUnitIds = unitallowe::where([$colName => $colId,'delete_status' => 0])->pluck('unit_id');
        if(!empty($allowedUnitIds)){
            $allowedUnitIds = $allowedUnitIds->toArray();
        }else{
            $allowedUnitIds = array();
        }
   //code for get inserted catagory,subcatagory,sub-sub-catagory----start---------------------------

   //---------------------------------Catagory----------------------------------------------------     
       $inserted_catagory = category::find($product_category[0]->id);
   //---------------------------------Catagory---------------------------------------------------- 

   //---------------------------------Sub-Catagory----------------------------------------------------- 
       if(!empty($product_category[1]->id))
        $inserted_sub_catagory = category::find($product_category[1]->id);
        else
        $inserted_sub_catagory = "";
   //---------------------------------Sub-Catagory-----------------------------------------------------

   //---------------------------------sub-Sub-Catagory------------------------------------------------------
        if(!empty($product_category[2]->id))
         $inserted_sub_sub_catagory = category::find($product_category[2]->id);
        else
        $inserted_sub_sub_catagory = "";
   //---------------------------------sub-Sub-Catagory------------------------------------------------------

//end----------------------------------------------------------------------------------------------
      

        return view('admin-views.product.edit', compact('elementCount','unit','allowedIds','allowedBrandIds','allCats','categories', 'br', 'product', 'product_category','current_unit','allowedUnitIds','processedDiscountArray','brand_original','inserted_catagory','inserted_sub_catagory','inserted_sub_sub_catagory'));

    }

    public function getSellerCatdata($AdminOrSellerId=null,$AdminOrSellerType=null)
    {

        if(!empty($AdminOrSellerId) && !empty($AdminOrSellerType))
        {
            $colId = $AdminOrSellerId;
            $colName = $AdminOrSellerType.'_id';
        }
        else
        {
            $colId = auth('admin')->id();
            $colName = 'admin_id';
        }

        $allowedIds = CategoryBlock::where([$colName => $colId,'delete_status' => 0])->pluck('level0_id');
        if(!empty($allowedIds)){
            $allowedIds = $allowedIds->toArray();
        }else{
            $allowedIds = array();
        }

        $allCats = Category::get();

        $data = array('status' => 1,'allowedIds' => $allowedIds, 'allCats' => $allCats);
        return response()->json($data);
    }

    public function update(Request $request, $id)
    {
        // $validator = Validator::make($request->all(), [
        //     'name' => 'required',
        //     'category_id' => 'required',
        //     'brand_id' => 'required',
        //     'unit' => 'required',
        //     'tax' => 'required|min:0',
        //     'unit_price' => 'required|numeric|min:1',
        //     'purchase_price' => 'required|numeric|min:1',
        // ], [
        //     'name.required' => 'Product name is required!',
        //     'category_id.required' => 'category  is required!',
        //     'brand_id.required' => 'brand  is required!',
        //     'unit.required' => 'Unit  is required!',
        // ]);

        $validator = Validator::make($request->all(), [
            'name' => 'required',
            'item_code' => 'required',
            'category_id' => 'required',
            'sub_category_id' => 'required',
            // 'brand_id' => 'required',
            // 'unit' => 'required',
            // 'images' => 'required',
            // 'image' => 'required',
            // 'tax' => 'required|min:0',
            'unit_price' => 'required|numeric|min:1',
            'purchase_price' => 'required|numeric|min:1',
        ], [
            'name.required' => 'Product name is required!',
            'item_code.required' => 'item code is required!',
            'category_id.required' => 'category  is required!',
            'sub_category_id.required' => 'sub category  is required!',
            'images.required' => 'Product images is required!',
            'image.required' => 'Product thumbnail is required!',
            // 'brand_id.required' => 'brand  is required!',
            // 'unit.required' => 'Unit  is required!',
        ]);

        if ($request['discount_type'] == 'percent') {
            $dis = ($request['unit_price'] / 100) * $request['discount'];
        } else {
            $dis = $request['discount'];
        }

        if ($request['unit_price'] <= $dis) {
            $validator->after(function ($validator) {
                $validator->errors()->add('unit_price', 'Discount can not be more or equal to the price!');
            });
        }

        $product = Product::find($id);
        $product->name = $request->name[array_search('en', $request->lang)];
        $product->item_code = $request->item_code;
        $product->part_no = $request->part_no;
        $product->serial_no = $request->serial_no;
       
        $category = [];
        if ($request->category_id != null) {
            array_push($category, [
                'id' => $request->category_id,
                'position' => 0,
            ]);
        }
        if ($request->sub_category_id != null) {
            array_push($category, [
                'id' => $request->sub_category_id,
                'position' => 1,
            ]);
        }
        if ($request->sub_sub_category_id != null) {
            array_push($category, [
                'id' => $request->sub_sub_category_id,
                'position' => 2,
            ]);
        }
        $product->category_ids = json_encode($category);
        $product->brand_id = $request->brand_id;
        $product->unit = $request->unit;
        $product->details = $request->description[array_search('en', $request->lang)];
        $product_images = json_decode($product->images);

        if ($request->has('colors_active') && $request->has('colors') && count($request->colors) > 0) {
            $product->colors = json_encode($request->colors);
        } else {
            $colors = [];
            $product->colors = json_encode($colors);
        }
        $choice_options = [];
        if ($request->has('choice')) {
            foreach ($request->choice_no as $key => $no) {
                $str = 'choice_options_' . $no;
                $item['name'] = 'choice_' . $no;
                $item['title'] = $request->choice[$key];
                $item['options'] = explode(',', implode('|', $request[$str]));
                array_push($choice_options, $item);
            }
        }
        $product->choice_options = json_encode($choice_options);
        $variations = [];
        //combinations start
        $options = [];
        if ($request->has('colors_active') && $request->has('colors') && count($request->colors) > 0) {
            $colors_active = 1;
            array_push($options, $request->colors);
        }
        if ($request->has('choice_no')) {
            foreach ($request->choice_no as $key => $no) {
                $name = 'choice_options_' . $no;
                $my_str = implode('|', $request[$name]);
                array_push($options, explode(',', $my_str));
            }
        }
        //Generates the combinations of customer choice options
        $combinations = Helpers::combinations($options);
        $variations = [];
        $stock_count = 0;
        if (count($combinations[0]) > 0) {
            foreach ($combinations as $key => $combination) {
                $str = '';
                foreach ($combination as $k => $item) {
                    if ($k > 0) {
                        $str .= '-' . str_replace(' ', '', $item);
                    } else {
                        if ($request->has('colors_active') && $request->has('colors') && count($request->colors) > 0) {
                            $color_name = Color::where('code', $item)->first()->name;
                            $str .= $color_name;
                        } else {
                            $str .= str_replace(' ', '', $item);
                        }
                    }
                }
                $item = [];
                $item['type'] = $str;
                //*********no need to convert currency as the system is runing on BHD As per client//*********//
                // $item['price'] = BackEndHelper::currency_to_usd(abs($request['price_' . str_replace('.', '_', $str)]));
                $item['price'] = abs($request['price_' . str_replace('.', '_', $str)]);
                $item['sku'] = $request['sku_' . str_replace('.', '_', $str)];
                $item['qty'] = abs($request['qty_' . str_replace('.', '_', $str)]);
                $item['discount'] = abs($request['discount_' . str_replace('.','_',$str)]);
                array_push($variations, $item);
                $stock_count += $item['qty'];
            }
        } else {
            $stock_count = (integer)$request['current_stock'];
        }

        if ($validator->errors()->count() > 0) {
            return response()->json(['errors' => Helpers::error_processor($validator)]);
        }

        if ($validator->fails()) {
            return back()->withErrors($validator)
                ->withInput();
        }

        //combinations end
        $product->variation = json_encode($variations);

        //$product->unit_price = BackEndHelper::currency_to_usd($request->unit_price);
        //$product->purchase_price = BackEndHelper::currency_to_usd($request->purchase_price);

       $product->unit_price = Convert::converToUsd($request->unit_price);
       $product->purchase_price = Convert::converToUsd($request->purchase_price);

        $product->tax = $request->tax == 'flat' ? BackEndHelper::currency_to_usd($request->tax) : $request->tax;
        $product->tax_type = $request->tax_type;
        // $product->discount = $request->discount_type == 'flat' ? BackEndHelper::currency_to_usd($request->discount) : $request->discount;
        $product->attributes = json_encode($request->choice_attributes);
        // $product->discount_type = $request->discount_type;
        $product->current_stock = abs($stock_count);


        $product->video_provider = 'youtube';
        $product->video_url = $request->video_link;
        if ($product->added_by == 'seller' && $product->request_status == 2) {
            $product->request_status = 1;
        }

        if ($request->ajax()) {
            return response()->json([], 200);
        } else {
            if ($request->file('images')) {
                foreach ($request->file('images') as $img) {
                    $product_images[] = ImageManager::upload('product/', 'png', $img);
                }
                $product->images = json_encode($product_images);
            }

            if ($request->file('image')) {
                $product->thumbnail = ImageManager::update('product/thumbnail/', $product->thumbnail, 'png', $request->file('image'));
            }

            $product->meta_title = $request->meta_title;
            $product->meta_description = $request->meta_description;
            if ($request->file('meta_image')) {
                $product->meta_image = ImageManager::update('product/meta/', $product->meta_image, 'png', $request->file('meta_image'));
            }

            $product->save();

            $disco=$request->discount_amt;
            if(!empty($disco))
            {
                 $answers = [];
                ProductDiscount::where("product_id", $product->id)->update(["status" => 1]);
                 for ($i = 0; $i < count($disco); $i++) {
                      if($disco[$i] > 0)
                    {
                        $answers[] = [
                            'product_id'    => $product->id,
                            'discount'      => Convert::converToUsd($disco[$i]),
                            'start_date'    => $request->startdate[$i],
                            'start_time'    => $request->starttime[$i],
                            'end_date'      => $request->enddate[$i],
                            'end_time'      => $request->endtime[$i],
                            'quantity'      => $request->quantity[$i],
                            'Buy'           => $request->buy[$i],
                            'Item'          => $request->item[$i],
                        ];
                    }
                 }
                 if(count($answers) > 0){
                ProductDiscount::insert($answers);
              }
            }

            foreach ($request->lang as $index => $key) {
                if ($request->name[$index] && $key != 'en') {
                    Translation::updateOrInsert(
                        ['translationable_type' => 'App\Model\Product',
                            'translationable_id' => $product->id,
                            'locale' => $key,
                            'key' => 'name'],
                        ['value' => $request->name[$index]]
                    );
                }
                if ($request->description[$index] && $key != 'en') {
                    Translation::updateOrInsert(
                        ['translationable_type' => 'App\Model\Product',
                            'translationable_id' => $product->id,
                            'locale' => $key,
                            'key' => 'description'],
                        ['value' => $request->description[$index]]
                    );
                }
            }
            Toastr::success('Product updated successfully.');
            return back();
        }
    }

    public function remove_image(Request $request)
    {
        ImageManager::delete('/product/' . $request['image']);
        $product = Product::find($request['id']);
        $array = [];
        if (count(json_decode($product['images'])) < 2) {
            Toastr::warning('You cannot delete all images!');
            return back();
        }
        foreach (json_decode($product['images']) as $image) {
            if ($image != $request['name']) {
                array_push($array, $image);
            }
        }
        Product::where('id', $request['id'])->update([
            'images' => json_encode($array),
        ]);
        Toastr::success('Product image removed successfully!');
        return back();
    }

    public function delete($id)
    {
        $product = Product::find($id);

        $translation = Translation::where('translationable_type', 'App\Model\Product')
            ->where('translationable_id', $id);
        $translation->delete();

        Cart::where('product_id', $product->id)->delete();
        Wishlist::where('product_id', $product->id)->delete();

        foreach (json_decode($product['images'], true) as $image) {
            ImageManager::delete('/product/' . $image);
        }
        ImageManager::delete('/product/thumbnail/' . $product['thumbnail']);
        $product->delete();

        FlashDealProduct::where(['product_id' => $id])->delete();
        DealOfTheDay::where(['product_id' => $id])->delete();

        Toastr::success('Product removed successfully!');
        return back();
    }

    public function bulk_import_index()
    {
        return view('admin-views.product.bulk-import');
    }

    public function bulk_import_data(Request $request)
    {
        try {
            $collections = (new FastExcel)->import($request->file('products_file'));
        } catch (\Exception $exception) {
            Toastr::error('You have uploaded a wrong format file, please upload the right file.');
            return back();
        }

        $data = [];
         $skip = ['youtube_video_url','details','unit','part_no','serial_no','brand_id','sub_sub_category_id','discount','discount_type',];;
        foreach ($collections as $collection) {
            foreach ($collection as $key => $value) {
                if ($value === "" && !in_array($key, $skip)) {
                    Toastr::error('Please fill ' . $key . ' fields');
                    return back();
                }
            }

            // $thumbnail = explode('/', $collection['thumbnail']);

            array_push($data, [
                'name' => $collection['name'],
                'item_code' => $collection['item_code'],
                'part_no' => $collection['part_no'],
                'serial_no' => $collection['serial_no'],
                'slug' => Str::slug($collection['name'], '-') . '-' . Str::random(6),
                'category_ids' => json_encode([['id' => $collection['category_id'], 'position' => 0], ['id' => $collection['sub_category_id'], 'position' => 1], ['id' => $collection['sub_sub_category_id'], 'position' => 2]]),
                'brand_id' => $collection['brand_id'],
                'unit' => $collection['unit'],
                'min_qty' => $collection['min_qty'],
                'refundable' => $collection['refundable'],
                'unit_price' => Convert::converToUsd($collection['unit_price']),
                'purchase_price' =>  Convert::converToUsd($collection['purchase_price']),
                'tax' => $collection['tax'],
                // 'discount' => $collection['discount'],
                // 'discount_type' => $collection['discount_type'],
                'current_stock' => $collection['current_stock'],
                'details' => $collection['details'],
                'video_provider' => 'youtube',
                'video_url' => $collection['youtube_video_url'],
                'images' => json_encode(['def.png']),
                // 'thumbnail' => $thumbnail[1],
                'status' => 1,
                'request_status' => 1,
                'colors' => json_encode([]),
                'attributes' => json_encode([]),
                'choice_options' => json_encode([]),
                'variation' => json_encode([]),
                'featured_status' => 1,
                'added_by' => 'admin',
                'user_id' => auth('admin')->id(),
            ]);
        }
        DB::table('products')->insert($data);
        Toastr::success(count($data) . ' - Products imported successfully!');
        return back();
    }

    public function bulk_export_data()
    {
        $products = Product::where(['added_by' => 'admin'])->get();
        //export from product
        $storage = [];
        foreach ($products as $item) {
            $category_id = 0;
            $sub_category_id = 0;
            $sub_sub_category_id = 0;
            foreach (json_decode($item->category_ids, true) as $category) {
                if ($category['position'] == 0) {
                    $category_id = $category['id'];
                } else if ($category['position'] == 1) {
                    $sub_category_id = $category['id'];
                } else if ($category['position'] == 2) {
                    $sub_sub_category_id = $category['id'];
                }
            }
            $storage[] = [
                'name' => $item->name,
                'item_code' => $item->item_code,
                'part_no' => $item->part_no,
                'serial_no' => $item->serial_no,
                'category_id' => $category_id,
                'sub_category_id' => $sub_category_id,
                'sub_sub_category_id' => $sub_sub_category_id,
                'brand_id' => $item->brand_id,
                'unit' => $item->unit,
                'min_qty' => $item->min_qty,
                'refundable' => $item->refundable,
                'youtube_video_url' => $item->video_url,
                'unit_price' => $item->unit_price,
                'purchase_price' => $item->purchase_price,
                'tax' => $item->tax,
                'discount' => $item->discount,
                'discount_type' => $item->discount_type,
                'current_stock' => $item->current_stock,
                'details' => $item->details,
                'thumbnail' => 'thumbnail/'.$item->thumbnail,
            ];
        }
        return (new FastExcel($storage))->download('inhouse_products.xlsx');
    }

    // new add method 30/05/2022 start

    public function get_child(Request $request)
    {
        $cat = Category::where(['parent_id' => $request->parent_id])->get();
        return response()->json([
            'row' => $cat
        ]);
    }

   public function getlatestbrand($selectedBrands_belong_to_user = Null ,$selectedBrands_belong_to_usertype = Null){
        
        if(!empty($selectedBrands_belong_to_user)&&!empty($selectedBrands_belong_to_usertype))
        {
        $colId = $selectedBrands_belong_to_user;
        $colName = $selectedBrands_belong_to_usertype.'_id';
        }
        else
        {
        $colId = auth('admin')->id();
        $colName =  "admin_id";
        }

        $allowedBrandIds = Brandallowe::where([$colName => $colId,'delete_status' => 0])->pluck('brand_id');
            if(!empty($allowedBrandIds)){
                $allowedBrandIds = $allowedBrandIds->toArray();
            }else{
                $allowedBrandIds = array();
            }

            $allBrand = Brand::get();

            $i=0;
            $selectedBrands = array();
            foreach ($allBrand as $key => $item) {
                if (in_array($item->id, $allowedBrandIds))
                {
                    $selectedBrands[$i] = $item;
                    $i++;
                }
            }
            $data = array('status' => 1,'brand' => $selectedBrands, 'allowedBrandIds' => $allowedBrandIds,'allBrand' => $allBrand);
            return response()->json($data);
    }

    

    public function selected_brands(Request $request)
    {
          $colId = $request->selectedBrand_belong_to_user;
          $colName = $request->selectedBrand_belong_to_usertype.'_id';

        Brandallowe::where([$colName => $colId])->update(['delete_status' => 1]);
        $idcat = $idsubcat = $idsubsubcat = '';
        foreach ($request->checkboxs as $key => $value) {
            $Brandallowe = new Brandallowe;

            if(!empty($request->selectedBrand_belong_to_user) && $request->selectedBrand_belong_to_usertype == "admin")
            {
                $Brandallowe->admin_id = $colId;
            }
            else
            {
                $Brandallowe->seller_id = $colId;
            }
            $Brandallowe->brand_id = $value;
            $Brandallowe->save();
        }

        $allowedBrandIds = Brandallowe::where([$colName => $colId,'delete_status' => 0])->pluck('brand_id');
        if(!empty($allowedBrandIds)){
            $allowedBrandIds = $allowedBrandIds->toArray();
        }else{
            $allowedBrandIds = array();
        }


        $allBrand = Brand::get();

        $i=0;
        $selectedBrands = array();
        foreach ($allBrand as $key => $item) {
            if (in_array($item->id, $allowedBrandIds))
            {
                $selectedBrands[$i] = $item;
                $i++;
            }
        }
        
        $data = array('status' => 1,'brand' => $selectedBrands);
        return response()->json($data); 
    }
     public function selected_brands_forAdd(Request $request)
    {
        Brandallowe::where(['admin_id' => auth('admin')->id()])->update(['delete_status' => 1]);
        $idcat = $idsubcat = $idsubsubcat = '';
        foreach ($request->checkboxs as $key => $value) {
            $Brandallowe = new Brandallowe;
            $Brandallowe->admin_id = auth('admin')->id();
            $Brandallowe->brand_id = $value;
            $Brandallowe->save();
        }

        $allowedBrandIds = Brandallowe::where(['admin_id' => auth('admin')->id(),'delete_status' => 0])->pluck('brand_id');
        if(!empty($allowedBrandIds)){
            $allowedBrandIds = $allowedBrandIds->toArray();
        }else{
            $allowedBrandIds = array();
        }


        $allBrand = Brand::get();

        $i=0;
        $selectedBrands = array();
        foreach ($allBrand as $key => $item) {
            if (in_array($item->id, $allowedBrandIds))
            {
                $selectedBrands[$i] = $item;
                $i++;
            }
        }
        
        $data = array('status' => 1,'brand' => $selectedBrands);
        return response()->json($data); 
    }
    
    public function block_ids(Request $request)
    {

        $colId = $request->product_belong_to_user;
        if(!empty($request->product_belong_to_user) && $request->product_belong_to_usertype == "admin")
        {
            $colName = 'admin_id';
        }
        else
        {
            $colName = 'seller_id';
        }


        CategoryBlock::where([$colName => $colId])->update(['delete_status' => 1]);
        $idcat = $idsubcat = $idsubsubcat = '';
        foreach ($request->checkboxs as $key => $value) {
            $CategoryBlock = new CategoryBlock;

            if(!empty($request->product_belong_to_user) && $request->product_belong_to_usertype == "admin")
            {
                $CategoryBlock->admin_id = $colId;
            }
            else
            {
                $CategoryBlock->seller_id = $colId;
            }
            
            $CategoryBlock->level0_id = $value;
            $CategoryBlock->save();
        }


        $allowedIds = CategoryBlock::where([$colName => $colId,'delete_status' => 0])->pluck('level0_id');
        $allowedIds = $allowedIds->toArray();
        $allCats = Category::get();

        foreach ($allCats as $key => $value) {
            if((in_array($value['id'], $allowedIds)) && ($value->parent_id==0)){
                $cat[$key] = $value->toArray();
            }
        }

        $data = array('status' => 1,'cat' => $cat);
        return response()->json($data);
    }    

  //----------------- start unit new method 09/06/2022-----------------

     public function selected_units(Request $request)
    {
         
        $colId = $request->selectedUnit_belong_to_user;
        $colName = $request->selectedUnit_belong_to_usertype.'_id';
        
        Unitallowe::where([$colName => $colId])->update(['delete_status' => 1]);
        $idcat = $idsubcat = $idsubsubcat = '';
        foreach ($request->checkboxs as $key => $value) {
            $Unitallowe = new Unitallowe;
            if(!empty($request->selectedUnit_belong_to_user) && $request->selectedUnit_belong_to_usertype == "admin")
            {
                $Unitallowe->admin_id = $colId;
            }
            else
            {
                $Unitallowe->seller_id = $colId;
            }
            $Unitallowe->unit_id = $value;
            $Unitallowe->save();
        }

        $allowedUnitIds = Unitallowe::where([$colName => $colId,'delete_status' => 0])->pluck('unit_id');
        if(!empty($allowedUnitIds)){
            $allowedUnitIds = $allowedUnitIds->toArray();
        }else{
            $allowedUnitIds = array();
        }


        $allUnit = unit::get();

        $i=0;
        $selectedUnits = array();
        foreach ($allUnit as $key => $item) {
            if (in_array($item->id, $allowedUnitIds))
            {
                $selectedUnits[$i] = $item;
                $i++;
            }
        }
        
        $data = array('status' => 1,'unit' => $selectedUnits);
        return response()->json($data); 
    } 

       public function selected_units_forAdd(Request $request)
    {
        Unitallowe::where(['admin_id' => auth('admin')->id()])->update(['delete_status' => 1]);
        $idcat = $idsubcat = $idsubsubcat = '';
        foreach ($request->checkboxs as $key => $value) {
            $Unitallowe = new Unitallowe;
            $Unitallowe->admin_id = auth('admin')->id();
            $Unitallowe->unit_id = $value;
            $Unitallowe->save();
        }

        $allowedUnitIds = Unitallowe::where(['admin_id' => auth('admin')->id(),'delete_status' => 0])->pluck('unit_id');
        if(!empty($allowedUnitIds)){
            $allowedUnitIds = $allowedUnitIds->toArray();
        }else{
            $allowedUnitIds = array();
        }


        $allUnit = unit::get();

        $i=0;
        $selectedUnits = array();
        foreach ($allUnit as $key => $item) {
            if (in_array($item->id, $allowedUnitIds))
            {
                $selectedUnits[$i] = $item;
                $i++;
            }
        }
        
        $data = array('status' => 1,'unit' => $selectedUnits);
        return response()->json($data); 
    } 
    
     public function getunit($selectedUnits_belong_to_user = Null,$selectedUnits_belong_to_usertype = Null){

         if(!empty($selectedUnits_belong_to_user)&&!empty($selectedUnits_belong_to_usertype))
        {
        $colId = $selectedUnits_belong_to_user;
        $colName = $selectedUnits_belong_to_usertype.'_id';
        }
        else
        {
        $colId = auth('admin')->id();
        $colName =  "admin_id";
        }

        $allowedUnitIds = Unitallowe::where([$colName => $colId,'delete_status' => 0])->pluck('unit_id');
            if(!empty($allowedUnitIds)){
                $allowedUnitIds = $allowedUnitIds->toArray();
            }else{
                $allowedUnitIds = array();
            }

            $allUnit = unit::get();

            $i=0;
            $selectedUnit = array();
            foreach ($allUnit as $key => $item) {
                if (in_array($item->id, $allowedUnitIds))
                {
                    $selectedUnit[$i] = $item;
                    $i++;
                }
            }
            $data = array('status' => 1,'unit' => $selectedUnit, 'allowedUnitIds' => $allowedUnitIds,'allUnit' => $allUnit);
            return response()->json($data);
    }

   public function units($name=null){
        $name = ucfirst($name);
        $checkbuplicatename = Unit::where('name', 'like', '%' . $name . '%')->get();
        if(!empty($checkbuplicatename) && $checkbuplicatename->count()>0)
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }

//----------------- End unit new method 09/06/2022-----------------


     // new add method 30/05/2022 start

     //new code 13_05_22

    public function brand_export()
    {
        $brands = Brand::where(['status' => 1])->get();
        //export from product
        $brandsarray = [];
        foreach ($brands as $item) {
            $brandsarray[] = [
                 'id' => $item->id,
                'name' => $item->name
            ];
        }
        return (new FastExcel($brandsarray))->download('brands.xlsx');
    }

    public function category_export()
    {
        $Category = Category::where(['position' => 0])->get();
        //export from product
        $Categoryarray = [];
        foreach ($Category as $item) {
            $Categoryarray[] = [
                'id' => $item->id,
                'name' => $item->name,
                'slug' => $item->slug
            ];
        }
        return (new FastExcel($Categoryarray))->download('Category.xlsx');
    }

    public function sub_category_export()
    {
        $SubCategory = Category::where(['position' => 1])->get();
        //export from product
        $SubCategoryarray = [];
        foreach ($SubCategory as $item) {
            $SubCategoryarray[] = [
                'id' => $item->id,
                'name' => $item->name,
                'slug' => $item->slug
            ];
        }
        return (new FastExcel($SubCategoryarray))->download('Subcategory.xlsx');
    }

    public function sub_sub_category_export()
    {
        $SubSubCategory = Category::where(['position' => 2])->get();
        //export from product
        $SubSubCategoryarray = [];
        foreach ($SubSubCategory as $item) {
            $SubSubCategoryarray[] = [
                'id' => $item->id,
                'name' => $item->name,
                'slug' => $item->slug
            ];
        }
        return (new FastExcel($SubSubCategoryarray))->download('Subsubcategory.xlsx');
    }  
}
