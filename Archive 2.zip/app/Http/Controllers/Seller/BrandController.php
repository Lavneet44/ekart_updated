<?php

namespace App\Http\Controllers\Seller;

use App\CPU\Helpers;
use App\CPU\ImageManager;
use App\Http\Controllers\Controller;
use App\Model\Admin;
use App\Model\Brand;
use App\Model\Brandallowe;
use Brian2694\Toastr\Facades\Toastr;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Model\Translation;

class BrandController extends Controller
{
    public function store(Request $request)
    {
        foreach($request->lang as $index=>$key)
        {
            if($request->name[$index] && $key != 'en')
            {
                Translation::updateOrInsert(
                    ['translationable_type'  => 'App\Model\Brand',
                        'translationable_id'    => $brand->id,
                        'locale'                => $key,
                        'key'                   => 'name'],
                    ['value'                 => $request->name[$index]]
                );
            }
        }

        $brand = new Brand;
        $brand->name = $request->name[array_search('en', $request->lang)];
        $brand->image = ImageManager::upload('brand/', 'png', $request->file('image'));
        $brand->status = 1;
        $r = $brand->save();

        $Brandallowe = new Brandallowe;
        $Brandallowe->seller_id = auth('seller')->id();
        $Brandallowe->brand_id = $brand->id;
        $s = $Brandallowe->save();

        if($r && $s)
        {
            $allowedBrandIds = Brandallowe::where(['seller_id' => auth('seller')->id(),'delete_status' => 0])->pluck('brand_id');
            if(!empty($allowedBrandIds)){
                $allowedBrandIds = $allowedBrandIds->toArray();
            }else{
                $allowedBrandIds = array();
            }
            $allBrand = Brand::get();
            $i=0;
            $selectedBrands = array();
            foreach ($allBrand as $key => $item) {
                if (in_array($item->id, $allowedBrandIds))
                {
                    $selectedBrands[$i] = $item;
                    $i++;
                }
            }
            $data = array('status' => 1,'brand' => $selectedBrands, 'allowedBrandIds' => $allowedBrandIds,'allBrand' => $allBrand);
            return response()->json($data);  
        }
    }

}
