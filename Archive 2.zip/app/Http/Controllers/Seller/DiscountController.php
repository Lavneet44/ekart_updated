<?php

namespace App\Http\Controllers\Seller;
use App\CPU\BackEndHelper;
use App\CPU\Convert;
use App\CPU\Helpers;
use App\CPU\ImageManager;
use App\Http\Controllers\Controller;
use App\Model\Seller;
use App\Model\Brand;
use App\Model\Category;
use App\Model\Color;
use App\Model\DealOfTheDay;
use App\Model\FlashDealProduct;
use App\Model\Product;
use App\Model\Review;
use App\Model\Translation;
use App\Model\PossibleVariant;
use App\Model\PossibleCombinationElements;
use App\Model\ProductVariant;
use Brian2694\Toastr\Facades\Toastr;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Rap2hpoutre\FastExcel\FastExcel;
use App\Model\Cart;
use App\Model\Unit;
use App\Model\CategoryBlock;
use App\Model\Brandallowe;
use App\Model\Unitallowe;
use App\Model\ProductDiscount;
use Illuminate\Validation\Rule;
use Redirect;
use Session;
use App\Model\Attribute;
use App\Discount_master;


class DiscountController extends Controller
{

    public function discount_page(){
        $discount = Discount_master::with('discounts')->where(['seller_id'=>auth('seller')->id(),'is_deleted'=>0,'is_hide'=>0])->get();
        $product = Product::where(['user_id' => auth('seller')->id(),'added_by' => 'seller'])->get();
        return view('seller-views.discounts.index',compact('product','discount'));
    }

    public function get_vairants(Request $request){

      $id = $request->id;
       $html = '<option value="">Select Option</option>';
      $variant = ProductVariant::where('product_id',$id)->get();
      if($variant){
        foreach($variant as $va){
          $html.='<option value="'.$va->id.'"';
          if(isset($request->selected) && !empty($request->selected)){
            $exp = explode(',',$request->selected);
            if(in_array($va->id, $exp)){
              $html.='selected';
            }
          }
          $html.=' data-val="'.$va->price.'" data-qty="'.$va->qty.'">'.str_replace('-', ' ', $va->sku).'</option>';
        }
      }
      echo $html;
    }

    public static function selectionCategorySearch(Request $request)
    { 
        if(isset($request->category_ids) && !empty($request->category_ids)){
          $cad = explode(',', $request->category_ids);
        }else{
          $cad = array();
        }
        $category = Category::where('selected_cat','LIKE','%'.auth('seller')->id().'%')->where('parent_id',0)->get();
        $user_id = auth('seller')->id();
        $html = '';
        foreach ($category as $key => $value) {
            $html.="<option value='".$value->id."'";
            if(in_array($value->id,$cad)) {
                $html.="selected";
            }
            $html.=">";
                $html.=$value->name;
            $html.="</option>";
           
            if(count($value->childes) > 0){
                    $html.=(new static)->selectionCategorySearchchild($value->childes,1,$cad);
            }
        }
        echo $html;
    }

    public static function selectionCategorySearchchild($child,$par,$cad = array())
    {
        $html = '';
        $per = $par;
        foreach ($child as $key => $value) {
            if($value->id_of_creater == auth('seller')->id()){
                $html.="<option value='".$value->id."'";
                if(in_array($value->id,$cad)) {
                    $html.="selected";
                }
                $html.=">";
                    $check = 1;
                    for ($i=0; $i < $per ; $i++) { 
                        $html.="---&nbsp;&nbsp;";
                        $check = $per+1;
                    }
                    $html.=$value->name;
                $html.="</option>";

                if(count($value->childes) > 0 && $value->childes->contains('id_of_creater',auth('seller')->id())){
                     
                        $html.=(new static)->selectionCategorySearchchild($value->childes,$check,$cad);
                }
            }
        }
        return $html;
    }

    public function get_product_selection(Request $request){
      $html = '<option value="">Select Option</option>';
      $product = Product::where(['user_id' => auth('seller')->id(),'added_by' => 'seller']);
      if(isset($request->brand) && !empty($request->category)){
        $product = $product->where('brand_id',$request->brand);
      }
      if(isset($request->category) && !empty($request->category)){
        $cate = explode(',',$request->category);
        $product = $product->where(function($products) use ($cate){
                foreach ($cate as $key => $value) {
                    $products->orWhereJsonContains('category_ids',$value);
                }
            });
      }
      $product = $product->get();
      foreach ($product as $key => $value){
        $html.='<option ';
        if(isset($request->selected) && !empty($request->selected)){
          if($request->selected == $value->id){
            $html.='selected ';
          }
        }
        $html.='value="'.$value->id.'">'.$value->name.'</option>';
      }
      echo $html;
    }

    public function get_variations_discount(Request $request)
    {
      if(isset($request->product) && !empty($request->product) && isset($request->is_edit) && $request->is_edit == 1){
        $variant = array();
        $product = Product::where(['user_id' => auth('seller')->id(),'added_by' => 'seller'])->get();
        if(isset($request->id) && !empty($request->id)){
          $var = explode(',',$request->id);
          $variant = ProductVariant::whereIn('id',$var)->get();
          $dis = Discount_master::where('id',$request->product)->with('discounts')->first();
        }
        return response()->json(['view' => view('seller-views.discounts._edit_discount_table',compact('variant','product','dis'))->render()]);
      }else{
        $variant = array();
        $product = Product::where(['user_id' => auth('seller')->id(),'added_by' => 'seller'])->get();
        if(isset($request->id) && !empty($request->id)){
          $var = explode(',',$request->id);
          $variant = ProductVariant::whereIn('id',$var)->get();
        }
        return response()->json(['view' => view('seller-views.discounts._create_discount_table',compact('variant','product'))->render()]);
      }
      
    }

    public function get_discount_hiddens()
    {
      $discount = Discount_master::with('discounts')->where(['seller_id'=>auth('seller')->id(),'is_deleted'=>0,'is_hide'=>1])->get();
      $product = Product::where(['user_id' => auth('seller')->id(),'added_by' => 'seller'])->get();
      return view('seller-views.discounts.hidden',compact('product','discount'));
    }

    public function create()
    {
      $categories = Category::where('selected_cat','LIKE','%'.auth('seller')->id().'%')->where('parent_id',0)->get();      
      $brands = Brand::where('selected_seller','LIKE','%'.auth('seller')->id().'%')->get();      
      $product = Product::where(['user_id' => auth('seller')->id(),'added_by' => 'seller'])->get();
      $discount = ProductDiscount::where(['seller_id'=>auth('seller')->id(),'is_deleted'=>0])->get();
      return view('seller-views.discounts.create',compact('product','discount','categories','brands'));
    }

    public function update_status(Request $request){
      $id = $request->id;
      if(Discount_master::where('id',$id)->update(['status'=>$request->status])){
        echo 1;
      }else{
        echo 0;
      }die;
    }

    public function update_hidden(Request $request){
      $id = $request->id;
      if(Discount_master::where('id',$id)->update(['is_hide'=>$request->is_hide])){
        echo 1;
      }else{
        echo 0;
      }die;
    }

    public function delete_discount(Request $request){
      $id = $request->id;
      if(Discount_master::where('id',$id)->update(['is_deleted'=>1])){
        echo 1;
      }else{
        echo 0;
      }die;
    }

    public function store(Request $request){
      $gettt = $request->input();
      $master = new Discount_master();
      $master->discount_label = $request->discount_label;
      $master->category_ids = implode(',',$request->category);
      $master->brands = $request->brand;
      $master->status = 1;
      $master->product_id = $request->product_id;
      $master->variants = implode(',',$request->variant_id);
      $master->seller_id = auth('seller')->id();
      $master->apply_for_all = $request->apply_for_all;
      $apple = $request->apply_for_all;
      if($master->save()){
        if(isset($request->variant_id) && !empty($request->variant_id)){
          foreach ($request->variant_id as $key => $value) {
            $discount = new ProductDiscount;
            $discount->discount_master_id = $master->id;
            $discount->category_ids = implode(',',$request->category);
            $discount->brands = $request->brand;
            $discount->product_id = $request->product_id;
            $discount->variant_id  = $value;
            if($apple == 1 && $request->not_applied[$key] == 0){
                $discount->discount_percent = $gettt['discount_percent'][0];
                $discount->discount = $gettt['discount'][0];
                $discount->type = $gettt['type'][0];
                $discount->start_date = date('Y-m-d',strtotime($gettt['startdate'][0]));
                $discount->end_date = date('Y-m-d',strtotime($gettt['enddate'][0]));
                $discount->end_time = date('H:i:s',strtotime($gettt['endtime'][0]));
                $discount->start_time = date('H:i:s',strtotime($gettt['starttime'][0]));
                $discount->not_applied = 0;
                $discount->buy = $gettt['buyquantity'][0];
                $discount->status = 1;
                if(isset($gettt['startdate'][0]) && isset($gettt['starttime'][0])){
                  $discount->startDuration = date('Y-m-d H:i:s',strtotime($gettt['startdate'][0].' '.$gettt['starttime'][0]));
                }
                if(isset($gettt['enddate'][0]) && isset($gettt['endtime'][0])){
                  $discount->endDuration = date('Y-m-d H:i:s',strtotime($gettt['enddate'][0].' '.$gettt['endtime'][0]));
                }
                $discount->free_qty = implode(',', $gettt['freequantity'][0]);
                $discount->item = implode(',', $gettt['item'][0]);
            }else{
                $discount->discount_percent = $request->discount_percent[$key];
                $discount->discount = $request->discount[$key];
                $discount->type = $request->type[$key];
                $discount->not_applied = 1;
                $discount->start_date = date('Y-m-d',strtotime($request->startdate[$key]));
                $discount->end_date = date('Y-m-d',strtotime($request->enddate[$key]));
                $discount->end_time = date('H:i:s',strtotime($request->endtime[$key]));
                $discount->start_time = date('H:i:s',strtotime($request->starttime[$key]));
                $discount->buy = $request->buyquantity[$key];
                $discount->status = 1;
                if(isset($request->startdate[$key]) && isset($request->starttime[$key])){
                  $discount->startDuration = date('Y-m-d H:i:s',strtotime($request->startdate[$key].' '.$request->starttime[$key]));
                }
                if(isset($request->enddate[$key]) && isset($request->endtime[$key])){
                  $discount->endDuration = date('Y-m-d H:i:s',strtotime($request->enddate[$key].' '.$request->endtime[$key]));
                }
                $discount->free_qty = implode(',', $request->freequantity[$key]);
                $discount->item = implode(',', $request->item[$key]);
            }
            $discount->quantity = $request->qty[$key];
            $discount->seller_id = auth('seller')->id();
            $discount->save();
          }
          Toastr::success('Discount Created Successfully!');
        }
      }else{
        Toastr::error('Something Went Wrong!');
      }  
      
      return redirect(route('seller.discount.index'));
    }


    public function copy_discount(Request $request)
    {
      $categories = Category::where('selected_cat','LIKE','%'.auth('seller')->id().'%')->where('parent_id',0)->get();      
      $brands = Brand::where('selected_seller','LIKE','%'.auth('seller')->id().'%')->get();      
      $product = Product::where(['user_id' => auth('seller')->id(),'added_by' => 'seller'])->get();
      $discount = Discount_master::where(['seller_id'=>auth('seller')->id(),'id'=>$request->id])->with('discounts')->first();
      return view('seller-views.discounts.copy',compact('product','discount','categories','brands'));
    }

    public function edit_discount(Request $request)
    {
      $categories = Category::where('selected_cat','LIKE','%'.auth('seller')->id().'%')->where('parent_id',0)->get();      
      $brands = Brand::where('selected_seller','LIKE','%'.auth('seller')->id().'%')->get();      
      $product = Product::where(['user_id' => auth('seller')->id(),'added_by' => 'seller'])->get();
      $discount = Discount_master::where(['seller_id'=>auth('seller')->id(),'id'=>$request->id])->with('discounts')->first();
      return view('seller-views.discounts.edit',compact('product','discount','categories','brands'));
        
    }

    public function update(Request $request)
    {
      $gettt = $request->input();
      // echo "<pre>"; print_r($gettt);die;
      if($request->apply_for_all == ''){ $apple = 0; }else{ $apple = $request->apply_for_all; }
      $master = Discount_master::where('id',$request->id)->first();
      $master->discount_label = $request->discount_label;
      $master->category_ids = implode(',',$request->category);
      $master->brands = $request->brand;
      $master->status = 1;
      $master->product_id = $request->product_id;
      $master->variants = implode(',',$request->variant_id);
      $master->apply_for_all = $apple;
      $master->seller_id = auth('seller')->id();
      if($master->save()){
        ProductDiscount::where('discount_master_id',$master->id)->delete();
        if(isset($request->variant_id) && !empty($request->variant_id)){
          foreach ($request->variant_id as $key => $value) {
            $discount = new ProductDiscount;
            $discount->discount_master_id = $master->id;
            $discount->category_ids = implode(',',$request->category);
            $discount->brands = $request->brand;
            $discount->product_id = $request->product_id;
            $discount->variant_id  = $value;
            if($apple == 1 && $request->not_applied[$key] == 0){
                if($key!=0){
                  $dis_amount = $gettt['discount_percent'][0];
                  $dis_bas = $gettt['base_price'][$key];
                  $dis_amount_final = ($dis_amount / 100) * $dis_bas;
                  $discount->discount_percent = $gettt['discount_percent'][0];
                  $discount->discount = $dis_amount_final;
                }else{
                  $discount->discount_percent = $gettt['discount_percent'][0];
                  $discount->discount = $gettt['discount'][0];
                }
                $discount->total_qty = $gettt['qty'][0];
                $discount->base_price = $gettt['base_price'][0];
                $discount->type = $gettt['type'][0];
                $discount->start_date = $gettt['startdate'][0];
                $discount->end_date = $gettt['enddate'][0];
                $discount->end_time = $gettt['endtime'][0];
                $discount->start_time = $gettt['starttime'][0];
                $discount->not_applied = 0;
                $discount->buy = $gettt['buyquantity'][0];
                $discount->status = 1;
                if(isset($gettt['startdate'][0]) && isset($gettt['starttime'][0])){
                  $discount->startDuration = date('Y-m-d H:i:s',strtotime($gettt['startdate'][0].' '.$gettt['starttime'][0]));
                }
                if(isset($gettt['enddate'][0]) && isset($gettt['endtime'][0])){
                  $discount->endDuration = date('Y-m-d H:i:s',strtotime($gettt['enddate'][0].' '.$gettt['endtime'][0]));
                }
                $discount->free_qty = implode(',', $gettt['freequantity'][0]);
                $discount->item = implode(',', $gettt['item'][0]);
            }else{
                $discount->total_qty = $request->qty[$key];
                $discount->base_price = $request->base_price[$key];
                $discount->discount_percent = $request->discount_percent[$key];
                $discount->discount = $request->discount[$key];
                $discount->not_applied = 1;
                $discount->type = $request->type[$key];
                $discount->start_date = $request->startdate[$key];
                $discount->end_date = $request->enddate[$key];
                $discount->end_time = $request->endtime[$key];
                $discount->start_time = $request->starttime[$key];
                $discount->buy = $request->buyquantity[$key];
                $discount->status = 1;
                if(isset($request->startdate[$key]) && isset($request->starttime[$key])){
                  $discount->startDuration = date('Y-m-d H:i:s',strtotime($request->startdate[$key].' '.$request->starttime[$key]));
                }
                if(isset($request->enddate[$key]) && isset($request->endtime[$key])){
                  $discount->endDuration = date('Y-m-d H:i:s',strtotime($request->enddate[$key].' '.$request->endtime[$key]));
                }
                $discount->free_qty = implode(',', $request->freequantity[$key]);
                $discount->item = implode(',', $request->item[$key]);
            }
            $discount->quantity = $request->qty[$key];
            $discount->seller_id = auth('seller')->id();
            $discount->save();
          }
          Toastr::success('Discount Updated Successfully!');
        }
      }else{
        Toastr::error('Something Went Wrong!');
      }
      return redirect(route('seller.discount.index'));
    }


}

?>