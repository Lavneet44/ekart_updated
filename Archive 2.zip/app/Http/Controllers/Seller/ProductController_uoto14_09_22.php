<?php

namespace App\Http\Controllers\Seller;

use App\CPU\BackEndHelper;
use App\CPU\Convert;
use App\CPU\Helpers;
use App\CPU\ImageManager;
use App\Http\Controllers\Controller;
use App\Model\Seller;
use App\Model\Brand;
use App\Model\Category;
use App\Model\Color;
use App\Model\DealOfTheDay;
use App\Model\FlashDealProduct;
use App\Model\Product;
use App\Model\Review;
use App\Model\Translation;
use App\Model\PossibleVariant;
use App\Model\PossibleCombinationElements;
use Brian2694\Toastr\Facades\Toastr;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Rap2hpoutre\FastExcel\FastExcel;
use App\Model\Cart;
use App\Model\Unit;
use App\Model\CategoryBlock;
use App\Model\Brandallowe;
use App\Model\Unitallowe;
use App\Model\ProductDiscount;
use Illuminate\Validation\Rule;


class ProductController extends Controller
{
    public function get_child(Request $request)
    {
        $cat = Category::where(['parent_id' => $request->parent_id])->get();
        return response()->json([
            'row' => $cat
        ]);
    }

    public function units($name=null){
        $name = ucfirst($name);
        $checkbuplicatename = Unit::where('name', 'like', '%' . $name . '%')->get();
        if(!empty($checkbuplicatename) && $checkbuplicatename->count()>0)
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }

    public function checkbrandsduplicate($name=null){
        $name = ucfirst($name);
        $checkbrandsname = Brand::where('name', 'like', '%' . $name . '%')->get();
        if(!empty($checkbrandsname) && $checkbrandsname->count()>0)
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }

    public function getlatestbrand(){
        $allowedBrandIds = Brandallowe::where(['seller_id' => auth('seller')->id(),'delete_status' => 0])->pluck('brand_id');
            if(!empty($allowedBrandIds)){
                $allowedBrandIds = $allowedBrandIds->toArray();
            }else{
                $allowedBrandIds = array();
            }

            $allBrand = Brand::get();

            $i=0;
            $selectedBrands = array();
            foreach ($allBrand as $key => $item) {
                if (in_array($item->id, $allowedBrandIds))
                {
                    $selectedBrands[$i] = $item;
                    $i++;
                }
            }
            $data = array('status' => 1,'brand' => $selectedBrands, 'allowedBrandIds' => $allowedBrandIds,'allBrand' => $allBrand);
            return response()->json($data);
    }

    public function getunit(){
        $allowedUnitIds = Unitallowe::where(['seller_id' => auth('seller')->id(),'delete_status' => 0])->pluck('unit_id');
            if(!empty($allowedUnitIds)){
                $allowedUnitIds = $allowedUnitIds->toArray();
            }else{
                $allowedUnitIds = array();
            }

            $allUnit = unit::get();

            $i=0;
            $selectedUnit = array();
            foreach ($allUnit as $key => $item) {
                if (in_array($item->id, $allowedUnitIds))
                {
                    $selectedUnit[$i] = $item;
                    $i++;
                }
            }
            $data = array('status' => 1,'unit' => $selectedUnit, 'allowedUnitIds' => $allowedUnitIds,'allUnit' => $allUnit);
            return response()->json($data);
    }



    public function add_new()
    {

        $Seller = Seller::where(['id' => auth('seller')->id(),'status' => 'approved','new_seller_status' => 'active'])->first();
        $allowedIds = CategoryBlock::where(['seller_id' => auth('seller')->id(),'delete_status' => 0])->pluck('level0_id');
        if(!empty($allowedIds)){
            $allowedIds = $allowedIds->toArray();
        }else{
            $allowedIds = array();
        }

        $allCats = Category::get();       
        $br = Brand::orderBY('name', 'ASC')->get();

        $allowedBrandIds = Brandallowe::where(['seller_id' => auth('seller')->id(),'delete_status' => 0])->pluck('brand_id');
        if(!empty($allowedBrandIds)){
            $allowedBrandIds = $allowedBrandIds->toArray();
        }else{
            $allowedBrandIds = array();
        }

         $allowedUnitIds = unitallowe::where(['seller_id' => auth('seller')->id(),'delete_status' => 0])->pluck('unit_id');
        if(!empty($allowedUnitIds)){
            $allowedUnitIds = $allowedUnitIds->toArray();
        }else{
            $allowedUnitIds = array();
        }

        $unit = Unit::orderBY('id', 'ASC')->get();
        return view('seller-views.product.add-new', compact('allCats','br','unit','allowedIds','allowedBrandIds','allowedUnitIds','Seller'));
    }

    public function getSellerCatdata()
    {
        $allowedIds = CategoryBlock::where(['seller_id' => auth('seller')->id(),'delete_status' => 0])->pluck('level0_id');
        if(!empty($allowedIds)){
            $allowedIds = $allowedIds->toArray();
        }else{
            $allowedIds = array();
        }

        $allCats = Category::get();

        $data = array('status' => 1,'allowedIds' => $allowedIds, 'allCats' => $allCats);
        return response()->json($data);
    }

    public function block_ids(Request $request)
    {
        CategoryBlock::where(['seller_id' => auth('seller')->id()])->update(['delete_status' => 1]);
        $idcat = $idsubcat = $idsubsubcat = '';
        foreach ($request->checkboxs as $key => $value) {
            $CategoryBlock = new CategoryBlock;
            $CategoryBlock->seller_id = auth('seller')->id();
            $CategoryBlock->level0_id = $value;
            $CategoryBlock->save();
        }


        $allowedIds = CategoryBlock::where(['seller_id' => auth('seller')->id(),'delete_status' => 0])->pluck('level0_id');
        $allowedIds = $allowedIds->toArray();
        $allCats = Category::get();

        foreach ($allCats as $key => $value) {
            if((in_array($value['id'], $allowedIds)) && ($value->parent_id==0)){
                $cat[$key] = $value;
            }
        }

        $data = array('status' => 1,'cat' => $cat);
        return response()->json($data);
    }    

    public function selected_brands(Request $request)
    {
        Brandallowe::where(['seller_id' => auth('seller')->id()])->update(['delete_status' => 1]);
        $idcat = $idsubcat = $idsubsubcat = '';
        foreach ($request->checkboxs as $key => $value) {
            $Brandallowe = new Brandallowe;
            $Brandallowe->seller_id = auth('seller')->id();
            $Brandallowe->brand_id = $value;
            $Brandallowe->save();
        }

        $allowedBrandIds = Brandallowe::where(['seller_id' => auth('seller')->id(),'delete_status' => 0])->pluck('brand_id');
        if(!empty($allowedBrandIds)){
            $allowedBrandIds = $allowedBrandIds->toArray();
        }else{
            $allowedBrandIds = array();
        }


        $allBrand = Brand::get();

        $i=0;
        $selectedBrands = array();
        foreach ($allBrand as $key => $item) {
            if (in_array($item->id, $allowedBrandIds))
            {
                $selectedBrands[$i] = $item;
                $i++;
            }
        }
        
        $data = array('status' => 1,'brand' => $selectedBrands);
        return response()->json($data); 
    }

    //----------------- start unit new method 09/06/2022-----------------

     public function selected_units(Request $request)
    {
        Unitallowe::where(['seller_id' => auth('seller')->id()])->update(['delete_status' => 1]);
        $idcat = $idsubcat = $idsubsubcat = '';
        foreach ($request->checkboxs as $key => $value) {
            $Unitallowe = new Unitallowe;
            $Unitallowe->seller_id = auth('seller')->id();
            $Unitallowe->unit_id = $value;
            $Unitallowe->save();
        }

        $allowedUnitIds = Unitallowe::where(['seller_id' => auth('seller')->id(),'delete_status' => 0])->pluck('unit_id');
        if(!empty($allowedUnitIds)){
            $allowedUnitIds = $allowedUnitIds->toArray();
        }else{
            $allowedUnitIds = array();
        }


        $allUnit = unit::get();

        $i=0;
        $selectedUnits = array();
        foreach ($allUnit as $key => $item) {
            if (in_array($item->id, $allowedUnitIds))
            {
                $selectedUnits[$i] = $item;
                $i++;
            }
        }
        
        $data = array('status' => 1,'unit' => $selectedUnits);
        return response()->json($data); 
    } 

//----------------- End unit new method 09/06/2022-----------------

    public function status_update(Request $request)
    {
        if ($request['status'] == 0) {
            Product::where(['id' => $request['id'], 'added_by' => 'seller', 'user_id' => \auth('seller')->id()])->update([
                'status' => $request['status'],
            ]);
            return response()->json([
                'success' => 1,
            ], 200);
        } elseif ($request['status'] == 1) {
            if (Product::find($request['id'])->request_status == 1) {
                Product::where(['id' => $request['id']])->update([
                    'status' => $request['status'],
                ]);
                return response()->json([
                    'success' => 1,
                ], 200);
            } else {
                return response()->json([
                    'success' => 0,
                ], 200);
            }
        }
    }

    public function featured_status(Request $request)
    {
        if ($request->ajax()) {
            $product = Product::find($request->id);
            $product->featured_status = $request->status;
            $product->save();
            $data = $request->status;
            return response()->json($data);
        }
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'part_no' => [
                Rule::unique('products')->where(function($query) {
                  $query->where('part_no', '!=', 'NULL');
              })
            ],
            'serial_no' => [
                Rule::unique('products')->where(function($query) {
                  $query->where('serial_no', '!=', 'NULL');
              })
            ],
            'name.*' => 'required|unique:products,name',
            'item_code' => 'required|unique:products,item_code',
            'category_id' => 'required',
            'sub_category_id' => 'required',
            // 'brand_id' => 'required',
            // 'unit' => 'required',
            'images' => 'required',
            'image' => 'required',
            //'tax' => 'required|min:0',
            //'unit_price' => 'required|numeric|min:1',
            //'purchase_price' => 'required|numeric|min:1',
        ], [
            'name.*.required' => 'Product name is required!',
            'name.*.unique' => 'Product name must be unique!',
            'item_code.required' => 'item code is required!',
            'category_id.required' => 'category  is required!',
            'sub_category_id.required' => 'sub category  is required!',
            'images.required' => 'Product images is required!',
            'image.required' => 'Product thumbnail is required!',
            //'unit_price.required' => 'unit price  is required!',
            //'unit_price.numeric' => 'unit price  is numeric!',
            //'purchase_price.required' => 'purchase price  is required!',
            //'purchase_price.numeric' => 'purchase price  is numeric!',
            //'brand_id.required' => 'brand  is required!',
            //'unit.required' => 'Unit  is required!',
        ]);

        if ($request['discount_type'] == 'percent') {
            $dis = ($request['unit_price'] / 100) * $request['discount'];
        } else {
            $dis = $request['discount'];
        }

        if ($request['unit_price'] <= $dis) {
            $validator->after(function ($validator) {
                $validator->errors()->add(
                    'unit_price', 'Discount can not be more or equal to the price!'
                );
            });
        }

        

        $product = new Product();
        $product->user_id = auth('seller')->id();
        $product->added_by = "seller";
        $product->name = $request->name[array_search('en', $request->lang)];
        $product->item_code = $request->item_code;
        $product->part_no = $request->part_no;
        $product->serial_no = $request->serial_no;
        $product->slug = Str::slug($request->name[array_search('en', $request->lang)], '-') . '-' . Str::random(6);

        $category = [];

        if ($request->category_id != null) {
            array_push($category, [
                'id' => $request->category_id,
                'position' => 0,
            ]);
        }
        if ($request->sub_category_id != null) {
            array_push($category, [
                'id' => $request->sub_category_id,
                'position' => 1,
            ]);
        }
        if ($request->sub_sub_category_id != null) {
            array_push($category, [
                'id' => $request->sub_sub_category_id,
                'position' => 2,
            ]);
        }

        $product->category_ids = json_encode($category);
        $product->brand_id = $request->brand_id;
        $product->unit = $request->unit;
        $product->details = $request->description[array_search('en', $request->lang)];

        if ($request->has('colors_active') && $request->has('colors') && count($request->colors) > 0) {
            $product->colors = json_encode($request->colors);
        } else {
            $colors = [];
            $product->colors = json_encode($colors);
        }
        $choice_options = [];
        if ($request->has('choice')) {
            foreach ($request->choice_no as $key => $no) {
                $str = 'choice_options_' . $no;
                $item['name'] = 'choice_' . $no;
                $item['title'] = $request->choice[$key];
                $item['options'] = explode(',', implode('|', $request[$str]));
                array_push($choice_options, $item);
            }
        }
        $product->choice_options = json_encode($choice_options);
        //combinations start
        $options = [];
        if ($request->has('colors_active') && $request->has('colors') && count($request->colors) > 0) {
            $colors_active = 1;
            array_push($options, $request->colors);
        }
        if ($request->has('choice_no')) {
            foreach ($request->choice_no as $key => $no) {
                $name = 'choice_options_' . $no;
                $my_str = implode('|', $request[$name]);
                array_push($options, explode(',', $my_str));
            }
        }
        //Generates the combinations of customer choice options
        $combinations = Helpers::combinations($options);

        $checkPrice = false;

        $variations = [];
        $stock_count = 0;
        if (count($combinations[0]) > 0) {
            $unitPriceFlag = 1;
            foreach ($combinations as $key => $combination) {
                $str = '';
                foreach ($combination as $k => $item) {
                    if ($k > 0) {
                        $str .= '-' . str_replace(' ', '', $item);
                    } else {
                        if ($request->has('colors_active') && $request->has('colors') && count($request->colors) > 0) {
                            $color_name = Color::where('code', $item)->first()->name;
                            $str .= $color_name;
                        } else {
                            $str .= str_replace(' ', '', $item);
                        }
                    }
                }

                if(($request['verify_status_' . str_replace('.','_',$str)]==1 && !empty($request['price_' . str_replace('.', '_', $str)]) && abs($request['price_' . str_replace('.', '_', $str)]) > 0))
                {
                    $checkPrice = true;
                    if($unitPriceFlag == 1)
                    {
                        (!empty($request->unit_price))?$unitPrice = $request->unit_price:$unitPrice = $request['price_' . str_replace('.', '_', $str)];
                        $unitPriceFlag++;
                    }
                }
                $item = [];
                    $item['type'] = $str;
                    //$item['price'] = Convert::usd(abs($request['price_' . str_replace('.', '_', $str)]));
                    $item['price'] = BackEndHelper::systemcurrency_to_selectedcurrency(abs($request['price_' . str_replace('.', '_', $str)]));
                    $item['sku'] = $request['sku_' . str_replace('.', '_', $str)];
                    $item['qty'] = abs($request['qty_' . str_replace('.', '_', $str)]);


                    (!empty($request['discount_' . str_replace('.','_',$str)]))?$VDiscount = $request['discount_' . str_replace('.','_',$str)]:$VDiscount = 0;
                    $item['discount'] = BackEndHelper::systemcurrency_to_selectedcurrency(abs($VDiscount));

                    (!empty($request['startdate_' . str_replace('.','_',$str)]))?$VDStartDate = $request['startdate_' . str_replace('.','_',$str)]:$VDStartDate = '';
                    (!empty($request['starttime_' . str_replace('.','_',$str)]))?$VDStartTime = $request['starttime_' . str_replace('.','_',$str)]:$VDStartTime = '';
                    if(!empty($VDStartDate) && !empty($VDStartTime)){
                        $comStartDAte = $VDStartDate.' '.$VDStartTime;
                    }
                    else{
                        $comStartDAte = 'null';
                    }

                    $item['startDuration'] =  $comStartDAte;

                    (!empty($request['enddate_' . str_replace('.','_',$str)]) && $request['enddate_' . str_replace('.','_',$str)] != '0000-00-00')?$VDEndDate = $request['enddate_' . str_replace('.','_',$str)]:$VDEndDate = '';
                    (!empty($request['endtime_' . str_replace('.','_',$str)]) && $request['endtime_' . str_replace('.','_',$str)] != '00:00')?$VDEndTime = $request['endtime_' . str_replace('.','_',$str)]:$VDEndTime = '';

                    if(!empty($VDEndDate) && !empty($VDEndTime)){
                        $comEndDAte = $VDEndDate.' '.$VDEndTime;
                    }
                    else{
                        $comEndDAte = 'null';
                    }
                    
                    $item['endDuration'] =  $comEndDAte;

                    $item['isverified_V_Discount'] =  $request['verify_status_' . str_replace('.','_',$str)];

                    // --parameters of free quantity and buy quantity are yet to be add-- //
                    array_push($variations, $item);

                    if($request['verify_status_' . str_replace('.','_',$str)]==1)
                    {
                        $stock_count += $item['qty'];
                    }
            }
        } else {
            if((empty($request->unit_price) || $request->unit_price > 0))
            {
                $checkPrice = false;
            }
            $stock_count = (integer)$request['current_stock'];
        }

        if (!$checkPrice) {
            $validator->after(function ($validator) {
                $validator->errors()->add(
                    'unit_price', 'Please assign Unit Price or Price For atleast One Variant as a verified Variant!'
                );
            });
        }

        if ($validator->errors()->count() > 0) {
            return response()->json(['errors' => Helpers::error_processor($validator)]);
        }

        //combinations end
        $product->variation = json_encode($variations);
        $product->unit_price = BackEndHelper::systemcurrency_to_selectedcurrency(abs($unitPrice));
        (!empty($request->purchase_price))?$purchasePrice = $request->purchase_price:$purchasePrice = 0;
        $product->purchase_price = BackEndHelper::systemcurrency_to_selectedcurrency(abs($purchasePrice));

        $product->tax = $request->tax;
        $product->tax_type = $request->tax_type;
        //$product->discount = $request->discount_type == 'flat' ? Convert::usd($request->discount) : $request->discount;
        //$product->discount_type = $request->discount_type;
        $product->attributes = json_encode($request->choice_attributes);
        $product->current_stock = abs($stock_count);

        $product->video_provider = 'youtube';
        $product->video_url = $request->video_link;
        $product->request_status = 0;
        $product->status = 0;
        $checkdiscount = $request->discoun_amt;

        if(!empty($request->discoun_amt) && ($request->discoun_amt > 0))
        {
            $ProductDiscount = new ProductDiscount();
            $ProductDiscount->discount = BackEndHelper::systemcurrency_to_selectedcurrency($request->discoun_amt);
            $ProductDiscount->start_date = $request->start_date;
            $ProductDiscount->start_time = $request->start_time;
            $ProductDiscount->end_date = $request->end_date;
            $ProductDiscount->end_time = $request->end_time;
            $ProductDiscount->quantity = $request->quantity;
            $ProductDiscount->buy = $request->buy;
            $ProductDiscount->Item = $request->item;
        }

        if ($request->ajax()) {
            return response()->json([], 200);
        } else {
            if ($request->file('images')) {
                foreach ($request->file('images') as $img) {
                    $product_images[] = ImageManager::upload('product/', 'png', $img);
                }
                $product->images = json_encode($product_images);
            }
            $product->thumbnail = ImageManager::upload('product/thumbnail/', 'png', $request->file('image'));

            $product->meta_title = $request->meta_title;
            $product->meta_description = $request->meta_description;
            $product->meta_image = ImageManager::upload('product/meta/', 'png', $request->meta_image);

            // ---the two line below are feature of admin approval status for product. But on demand of customer no such approval from admin further needed so by pass this functionality ---//
            $product->request_status = 1;
            $product->status = 1; 

            // echo "<pre>";
            // print_r($product->toArray());
            // die;
            $product->save();

            if(!empty($checkdiscount) && ($request->discoun_amt > 0))
            {   
                $ProductDiscount->product_id = $product->id;
                $ProductDiscount->save();
            }

            $data = [];
            foreach ($request->lang as $index => $key) {
                if ($request->name[$index] && $key != 'en') {
                    array_push($data, array(
                        'translationable_type' => 'App\Model\Product',
                        'translationable_id' => $product->id,
                        'locale' => $key,
                        'key' => 'name',
                        'value' => $request->name[$index],
                    ));
                }
                if ($request->description[$index] && $key != 'en') {
                    array_push($data, array(
                        'translationable_type' => 'App\Model\Product',
                        'translationable_id' => $product->id,
                        'locale' => $key,
                        'key' => 'description',
                        'value' => $request->description[$index],
                    ));
                }
            }
            Translation::insert($data);
            Toastr::success('Product added successfully!');
            return redirect()->route('seller.product.list');
        }
    }

    function list(Request $request)
    {
        $query_param = [];
        $search = $request['search'];
        if ($request->has('search')) {
            $key = explode(' ', $request['search']);
            $products = Product::where(['added_by' => 'seller', 'user_id' => \auth('seller')->id()])
                ->where(function ($q) use ($key) {
                    foreach ($key as $value) {
                        $q->Where('name', 'like', "%{$value}%");
                    }
                });
            $query_param = ['search' => $request['search']];
        } else {
            $products = Product::where(['added_by' => 'seller', 'user_id' => \auth('seller')->id()]);
        }
        

        $products = $products->orderBy('id', 'DESC')->paginate(Helpers::pagination_limit())->appends($query_param);
       
        return view('seller-views.product.list', compact('products', 'search'));
    }

    public function stock_limit_list(Request $request, $type)
    {
        $stock_limit = Helpers::get_business_settings('stock_limit');
        $sort_oqrderQty = $request['sort_oqrderQty'];
        $query_param = $request->all();
        $search = $request['search'];
        $pro = Product::where(['added_by' => 'seller', 'user_id' => auth('seller')->id()])
            ->when($request->has('status') && $request->status != null, function ($query) use ($request) {
                $query->where('request_status', $request->status);
            });

        if ($request->has('search')) {
            $key = explode(' ', $request['search']);
            $pro = $pro->where(function ($q) use ($key) {
                foreach ($key as $value) {
                    $q->Where('name', 'like', "%{$value}%");
                }
            });
            $query_param = ['search' => $request['search']];
        }

        $request_status = $request['status'];

        $pro = $pro->withCount('order_details')->when($request->sort_oqrderQty == 'quantity_asc', function ($q) use ($request) {
            return $q->orderBy('current_stock', 'asc');
        })
            ->when($request->sort_oqrderQty == 'quantity_desc', function ($q) use ($request) {
                return $q->orderBy('current_stock', 'desc');
            })
            ->when($request->sort_oqrderQty == 'order_asc', function ($q) use ($request) {
                return $q->orderBy('order_details_count', 'asc');
            })
            ->when($request->sort_oqrderQty == 'order_desc', function ($q) use ($request) {
                return $q->orderBy('order_details_count', 'desc');
            })
            ->when($request->sort_oqrderQty == 'default', function ($q) use ($request) {
                return $q->orderBy('id');
            })->where('current_stock', '<', $stock_limit);


        $products = $pro->orderBy('id', 'DESC')->paginate(Helpers::pagination_limit())->appends(['status' => $request['status']])->appends($query_param);
        return view('seller-views.product.stock-limit-list', compact('products', 'search', 'request_status', 'sort_oqrderQty'));
    }

    public function update_quantity(Request $request)
    {
        $variations = [];
        $stock_count = $request['current_stock'];
        if ($request->has('type')) {
            foreach ($request['type'] as $key => $str) {
                $item = [];
                $item['type'] = $str;
                $item['price'] = BackEndHelper::currency_to_usd(abs($request['price_' . str_replace('.', '_', $str)]));
                $item['sku'] = $request['sku_' . str_replace('.', '_', $str)];
                $item['qty'] = abs($request['qty_' . str_replace('.', '_', $str)]);
                array_push($variations, $item);
            }
        }

        $product = Product::find($request['product_id']);
        if ($stock_count >= 0) {
            $product->current_stock = $stock_count;
            $product->variation = json_encode($variations);
            $product->save();
            Toastr::success(\App\CPU\translate('product_quantity_updated_successfully!'));
            return back();
        } else {
            Toastr::warning(\App\CPU\translate('product_quantity_can_not_be_less_than_0_!'));
            return back();
        }
    }

    public function get_categories(Request $request)
    {
        $cat = Category::where(['parent_id' => $request->parent_id])->get();
        $idArray = array();
        foreach ($cat as $key => $row) {
            if ($row->id == $request->sub_category) {
                $idArray[$key] = $row;
            } else {
                $idArray[$key] = $row;
            }  
        }
        return response()->json([
            'row' => $idArray
        ]);
    }


    public function get_variations(Request $request)
    {
        $product = Product::find($request['id']);
        return response()->json([
            'view' => view('seller-views.product.partials._update_stock', compact('product'))->render()
        ]);
    }

    public function checkVariantExist(Request $request)
    {

            $oldString = $request->oldSkuSrting;
            $ArrOfEle = explode('-',$request->newSkuString);
            $ArrOfEle_hex = explode('-',$request->newSkuString);

            if(!empty($ArrOfEle_hex[0]))
            {
                if($request->colors_active == 1)
                {
                        $color_name = \App\Model\Color::where('code', $ArrOfEle_hex[0])->first()->name;
                        $ArrOfEle[0] = $color_name;
                }
            }

            $ArrOfEle=array_filter($ArrOfEle);
            $ArrOfEle_hex=array_filter($ArrOfEle_hex);

            $modStr = implode("-", $ArrOfEle);
            $modStr_hex = implode("-", $ArrOfEle_hex);

            $status2 = PossibleVariant::where(['str' => $modStr_hex,'status' => 1])->first();
            // echo "<pre>";
            // print_r($status2);
            // die;
            $combination = PossibleCombinationElements::where('seller_id',auth('seller')->id())->first()->combination_string;
            $combination = json_decode($combination);
            $rowIndex = $request->rowIndex;
            $html = '';

            if(empty($status2))
            {
                //--Need to update to old str DISABLE, as new Str will take it's palce
                $updateOldSku = PossibleVariant::where(['str' => $oldString,'status' => 1])->update(['status' => 2]);

                $variantCombinations = new PossibleVariant();
                $variantCombinations->seller_id = auth('seller')->id();
                $variantCombinations->str = $modStr_hex;
                $variantCombinations->save();

                $strArray = [];
                $strArray = explode('-',  $modStr_hex);
                foreach($combination as $keys => $sc)
                {
                $html.='<td >';
                    $html.='<label class="control-label">'.$sc[0].'</label>';
                    $html.='<select class="form-control" data-row="'.$rowIndex.'" data-col="';$html.=(!empty($combination))?count($combination):0;$html.='" onchange="checkVariant('.$keys.',this,'.$rowIndex.')" id="'.$rowIndex.$keys.'" >';
                            $html.='<option value="">None</option>';
                            foreach($sc as $in => $s){
                                if($in){
                                $html.='<option ';$html.=(in_array($s, $strArray))?"selected":"";$html.=' value="'.$s.'">';$html.=($sc[0]=='color')?Color::where('code', $s)->first()->name:$s;$html.='</option>';
                                }
                            }
                    $html.='</select>';
                $html.='</td>';
                }

                return array(['status' => true, 'originalStr' => $modStr_hex,'showstr' => $modStr,'matchedStr' => '','changedIndex' => '','html'=>$html]);
            }
            else
            {
                $strArray = [];
                $strArray = explode('-',  $oldString);
                foreach($combination as $keys => $sc)
                {
                $html.='<td >';
                    $html.='<label class="control-label">'.$sc[0].'</label>';
                    $html.='<select class="form-control" data-row="'.$rowIndex.'" data-col="';$html.=(!empty($combination))?count($combination):0;$html.='" onchange="checkVariant('.$keys.',this,'.$rowIndex.')" id="'.$rowIndex.$keys.'" >';
                            $html.='<option value="">None</option>';
                            foreach($sc as $in => $s){
                                if($in){
                                $html.='<option value="'.$s.'" ';$html.=(in_array($s, $strArray))?"selected":"";$html.='>';$html.=($sc[0]=='color')?Color::where('code', $s)->first()->name:$s;$html.='</option>';
                                }
                            }
                    $html.='</select>';
                $html.='</td>';
                }

                return array(['status' => false, 'originalStr' => '','showstr' => '','matchedStr' => $oldString,'changedIndex' => $request->changedIndex,'html'=>$html]);

            }

    }

    public function get_all_color(Request $request)
    {

        echo "<pre>";
        print_r($request->selectedcombination);
        print_r($request->oldcombination);
        print_r($request->totalcombination);
        // $allColor = Color::get(['name','code']);
        // if(!empty($allColor))
        // {
        //     return $allColor;
        // }
        // else
        // {
        //     return null;
        // }
    }

    public function sku_combination(Request $request)
    {
        $sellerItem = Product::where(['user_id' => auth('seller')->id(),'added_by' => 'seller'])->get();
        
        $options = [];$selectColoumn = [];$prod_id="";$straArray=[];$straA=[];$final=[];$colors_active = 0;
        if ($request->has('colors_active') && $request->has('colors') && count($request->colors) > 0){
            $colors_active = 1;
            array_push($options, $request->colors);
            $arr = $request->colors;
            $pos = 0;
            $val = 'color';
         
            $selectColoumn[0] = array_merge(array_slice($arr, 0, $pos), array($val), array_slice($arr, $pos));
        } else {
            $colors_active = 0;
        }

        $unit_price = $request->unit_price;
        $product_name = $request->name[array_search('en', $request->lang)];
        if(!empty($request->productId))
        {
            $prod_id = $request->productId;
        }

        if ($request->has('choice_no')) {
            foreach ($request->choice_no as $key => $no) {
                $name = 'choice_options_' . $no;
                $my_str = implode('', $request[$name]);
                array_push($options, explode(',', $my_str));
            }
        }

        if ($request->has('choice_no')) {
            foreach ($request->choice_no as $key => $no) {
                $name = 'choice_options_' . $no;
                $my_str = $request->choice[$key].','.implode('', $request[$name]);
                array_push($selectColoumn, explode(',', $my_str));
            }
        }

        $combinations = Helpers::combinations($options);

        foreach ($combinations as $key => $combination)
        {
            $sku = '';
            //foreach (explode(' ', $product_name) as $key => $value) {
                //$sku .= substr($value, 0, 1);
            //}
            $string ="";
            if(!empty($product_name))
            {
                $string = strval($product_name);
            }
            else
            {
                $string ="N/A";
            }
            $sku .= trim($string);

            $str = '';
            foreach ($combination as $key => $item){

                if($key > 0 ){
                    $str .= '-'.str_replace(' ', '', $item);
                    $sku .='-'.str_replace(' ', '', $item);
                }
                else
                {
                    if($colors_active == 1){
                        //$color_name = \App\Model\Color::where('code', $item)->first()->name;
                        $color_name = $item;
                        $str .= $color_name;
                        $sku .='-'.$color_name;
                    }
                    else{
                        $str .= str_replace(' ', '', $item);
                        //$sku .='-'.str_replace(' ', '', $item);
                    }
                }
            }

            

            $orignalskr = (!empty($request->original_value))?$request->original_value:'';
            $changedskr = (!empty($request->changed_value))?$request->changed_value:'';

            if(!empty($orignalskr)){
                if($orignalskr == $str)
                {
                    $str = $changedskr;
                }   
            }
            array_push($straArray,$str);
        }


        PossibleVariant::where(["seller_id" => auth('seller')->id()])->delete();
        PossibleCombinationElements::where(["seller_id" => auth('seller')->id()])->delete();
        
        $stringOfCombination= json_encode($selectColoumn);
        $possCombination = new PossibleCombinationElements();
        $possCombination->seller_id = auth('seller')->id();
        $possCombination->combination_string = $stringOfCombination;
        $possCombination->save();
        foreach($straArray as $stA => $st)
        {
            $variantCombinations = new PossibleVariant();
            $variantCombinations->seller_id = auth('seller')->id();
            $variantCombinations->str = $st;
            $variantCombinations->save();
        }


        foreach ($straArray as $key => $st) {
            $r = explode('-', $st);
            array_push($straA, $r);
        }

        // return response()->json([
        //     'view' => view('admin-views.product.partials._sku_combinations', compact('combinations', 'unit_price', 'colors_active', 'product_name', 'prod_id', 'selectColoumn','orignalskr','changedskr','colors_active','sellerItem'))->render(),
        // ]);
        return response()->json([
            'view' => view('admin-views.product.partials._sku_combinations', compact('combinations', 'colors_active', 'prod_id', 'selectColoumn','orignalskr','changedskr','colors_active','sellerItem'))->render(),
        ]);
    }

    public function edit($id)
    {
            $product = Product::withoutGlobalScopes()->with('translations')->find($id);

            // $product->unit_price =\App\CPU\Convert::default($product->unit_price);
            // $product->purchase_price =\App\CPU\Convert::default($product->purchase_price);

            $processedDiscountArray=[];
            $i=0;
            foreach ($product->productDiscount as $key => $value) {
                if($value->status!=1){
                    $disPer = ($value->discount/$product->unit_price)*100;
                    $processedDiscountArray[$i]['id'] = $value->id;
                    $processedDiscountArray[$i]['discount'] = $value->discount;
                    $processedDiscountArray[$i]['start_date'] = $value->start_date;
                    $processedDiscountArray[$i]['start_time'] = $value->start_time;
                    $processedDiscountArray[$i]['end_date'] = $value->end_date;
                    $processedDiscountArray[$i]['end_time'] = $value->end_time;
                    $processedDiscountArray[$i]['quantity'] = $value->quantity;
                    $processedDiscountArray[$i]['buy'] = $value->buy;
                    $processedDiscountArray[$i]['Item'] = $value->Item;
                    $processedDiscountArray[$i]['status'] = $value->status;
                    //$processedDiscountArray[$i]['calculatedDiscountPersent'] = convert::default($disPer);
                    $processedDiscountArray[$i]['calculatedDiscountPersent'] = $disPer;
                    $i++;
                }
            }

            $variantPresent = 0;
            if(!empty($product))
            {
                $count = count(json_decode($product->variation));
                for ($i = 0; $i < $count; $i++) {
                    if (json_decode($product->variation)[$i]->isverified_V_Discount == 1) {
                        $variantPresent = 1;
                        break;
                    }
                }
            }

            $product_category = json_decode($product->category_ids);
            $elementCount  = count($product_category);
            $product->colors = json_decode($product->colors);
            $categories = Category::where(['parent_id' => 0])->get();
            $allCats = Category::get();      

            $allowedIds = CategoryBlock::where(['seller_id' => auth('seller')->id(),'delete_status' => 0])->pluck('level0_id');
            if(!empty($allowedIds)){
                $allowedIds = $allowedIds->toArray();
            }else{
                $allowedIds = array();
            }


            $allowedBrandIds = Brandallowe::where(['seller_id' => auth('seller')->id(),'delete_status' => 0])->pluck('brand_id');
            if(!empty($allowedBrandIds)){
                $allowedBrandIds = $allowedBrandIds->toArray();
            }else{
                $allowedBrandIds = array();
            }

            $br = Brand::orderBY('name', 'ASC')->get();
            $unit = Unit::orderBY('id', 'ASC')->get();
            $current_unit= unit::find($product->unit);
            $allowedUnitIds = unitallowe::where(['seller_id' => auth('seller')->id(),'delete_status' => 0])->pluck('unit_id');
            if(!empty($allowedUnitIds)){
                $allowedUnitIds = $allowedUnitIds->toArray();
            }else{
                $allowedUnitIds = array();
            }
            //code for get inserted catagory,subcatagory,sub-sub-catagory----start---------------------------
            $brand_original = $product->brand;
            //---------------------------------Catagory----------------------------------------------------     
            $inserted_catagory = category::find($product_category[0]->id);
            //---------------------------------Catagory---------------------------------------------------- 

            //---------------------------------Sub-Catagory----------------------------------------------------- 
            if(!empty($product_category[1]->id))
                $inserted_sub_catagory = category::find($product_category[1]->id);
            else
                $inserted_sub_catagory = "";
            //---------------------------------Sub-Catagory-----------------------------------------------------

            //---------------------------------sub-Sub-Catagory------------------------------------------------------
            if(!empty($product_category[2]->id))
                $inserted_sub_sub_catagory = category::find($product_category[2]->id);
            else
                $inserted_sub_sub_catagory = "";
            //---------------------------------sub-Sub-Catagory------------------------------------------------------

            //end----------------------------------------------------------------------------------------------

            return view('seller-views.product.edit', compact('elementCount','unit','allowedIds','allowedBrandIds','allCats','categories', 'br', 'product', 'product_category','current_unit','allowedUnitIds','processedDiscountArray','brand_original','inserted_catagory','inserted_sub_catagory','inserted_sub_sub_catagory','variantPresent'));

    }

    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'part_no' => [
                Rule::unique('products')->where(function($query) {
                  $query->where('part_no', '!=', 'NULL');
              })
            ],
            'name' => 'required',
            'item_code' => 'required',
            'category_id' => 'required',
            'sub_category_id' => 'required',
            //'tax' => 'required|min:0',
            // 'unit_price' => 'required|numeric|min:1',
            // 'purchase_price' => 'required|numeric|min:1',
        ], [
            'name.required' => 'Product name is required!',
            'item_code.required' => 'item code is required!',
            'category_id.required' => 'category  is required!',
            // 'unit_price.required' => 'unit price  is required!',
            // 'unit_price.numeric' => 'unit price  is numeric!',
            // 'purchase_price.required' => 'purchase price  is required!',
            // 'purchase_price.numeric' => 'purchase price  is numeric!',
            'sub_category_id.required' => 'sub category  is required!',
            'images.required' => 'Product images is required!',
            'image.required' => 'Product thumbnail is required!',
        ]);


        if ($request['discount_type'] == 'percent') {
            $dis = ($request['unit_price'] / 100) * $request['discount'];
        } else {
            $dis = $request['discount'];
        }

        if ($request['unit_price'] <= $dis) {
            $validator->after(function ($validator) {
                $validator->errors()->add('unit_price', 'Discount can not be more or equal to the price!');
            });
        }

        $product = Product::find($id);
        $product->name = $request->name[array_search('en', $request->lang)];

        $category = [];
        if ($request->category_id != null) {
            array_push($category, [
                'id' => $request->category_id,
                'position' => 0,
            ]);
        }
        if ($request->sub_category_id != null) {
            array_push($category, [
                'id' => $request->sub_category_id,
                'position' => 1,
            ]);
        }
        if ($request->sub_sub_category_id != null) {
            array_push($category, [
                'id' => $request->sub_sub_category_id,
                'position' => 2,
            ]);
        }
        $product->category_ids = json_encode($category);
        $product->brand_id = $request->brand_id;
        $product->item_code = $request->item_code;
        $product->part_no = $request->part_no;
        $product->serial_no = $request->serial_no;
        $product->unit = $request->unit;
        $product->details = $request->description[array_search('en', $request->lang)];

        if ($request->has('colors_active') && $request->has('colors') && count($request->colors) > 0) {
            $product->colors = json_encode($request->colors);
        } else {
            $colors = [];
            $product->colors = json_encode($colors);
        }
        $choice_options = [];
        if ($request->has('choice')) {
            foreach ($request->choice_no as $key => $no) {
                $str = 'choice_options_' . $no;
                $item['name'] = 'choice_' . $no;
                $item['title'] = $request->choice[$key];
                $item['options'] = explode(',', implode('|', $request[$str]));
                array_push($choice_options, $item);
            }
        }
        $product->choice_options = json_encode($choice_options);
        $variations = [];
        //combinations start
        $options = [];
        if ($request->has('colors_active') && $request->has('colors') && count($request->colors) > 0) {
            $colors_active = 1;
            array_push($options, $request->colors);
        }
        if ($request->has('choice_no')) {
            foreach ($request->choice_no as $key => $no) {
                $name = 'choice_options_' . $no;
                $my_str = implode('|', $request[$name]);
                array_push($options, explode(',', $my_str));
            }
        }
        //Generates the combinations of customer choice options
        $combinations = Helpers::combinations($options);
        $checkPrice ='';$variations = [];$stock_count = 0;
        if (count($combinations[0]) > 0) {
            $unitPriceFlag = 1;
            foreach ($combinations as $key => $combination) {
                $str = '';
                foreach ($combination as $k => $item) {
                    if ($k > 0) {
                        $str .= '-' . str_replace(' ', '', $item);
                    } else {
                        if ($request->has('colors_active') && $request->has('colors') && count($request->colors) > 0) {
                            $color_name = Color::where('code', $item)->first()->name;
                            $str .= $color_name;
                        } else {
                            $str .= str_replace(' ', '', $item);
                        }
                    }
                }
                if(($request['verify_status_' . str_replace('.','_',$str)]==1 && !empty($request['price_' . str_replace('.', '_', $str)]) && abs($request['price_' . str_replace('.', '_', $str)]) > 0))
                {
                    $checkPrice = true;
                    if($unitPriceFlag == 1)
                    {
                        $unitPrice = $request['price_' . str_replace('.', '_', $str)];
                        $unitPriceFlag++;
                    }
                }
                $item = [];
                $item['type'] = $str;
                //$item['price'] = Convert::usd(abs($request['price_' . str_replace('.', '_', $str)]));
                // --change this to newly formed
                //$item['price'] = Convert::converToUsd(abs($request['price_' . str_replace('.', '_', $str)]),auth('seller')->id());
                $item['price'] = BackEndHelper::systemcurrency_to_selectedcurrency(abs($request['price_' . str_replace('.', '_', $str)]));
                $item['sku'] = $request['sku_' . str_replace('.', '_', $str)];
                $item['qty'] = abs($request['qty_' . str_replace('.', '_', $str)]);
                // $item['discount'] = BackEndHelper::systemcurrency_to_selectedcurrency(abs($request['discount_' . str_replace('.','_',$str)]));

                (!empty($request['discount_' . str_replace('.','_',$str)]))?$VDiscount = $request['discount_' . str_replace('.','_',$str)]:$VDiscount = 0;
                    $item['discount'] = BackEndHelper::systemcurrency_to_selectedcurrency(abs($VDiscount));

                    (!empty($request['startdate_' . str_replace('.','_',$str)]))?$VDStartDate = $request['startdate_' . str_replace('.','_',$str)]:$VDStartDate = '';
                    (!empty($request['starttime_' . str_replace('.','_',$str)]))?$VDStartTime = $request['starttime_' . str_replace('.','_',$str)]:$VDStartTime = '';
                    if(!empty($VDStartDate) && !empty($VDStartTime)){
                        $comStartDAte = $VDStartDate.' '.$VDStartTime;
                    }
                    else{
                        $comStartDAte = 'null';
                    }

                    $item['startDuration'] =  $comStartDAte;

                    (!empty($request['enddate_' . str_replace('.','_',$str)]) && $request['enddate_' . str_replace('.','_',$str)] != '0000-00-00')?$VDEndDate = $request['enddate_' . str_replace('.','_',$str)]:$VDEndDate = '';
                    (!empty($request['endtime_' . str_replace('.','_',$str)] && $request['endtime_' . str_replace('.','_',$str)] != '00:00'))?$VDEndTime = $request['endtime_' . str_replace('.','_',$str)]:$VDEndTime = '';

                    if(!empty($VDEndDate) && !empty($VDEndTime)){
                        $comEndDAte = $VDEndDate.' '.$VDEndTime;
                    }
                    else{
                        $comEndDAte = 'null';
                    }
                    
                    $item['endDuration'] =  $comEndDAte;

                    $item['isverified_V_Discount'] =  $request['verify_status_' . str_replace('.','_',$str)];


                array_push($variations, $item);
                $stock_count += $item['qty'];
            }
        } 
        else 
        {
            if((empty($request->unit_price) || $request->unit_price == 0))
            {
                $checkPrice = false;
            }
            $unitPrice = $request->unit_price;
            $stock_count = (integer)$request['current_stock'];
        }
        if (!$checkPrice && $checkPrice != '') {
            $validator->after(function ($validator) {
                $validator->errors()->add(
                    'unit_price', 'Please assign Unit Price or Price For atleast One Variant as a verified Variant!'
                );
            });
        }

        if ($validator->errors()->count() > 0) {
            return response()->json(['errors' => Helpers::error_processor($validator)]);
        }

        //combinations end
        $product->variation = json_encode($variations);

        $product->unit_price = BackEndHelper::systemcurrency_to_selectedcurrency($unitPrice);
        //$product->unit_price = Helpers::currency_converter($request->unit_price);
        //$product->unit_price = Convert::usd($request->unit_price);
        //$product->unit_price = BackEndHelper::usd_to_currency($request->unit_price);

        (!empty($request->purchase_price))?$purchasePrice = $request->purchase_price:$purchasePrice = 0;
        $product->purchase_price = BackEndHelper::systemcurrency_to_selectedcurrency($purchasePrice);
        //$product->purchase_price = Helpers::currency_converter($request->purchase_price);
        //$product->purchase_price = Convert::usd($request->purchase_price);
        //$product->purchase_price = BackEndHelper::usd_to_currency($request->purchase_price);
        $product->tax = $request->tax;
        $product->tax_type = $request->tax_type;
        // $product->discount = $request->discount_type == 'flat' ? BackEndHelper::systemcurrency_to_selectedcurrency($request->discount) : $request->discount;
        $product->attributes = json_encode($request->choice_attributes);
        $product->discount_type = $request->discount_type;
        $product->current_stock = abs($stock_count);

        $product->video_provider = 'youtube';
        $product->video_url = $request->video_link;
        if ($product->request_status == 2) {
            $product->request_status = 0;
        }

        if ($request->ajax()) {
            return response()->json([], 200);
        } else {
            $product_images = json_decode($product->images);
            if ($request->file('images')) {
                foreach ($request->file('images') as $img) {
                    $product_images[] = ImageManager::upload('product/', 'png', $img);
                }
                $product->images = json_encode($product_images);
            }

            if ($request->file('image')) {
                $product->thumbnail = ImageManager::update('product/thumbnail/', $product->thumbnail, 'png', $request->file('image'));
            }

            $product->meta_title = $request->meta_title;
            $product->meta_description = $request->meta_description;
            if ($request->file('meta_image')) {
                $product->meta_image = ImageManager::update('product/meta/', $product->meta_image, 'png', $request->file('meta_image'));
            }

            $product->save();

             $disco=$request->discount_amt;
            if(!empty($disco) &&  $disco )
            {
                $answers = [];
                ProductDiscount::where("product_id", $product->id)->update(["status" => 1]);
                 for ($i = 0; $i < count($disco); $i++) {
                    if($disco[$i] > 0)
                    {

                        $answers[] = [
                            'product_id'    => $product->id,
                            'discount'      => BackEndHelper::systemcurrency_to_selectedcurrency($disco[$i]),
                            'start_date'    => $request->startdate[$i],
                            'start_time'    => $request->starttime[$i],
                            'end_date'      => $request->enddate[$i],
                            'end_time'      => $request->endtime[$i],
                            'quantity'      => $request->quantity[$i],
                            'Buy'           => $request->buy[$i],
                            'Item'          => $request->item[$i],
                        ];
                    }
                 }
                  if(count($answers) > 0){
                ProductDiscount::insert($answers);
                }
            }
            

            foreach ($request->lang as $index => $key) {
                if ($request->name[$index] && $key != 'en') {
                    Translation::updateOrInsert(
                        ['translationable_type' => 'App\Model\Product',
                            'translationable_id' => $product->id,
                            'locale' => $key,
                            'key' => 'name'],
                        ['value' => $request->name[$index]]
                    );
                }
                if ($request->description[$index] && $key != 'en') {
                    Translation::updateOrInsert(
                        ['translationable_type' => 'App\Model\Product',
                            'translationable_id' => $product->id,
                            'locale' => $key,
                            'key' => 'description'],
                        ['value' => $request->description[$index]]
                    );
                }
            }
            Toastr::success('Product updated successfully.');
            return back();
        }
    }

    public function view($id)
    {
        $product = Product::with(['reviews'])->where(['id' => $id])->first();
        $reviews = Review::where(['product_id' => $id])->paginate(Helpers::pagination_limit());
        return view('seller-views.product.view', compact('product', 'reviews'));
    }

    public function remove_image(Request $request)
    {
        ImageManager::delete('/product/' . $request['image']);
        $product = Product::find($request['id']);
        $array = [];
        if (count(json_decode($product['images'])) < 2) {
            Toastr::warning('You cannot delete all images!');
            return back();
        }
        foreach (json_decode($product['images']) as $image) {
            if ($image != $request['name']) {
                array_push($array, $image);
            }
        }
        Product::where('id', $request['id'])->update([
            'images' => json_encode($array),
        ]);
        Toastr::success('Product image removed successfully!');
        return back();
    }

    public function delete($id)
    {
        $product = Product::find($id);
        Cart::where('product_id', $product->id)->delete();
        foreach (json_decode($product['images'], true) as $image) {
            ImageManager::delete('/product/' . $image);
        }
        ImageManager::delete('/product/thumbnail/' . $product['thumbnail']);
        $product->delete();
        FlashDealProduct::where(['product_id' => $id])->delete();
        DealOfTheDay::where(['product_id' => $id])->delete();
        Toastr::success('Product removed successfully!');
        return back();
    }

    public function bulk_import_index()
    {
        return view('seller-views.product.bulk-import');
    }

    public function bulk_import_data(Request $request)
    {
        try {
            $collections = (new FastExcel)->import($request->file('products_file'));
        } catch (\Exception $exception) {
            Toastr::error('You have uploaded a wrong format file, please upload the right file.');
            return back();
        }
        $data = [];
        $skip = ['youtube_video_url','details','unit','part_no','serial_no','brand_id','sub_sub_category_id','discount','discount_type',];
        foreach ($collections as $collection) {
            foreach ($collection as $key => $value) {
                if ($value === "" && !in_array($key, $skip)) {
                    Toastr::error('Please fill ' . $key . ' fields');
                    return back();
                }
            }

            // $thumbnail = explode('/', $collection['thumbnail']);

            array_push($data, [
                'name' => $collection['name'],
                'item_code' => $collection['item_code'],
                'part_no' => $collection['part_no'],
                'serial_no' => $collection['serial_no'],
                'slug' => Str::slug($collection['name'], '-') . '-' . Str::random(6),
                 'category_ids' => json_encode([['id' => $collection['category_id'], 'position' => 0], ['id' => $collection['sub_category_id'], 'position' => 1],['id' => $collection['sub_sub_category_id'], 'position' => 2]]),
                'brand_id' => $collection['brand_id'],
                'unit' => $collection['unit'],
                'min_qty' => $collection['min_qty'],
                'refundable' => $collection['refundable'],
                // 'unit_price' => $collection['unit_price'],
                // 'purchase_price' => $collection['purchase_price'],
                'unit_price' => Convert::converToUsd($collection['unit_price'],auth('seller')->id()),
                'purchase_price' =>  Convert::converToUsd($collection['purchase_price'],auth('seller')->id()),
                'tax' => $collection['tax'],
                // 'discount' => $collection['discount'],
                // 'discount_type' => $collection['discount_type'],
                'current_stock' => $collection['current_stock'],
                'details' => $collection['details'],
                'video_provider' => 'youtube',
                'video_url' => $collection['youtube_video_url'],
                'images' => json_encode(['def.png']),
                // 'thumbnail' => $thumbnail[1],
                'status' => 0,
                'colors' => json_encode([]),
                'attributes' => json_encode([]),
                'choice_options' => json_encode([]),
                'variation' => json_encode([]),
                'featured_status' => 1,
                'added_by' => 'seller',
                'user_id' => auth('seller')->id(),
            ]);
        }
        DB::table('products')->insert($data);
        Toastr::success(count($data) . ' - Products imported successfully!');
        return back();
    }

    public function bulk_export_data()
    {
        $products = Product::where(['added_by' => 'seller', 'user_id' => \auth('seller')->id()])->get();
        //export from product
        $storage = [];
        foreach ($products as $item) {
            $category_id = 0;
            $sub_category_id = 0;
            $sub_sub_category_id = 0;
            foreach (json_decode($item->category_ids, true) as $category) {
                if ($category['position'] == 0) {
                    $category_id = $category['id'];
                } else if ($category['position'] == 1) {
                    $sub_category_id = $category['id'];
                } else if ($category['position'] == 2) {
                    $sub_sub_category_id = $category['id'];
                }
            }
            $storage[] = [
                'name' => $item->name,
                'item_code' => $item->item_code,
                'part_no' => $item->part_no,
                'serial_no' => $item->serial_no,
                'category_id' => $category_id,
                'sub_category_id' => $sub_category_id,
                'sub_sub_category_id' => $sub_sub_category_id,
                'brand_id' => $item->brand_id,
                'unit' => $item->unit,
                'min_qty' => $item->min_qty,
                'refundable' => $item->refundable,
                'youtube_video_url' => $item->video_url,
                'unit_price' => $item->unit_price,
                'purchase_price' => $item->purchase_price,
                'tax' => $item->tax,
                'discount' => $item->discount,
                'discount_type' => $item->discount_type,
                'current_stock' => $item->current_stock,
                'details' => $item->details,
                'thumbnail' => 'thumbnail/'.$item->thumbnail

            ];
        }
        return (new FastExcel($storage))->download('products.xlsx');
    }

     //new code 13_05_22

    public function brand_export()
    {
        $brands = Brand::where(['status' => 1])->get();
        //export from product
        $brandsarray = [];
        foreach ($brands as $item) {
            $brandsarray[] = [
                 'id' => $item->id,
                'name' => $item->name
            ];
        }
        return (new FastExcel($brandsarray))->download('brands.xlsx');
    }

    public function seller_guide()
    {
            $selectedCatIds = CategoryBlock::where(['seller_id' => auth('seller')->id(),'delete_status' => 0])->pluck('level0_id');
            if(!empty($selectedCatIds)){
                $selectedCatIds = $selectedCatIds->toArray();
            }else{
                $selectedCatIds = array();
            }
            $items = Category::with('childes')->whereIn('id', $selectedCatIds)->where('parent_id',0)->get();

            $allowedBrandIds = Brandallowe::where(['seller_id' => auth('seller')->id(),'delete_status' => 0])->pluck('brand_id');
            if(!empty($allowedBrandIds)){
                $allowedBrandIds = $allowedBrandIds->toArray();
            }else{
                $allowedBrandIds = array();
            }
            $brands = Brand::whereIn('id', $allowedBrandIds)->get();
            
            $allowedUnitIds = unitallowe::where(['seller_id' => auth('seller')->id(),'delete_status' => 0])->pluck('unit_id');
            if(!empty($allowedUnitIds)){
                $allowedUnitIds = $allowedUnitIds->toArray();
            }else{
                $allowedUnitIds = array();
            }
            $units = Unit::whereIn('id', $allowedUnitIds)->get();
            return view('seller-views.product.csv_instruction', compact('items','selectedCatIds','brands','units'));
        
    }

    public function category_export()
    {
        $Category = Category::where(['position' => 0])->get();
        //export from product
        $Categoryarray = [];
        foreach ($Category as $item) {
            $Categoryarray[] = [
                'id' => $item->id,
                'name' => $item->name,
                'slug' => $item->slug
            ];
        }
        return (new FastExcel($Categoryarray))->download('Category.xlsx');
    }

    public function sub_category_export()
    {
        $SubCategory = Category::where(['position' => 1])->get();
        //export from product
        $SubCategoryarray = [];
        foreach ($SubCategory as $item) {
            $SubCategoryarray[] = [
                'id' => $item->id,
                'name' => $item->name,
                'slug' => $item->slug
            ];
        }
        return (new FastExcel($SubCategoryarray))->download('Subcategory.xlsx');
    }

    public function sub_sub_category_export()
    {
        $SubSubCategory = Category::where(['position' => 2])->get();
        //export from product
        $SubSubCategoryarray = [];
        foreach ($SubSubCategory as $item) {
            $SubSubCategoryarray[] = [
                'id' => $item->id,
                'name' => $item->name,
                'slug' => $item->slug
            ];
        }
        return (new FastExcel($SubSubCategoryarray))->download('Subsubcategory.xlsx');
    }
}
