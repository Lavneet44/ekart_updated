<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class plantabsInvoice extends Model
{
    protected $table = 'plantabs_invoices';

}