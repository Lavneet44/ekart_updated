<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Auth;
use App\Model\Currency;

class SellerMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param \Illuminate\Http\Request $request
     * @param \Closure $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        //if (auth('seller')->check() && auth('seller')->user()->status == 'active') {
        
        if (auth('seller')->check() && auth('seller')->user()->new_seller_status == 'active') {
            session()->put('seller_currency_id', auth('seller')->user()->seller_currency);

            $sell_curr_condition = [];
            if (session()->has('seller_currency_id')) {
                $sell_curr_condition = ['id' => session()->get('seller_currency_id')];
            } else {
                $sell_curr_condition = ['default_currency' => 1];
            }
            $sellercurrency = Currency::where($sell_curr_condition)->first();
            if(!empty($sellercurrency))
            {
                session()->put('sellercurrencycode', $sellercurrency->code);
                session()->put('sellercurrencysymbol', $sellercurrency->symbol);
                // -- initially above sessions are in use but we can also entire info of seller currency to a single session-- //
                session()->put('seller_currency_info', $sellercurrency);
            }
            return $next($request);
        }
        auth()->guard('seller')->logout();
        return redirect()->route('seller.auth.login');
    }
}
