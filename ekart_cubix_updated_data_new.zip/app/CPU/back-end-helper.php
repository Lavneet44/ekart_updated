<?php

namespace App\CPU;

use App\Model\BusinessSetting;
use App\Model\Currency;
use App\Model\Order;
use Illuminate\Support\Carbon;

class BackEndHelper
{
    public static function currency_to_usd($amount)
    {
        $currency_model = Helpers::get_business_settings('currency_model');
        if ($currency_model == 'multi_currency') {
            $default = Currency::find(BusinessSetting::where(['type' => 'system_default_currency'])->first()->value);
            $usd = Currency::where('code', 'USD')->first()->exchange_rate;
            $rate = $default['exchange_rate'] / $usd;
            $value = floatval($amount) / floatval($rate);
        } else {
            $value = floatval($amount);
        }

        return $value;
    }

    public static function usd_to_currency($amount)
    {
        $currency_model = Helpers::get_business_settings('currency_model');
        if ($currency_model == 'multi_currency') {

            if (session()->has('default')) {
                $default = session('default');
            } else {
                $default = Currency::find(Helpers::get_business_settings('system_default_currency'))->exchange_rate;
                session()->put('default', $default);
            }

            if (session()->has('usd')) {
                $usd = session('usd');
            } else {
                $usd = Currency::where('code', 'USD')->first()->exchange_rate;
                session()->put('usd', $usd);
            }

            $rate = $default / $usd;
            $value = floatval($amount) * floatval($rate);
        } else {
            $value = floatval($amount);
        }

        return round($value, 2);
    }

    public static function systemcurrency_to_selectedcurrency($amount)
    {
        $system_default_exRate = $user_selected_exRate =""; $value = 0;
        $currency_model = Helpers::get_business_settings('currency_model');
        if ($currency_model == 'multi_currency') {
            if (session()->has('seller_currency_info')) {
                $selected_currency = ['id' => session()->get('seller_currency_info')->id];
            } else {
                $selected_currency = ['default_currency' => 1];
            }

            $sellerDcurrency = Currency::where($selected_currency)->first();
            if(!empty($sellerDcurrency))
            {
                $user_selected_exRate = $sellerDcurrency->exchange_rate;
            }


            if (session()->has('system_default_currency_info')) {
                $system_default_exRate = session()->get('system_default_currency_info')->exchange_rate;
            } else {
                $system_default_exRate = Currency::where('default_currency',1)->first('exchange_rate');
            }

            if(!empty($system_default_exRate) && !empty($user_selected_exRate))
            {
                $value = floatval(($system_default_exRate/$user_selected_exRate)*$amount);
            }


        } else {
            $value = floatval($amount);
        }
        return $value;

    }

    public static function currency_symbol()
    {
        $currency = Currency::where('id', Helpers::get_business_settings('system_default_currency'))->first();
        return $currency->symbol;
    }

    public static function set_symbol($amount)
    {
        $position = Helpers::get_business_settings('currency_symbol_position');
        if (!is_null($position) && $position == 'left') {
            $string = currency_symbol() . '' . number_format($amount, 2);
        } else {
            $string = number_format($amount, 2) . '' . currency_symbol();
        }
        return $string;
    }

    // --- function to formate currency [implimented for admin only now] ---//
    public static function currency_formate($amount)
    {
        $position = Helpers::get_business_settings('currency_symbol_position');
        $systemDefaultCurrencyInfo = Currency::where('id', Helpers::get_business_settings('system_default_currency'))->first();
        if (!is_null($position) && $position == 'left') {
            $string = currency_symbol() . ' ' . number_format($amount, $systemDefaultCurrencyInfo->currency_formate);
        } else {
            $string = number_format($amount, $systemDefaultCurrencyInfo->currency_formate) . ' ' . currency_symbol();
        }
        return $string;
    }

    public static function set_plan_currency($amount,$currencyId)
    {
        //$position = Helpers::get_business_settings('currency_symbol_position');
        $position = 'Right';
        $currency = Currency::where('id', $currencyId)->first();

        if (!is_null($position) && $position == 'left') {
            $string = $currency->symbol . ' ' . number_format($amount, $currency->currency_formate);
        } else {
            $string = number_format($amount, $currency->currency_formate) . ' ' . $currency->symbol;
        }
        return $string;
    }

    public static function set_plan_duration($duration,$durationType)
    {
        //$position = Helpers::get_business_settings('currency_symbol_position');
        $position = "Right";
        if($durationType=='1'){
            $durationType='Days';
        }elseif($durationType=='2'){
            if($duration==1)
                return 'Month';
            $durationType='Months';
        }elseif($durationType=='3'){
            $durationType='Year';
        }else{
            $durationType='-';
        }
        if (!is_null($position) && $position == 'left') {
            $string = $durationType . ' ' . $duration;
        } else {
            $string = $duration . ' ' . $durationType;
        }
        return $string;
    }

    public static function currency_code()
    {
        $currency = Currency::where('id', Helpers::get_business_settings('system_default_currency'))->first();
        return $currency->code;
    }

    public static function max_earning()
    {
        $data = Order::where(['order_status' => 'delivered'])->select('id', 'created_at', 'order_amount')
            ->get()
            ->groupBy(function ($date) {
                return Carbon::parse($date->created_at)->format('m');
            });

        $max = 0;
        foreach ($data as $month) {
            $count = 0;
            foreach ($month as $order) {
                $count += $order['order_amount'];
            }
            if ($count > $max) {
                $max = $count;
            }
        }
        return $max;
    }

    public static function max_orders()
    {
        $data = Order::select('id', 'created_at')
            ->get()
            ->groupBy(function ($date) {
                return Carbon::parse($date->created_at)->format('m');
            });

        $max = 0;
        foreach ($data as $month) {
            $count = 0;
            foreach ($month as $order) {
                $count += 1;
            }
            if ($count > $max) {
                $max = $count;
            }
        }
        return $max;
    }

}
