<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class SubscriptionPlan extends Model
{

    protected $table = 'subscription_plans';

    public function currency()
    {
        return $this->hasMany(Currency::class,'id','currency_id');
    }

    public function planCurrency()
    {
        return $this->hasOne(Currency::class,'id','currency_id');
    }

    public function offer()
    {
        return $this->hasOne(PlanOffer::class,'plan_id','id');
    }

    public function offers()
    {
        return $this->hasMany(PlanOffer::class,'plan_id','id');
    }

    public function latestoffers()
    {
        return $this->hasOne(PlanOffer::class,'plan_id','id')->latest();
    }

    public function validOffers()
    {
        return $this->offers()
        ->where('offer_delete',0)
        ->whereNotNull('offer_startdate')
        ->where('offer_startdate','<=',date('Y-m-d'))
        ->whereHold(0)->orderBy('id','DESC');
    }

}
