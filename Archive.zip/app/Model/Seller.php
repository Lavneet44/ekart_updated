<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class Seller extends Authenticatable
{
    use Notifiable;

    protected $casts = [
        'id' => 'integer',
        'orders_count' => 'integer',
        'product_count' => 'integer',
    ];

    public function scopeApproved($query)
    {
        return $query->where(['status'=>'approved']);
    }

    public function shop()
    {
        return $this->hasOne(Shop::class, 'seller_id');
    }

    public function shops()
    {
        return $this->hasMany(Shop::class, 'seller_id');
    }

    public function orders()
    {
        return $this->hasMany(Order::class, 'seller_id');
    }

    public function product()
    {
        return $this->hasMany(Product::class, 'user_id')->where(['added_by'=>'seller']);
    }

    public function wallet()
    {
        return $this->hasOne(SellerWallet::class);
    }

    public function sellerpplan()
    {
        return $this->hasOne(SellerPlan::class,);
    }

    public function registerSellerPlanRequest()
    {
        return $this->hasOne(SubscriptionPlan::class,'id','seller_plan_request');
    }

    public function registerSellerPlanRequestOffer()
    {
        return $this->hasOne(PlanOffer::class,'id','plan_offer_id');
    }

    public function registerSellerPlan()
    {
        return $this->hasOne(SubscriptionPlan::class,'id','seller_plan_request');
    }

    public function registerSellerPlanWithOffers()
    {
        return $this->registerSellerPlan()->with('offers'); 
    }

    public function paidSeller()
    {
        return $this->hasOne(plantabsInvoice::class, 'seller_id','id');
    }

    public function SellerCurrency()
    {
        return $this->hasOne(Currency::class, 'id','seller_currency');
    }

} 
    