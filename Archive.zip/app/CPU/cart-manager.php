<?php

namespace App\CPU;

use App\Model\Cart;
use App\Model\CartShipping;
use App\Model\Color;
use App\Model\Product;
use App\Model\ProductVariant;
use App\Model\CreditPermission;
use App\Model\Shop;
use Barryvdh\Debugbar\Twig\Extension\Debug;
use Cassandra\Collection;
use Illuminate\Support\Str;

class CartManager
{
    public static function cart_to_db()
    {
        $user = Helpers::get_customer();
        if (session()->has('offline_cart')) {
            $cart = session('offline_cart');
            $storage = [];
            foreach ($cart as $item) {
                $db_cart = Cart::where(['customer_id' => $user->id, 'seller_id' => $item['seller_id'], 'seller_is' => $item['seller_is']])->first();
                $storage[] = [
                    'customer_id' => $user->id,
                    'cart_group_id' => isset($db_cart) ? $db_cart['cart_group_id'] : str_replace('offline', $user->id, $item['cart_group_id']),
                    'product_id' => $item['product_id'],
                    'color' => $item['color'],
                    'choices' => $item['choices'],
                    'variations' => $item['variations'],
                    'variant' => $item['variant'],
                    'quantity' => $item['quantity'],
                    'price' => $item['price'],
                    'tax' => $item['tax'],
                    'discount' => $item['discount'],
                    'slug' => $item['slug'],
                    'name' => $item['name'],
                    'thumbnail' => $item['thumbnail'],
                    'seller_id' => $item['seller_id'],
                    'seller_is' => $item['seller_is'],
                    'shop_info' => $item['shop_info'],
                    'created_at' => now(),
                    'updated_at' => now(),
                ];
            }
            Cart::insert($storage);
            session()->put('offline_cart', collect([]));
        }
    }

    public static function get_cart($group_id = null)
    {
        $user = Helpers::get_customer();
        if (session()->has('cart_session')) {
            $cart = session('offline_cart');
            if($user == 'offline'){
                return Cart::where('cart_group_id',session('cart_session'))->get();
            }else{
                return Cart::where('customer_id',auth('customer')->id())->orWhere('cart_group_id',session('cart_session'))->get();
            }
        }
        if ($group_id == null) {
            $cart = Cart::whereIn('cart_group_id', CartManager::get_cart_group_ids())->get();
        } else {
            $cart = Cart::where('cart_group_id', $group_id)->get();
        }

        return $cart;
    }

    public static function get_credit_permission($cart = null)
    {
        $value = array();
        $permission = false;
        foreach($cart as $key => $c)
        {
            $pro = Product::whereId($c->product_id)->first();
            $CreditPermission = CreditPermission::whereSellerId($pro->seller->id)->whereCustomerId($c->customer_id)->first();
            if(!empty($CreditPermission))
            {
                $v = $CreditPermission->credit_permission? 'true' : 'false';
                array_push($value,$v);
            }
        }

        if(!in_array('false',$value,true) && !empty($value))
        {
            $permission = true;
        }
        return $permission;
    }

    public static function get_cart_group_ids($request = null)
    {
        $user = Helpers::get_customer($request);
        if ($user == 'offline') {
            if (session()->has('offline_cart') == false) {
                session()->put('offline_cart', collect([]));
            }
            $cart = session('offline_cart');
            $cart_ids = array_unique($cart->pluck('cart_group_id')->toArray());
        } else {
            $cart_ids = Cart::where(['customer_id' => $user->id])->groupBy('cart_group_id')->pluck('cart_group_id')->toArray();
        }
        return $cart_ids;
    }

    public static function get_shipping_cost($group_id = null)
    {
        if ($group_id == null) {
            $cost = CartShipping::whereIn('cart_group_id', CartManager::get_cart_group_ids())->sum('shipping_cost');
        } else {
            $data = CartShipping::where('cart_group_id', $group_id)->first();
            $cost = isset($data) ? $data->shipping_cost : 0;
        }
        return $cost;
    }

    public static function cart_total($cart)
    {
        $total = 0;
        if (!empty($cart)) {
            foreach ($cart as $item) {
                $product_subtotal = $item['price'] * $item['quantity'];
                $total += $product_subtotal;
            }
        }
        return $total;
    }

    public static function cart_total_applied_discount($cart)
    {
        $total = 0;
        if (!empty($cart)) {
            foreach ($cart as $item) {
                $product_subtotal = ($item['price'] - $item['discount']) * $item['quantity'];
                $total += $product_subtotal;
            }
        }
        return $total;
    }

    public static function cart_total_with_tax($cart)
    {
        $total = 0;
        if (!empty($cart)) {
            foreach ($cart as $item) {
                $product_subtotal = ($item['price'] * $item['quantity']) + ($item['tax'] * $item['quantity']);
                $total += $product_subtotal;
            }
        }
        return $total;
    }

    public static function cart_grand_total($cart_group_id = null)
    {
        $cart = CartManager::get_cart($cart_group_id);
        $shipping_cost = CartManager::get_shipping_cost($cart_group_id);
        $total = 0;
        if (!empty($cart)) {
            foreach ($cart as $item) {
                $product_subtotal = ($item['price'] * $item['quantity'])
                    + ($item['tax'] * $item['quantity'])
                    - $item['discount'] * $item['quantity'];
                $total += $product_subtotal;
            }
            $total += $shipping_cost;
        }
        return $total;
    }

    public static function cart_clean($request = null)
    {
        $cart_ids = CartManager::get_cart_group_ids($request);
        CartShipping::whereIn('cart_group_id', $cart_ids)->delete();
        Cart::whereIn('cart_group_id', $cart_ids)->delete();

        session()->forget('coupon_code');
        session()->forget('coupon_discount');
        session()->forget('payment_method');
        session()->forget('shipping_method_id');
        session()->forget('billing_address_id');
        session()->forget('order_id');
        session()->forget('cart_group_id');
        session()->forget('order_note');
    }

    public static function add_to_cart($request, $from_api = false)
    {
        // return($request);
        $product_id = $request->id;
        $str = '';
        $variations = [];
        $price = 0;

        $user = Helpers::get_customer($request);
        // return $user;
        $product = Product::find($request->id);
        // return response()->json($product);die;
        if ($request->has('color')) {
            $str = $request['color'];
            $variations['color'] = $str;
        }


        $choices = [];
        $qty_selected = [];
        $variant_selected = [];
        if(!empty($request->quantity)){
            foreach($request->quantity as $q => $qt){
                if($qt > 0){
                    if($user == 'offline'){
                        if (session()->has('cart_session')) {
                            $cart = session('offline_cart');
                            $check = Cart::where('cart_group_id',session('cart_session'))->where('product_id', $product->id)->where('variant', $request['variants_id'][$q])->first();
                            if (isset($check) == false) {
                                $tax = Helpers::tax_calculation($price, $product['tax'], 'percent');
                                $variantProduct = ProductVariant::where(['id' => $request['variants_id'][$q],'product_id' => $product->id])->first();
                                $price = (!empty($variantProduct->price) && $variantProduct->price > 0)?$variantProduct->price:0;
                                $cart = new Cart();
                                $cart['color'] = $request->has('color') ? $request['color'] : null;
                                $cart['product_id'] = $product->id;
                                $cart['variations'] = json_encode($variations); 
                                $cart['cart_group_id'] = session('cart_session');
                                $cart['customer_id'] = $user->id ?? 0;
                                $cart['quantity'] = $qt;
                                $cart['price'] = $price;
                                $cart['tax'] = $tax;
                                $cart['variant'] = $request['variants_id'][$q];
                                $cart['slug'] = $product->slug;
                                $cart['name'] = $product->name;
                                $cart['thumbnail'] = $product->thumbnail;
                                $cart['seller_id'] = ($product->added_by == 'admin') ? 1 : $product->user_id;
                                $cart['seller_is'] = $product->added_by;
                                if ($product->added_by == 'seller') {
                                    $cart['shop_info'] = Shop::where(['seller_id' => $product->user_id])->first()->name;
                                } else {
                                    $cart['shop_info'] = Helpers::get_business_settings('company_name');
                                }
                                $cart->save();
                            } else {
                                Cart::where('cart_group_id',session('cart_session'))->where('product_id', $product->id)->where('variant', $request['variants_id'][$q])->update(['quantity'=>($check['quantity']+$qt)]);
                                return [
                                    'status' => 1,
                                    'message' => 'Qty Updated',
                                ];
                            }
                        } else {
                            $tax = Helpers::tax_calculation($price, $product['tax'], 'percent');
                            $variantProduct = ProductVariant::where(['id' => $request['variants_id'][$q],'product_id' => $product->id])->first();
                            $price = (!empty($variantProduct->price) && $variantProduct->price > 0)?$variantProduct->price:0;
                            $cart = new Cart();
                            $cart['color'] = $request->has('color') ? $request['color'] : null;
                            $cart['product_id'] = $product->id;
                            $cart['variations'] = json_encode($variations); 
                            if ($user == 'offline') {
                                $check = session('offline_cart');
                                $cart_check = $check
                                    ->where(['seller_id'=> ($product->added_by == 'admin') ? 1 : $product->user_id])
                                    ->where('seller_is', $product->added_by)
                                    ->first();
                            } else {
                                $cart_check = Cart::where([
                                    'customer_id' => $user->id,
                                    'seller_id' => ($product->added_by == 'admin') ? 1 : $product->user_id,
                                    'seller_is' => $product->added_by])->first();
                            }

                            session()->put('cart_session', time());
                            if (isset($cart_check)) {
                                $cart['cart_group_id'] = $cart_check['cart_group_id'];
                            } else {
                                $cart['cart_group_id'] = session('cart_session');
                            }

                            $cart['customer_id'] = $user->id ?? 0;
                            $cart['quantity'] = $qt;
                            $cart['price'] = $price;
                            $cart['tax'] = $tax;
                            $cart['slug'] = $product->slug;
                            $cart['name'] = $product->name;
                            $cart['variant'] = $request['variants_id'][$q];
                            $cart['thumbnail'] = $product->thumbnail;
                            $cart['seller_id'] = ($product->added_by == 'admin') ? 1 : $product->user_id;
                            $cart['seller_is'] = $product->added_by;
                            if ($product->added_by == 'seller') {
                                $cart['shop_info'] = Shop::where(['seller_id' => $product->user_id])->first()->name;
                            } else {
                                $cart['shop_info'] = Helpers::get_business_settings('company_name');
                            }
                            $cart->save();
                        }
                    }else{
                        $check = Cart::where('product_id', $product->id)->where('customer_id',$user->id)->where('variant', $request['variants_selection'][$q])->first();
                        if(!$check){
                            $tax = Helpers::tax_calculation($price, $product['tax'], 'percent');
                            $variantProduct = ProductVariant::where(['id' => $request['variants_id'][$q],'product_id' => $product->id])->first();
                            $price = (!empty($variantProduct->price) && $variantProduct->price > 0)?$variantProduct->price:0;
                            $cart = new Cart();
                            $cart['color'] = $request->has('color') ? $request['color'] : null;
                            $cart['product_id'] = $product->id;
                            $cart['variations'] = json_encode($variations); 
                            
                            session()->put('cart_session', time());
                            $cart['cart_group_id'] = session('cart_session');
                            $cart['customer_id'] = $user->id ?? 0;
                            $cart['quantity'] = $qt;
                            $cart['price'] = $price;
                            $cart['tax'] = $tax;
                            $cart['variant'] = $request['variants_id'][$q];
                            $cart['slug'] = $product->slug;
                            $cart['name'] = $product->name;
                            $cart['thumbnail'] = $product->thumbnail;
                            $cart['seller_id'] = ($product->added_by == 'admin') ? 1 : $product->user_id;
                            $cart['seller_is'] = $product->added_by;
                            if ($product->added_by == 'seller') {
                                $cart['shop_info'] = Shop::where(['seller_id' => $product->user_id])->first()->name;
                            } else {
                                $cart['shop_info'] = Helpers::get_business_settings('company_name');
                            }
                            $cart->save();
                        }else{
                            Cart::where('product_id', $product->id)->where('customer_id',$user->id)->where('variant', $request['variants_selection'][$q])->update(['quantity'=>($check['quantity']+$qt)]);
                            return [
                                'status' => 1,
                                'message' => 'Qty Updated',
                            ];
                        }
                    }
                    
                }
            }
        }
        return [
            'status' => 1,
            'message' => translate('successfully_added!')
        ];        
        // foreach (json_decode($product->choice_options) as $key => $choice) {
        //     $choices[$choice->name] = $request[$choice->name];
        //     $variations[$choice->title] = $request[$choice->name];
        //     if ($str != null) {
        //         $str .= '-' . str_replace(' ', '', $request[$choice->name]);
        //     } else {
        //         $str .= str_replace(' ', '', $request[$choice->name]);
        //     }
        // }

        // return $str;
        // if ($user == 'offline') {
        //     if (session()->has('offline_cart')) {
        //         $cart = session('offline_cart');
        //         $check = $cart->where('product_id', $request->id)->where('variant', $str)->first();
        //         if (isset($check) == false) {
        //             $cart = collect();
        //             $cart['id'] = time();
        //         } else {
        //             return [
        //                 'status' => 0,
        //                 'message' => translate('already_added!')
        //             ];
        //         }
        //     } else {
        //         $cart = collect();
        //         session()->put('offline_cart', $cart);
        //     }
        // } else {
        //     $cart = Cart::where(['product_id' => $request->id, 'customer_id' => $user->id, 'variant' => $str])->first();
        //     if (isset($cart) == false) {
        //         $cart = new Cart();
        //     } else {
        //         return [
        //             'status' => 0,
        //             'message' => translate('already_added!')
        //         ];
        //     }
        // }

        // $cart['color'] = $request->has('color') ? $request['color'] : null;
        // $cart['product_id'] = $product->id;
        // $cart['choices'] = json_encode($choices);

        // //chek if out of stock
        // if ($product['current_stock'] < $request['quantity']) {
        //     return [
        //         'status' => 0,
        //         'message' => translate('out_of_stock!')
        //     ];
        // }

        // $cart['variations'] = json_encode($variations);
        // $cart['variant'] = $str;

        // //Check the string and decreases quantity for the stock
        // if ($str != null) {
        //     // $count = count(json_decode($product->variation));
        //     // for ($i = 0; $i < $count; $i++) {
        //     //     if (json_decode($product->variation)[$i]->type == $str) {
        //     //         $price = json_decode($product->variation)[$i]->price;
        //     //         if (json_decode($product->variation)[$i]->qty < $request['quantity']) {
        //     //             return [
        //     //                 'status' => 0,
        //     //                 'message' => translate('out_of_stock!')
        //     //             ];
        //     //         }
        //     //     }
        //     // }
        //     //$price = json_decode($product->variation)[$i]->price;
        //     $variantProduct = ProductVariant::where(['type' => $str,'product_id' => $product->id])->first();
        //     $price = (!empty($variantProduct->price) && $variantProduct->price > 0)?$variantProduct->price:0;
        //     $qty = (!empty($variantProduct->qty) && $variantProduct->qty > 0)?$variantProduct->qty:0;

        //     if(Helpers::variantDiscountStatus($variantProduct->startDuration, $variantProduct->endDuration))
        //     {
        //         $finaldiscount = $variantProduct->discount;
        //     }
        //     else
        //     {
        //        $finaldiscount = 0; 
        //     }

        //     if ($qty < $request['quantity']) {
        //         return [
        //             'status' => 0,
        //             'message' => translate('out_of_stock!')
        //         ];
        //     }
        // } else {
        //     $price = $product->unit_price;
        //     $finaldiscount = Helpers::get_product_discount($product, $price);
        // }

        // $tax = Helpers::tax_calculation($price, $product['tax'], 'percent');

        // //generate group id
        
        // //generate group id end

        // $cart['customer_id'] = $user->id ?? 0;
        // $cart['quantity'] = $request['quantity'];
        // /*$data['shipping_method_id'] = $shipping_id;*/
        // $cart['price'] = $price;
        // //$cart['price'] = Convert::converToUsd($price);
        // $cart['tax'] = $tax;
        // $cart['slug'] = $product->slug;
        // $cart['name'] = $product->name;
        // $cart['discount'] = $finaldiscount;
        // /*$data['shipping_cost'] = $shipping_cost;*/
        // $cart['thumbnail'] = $product->thumbnail;
        // $cart['seller_id'] = ($product->added_by == 'admin') ? 1 : $product->user_id;
        // $cart['seller_is'] = $product->added_by;
        // if ($product->added_by == 'seller') {
        //     $cart['shop_info'] = Shop::where(['seller_id' => $product->user_id])->first()->name;
        // } else {
        //     $cart['shop_info'] = Helpers::get_business_settings('company_name');
        // }

        // if ($user == 'offline') {
        //     $offline_cart = session('offline_cart');
        //     $offline_cart->push($cart);
        //     session()->put('offline_cart', $offline_cart);
        // } else {
        //     $cart->save();
        // }
        // return [
        //     'status' => 1,
        //     'message' => translate('successfully_added!')
        // ];
    }

    public static function update_cart_qty($request)
    {
        $user = Helpers::get_customer($request);
        $status = 1;
        $qty = 0;
        $cart = Cart::where(['id' => $request->key, 'customer_id' => $user->id])->first();

        $product = Product::find($cart['product_id']);
        $count = count(json_decode($product->variation));
        if ($count) {
            for ($i = 0; $i < $count; $i++) {
                if (json_decode($product->variation)[$i]->type == $cart['variant']) {
                    if (json_decode($product->variation)[$i]->qty < $request->quantity) {
                        $status = 0;
                        $qty = $cart['quantity'];
                    }
                }
            }
        } else if ($product['current_stock'] < $request->quantity) {
            $status = 0;
            $qty = $cart['quantity'];
        }

        if ($status) {
            $qty = $request->quantity;
            $cart['quantity'] = $request->quantity;
        }

        $cart->save();

        return [
            'status' => $status,
            'qty' => $qty,
            'message' => $status == 1 ? translate('successfully_updated!') : translate('sorry_stock_is_limited')
        ];
    }
}
