<?php

namespace App\Http\Controllers\Admin;

use App\CPU\Helpers;
use App\CPU\ImageManager;
use App\Http\Controllers\Controller;
use App\Model\CompanyType;
use Brian2694\Toastr\Facades\Toastr;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use function App\CPU\translate;

class CompanyTypeController extends Controller
{   
    public function index()
    {
        return view('admin-views.company-type.add');
    }

    public function store(Request $request)
    {
        $request->validate([
            'company_type' => 'required',
        ], [
            'company_type.required' => 'First name is required!'
        ]);

        $ct = new CompanyType();
        $ct->company_type = $request->company_type;
        $ct->save();

        Toastr::success('Company-type added successfully!');
        return redirect('admin/company-type/list');
    }

    public function list(Request $request)
    {
        $query_param = [];
        $search = $request['search'];
        if ($request->has('search')) {
            $key = explode(' ', $request['search']);
            $Company_type = CompanyType::where(function ($q) use ($key) {
                foreach ($key as $value) {
                    $q->orWhere('company_type', 'like', "%{$value}%");
                }
            });
            $query_param = ['search' => $request['search']];
        } else {
            $Company_type = new CompanyType();
        }

        $Company_type = $Company_type->latest()->paginate(25)->appends($query_param);
        return view('admin-views.company-type.list', compact('Company_type', 'search'));
    }

    public function edit($id)
    {
        $CompanyType = CompanyType::find($id);
        return view('admin-views.company-type.edit', compact('CompanyType'));
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'company_type' => 'required',
        ], [
            'company_type.required' => 'First name is required!'
        ]);
        $companyType = CompanyType::where(['id' => $id])->first();
        $companyType->company_type = $request->company_type;
        $companyType->save();

        Toastr::success('Company-type updated successfully!');
        return redirect('admin/company-type/list');
    }

    public function status(Request $request)
    {
        $CompanyType = CompanyType::find($request->id);
        $CompanyType->status = $request->status;
        $CompanyType->save();
        return response()->json([], 200);
    }

}
