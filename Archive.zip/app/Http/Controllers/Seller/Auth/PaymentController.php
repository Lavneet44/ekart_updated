<?php

namespace App\Http\Controllers\Seller\Auth;

use App\Http\Controllers\Controller;
use App\Model\Seller;
use App\Model\SellerPlan;
use App\Model\SellerWallet;
use Brian2694\Toastr\Facades\Toastr;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Gregwar\Captcha\CaptchaBuilder;
use App\CPU\Helpers;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Crypt;

class PaymentController extends Controller
{

    public function __construct()
    {
        $this->middleware('guest:seller');
    }

    public function paymentView(Request $request, $id,$otp=NULL)
    {
        $seller = Seller::findOrFail($id);
        $finalAmount=0;
        $seller->finalprice = (!empty($seller->registerSellerPlanRequestOffer) && $seller->registerSellerPlanRequestOffer->count()>0)?$seller->registerSellerPlanRequestOffer->new_ammount:$seller->registerSellerPlanRequest->price;

        $plan_data=$seller->id."/".$seller->registerSellerPlanRequest->id."/".$seller->finalprice; 
        $password="password";
        $encrypted_string=openssl_encrypt($plan_data,"AES-128-ECB",$password);
        $seller->pd=$encrypted_string;
        $seller->ontips = $otp;
        return view('seller-views.auth.payment-view',compact('seller'));
    }

    public function payment_process(Request $request)
    {
        $request->validate([
            'plan_data' => 'required',
        ]);
        $password="password";
        $decrypted_string=openssl_decrypt($request->plan_data,"AES-128-ECB",$password);
        $dirs = explode('/', $decrypted_string);
        $seller_id = $dirs[0];
        $requested_plan_id = $dirs[1];
        $final_amount = $dirs[2];


        $seller = Seller::Where(['id' => $seller_id])->first();
        $payment_status = "success";
        $transaction_id = Str::random(10);

        

        if (isset($seller) && $payment_status == "success") {
            DB::table('plantabs_invoices')->insert([
                'seller_id' => $seller->id,
                'plan_id' => $seller->registerSellerPlanRequest->id,
                'result' => $payment_status,
                'amount' => $final_amount,
                'currency' => $seller->registerSellerPlanRequest->planCurrency->id,
                'transaction_id' => $transaction_id,
                'created_at' => now(),
            ]);

            $sellerPlan = new SellerPlan();
            $sellerPlan->seller_id = $seller->id;
            $sellerPlan->subscription_plan_id = $seller->registerSellerPlanRequest->id;
            $sellerPlan->status = 1;
            $sellerPlan->save();

            $randompassword = Str::random(10);
            //$updateseller = Seller::Where(['id' => $seller->id])->update(['status' => 'active','password' => Hash::make($randompassword)]);
            $updateseller = Seller::find($seller->id);
            $updateseller->password = bcrypt($randompassword);
            
            //--it is active here but able togo dashboard only when he/she update the OTP(change OTP status to 1 from 0)--//
            $updateseller->new_seller_status = 'active';
            $updateseller->save();

            //----Also sent One time password(randompassword) in message body----//
            //Mail::to($seller['email'])->send(new \App\Mail\PlanPaid($reset_url));

            Toastr::success('Payment Done Successfully,');
            return redirect()->route('seller.auth.payment',['id' => $seller->id, 'password' => $randompassword]);
        }
        else
        {
            Toastr::success('Payment Fail');
            return back();
        }
    }
}