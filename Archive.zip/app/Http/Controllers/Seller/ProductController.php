<?php

namespace App\Http\Controllers\Seller;

use App\CPU\BackEndHelper;
use App\CPU\Convert;
use App\CPU\Helpers;
use App\CPU\ImageManager;
use App\Http\Controllers\Controller;
use App\Model\Seller;
use App\Model\Brand;
use App\Model\Category;
use App\Model\Color;
use App\Model\DealOfTheDay;
use App\Model\FlashDealProduct;
use App\Model\Product;
use App\Model\Review;
use App\Model\Translation;
use App\Model\PossibleVariant;
use App\Model\PossibleCombinationElements;
use App\Model\ProductVariant;
use Brian2694\Toastr\Facades\Toastr;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Rap2hpoutre\FastExcel\FastExcel;
use Rap2hpoutre\FastExcel\SheetCollection;
use App\Model\Cart;
use App\Model\Unit;
use App\Model\CategoryBlock;
use App\Model\Brandallowe;
use App\Model\Unitallowe;
use App\Model\ProductDiscount;
use Illuminate\Validation\Rule;
use Redirect;
use Session;
use App\Model\Attribute;


class ProductController extends Controller
{

    public function update_unit_seller(Request $request)
    {
        
        $unit = Unit::find($request->id);
        $unit->name = $request->name;
        $unit->symbol = $request->symbol;
        $unit->created_by = auth('seller')->id();
        $unit->selected_seller = json_encode(array(auth('seller')->id()));
        $unit->status = 1;
        if($unit->save()){
            return back();
        }
        return back();
    }

    public function add_attribute_seller(Request $request)
    {
        
        $unit = new Attribute;
        $unit->name = $request->name;
        $unit->created_by = auth('seller')->id();
        $unit->selected_seller = json_encode(array(auth('seller')->id()));
        // $unit->status = 1;
        if($unit->save()){
            return back();
        }
        return back();
        
    }

    public function create_attributes_ajax(Request $request)
    {
        
        $unit = new Attribute;
        $unit->name = $request->name;
        $unit->created_by = auth('seller')->id();
        $unit->selected_seller = json_encode(array(auth('seller')->id()));
        // $unit->status = 1;
        if($unit->save()){
            return response()->json(['code'=>1]);
        }
        return response()->json(['code'=>0]);
        
    }

    public function create_unit_ajax(Request $request)
    {
        
        $unit = new Unit;
        $unit->name = $request->name;
        $unit->symbol = $request->symbol;
        $unit->created_by = auth('seller')->id();
        $unit->selected_seller = json_encode(array(auth('seller')->id()));
        $unit->status = 1;
        if($unit->save()){
            return response()->json(['code'=>1]);
        }
        return response()->json(['code'=>0]);
        
    }

    public function add_unit_seller(Request $request)
    {
        
        $unit = new Unit;
        $unit->name = $request->name;
        $unit->symbol = $request->symbol;
        $unit->created_by = auth('seller')->id();
        $unit->selected_seller = json_encode(array(auth('seller')->id()));
        $unit->status = 1;
        if($unit->save()){
            return back();
        }
        return back();
        
    }

    public function units_page()
    {
        $units = Unit::all();
        $br = Unit::where('selected_seller','LIKE','%'.auth('seller')->id().'%')->latest()->paginate(10);
        return view('seller-views.brands.unit-page',compact('units','br'));
    }

    public function attribute_function(Request $request)
    {
        $atri = Attribute::all();
        $br = Attribute::where('selected_seller','LIKE','%'.auth('seller')->id().'%')->paginate(10);
        return view('seller-views.brands.attributes-page',compact('atri','br'));
    }


    public function add_brandPage()
    {
        return view('seller-views.brands.add-new');
    }

    public function add_brand_new(Request $request)
    {
        $brand = new Brand;
        $brand->name = $request->name[array_search('en', $request->lang)];
        $brand->image = ImageManager::upload('brand/', 'png', $request->file('image'));
        $brand->status = 1;
        $brand->created_by = auth('seller')->id();
        $brand->selected_seller = json_encode(array(auth('seller')->id()));
        if($brand->save()){
            return redirect()->back();
        }else{
            return redirect()->back();
        }
    }

    public function create_brand_ajax(Request $request)
    {
        $brand = new Brand;
        $brand->name = $request->name[array_search('en', $request->lang)];
        $brand->image = ImageManager::upload('brand/', 'png', $request->file('image'));
        $brand->status = 1;
        $brand->created_by = auth('seller')->id();
        $brand->selected_seller = json_encode(array(auth('seller')->id()));
        if($brand->save()){
            return response()->json(['code'=>1]);
        }else{
            return response()->json(['code'=>0]);
        }
    }

    function getBrandAjax()
    {
        $html = '<option value="" selected disabled>---Select---</option>';
        $brand = Brand::where('selected_seller','LIKE','%'.auth('seller')->id().'%')->get();
        if($brand){
            foreach ($brand as $key => $value) {
                $html.='<option value="'.$value->id.'">'.$value->name.'</option>';
            }
        }
        return $html;
    }

    function getUnitAjax()
    {
        $html = '<option value="" selected disabled>---Select---</option>';
        $brand = Unit::where('selected_seller','LIKE','%'.auth('seller')->id().'%')->get();
        if($brand){
            foreach ($brand as $key => $value) {
                $html.='<option value="'.$value->id.'">'.$value->name.'</option>';
            }
        }
        return $html;
    }

    function getAttributesAjax()
    {
        $html = '';
        $brand = Attribute::where('selected_seller','LIKE','%'.auth('seller')->id().'%')->get();
        if($brand){
            foreach ($brand as $key => $value) {
                $html.='<option value="'.$value->id.'">'.$value->name.'</option>';
            }
        }
        return $html;
    }

    public function brands_update($id)
    {
        $b = Brand::where(['id' => $id])->withoutGlobalScopes()->first();
        return view('seller-views.brands.edit', compact('b'));
    }

    public function update_brand_data(Request $request,$id)
    {
        $brand = Brand::find($id);
        $brand->name = $request->name[array_search('en', $request->lang)];
        if ($request->has('image')) {
            $brand->image = ImageManager::update('brand/', $brand['image'], 'png', $request->file('image'));
         }
        $brand->save();
        foreach ($request->lang as $index => $key) {
            if ($request->name[$index] && $key != 'en') {
                Translation::updateOrInsert(
                    ['translationable_type' => 'App\Model\Brand',
                        'translationable_id' => $brand->id,
                        'locale' => $key,
                        'key' => 'name'],
                    ['value' => $request->name[$index]]
                );
            }
        }

        Toastr::success('Brand updated successfully!');
        return back();
    }

    function delete_brand_data(Request $request)
    {
        $translation = Translation::where('translationable_type','App\Model\Brand')
                                    ->where('translationable_id',$request->id);
        $translation->delete();
        $brand = Brand::find($request->id);
        ImageManager::delete('/brand/' . $brand['image']);
        $brand->delete();
        return response()->json();
    }

    function seller_selected_brand(Request $request)
    {
        if(!empty($request->id)){
            $brand = Brand::whereIn('id',$request->id)->get();
            // print(count($category));
            $notupdated = Brand::whereNotIn('id',$request->id)->get();
            if($brand){
                foreach ($brand as $key => $value) {
                    if($value->selected_seller!=''){
                        $cat = json_decode($value->selected_seller,true);
                        if(!in_array(auth('seller')->id(),$cat)){
                            array_push($cat,auth('seller')->id()); 
                        }
                    }else{
                        $cat = array();
                        array_push($cat,auth('seller')->id());
                    }
                    Brand::where('id',$value->id)->update(['selected_seller'=>json_encode($cat)]);
                }
                
            }
        }else{
            $notupdated = Brand::all();
        }
        if($notupdated){
            foreach($notupdated as $kk => $cc){
                if($cc->selected_seller!=''){
                    $cata = json_decode($cc->selected_seller);
                    $k = array_search(auth('seller')->id(),$cata);
                    if($k !== false){
                        unset($cata[$k]);
                    }
                    Brand::where('id',$cc->id)->update(['selected_seller'=>json_encode($cata)]);
                }
            }
        }
        return Redirect::back();
    }

    function seller_selected_units(Request $request)
    {
        if(!empty($request->id)){
            $brand = Unit::whereIn('id',$request->id)->get();
            // print(count($category));
            $notupdated = Unit::whereNotIn('id',$request->id)->get();
            if($brand){
                foreach ($brand as $key => $value) {
                    if($value->selected_seller!=''){
                        $cat = json_decode($value->selected_seller,true);
                        if(!in_array(auth('seller')->id(),$cat)){
                            array_push($cat,auth('seller')->id()); 
                        }
                    }else{
                        $cat = array();
                        array_push($cat,auth('seller')->id());
                    }
                    Unit::where('id',$value->id)->update(['selected_seller'=>json_encode($cat)]);
                }
                
            }
        }else{
            $notupdated = Unit::all();
        }
        if($notupdated){
            foreach($notupdated as $kk => $cc){
                if($cc->selected_seller!=''){
                    $cata = json_decode($cc->selected_seller);
                    $k = array_search(auth('seller')->id(),$cata);
                    if($k !== false){
                        unset($cata[$k]);
                    }
                    Unit::where('id',$cc->id)->update(['selected_seller'=>json_encode($cata)]);
                }
            }
        }
        return Redirect::back();
    }

    function seller_selected_attributes(Request $request)
    {
        if(!empty($request->id)){
            $brand = Attribute::whereIn('id',$request->id)->get();
            $notupdated = Attribute::whereNotIn('id',$request->id)->get();
            if($brand){
                foreach ($brand as $key => $value) {
                    if($value->selected_seller!=''){
                        $cat = json_decode($value->selected_seller,true);
                        if(!in_array(auth('seller')->id(),$cat)){
                            array_push($cat,auth('seller')->id()); 
                        }
                    }else{
                        $cat = array();
                        array_push($cat,auth('seller')->id());
                    }
                    Attribute::where('id',$value->id)->update(['selected_seller'=>json_encode($cat)]);
                }
            }
        }else{
            $notupdated = Attribute::all();
        }
        
        
        if($notupdated){
            foreach($notupdated as $kk => $cc){
                if($cc->selected_seller!=''){
                    $cata = json_decode($cc->selected_seller);
                    $k = array_search(auth('seller')->id(),$cata);
                    if($k !== false){
                        unset($cata[$k]);
                    }
                    Attribute::where('id',$cc->id)->update(['selected_seller'=>json_encode($cata)]);
                }
            }
        }
        return Redirect::back();
    }


    public function brands_function(Request $request)
    {   
        $query_param = [];
        $search = $request['search'];
        if ($request->has('search'))
        {
            $key = explode(' ', $request['search']);
            $br = Brand::where(function ($q) use ($key) {
                foreach ($key as $value) {
                    $q->Where('name', 'like', "%{$value}%");
                }
            });
            $query_param = ['search' => $request['search']];
        }else{
            $br = new Brand();
        }
        $brands = Brand::all();
        $br = $br->where('selected_seller','LIKE','%'.auth('seller')->id().'%')->latest()->paginate(Helpers::pagination_limit())->appends($query_param);
        return view('seller-views.brands.list', compact('br','search','brands'));
    }

    function updateParentCategory(Request $request)
    {
        if(!empty($request->id)){
            $category = Category::whereIn('id',$request->id)->get();
            // print(count($category));
            $notupdated = Category::whereNotIn('id',$request->id)->get(); 
            if($category){
                foreach ($category as $key => $value) {
                    if($value->selected_cat!=''){
                        $cat = json_decode($value->selected_cat,true);
                        if(!in_array(auth('seller')->id(),$cat)){
                            array_push($cat,auth('seller')->id()); 
                        }
                    }else{
                        $cat = array();
                        array_push($cat,auth('seller')->id());
                    }
                    Category::where('id',$value->id)->update(['selected_cat'=>json_encode($cat)]);
                }
            }
        }else{
            $notupdated = Category::all();
        }
       
        // print(count($notupdated));die;
        
        if($notupdated){
            foreach($notupdated as $kk => $cc){
                if($cc->selected_cat!=''){
                    $cata = json_decode($cc->selected_cat);
                    $k = array_search(auth('seller')->id(),$cata);
                    if($k !== false){
                        unset($cata[$k]);
                    }
                    Category::where('id',$cc->id)->update(['selected_cat'=>json_encode($cata)]);
                }
            }
        }
        return Redirect::back();
    }

    public function deletecategorydata($id)
    {
        $product = Product::where('category_ids',$id)->get();
        if($product){ echo 1;}else{ echo 0;}die;
        if(Category::where('id',$id)->update(['id_of_creater'=>null])){
            Category::where('parent_id',$id)->where('id_of_creater',auth('seller')->id())->update(['id_of_creater'=>null]);
            return Redirect::back();
        }
        return Redirect::back();
    }


    public function editSellerCat(Request $request)
    {
        $cat = Category::find($request->id);
        $cat->name = $request->name;
        $cat->slug = Str::slug($request->name);
        $cat->parent_id = $request->parent_id;
        // if ($request->image) {
        //     $cat->icon = ImageManager::update('category/', $cat->icon, 'png', $request->file('image'));
        // }
        $cat->id_of_creater = auth('seller')->id();
        if($cat->save()){
            return Redirect::route('seller.product.categories');
        }
        return Redirect::back();
    }

    public function createSellerCat(Request $request)
    {
        if(isset($request->parent_id) && $request->parent_id == ''){
            return Redirect::back();
        }
        if(!isset($request->parent_id)){
            
            return Redirect::back();
        }
        $user = auth('seller')->id();
        $cat = new Category;
        $cat->slug = Str::slug($request->name);
        $cat->parent_id = $request->parent_id;
        $cat->name = $request->name;
        // $cat->icon = ImageManager::upload('category/', 'png', $request->file('image'));
        $cat->id_of_creater = $user;
        
        if($cat->save()){
            return Redirect::route('seller.product.categories');
        }
        return Redirect::back();
    }

    public function create_category_ajax(Request $request)
    {
        // print_r($request->category_ids);die;
        
        if(is_array($request->category_ids) &&  $request->category_ids!=''){
            foreach ($request->category_ids as $key => $value) {
                $user = auth('seller')->id();
                $cat = new Category;
                $cat->slug = Str::slug($request->name);
                $cat->parent_id = $value;
                $cat->name = $request->name;
                // $cat->icon = ImageManager::upload('category/', 'png', $request->file('image'));
                $cat->id_of_creater = $user;
                $cat->save();
            }
            return response()->json(['code'=>1]);
        }
        
        
        return response()->json(['code'=>0]);
    }

    public static function generateParentCategoryTree($category,$selected=null,$edited=null)
    {   


        $user_id = auth('seller')->id();

        $html = '';

        foreach ($category as $key => $value) {
            
            $html.= "<li style'margin-bottom:10px'><input type='radio' ";
                        if($selected!=null && $value->id == $selected){ $html.="checked"; }
                        $html.=" name='parent_id' value='".$value->id."'> 
                        <a href='#item_".$value->id."' data-toggle='collapse' style='cursor:pointer;'><label for=''> ".$value->name."</label>";
                        if(count($value->childes) > 0 && $value->childes->contains('id_of_creater',$user_id)){
                            // if($value->parent_id != 0 && $value->id_of_creater == $user_id){
                                $html.="<span class='tio-arrow-drop-down-circle-outlined' style='margin-left:10px;'></span>";
                            // }
                        }
            $html.="</a>";
            if(count($value->childes) > 0){
                    $html.= "<ul id='item_".$value->id."' class='collapse' style='list-style:none;'>";
                    $html.=(new static)->buildCatTree($value->childes,$selected,$edited);
                    $html.= "</ul>";
            }
            $html.='</li>';
        }
        echo $html;
    }

    public static function buildCatTree($category,$selected=null,$edited=null)
    {
        $html = '';
        foreach ($category as $key => $value) {
            if($value->id_of_creater == auth('seller')->id()){
                if($edited == null || $edited != $value->id){
                    $html.= "<li style'margin-bottom:10px'><input type='radio'"; 
                    if($selected!=null && $value->id == $selected){ $html.="checked"; }
                    $html.=" name='parent_id' value='".$value->id."'> 
                                <a href='#item_".$value->id."' data-toggle='collapse' style='cursor:pointer;'><label for=''> ".$value->name."</label>";
                                if(count($value->childes) > 0 && $value->childes->contains('id_of_creater',auth('seller')->id())){
                                    // if($value->parent_id != 0 && $value->id_of_creater == $user_id){
                                        $html.="<span  class='tio-arrow-drop-down-circle-outlined' style='margin-left:10px;'></span>";
                                    // }
                                }
                    $html.="</a>";
                    if(count($value->childes) > 0){
                            
                            $html.= "<ul id='item_".$value->id."' class='collapse' style='list-style:none;'>";
                            $html.=(new static)->buildCatTree($value->childes,$selected,$edited);
                            $html.= "</ul>";
                    }
                    $html.='</li>';
                }
            }
        }
        return $html;
    }


   

    public static function generateParentCategoryPTree($category,$selected=null)
    {   
        $user_id = auth('seller')->id();
        if($selected!=''){
            $selec = json_decode($selected,TRUE);
        }else{
            $selec = array();
        }
        // print_r($selec);die;
        $html = '';
        foreach ($category as $key => $value) {
            $html.= "<li style='margin-bottom:10px;font-size:17px;'><input type='checkbox' name='category_ids[]' value='".$value->id."' class='checkbox_check' ";
                    if(in_array($value->id,$selec)){
                        $html.="checked";
                    }
            $html.=" data-parent='".$value->parent_id."'> <a href='#item_".$value->id."' data-toggle='collapse' style='cursor:pointer;'>  <label for=''> ".$value->name."</label>";
                        if(count($value->childes) > 0 && $value->childes->contains('id_of_creater',$user_id)){
                            // if($value->parent_id != 0 && $value->id_of_creater == $user_id){
                                $html.="<span class='tio-arrow-drop-down-circle-outlined' style='margin-left:10px;'></span>";
                            // }
                        }
                        $html.='</a>';
            if(count($value->childes) > 0){
                    
                    $html.= "<ul id='item_".$value->id."' class='collapse' style='list-style:none;'>";
                    $html.=(new static)->buildCatPTree($value->childes,$selec);
                    $html.= "</ul>";
            }
            $html.='</li>';
        }
        echo $html;
    }

    public static function buildCatPTree($category,$selec = array())
    {
        $html = '';
        foreach ($category as $key => $value) {
            if($value->id_of_creater == auth('seller')->id()){
                $html.= "<li style='margin-bottom:10px;font-size:17px;'><input type='checkbox' name='category_ids[]' class='checkbox_check' ";
                if(in_array($value->id,$selec)){
                    $html.=" checked ";
                }
                $html.="value='".$value->id."' data-parent='".$value->parent_id."'> 
                            <a href='#item_".$value->id."' data-toggle='collapse' style='cursor:pointer;'><label for=''> ".$value->name."</label>";
                            if(count($value->childes) > 0){
                                // if($value->parent_id != 0 && $value->id_of_creater == $user_id){
                                    $html.="<span class='tio-arrow-drop-down-circle-outlined' style='margin-left:10px;'></span>";
                                // }
                            }
                            $html.='</a>';
                if(count($value->childes) > 0 && $value->childes->contains('id_of_creater',auth('seller')->id())){
                        
                        $html.= "<ul id='item_".$value->id."' class='collapse' style='list-style:none;'>";
                        $html.=(new static)->buildCatPTree($value->childes,$selec);
                        $html.= "</ul>";
                }
                $html.='</li>';
            }
        }
        return $html;
    }


    public static function selectionCategorySearch($category,$cad = array())
    {
        $user_id = auth('seller')->id();
        $html = '';
        foreach ($category as $key => $value) {
            $html.="<option value='".$value->id."'";
            if(in_array($value->id,$cad)) {
                $html.="selected";
            }
            $html.=">";
                $html.=$value->name;
            $html.="</option>";
           
            if(count($value->childes) > 0){
                    $html.=(new static)->selectionCategorySearchchild($value->childes,1,$cad);
            }
        }
        echo $html;
    }

    public static function selectionCategorySearchchild($child,$par,$cad = array())
    {
        $html = '';
        $per = $par;
        foreach ($child as $key => $value) {
            if($value->id_of_creater == auth('seller')->id()){
                $html.="<option value='".$value->id."'";
                if(in_array($value->id,$cad)) {
                    $html.="selected";
                }
                $html.=">";
                    $check = 1;
                    for ($i=0; $i < $per ; $i++) { 
                        $html.="---&nbsp;&nbsp;";
                        $check = $per+1;
                    }
                    $html.=$value->name;
                $html.="</option>";

                if(count($value->childes) > 0 && $value->childes->contains('id_of_creater',auth('seller')->id())){
                     
                        $html.=(new static)->selectionCategorySearchchild($value->childes,$check,$cad);
                }
            }
        }
        return $html;
    }

    public static function generateCategoryTree($category)
    {
        $user_id = auth('seller')->id();
        $html = '';
        foreach ($category as $key => $value) {
            $html.="<tr>";
                $html.="<td>".$value->name."</td>";
                // $html.="<td><img src='".url('storage/app/public/category')."/".$value->icon."' style='width:50px;'</td>";
                $html.="<td>";
                $parent = Category::where('id',$value->parent_id)->first();
                if($parent != null){
                    $html.=$parent->name;
                }
                $html.="</td>";
                $html.="<td><a href='".url('seller/product/add-category/'.$value->id)."' class='btn btn-primary mr-1'>Add Sub Category</a></td>";
            $html.="</tr>";
            // $html.= "<li style='margin-top:10px;margin-bottom:10px;font-size:17px;background:#eee;padding:10px;border:1px solid #000;'><div class='row' style='width:100%;'><div class='col-md-9'><a href='#item_".$value->id."' data-toggle='collapse' style='cursor:pointer;'>  <label for=''> ".$value->name."</label>";
                        
            //             $html.='</a></div>';
            //             if($value->parent_id != 0){
            //                 $html.='<div class="col-md-3"><a href="'.url('seller/product/categories?category_id=').''.$value->id.'" class="btn btn-warning mr-1"><i class="tio-edit"></i></a><a href="#0" class="btn btn-danger"><i class="tio-poi-delete"></i></a>';
            //                 if(count($value->childes) > 0 && $value->childes->contains('id_of_creater',$user_id)){
            //                     // if($value->parent_id != 0 && $value->id_of_creater == $user_id){
            //                         $html.="<a href='#item_".$value->id."' data-toggle='collapse' style='cursor:pointer;' class='btn btn-primary ml-1'><span class='tio-arrow-drop-down-circle-outlined'></span></a>";
            //                     // }
            //                 }

            //                 $html.='</div>';

            //             }elseif($value->parent_id == 0){
            //                 if(count($value->childes) > 0 && $value->childes->contains('id_of_creater',$user_id)){
            //                 // if($value->parent_id != 0 && $value->id_of_creater == $user_id){
            //                     $html.="<div class='col-md-3'><a href='#item_".$value->id."' data-toggle='collapse' class='btn btn-primary ml-1 float-right' style='cursor:pointer;'><span class='tio-arrow-drop-down-circle-outlined'></span></a></div>";
            //                 // }
            //                 }
            //             }
            //             $html.='</div>';
            if(count($value->childes) > 0){
                    // $html.= "<ul id='item_".$value->id."' class='collapse' style='list-style:none;padding-left:0;'>";
                    $html.=(new static)->buildChild($value->childes,1);
                    // $html.= "</ul>";
            }
        }
        echo $html;
    }

    public static function buildChild($child,$par)
    {
        $html = '';
        $per = $par;
        foreach ($child as $key => $value) {
            if($value->id_of_creater == auth('seller')->id()){
                $html.="<tr>";
                    $html.="<td>";
                    $check = 1;
                    for ($i=0; $i < $per ; $i++) { 
                        $html.="---&nbsp;&nbsp;";
                        $check = $per+1;
                    }
                    $html.="".$value->name."</td>";
                    // $html.="<td><img src='".url('storage/app/public/category')."/".$value->icon."' style='width:50px;'></td>";
                    $html.="<td>";
                    $parent = Category::where('id',$value->parent_id)->first();
                    if($parent != null){
                        $html.=$parent->name;
                    }
                    $html.="</td>";
                    $html.="<td><a href='".url('seller/product/add-category/'.$value->id)."' class='btn btn-primary mr-1'>Add Sub Category</a>";
                    if($value->parent_id!=0){
                        $html.='<a href="'.url('seller/product/categories/'.$value->id).'" class="btn btn-warning mr-1"><i class="tio-edit"></i></a><a href="javascript:deleteCategory('.$value->id.')" class="btn btn-danger"><i class="tio-poi-delete"></i></a>';
                    }
                    $html.="</td>";
                $html.="</tr>";
                // $html.= "<li style='margin-top:10px;margin-bottom:10px;font-size:17px;background:#eee;padding:10px;border:1px solid #000;'><div class='row' style='width:100%;'><div class='col-md-9'>
                //             <a href='#item_".$value->id."' data-toggle='collapse' style='cursor:pointer;'><label for=''> ".$value->name."</label>";
                            
                //             $html.='</a></div>';
                //             if($value->parent_id != 0){
                //                 $html.='<div class="col-md-3"><a href="'.url('seller/product/categories?category_id=').''.$value->id.'" class="btn btn-warning mr-1"><i class="tio-edit"></i></a><a href="javascript:deleteCategory('.$value->id.')" class="btn btn-danger"><i class="tio-poi-delete"></i></a>';
                //                 if(count($value->childes) > 0){
                //                 // if($value->parent_id != 0 && $value->id_of_creater == $user_id){
                //                     $html.="<a href='#item_".$value->id."' class='btn btn-primary ml-1' data-toggle='collapse' style='cursor:pointer;'><span class='tio-arrow-drop-down-circle-outlined'></span></a>";
                //                 // }
                //                 }
                //                 $html.='</div>';
                //             }
                //             $html.='</div>';
                if(count($value->childes) > 0 && $value->childes->contains('id_of_creater',auth('seller')->id())){
                        
                        // $html.= "<ul id='item_".$value->id."' class='collapse' style='list-style:none;padding-left:0;'>";
                        $html.=(new static)->buildChild($value->childes,$check);
                        // $html.= "</ul>";
                }
            }
        }
        return $html;
    }

    public function create_category($id=null)
    {
        $category = Category::where('parent_id',0)->where('selected_cat','LIKE','%'.auth('seller')->id().'%')->get();
        $selected_id = $id;
        if($id != null){
            $selected_id = $id;
        }else{
            $selected_id = '';
        }
        return view('seller-views.category.create',compact('category','selected_id'));
    }

    public function get_categories_datalist()
    {
        $seller = auth('seller')->id();
        $categories = Category::where('parent_id',0)->where('selected_cat','LIKE','%'.$seller.'%')->get();
        $data =  $this->generateParentCategoryPTree($categories);
        return $data;
    }

    function editCategories($id)
    {
        $seller = auth('seller')->id();
        // echo $id;die;
        $edit_cat = Category::where('id',$id)->first();
        // print_r($edit_cat);die;
        $category = Category::where('parent_id',0)->where('selected_cat','LIKE','%'.$seller.'%')->get();
        return view('seller-views.category.edit-category',compact('category','edit_cat'));
    }

    public function categories()
    {
        $seller = auth('seller')->id();
        $categories = Category::where('parent_id',0)->get();
        $category = Category::where('parent_id',0)->where('selected_cat','LIKE','%'.$seller.'%')->get();
        return view('seller-views.category.category',compact('category','categories'));
    }

    public function get_child(Request $request)
    {
        $cat = Category::where(['parent_id' => $request->parent_id])->get();
        return response()->json([
            'row' => $cat
        ]);
    }

    public function units($name=null){
        $name = ucfirst($name);
        $checkbuplicatename = Unit::where('name', 'like', '%' . $name . '%')->get();
        if(!empty($checkbuplicatename) && $checkbuplicatename->count()>0)
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }

    public function checkbrandsduplicate($name=null){
        $name = ucfirst($name);
        $checkbrandsname = Brand::where('name', 'like', '%' . $name . '%')->get();
        if(!empty($checkbrandsname) && $checkbrandsname->count()>0)
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }

    public function getlatestbrand(){
        $allowedBrandIds = Brandallowe::where(['seller_id' => auth('seller')->id(),'delete_status' => 0])->pluck('brand_id');
            if(!empty($allowedBrandIds)){
                $allowedBrandIds = $allowedBrandIds->toArray();
            }else{
                $allowedBrandIds = array();
            }

            $allBrand = Brand::get();

            $i=0;
            $selectedBrands = array();
            foreach ($allBrand as $key => $item) {
                if (in_array($item->id, $allowedBrandIds))
                {
                    $selectedBrands[$i] = $item;
                    $i++;
                }
            }
            $data = array('status' => 1,'brand' => $selectedBrands, 'allowedBrandIds' => $allowedBrandIds,'allBrand' => $allBrand);
            return response()->json($data);
    }

    public function getunit(){
        $allowedUnitIds = Unitallowe::where(['seller_id' => auth('seller')->id(),'delete_status' => 0])->pluck('unit_id');
            if(!empty($allowedUnitIds)){
                $allowedUnitIds = $allowedUnitIds->toArray();
            }else{
                $allowedUnitIds = array();
            }

            $allUnit = unit::get();

            $i=0;
            $selectedUnit = array();
            foreach ($allUnit as $key => $item) {
                if (in_array($item->id, $allowedUnitIds))
                {
                    $selectedUnit[$i] = $item;
                    $i++;
                }
            }
            $data = array('status' => 1,'unit' => $selectedUnit, 'allowedUnitIds' => $allowedUnitIds,'allUnit' => $allUnit);
            return response()->json($data);
    }



    public function add_new()
    {

        $Seller = Seller::where(['id' => auth('seller')->id(),'status' => 'approved','new_seller_status' => 'active'])->first();

        $sellerItems = Product::where(['user_id' => auth('seller')->id(),'added_by' => 'seller'])->get();


        $allowedIds = CategoryBlock::where(['seller_id' => auth('seller')->id(),'delete_status' => 0])->pluck('level0_id');
        if(!empty($allowedIds)){
            $allowedIds = $allowedIds->toArray();
        }else{
            $allowedIds = array();
        }

        $allCats = Category::get(); 
        $categories = Category::where('selected_cat','LIKE','%'.auth('seller')->id().'%')->where('parent_id',0)->get();      
        $brands = Brand::where('selected_seller','LIKE','%'.auth('seller')->id().'%')->get();      
        $units = Unit::where('selected_seller','LIKE','%'.auth('seller')->id().'%')->get();      
        $br = Brand::orderBY('name', 'ASC')->get();

        $allowedBrandIds = Brandallowe::where(['seller_id' => auth('seller')->id(),'delete_status' => 0])->pluck('brand_id');
        if(!empty($allowedBrandIds)){
            $allowedBrandIds = $allowedBrandIds->toArray();
        }else{
            $allowedBrandIds = array();
        }

         $allowedUnitIds = unitallowe::where(['seller_id' => auth('seller')->id(),'delete_status' => 0])->pluck('unit_id');
        if(!empty($allowedUnitIds)){
            $allowedUnitIds = $allowedUnitIds->toArray();
        }else{
            $allowedUnitIds = array();
        }

        $unit = Unit::orderBY('id', 'ASC')->get();
        return view('seller-views.product.add-new', compact('allCats','br','unit','allowedIds','allowedBrandIds','allowedUnitIds','Seller','sellerItems','categories','brands','units'));
    }

    public function getSellerCatdata()
    {
        $allowedIds = CategoryBlock::where(['seller_id' => auth('seller')->id(),'delete_status' => 0])->pluck('level0_id');
        if(!empty($allowedIds)){
            $allowedIds = $allowedIds->toArray();
        }else{
            $allowedIds = array();
        }

        $allCats = Category::get();

        $data = array('status' => 1,'allowedIds' => $allowedIds, 'allCats' => $allCats);
        return $data;
    }

    public function block_ids(Request $request)
    {
        CategoryBlock::where(['seller_id' => auth('seller')->id()])->update(['delete_status' => 1]);
        $idcat = $idsubcat = $idsubsubcat = '';
        foreach ($request->checkboxs as $key => $value) {
            $CategoryBlock = new CategoryBlock;
            $CategoryBlock->seller_id = auth('seller')->id();
            $CategoryBlock->level0_id = $value;
            $CategoryBlock->save();
        }


        $allowedIds = CategoryBlock::where(['seller_id' => auth('seller')->id(),'delete_status' => 0])->pluck('level0_id');
        $allowedIds = $allowedIds->toArray();
        $allCats = Category::get();

        foreach ($allCats as $key => $value) {
            if((in_array($value['id'], $allowedIds)) && ($value->parent_id==0)){
                $cat[$key] = $value;
            }
        }

        $data = array('status' => 1,'cat' => $cat);
        return response()->json($data);
    }    

    public function selected_brands(Request $request)
    {
        Brandallowe::where(['seller_id' => auth('seller')->id()])->update(['delete_status' => 1]);
        $idcat = $idsubcat = $idsubsubcat = '';
        foreach ($request->checkboxs as $key => $value) {
            $Brandallowe = new Brandallowe;
            $Brandallowe->seller_id = auth('seller')->id();
            $Brandallowe->brand_id = $value;
            $Brandallowe->save();
        }

        $allowedBrandIds = Brandallowe::where(['seller_id' => auth('seller')->id(),'delete_status' => 0])->pluck('brand_id');
        if(!empty($allowedBrandIds)){
            $allowedBrandIds = $allowedBrandIds->toArray();
        }else{
            $allowedBrandIds = array();
        }


        $allBrand = Brand::get();

        $i=0;
        $selectedBrands = array();
        foreach ($allBrand as $key => $item) {
            if (in_array($item->id, $allowedBrandIds))
            {
                $selectedBrands[$i] = $item;
                $i++;
            }
        }
        
        $data = array('status' => 1,'brand' => $selectedBrands);
        return response()->json($data); 
    }

    //----------------- start unit new method 09/06/2022-----------------

     public function selected_units(Request $request)
    {
        Unitallowe::where(['seller_id' => auth('seller')->id()])->update(['delete_status' => 1]);
        $idcat = $idsubcat = $idsubsubcat = '';
        foreach ($request->checkboxs as $key => $value) {
            $Unitallowe = new Unitallowe;
            $Unitallowe->seller_id = auth('seller')->id();
            $Unitallowe->unit_id = $value;
            $Unitallowe->save();
        }

        $allowedUnitIds = Unitallowe::where(['seller_id' => auth('seller')->id(),'delete_status' => 0])->pluck('unit_id');
        if(!empty($allowedUnitIds)){
            $allowedUnitIds = $allowedUnitIds->toArray();
        }else{
            $allowedUnitIds = array();
        }


        $allUnit = unit::get();

        $i=0;
        $selectedUnits = array();
        foreach ($allUnit as $key => $item) {
            if (in_array($item->id, $allowedUnitIds))
            {
                $selectedUnits[$i] = $item;
                $i++;
            }
        }
        
        $data = array('status' => 1,'unit' => $selectedUnits);
        return response()->json($data); 
    } 

//----------------- End unit new method 09/06/2022-----------------

    public function status_update(Request $request)
    {
       if(Product::where(['id' => $request->id, 'added_by' => 'seller', 'user_id' => auth('seller')->id()])->update([
                'status' => $request->status,'request_status'=> $request->status,
            ])){
        return response()->json([
                'success' => 1,
            ], 200);
       }
       return response()->json([
                'success' => 0,
            ], 200);
    }

    public function featured_status(Request $request)
    {
        if ($request->ajax()) {
            $product = Product::find($request->id);
            $product->featured_status = $request->status;
            $product->save();
            $data = $request->status;
            return response()->json($data);
        }
    }

    public function store(Request $request)
    {
        // echo "<pre>";
        // print_r($request->active_discount);die;
        $validator = Validator::make($request->all(), [
            'part_no' => [
                Rule::unique('products')->where(function($query) {
                  $query->where('part_no', '!=', 'NULL');
              })
            ],
            'serial_no' => [
                Rule::unique('products')->where(function($query) {
                  $query->where('serial_no', '!=', 'NULL');
              })
            ],
            'name.*' => 'required|unique:products,name',
            'item_code' => 'required|unique:products,item_code',
            'category_ids' => 'required',
            'unit' => 'required',
            'images' => 'required',
            'image' => 'required',
        ], [
            'name.*.required' => 'Product name is required!',
            'name.*.unique' => 'Product name must be unique!',
            'item_code.required' => 'item code is required!',
            'category_ids.required' => 'category  is required!',
            'images.required' => 'Product images is required!',
            'image.required' => 'Product thumbnail is required!',
            'unit.required' => 'Unit  is required!',
        ]);

        if(!empty($request['unit_price']))
        {
            if ($request['discount_type'] == 'percent') {
                $dis = ($request['unit_price'] / 100) * $request['discount'];
            } else {
                $dis = $request['discount'];
            }

            if ($request['unit_price'] <= $dis) {
                $validator->after(function ($validator) {
                    $validator->errors()->add(
                        'unit_price', 'Discount can not be more or equal to the price!'
                    );
                });
            } 
        }

        $checkPrice = false;
        $variations = [];
        $stock_count = 0;
        

        $product = new Product();
        $product->user_id = auth('seller')->id();
        $product->added_by = "seller";
        $product->name = $request->name[array_search('en', $request->lang)];
        $product->system_item_code = $request->system_item_code;
        $product->item_code = $request->item_code;
        $product->part_no = $request->part_no;
        $product->serial_no = $request->serial_no;
        $product->slug = Str::slug($request->name[array_search('en', $request->lang)], '-') . '-' . Str::random(6);
        $product->category_ids = json_encode($request->category_ids);
        $product->brand_id = $request->brand_id;
        $product->unit = $request->unit;
        $product->details = $request->description[array_search('en', $request->lang)];

        if ($request->has('colors_active') && $request->has('colors') && count($request->colors) > 0) {
            foreach($request->colors as $ind => $col)
            {
                $colors[$ind] = trim($col);
            }
            $product->colors = json_encode($colors);
        } else {
            $colors = [];
            $product->colors = json_encode($colors);
        }
        $choice_options = [];
        if ($request->has('choice')) {
            foreach ($request->choice_no as $key => $no) {
                $procced_choice_options = [];
                $str = 'choice_options_' . $no;
                $item['name'] = 'choice_' . $no;
                $item['title'] = $request->choice[$key];
                $procced_choice_options = explode(',', implode('|', $request[$str]));
                foreach($procced_choice_options as $index => $opt)
                {
                    $item['options'][$index] = trim($opt);
                }
                array_push($choice_options, $item);
            }
        }

        $product->choice_options = json_encode($choice_options);
        //combinations start
        $options = [];
        if ($request->has('colors_active') && $request->has('colors') && count($request->colors) > 0) {
            $colors_active = 1;
            array_push($options, $request->colors);
        }

        if ($request->has('choice_no')) {
            foreach ($request->choice_no as $key => $no) {
                $name = 'choice_options_' . $no;
                $my_str = implode('|', $request[$name]);
                array_push($options, explode(',', $my_str));
            }
        }
        //Generates the combinations of customer choice options
        $combinations = Helpers::combinations($options);

        $FlagValidVariantPresent = '';

        if((empty($request->unit_price) || $request->unit_price == 0))
        {
            $verify_status=[];$type='';$price=[];$qty=[];
            $verify_status = $request->active_discount;
            $price = $request->price;
            $qty = $request->qty;
            

            foreach($verify_status as $index => $item)
            {
                if($item == 1)
                {
                    $FlagValidVariantPresent = 1;

                    $stock_count += (!empty($qty[$index])?$qty[$index]:0);

                    if($FlagValidVariantPresent == 1)
                    {
                        (!empty($price[$index]))?$uprice = $price[$index]:$uprice=0;
                        (!empty($request->unit_price))?$unitPrice = $request->unit_price:$unitPrice = $uprice;
                        $checkPrice = true;
                        $FlagValidVariantPresent++;
                    }
                }
            }
            $stock_count = (integer)$stock_count;
            $product->variant_product = 1;
        }
        else
        {
           $unitPrice = $request->unit_price;
           $checkPrice = true;
           $stock_count = (integer)$request['current_stock'];
        }

        if (!$checkPrice) {
            $validator->after(function ($validator) {
                $validator->errors()->add(
                    'unit_price', 'Please assign Unit Price or Price For atleast One Variant as a verified Variant!'
                );
            });
        }

        if ($validator->errors()->count() > 0) {
            return response()->json(['errors' => Helpers::error_processor($validator)]);
        }

        //combinations end
        $product->variation = json_encode($variations);
    
        $product->unit_price = BackEndHelper::systemcurrency_to_selectedcurrency(abs($unitPrice));
        (!empty($request->purchase_price))?$purchasePrice = $request->purchase_price:$purchasePrice = 0;
        $product->purchase_price = BackEndHelper::systemcurrency_to_selectedcurrency(abs($purchasePrice));

        $product->tax = $request->tax;
        $product->tax_type = $request->tax_type;
        $product->attributes = json_encode($request->choice_attributes);
        $product->current_stock = abs($stock_count);

        $product->video_provider = 'youtube';
        $product->video_url = $request->video_link;
        $product->request_status = 0;
        $product->status = 0;
        $checkdiscount = $request->discoun_amt;


        if ($request->ajax()) {
            return response()->json([], 200);
        } else {
            if ($request->file('images')) {
                foreach ($request->file('images') as $img) {
                    $product_images[] = ImageManager::upload('product/', 'png', $img);
                }
                $product->images = json_encode($product_images);
            }
            $product->thumbnail = ImageManager::upload('product/thumbnail/', 'png', $request->file('image'));

            $product->meta_title = $request->meta_title;
            $product->meta_description = $request->meta_description;
            $product->meta_image = ImageManager::upload('product/meta/', 'png', $request->meta_image);

            // ---the two line below are feature of admin approval status for product. But on demand of customer no such approval from admin further needed so by pass this functionality ---//
            $product->request_status = 1;
            $product->status = 1; 
            $product->save();

            if(!empty($checkdiscount) && ($request->discoun_amt > 0))
            {   
                Product::where('id',$product->id)->update(['discount_flag' => 1]);
                $ProductDiscount = new ProductDiscount();
                $ProductDiscount->product_id = $product->id;
                $ProductDiscount->discount = BackEndHelper::systemcurrency_to_selectedcurrency($request->discoun_amt);

                (!empty($request->start_date))?$VDStartDate = $request->start_date:$VDStartDate = '';
                (!empty($request->start_time))?$VDStartTime = $request->start_time:$VDStartTime = '';
                if(!empty($VDStartDate) && !empty($VDStartTime)){
                    $comStartDAte = $VDStartDate.' '.$VDStartTime;
                }
                else{
                    $comStartDAte = 'null';
                }

                $ProductDiscount->startDuration =  $comStartDAte;

                (!empty($request->end_date))?$VDEndDate = $request->end_date:$VDEndDate = '';
                (!empty($request->end_time))?$VDEndTime = $request->end_time:$VDEndTime = '';
                if(!empty($VDEndDate) && !empty($VDEndTime)){
                    $comEndDAte = $VDEndDate.' '.$VDEndTime;
                }
                else{
                    $comEndDAte = 'null';
                }

                $ProductDiscount->endDuration =  $comEndDAte;
                $ProductDiscount->quantity = $request->quantity;
                $ProductDiscount->buy = $request->buy;
                $ProductDiscount->Item = $request->item;
                $ProductDiscount->save();
            }


            if((empty($request->unit_price) || $request->unit_price == 0))
            {
                $verify_status='';
                $type='';
                $price='';
                $qty='';
                $startdate='';
                $starttime='';
                $enddate='';
                $endtime='';
                $sku='';
                $discount=''; 
                $check_discount = [];
                $check_verify_status = [];

                $verify_status = $request->active_discount; $type = $request->str; 
                $sku = $request->sku; $orignalstr = $request->orignal_str;
                $price = $request->price; $qty = $request->qty;
                $discount = $request->discount; $startdate = $request->startdate;
                $starttime = $request->starttime; $enddate = $request->enddate;
                $endtime = $request->endtime;

                // $check_verify_status = array_filter($verify_status);
                // $check_discount = array_filter($discount);
                // if(count($check_discount) > 0 && count($check_verify_status))
                // {
                //     Product::where('id',$product->id)->update(['discount_flag' => 1]);
                // }

                foreach($verify_status as $index => $item)
                {
                    $ProductVariant = new ProductVariant();
                    $ProductVariant->verify_status = (!empty($verify_status[$index])?$verify_status[$index]:0);
                    $ProductVariant->product_id = $product->id;
                    $ProductVariant->type = (!empty($type[$index])?$type[$index]:'');
                    $ProductVariant->sku = (!empty($sku[$index])?$sku[$index]:'');
                    $ProductVariant->orignalstr = (!empty($orignalstr[$index])?$orignalstr[$index]:'');

                    if(!empty($price[$index]))
                    {
                        $ProductVariant->price = BackEndHelper::systemcurrency_to_selectedcurrency(abs($price[$index]));
                    }
                    else
                    {
                        $ProductVariant->price = 0;
                    }

                    $ProductVariant->qty = (!empty($qty[$index])?$qty[$index]:0);

                    
                        $ProductVariant->discount = 0;
                        $ProductVariant->discount_percent = 0.00;
                    


                    (!empty($startdate[$index]))?$VDStartDate = ($startdate[$index]):$VDStartDate = '';
                    (!empty($starttime[$index]))?$VDStartTime = $starttime[$index]:$VDStartTime = '';
                    if(!empty($VDStartDate) && !empty($VDStartTime)){
                        $comStartDAte = $VDStartDate.' '.$VDStartTime;
                    }
                    else{
                        $comStartDAte = 'null';
                    }

                    $ProductVariant->startDuration =  $comStartDAte;

                    (!empty($enddate[$index]))?$VDEndDate = ($enddate[$index]):$VDEndDate = '';
                    (!empty($endtime[$index]))?$VDEndTime = $endtime[$index]:$VDEndTime = '';
                    if(!empty($VDEndDate) && !empty($VDEndTime)){
                        $comEndDAte = $VDEndDate.' '.$VDEndTime;
                    }
                    else{
                        $comEndDAte = 'null';
                    }

                    $ProductVariant->endDuration =  $comEndDAte;
                    $ProductVariant->save();
                }
            }

            $data = [];
            foreach ($request->lang as $index => $key) {
                if ($request->name[$index] && $key != 'en') {
                    array_push($data, array(
                        'translationable_type' => 'App\Model\Product',
                        'translationable_id' => $product->id,
                        'locale' => $key,
                        'key' => 'name',
                        'value' => $request->name[$index],
                    ));
                }
                if ($request->description[$index] && $key != 'en') {
                    array_push($data, array(
                        'translationable_type' => 'App\Model\Product',
                        'translationable_id' => $product->id,
                        'locale' => $key,
                        'key' => 'description',
                        'value' => $request->description[$index],
                    ));
                }
            }
            Translation::insert($data);
            Toastr::success('Product added successfully!');
            return redirect()->route('seller.product.list');
        }
    }

    function list(Request $request)
    {
    
        $query_param = [];
        $search = $request['search'];
        $products = Product::where(['added_by' => 'seller', 'user_id' => \auth('seller')->id()]);
        if($request->has('name') && $request['name']!=''){
             $products = $products->where('name','LIKE','%'.$request['name'].'%');
        }
        if($request->has('item_code') && $request['item_code']!=''){
             $products = $products->where('item_code','LIKE','%'.$request['item_code'].'%');
        }
        if($request->has('part_no') && $request['part_no']!=''){
             $products = $products->where('part_no','LIKE','%'.$request['part_no'].'%');
        }
        if($request->has('categories') && $request['categories']!=''){
            $cate = $request['categories'];
            $products = $products->where(function($products) use ($cate){
                foreach ($cate as $key => $value) {
                    $products->orWhereJsonContains('category_ids',$value);
                }
            });
        }
        
        if($request->has('brands') && $request['brands']!=''){
             $products = $products->whereIn('brand_id',$request['brands']);
        }
        if($request->has('units') && $request['units']){
             $products = $products->whereIn('unit',$request['units']);
        }
        if($request->has('attributes') && $request['attributes']){
            $attri = $request['attributes'];
            $products = $products->where(function($products) use ($attri){
                foreach ($attri as $key => $value) {
                    $products->orWhere('attributes','LIKE','%'.$value.'%');
                }
            });
            // foreach ($request['attributes'] as $key => $value) {
                //  $products->whereJsonContains('attributes',$request['attributes'][0]);
                // for ($i=0; $i < count($request['attributes']) ; $i++) { 
                //     $products->orWhereJsonContains('attributes',$request['attributes'][$i]);
                // }
            // }
        }
         $products = $products->orderBy('id', 'DESC')->paginate(Helpers::pagination_limit());
        // if ($request->has('search')) {
        //     $key = explode(' ', $request['search']);
        //     $products = Product::where(['added_by' => 'seller', 'user_id' => \auth('seller')->id()])
        //         ->where(function ($q) use ($key) {
        //             foreach ($key as $value) {
        //                 $q->Where('name', 'like', "%{$value}%");
        //             }
        //         });
        //     $query_param = ['search' => $request['search']];
        // } else {
        //     $products = Product::where(['added_by' => 'seller', 'user_id' => \auth('seller')->id()]);
        // }
        $categories = Category::where('parent_id',0)->where('selected_cat','LIKE','%'.auth('seller')->id().'%')->get();
        $brand = Brand::where('selected_seller','LIKE','%'.auth('seller')->id().'%')->get();
        $unit = Unit::where('selected_seller','LIKE','%'.auth('seller')->id().'%')->get();
        $attribute = Attribute::where('selected_seller','LIKE','%'.auth('seller')->id().'%')->get();

        // $products->orderBy('id', 'DESC')->paginate(Helpers::pagination_limit())->appends($query_param);
       
        return view('seller-views.product.list', compact('products', 'search','categories','brand','unit','attribute'));
    }

    public function stock_limit_list(Request $request, $type)
    {
        $stock_limit = Helpers::get_business_settings('stock_limit');
        $sort_oqrderQty = $request['sort_oqrderQty'];
        $query_param = $request->all();
        $search = $request['search'];
        $pro = Product::where(['added_by' => 'seller', 'user_id' => auth('seller')->id()])
            ->when($request->has('status') && $request->status != null, function ($query) use ($request) {
                $query->where('request_status', $request->status);
            });

        if ($request->has('search')) {
            $key = explode(' ', $request['search']);
            $pro = $pro->where(function ($q) use ($key) {
                foreach ($key as $value) {
                    $q->Where('name', 'like', "%{$value}%");
                }
            });
            $query_param = ['search' => $request['search']];
        }

        $request_status = $request['status'];

        $pro = $pro->withCount('order_details')->when($request->sort_oqrderQty == 'quantity_asc', function ($q) use ($request) {
            return $q->orderBy('current_stock', 'asc');
        })
            ->when($request->sort_oqrderQty == 'quantity_desc', function ($q) use ($request) {
                return $q->orderBy('current_stock', 'desc');
            })
            ->when($request->sort_oqrderQty == 'order_asc', function ($q) use ($request) {
                return $q->orderBy('order_details_count', 'asc');
            })
            ->when($request->sort_oqrderQty == 'order_desc', function ($q) use ($request) {
                return $q->orderBy('order_details_count', 'desc');
            })
            ->when($request->sort_oqrderQty == 'default', function ($q) use ($request) {
                return $q->orderBy('id');
            })->where('current_stock', '<', $stock_limit);


        $products = $pro->orderBy('id', 'DESC')->paginate(Helpers::pagination_limit())->appends(['status' => $request['status']])->appends($query_param);
        return view('seller-views.product.stock-limit-list', compact('products', 'search', 'request_status', 'sort_oqrderQty'));
    }

    public function update_quantity(Request $request)
    {
        $variations = [];
        $stock_count = $request['current_stock'];
        if ($request->has('type')) {
            foreach ($request['type'] as $key => $str) {
                $item = [];
                $item['type'] = $str;
                $item['price'] = BackEndHelper::currency_to_usd(abs($request['price_' . str_replace('.', '_', $str)]));
                $item['sku'] = $request['sku_' . str_replace('.', '_', $str)];
                $item['qty'] = abs($request['qty_' . str_replace('.', '_', $str)]);
                array_push($variations, $item);
            }
        }

        $product = Product::find($request['product_id']);
        if ($stock_count >= 0) {
            $product->current_stock = $stock_count;
            $product->variation = json_encode($variations);
            $product->save();
            Toastr::success(\App\CPU\translate('product_quantity_updated_successfully!'));
            return back();
        } else {
            Toastr::warning(\App\CPU\translate('product_quantity_can_not_be_less_than_0_!'));
            return back();
        }
    }

    public function get_categories(Request $request)
    {
        $cat = Category::where(['parent_id' => $request->parent_id])->get();
        $idArray = array();
        foreach ($cat as $key => $row) {
            if ($row->id == $request->sub_category) {
                $idArray[$key] = $row;
            } else {
                $idArray[$key] = $row;
            }  
        }
        return response()->json([
            'row' => $idArray
        ]);
    }


    public function get_variations(Request $request)
    {
        $product = Product::find($request['id']);
        return response()->json([
            'view' => view('seller-views.product.partials._update_stock', compact('product'))->render()
        ]);
    }

    public function checkVariantExist(Request $request)
    {
        $oldString = $request->oldSkuSrting;
        $ArrOfEle = explode('-',$request->newSkuString);
        $ArrOfEle_hex = explode('-',$request->newSkuString);

        if(!empty($ArrOfEle_hex[0]))
        {
            if($request->colors_active == 1)
            {
                    $color_name = \App\Model\Color::where('code', $ArrOfEle_hex[0])->first()->name;
                    $ArrOfEle[0] = $color_name;
            }
        }

        $ArrOfEle=array_filter($ArrOfEle);
        $ArrOfEle_hex=array_filter($ArrOfEle_hex);

        $modStr = implode("-", $ArrOfEle);
        $modStr_hex = implode("-", $ArrOfEle_hex);

        $status2 = PossibleVariant::where(['str' => $modStr_hex,'status' => 1])->first();
        // echo "<pre>";
        // print_r($status2);
        // die;
        $combination = PossibleCombinationElements::where('seller_id',auth('seller')->id())->first()->combination_string;
        $combination = json_decode($combination);
        $rowIndex = $request->rowIndex;
        $html = '';

        if(empty($status2))
        {
            //--Need to update to old str DISABLE, as new Str will take it's palce
            $updateOldSku = PossibleVariant::where(['str' => $oldString,'status' => 1])->update(['status' => 2]);

            $variantCombinations = new PossibleVariant();
            $variantCombinations->seller_id = auth('seller')->id();
            $variantCombinations->str = $modStr_hex;
            $variantCombinations->save();

            $strArray = [];
            $strArray = explode('-',  $modStr_hex);
            foreach($combination as $keys => $sc)
            {
            $html.='<td >';
                $html.='<label class="control-label">'.$sc[0].'</label>';
                $html.='<select class="form-control" data-row="'.$rowIndex.'" data-col="';$html.=(!empty($combination))?count($combination):0;$html.='" onchange="checkVariant('.$keys.',this,'.$rowIndex.')" id="'.$rowIndex.$keys.'" >';
                        $html.='<option value="">None</option>';
                        foreach($sc as $in => $s){
                            if($in){
                            $html.='<option ';$html.=(in_array($s, $strArray))?"selected":"";$html.=' value="'.$s.'">';$html.=($sc[0]=='color')?Color::where('code', $s)->first()->name:$s;$html.='</option>';
                            }
                        }
                $html.='</select>';
            $html.='</td>';
            }

            return array(['status' => true, 'originalStr' => $modStr_hex,'showstr' => $modStr,'matchedStr' => '','changedIndex' => '','html'=>$html]);
        }
        else
        {
            $strArray = [];
            $strArray = explode('-',  $oldString);
            foreach($combination as $keys => $sc)
            {
            $html.='<td >';
                $html.='<label class="control-label">'.$sc[0].'</label>';
                $html.='<select class="form-control" data-row="'.$rowIndex.'" data-col="';$html.=(!empty($combination))?count($combination):0;$html.='" onchange="checkVariant('.$keys.',this,'.$rowIndex.')" id="'.$rowIndex.$keys.'" >';
                        $html.='<option value="">None</option>';
                        foreach($sc as $in => $s){
                            if($in){
                            $html.='<option value="'.$s.'" ';$html.=(in_array($s, $strArray))?"selected":"";$html.='>';$html.=($sc[0]=='color')?Color::where('code', $s)->first()->name:$s;$html.='</option>';
                            }
                        }
                $html.='</select>';
            $html.='</td>';
            }

            return array(['status' => false, 'originalStr' => '','showstr' => '','matchedStr' => $oldString,'changedIndex' => $request->changedIndex,'html'=>$html]);

        }

    }

    public function checkVariantExistOnEdit(Request $request)
    {
        echo "<pre>";
        print_r($request->all());
        $r = json_decode($request->strArrayEncoded);
        print_r($r);
        die('456');
        $new_string = $request->newSkuString;
        $check_new_str = ProductVariant::where('type',$new_string)->first();
        if(!empty($check_new_str))
        {

        }


        $oldString = $request->oldSkuSrting;
        $ArrOfEle = explode('-',$request->newSkuString);
        $ArrOfEle_hex = explode('-',$request->newSkuString);

        if(!empty($ArrOfEle_hex[0]))
        {
            if($request->colors_active == 1)
            {
                    $color_name = \App\Model\Color::where('code', $ArrOfEle_hex[0])->first()->name;
                    $ArrOfEle[0] = $color_name;
            }
        }

        $ArrOfEle=array_filter($ArrOfEle);
        $ArrOfEle_hex=array_filter($ArrOfEle_hex);

        $modStr = implode("-", $ArrOfEle);
        $modStr_hex = implode("-", $ArrOfEle_hex);

        $status2 = PossibleVariant::where(['str' => $modStr_hex,'status' => 1])->first();
        // echo "<pre>";
        // print_r($status2);
        // die;
        $combination = PossibleCombinationElements::where('seller_id',auth('seller')->id())->first()->combination_string;
        $combination = json_decode($combination);
        $rowIndex = $request->rowIndex;
        $html = '';

        if(empty($status2))
        {
            //--Need to update to old str DISABLE, as new Str will take it's palce
            $updateOldSku = PossibleVariant::where(['str' => $oldString,'status' => 1])->update(['status' => 2]);

            $variantCombinations = new PossibleVariant();
            $variantCombinations->seller_id = auth('seller')->id();
            $variantCombinations->str = $modStr_hex;
            $variantCombinations->save();

            $strArray = [];
            $strArray = explode('-',  $modStr_hex);
            foreach($combination as $keys => $sc)
            {
            $html.='<td >';
                $html.='<label class="control-label">'.$sc[0].'</label>';
                $html.='<select class="form-control" data-row="'.$rowIndex.'" data-col="';$html.=(!empty($combination))?count($combination):0;$html.='" onchange="checkVariant('.$keys.',this,'.$rowIndex.')" id="'.$rowIndex.$keys.'" >';
                        $html.='<option value="">None</option>';
                        foreach($sc as $in => $s){
                            if($in){
                            $html.='<option ';$html.=(in_array($s, $strArray))?"selected":"";$html.=' value="'.$s.'">';$html.=($sc[0]=='color')?Color::where('code', $s)->first()->name:$s;$html.='</option>';
                            }
                        }
                $html.='</select>';
            $html.='</td>';
            }

            return array(['status' => true, 'originalStr' => $modStr_hex,'showstr' => $modStr,'matchedStr' => '','changedIndex' => '','html'=>$html]);
        }
        else
        {
            $strArray = [];
            $strArray = explode('-',  $oldString);
            foreach($combination as $keys => $sc)
            {
            $html.='<td >';
                $html.='<label class="control-label">'.$sc[0].'</label>';
                $html.='<select class="form-control" data-row="'.$rowIndex.'" data-col="';$html.=(!empty($combination))?count($combination):0;$html.='" onchange="checkVariant('.$keys.',this,'.$rowIndex.')" id="'.$rowIndex.$keys.'" >';
                        $html.='<option value="">None</option>';
                        foreach($sc as $in => $s){
                            if($in){
                            $html.='<option value="'.$s.'" ';$html.=(in_array($s, $strArray))?"selected":"";$html.='>';$html.=($sc[0]=='color')?Color::where('code', $s)->first()->name:$s;$html.='</option>';
                            }
                        }
                $html.='</select>';
            $html.='</td>';
            }

            return array(['status' => false, 'originalStr' => '','showstr' => '','matchedStr' => $oldString,'changedIndex' => $request->changedIndex,'html'=>$html]);

        }

    }

    public function get_all_color(Request $request)
    {

        echo "<pre>";
        print_r($request->selectedcombination);
        print_r($request->oldcombination);
        print_r($request->totalcombination);
        // $allColor = Color::get(['name','code']);
        // if(!empty($allColor))
        // {
        //     return $allColor;
        // }
        // else
        // {
        //     return null;
        // }
    }

    public function sku_combination(Request $request)
    {
        $sellerItem = Product::where(['user_id' => auth('seller')->id(),'added_by' => 'seller'])->get();
        
        $options = [];$selectColoumn = [];$prod_id="";$straArray=[];$straA=[];$final=[];$colors_active = 0;
        if ($request->has('colors_active') && $request->has('colors') && count($request->colors) > 0){
            $colors_active = 1;
            array_push($options, $request->colors);
            $arr = $request->colors;
            $pos = 0;
            $val = 'color';
         
            $selectColoumn[0] = array_merge(array_slice($arr, 0, $pos), array($val), array_slice($arr, $pos));
        } else {
            $colors_active = 0;
        }

        $unit_price = $request->unit_price;
        $product_name = $request->name[array_search('en', $request->lang)];
        if(!empty($request->productId))
        {
            $prod_id = $request->productId;
        }

        if ($request->has('choice_no')) {
            foreach ($request->choice_no as $key => $no) {
                $name = 'choice_options_' . $no;
                $my_str = implode('', $request[$name]);
                array_push($options, explode(',', $my_str));
            }
        }

        if ($request->has('choice_no')) {
            foreach ($request->choice_no as $key => $no) {
                $name = 'choice_options_' . $no;
                $my_str = $request->choice[$key].','.implode('', $request[$name]);
                array_push($selectColoumn, explode(',', $my_str));
            }
        }

        $combinations = Helpers::combinations($options);

        foreach ($combinations as $key => $combination)
        {
            $sku = '';
            //foreach (explode(' ', $product_name) as $key => $value) {
                //$sku .= substr($value, 0, 1);
            //}
            $string ="";
            if(!empty($product_name))
            {
                $string = strval($product_name);
            }
            else
            {
                $string ="N/A";
            }
            $sku .= trim($string);

            $str = '';
            foreach ($combination as $key => $item){

                if($key > 0 ){
                    $str .= '-'.str_replace(' ', '', $item);
                    //$sku .='-'.str_replace(' ', '', $item);
                }
                else
                {
                    if($colors_active == 1){
                        //$color_name = \App\Model\Color::where('code', $item)->first()->name;
                        $color_name = $item;
                        $str .= $color_name;
                        //$sku .='-'.$color_name;
                    }
                    else{
                        $str .= str_replace(' ', '', $item);
                        //$sku .='-'.str_replace(' ', '', $item);
                    }
                }
            }

            

            $orignalskr = (!empty($request->original_value))?$request->original_value:'';
            $changedskr = (!empty($request->changed_value))?$request->changed_value:'';

            if(!empty($orignalskr)){
                if($orignalskr == $str)
                {
                    $str = $changedskr;
                }   
            }
            array_push($straArray,$str);
        }


        PossibleVariant::where(["seller_id" => auth('seller')->id()])->delete();
        PossibleCombinationElements::where(["seller_id" => auth('seller')->id()])->delete();
        
        $stringOfCombination= json_encode($selectColoumn);
        $possCombination = new PossibleCombinationElements();
        $possCombination->seller_id = auth('seller')->id();
        $possCombination->combination_string = $stringOfCombination;
        $possCombination->save();
        foreach($straArray as $stA => $st)
        {
            $variantCombinations = new PossibleVariant();
            $variantCombinations->seller_id = auth('seller')->id();
            $variantCombinations->str = $st;
            $variantCombinations->save();
        }


        foreach ($straArray as $key => $st) {
            $r = explode('-', $st);
            array_push($straA, $r);
        }

        // return response()->json([
        //     'view' => view('admin-views.product.partials._sku_combinations', compact('combinations', 'unit_price', 'colors_active', 'product_name', 'prod_id', 'selectColoumn','orignalskr','changedskr','colors_active','sellerItem'))->render(),
        // ]);
        return response()->json([
            'view' => view('admin-views.product.partials._sku_combinations', compact('combinations', 'colors_active', 'prod_id', 'selectColoumn','orignalskr','changedskr','colors_active','sellerItem','sku'))->render(),
        ]);
    }

    public function edit_sku_combination(Request $request)
    {
        // echo "<pre>";
        // print_r($request->all());
        // die;
        $proVariant = $originalSkuArray = [];$colors_active=0; $selectColoumn=[];
        $product = Product::find($request->productid);

        if(!empty($productVariant) && count($productVariant))
        {
            foreach($productVariant as $ind => $pV)
            {
                array_push($proVariant, $pV->type);
            }
        }

        // -- requested attribute option array to create sku start
        if ($request->has('colors') && count($request->colors) > 0) {
            // -- product table need to be modify when some thing added or remove
            $product->colors = $request->colors;
            // -- product table need to be modify when some thing added or remove
        } else {
            $colors = [];
            // -- product table need to be modify when some thing added or remove
            $product->colors = $colors;
            // -- product table need to be modify when some thing added or remove
        }

        if($product->colors)
        {
            $colors_active = 1;
            $stcolor = $product->colors;
            $arr = $stcolor;
            $pos = 0;
            $val = 'color';

            $selectColoumn[0] = array_merge(array_slice($arr, 0, $pos), array($val), array_slice($arr, $pos));
        }

        $choice_options = [];
        if ($request->has('choice')) {
            foreach ($request->choice_no as $key => $no) {
                $str = 'choice_options_' . $no;
                $item['name'] = 'choice_' . $no;
                $item['title'] = $request->choice[$key];
                $item['options'] = explode(',', implode('|', $request[$str]));
                array_push($choice_options, $item);
                $arr = $item['options'];
                $pos = 0;
                $val = $item['title'];

                $filtered = array_merge(array_slice($arr, 0, $pos), array($val), array_slice($arr, $pos));
                array_push($selectColoumn, $filtered);

            }
        }
        $variantsObject['colors_active'] = $colors_active;
        $variantsObject['selectColoumn'] = $selectColoumn;

        // -- product table need to be modify when some thing added or remove
        $product->choice_options = json_encode($choice_options);
        // -- product table need to be modify when some thing added or remove

        $variations = [];
        //combinations start
        $options = [];
        if ($request->has('colors_active') && $request->has('colors') && count($request->colors) > 0) {
            $colors_active = 1;
            array_push($options, $request->colors);
        }

        if ($request->has('choice_no')) {
            foreach ($request->choice_no as $key => $no) {
                $name = 'choice_options_' . $no;
                $my_str = implode('|', $request[$name]);
                array_push($options, explode(',', $my_str));
            }
        }
        // -- requested attribute option array to create sku end

        // -- product table need to be modify when some thing added or remove
        $product->attributes = json_encode($request->choice_attributes);
        // -- product table need to be modify when some thing added or remove

        $combinations = Helpers::combinations($options);
        $possibleStrs = [];
        $possibleStr = [];
        if (count($combinations[0]) > 0) {
            $unitPriceFlag = 1;
            foreach ($combinations as $key => $combination) {
                $sku = '';
                $strOriginal = '';
                foreach ($combination as $k => $item) {
                    if ($k > 0) {
                        $sku .= '-' . str_replace(' ', '', $item);
                        $strOriginal .= '-' . str_replace(' ', '', $item);
                    } else {
                        if ($request->has('colors_active') && $request->has('colors') && count($request->colors) > 0) {
                            $color_name = Color::where('code', $item)->first()->name;
                            $sku .= $color_name;
                            $strOriginal .= $item;
                        } else {
                            $sku .= str_replace(' ', '', $item);
                            $strOriginal .= str_replace(' ', '', $item);
                        }
                    }

                }
                $possibleStr['str'] = $strOriginal;
                $possibleStr['sku'] = $sku;
                array_push($possibleStrs, $possibleStr);
            }
        }

        $a=[];
        foreach($possibleStrs as $index => $ps)
        {
            $check = ProductVariant::where('orignalstr',$ps['str'])->first();
            if(!empty($check))
            {
                $a[$index] = $check->toArray();
            }
            else
            {
                $emptyArray['id'] = '';
                $emptyArray['product_id'] = $product->id;
                $emptyArray['type'] = $ps['str'];
                $emptyArray['orignalstr'] = $ps['str'];
                $emptyArray['price'] = 0;
                $emptyArray['sku'] = $ps['sku'];
                $emptyArray['qty'] = 0;
                $emptyArray['discount'] = '';
                $emptyArray['startDuration'] = '';
                $emptyArray['endDuration'] = '';
                $emptyArray['verify_status'] = 0;
                $a[$index] = $emptyArray;
            }
            
        }

        $variantsObject['combinations'] = $a;
        return view('seller-views.product.partials._edit_variant', compact('variantsObject','colors_active'));
    }

    public function variant($id)
    {
            $variantsObject = [];$combinations = [];$selectColoumn = [];$colors_active = 0;
            $sellerItems = Product::where(['user_id' => auth('seller')->id(),'added_by' => 'seller'])->get();
            $product = Product::withoutGlobalScopes()->with('translations')->find($id);
            if($product->user_id == auth('seller')->id())
            {
                if(!empty($product))
                {
                    $comb = ProductVariant::where(['product_id' => $id, 'isEnable' => 1])->get();
                    if(!empty($comb))
                    {
                        $combinations = $comb->toArray();
                    }

                    //--to create modifiers (Start)
                    if($product->colors)
                    {
                        $colors_active = 1;
                        $stcolor = json_decode($product->colors);
                        $arr = $stcolor;
                        $pos = 0;
                        $val = 'color';

                        $selectColoumn[0] = array_merge(array_slice($arr, 0, $pos), array($val), array_slice($arr, $pos));
                    }

                    if(!empty($product->choice_options))
                    {
                        $st = json_decode($product->choice_options);

                        foreach($st as $key => $t)
                        {
                            $string ='';
                            $string = $t->title;
                            if(!empty($t->options))
                            {
                                $string = $string.','.implode(',', $t->options);
                            }
                            array_push($selectColoumn, explode(',', $string));
                        } 
                    }
                    //--to create modifiers (End)
                }

                $variantsObject['selectColoumn'] = $selectColoumn;
                $variantsObject['combinations'] = $combinations;
                $variantsObject['colors_active'] = $colors_active;
            }

            return view('seller-views.product.variant', compact('product','variantsObject','colors_active','sellerItems'));

    }

    public function update_variant(Request $request)
    {
        // --assign multiple request to single varianbles (Start)
            $verify_status='';$type='';$price='';$qty='';$startdate='';$starttime='';$enddate='';$endtime='';$sku='';$discount=''; $buyquantity ='';$freequantity ='';$freeitem =array();

            $verify_status = $request->verify_status;
        
            $type           = $request->changed_str;
            $orignalstr     = $request->original_str;
            $price          = $request->price;
            $qty            = $request->qty;

            $product = Product::find($request->productid);

            if($request->has('choice_attributes'))
            {
                $product->attributes = json_encode($request->choice_attributes);
            }
            else
            {
                $product->attributes = $product->attributes;
            }

            if ($request->has('colors_active') && $request->has('colors') && count($request->colors) > 0) {
                $product->colors = json_encode($request->colors);
            } else {
                $product->colors = $product->colors;
            }

            $choice_options = [];
            if ($request->has('choice')) {
                foreach ($request->choice_no as $key => $no) {
                    $str = 'choice_options_' . $no;
                    $item['name'] = 'choice_' . $no;
                    $item['title'] = $request->choice[$key];
                    $item['options'] = explode(',', implode('|', $request[$str]));
                    array_push($choice_options, $item);
                }
            }
            else
            {
                $product->choice_options = $product->choice_options;
            }

            $product->choice_options = json_encode($choice_options);

            $product->variant_product = 1;

            // --update quantity price and other parameters
            $stock_count = 0;
            $unit_price = 0;
            foreach($verify_status as $index => $item)
            {
                if($item == 1)
                {
                    $stock_count += (!empty($qty[$index])?$qty[$index]:0);
                    $unit_price = abs((!empty($price[$item]) && $price[$item] != 0)?$price[$item]:0);
                }
            }
            $stock_count = (integer)$stock_count;
            $product->unit_price = abs($unit_price);
            $product->current_stock = abs($stock_count);

            // Update all the Variant to disable before insert new, for Update
            ProductVariant::where('product_id',$product->id)->update(['isEnable' => 0]);
            $product->save();
            // Update four fields of product table in string fromate (end)


            foreach($verify_status as $index => $item)
            {   
                
                $ProductVariant = new ProductVariant();
                $ProductVariant->verify_status = (!empty($verify_status[$index])?$verify_status[$index]:0);
                $ProductVariant->product_id = $product->id;
                $ProductVariant->type = (!empty($type[$index])?$type[$index]:'');
                $ProductVariant->orignalstr = (!empty($orignalstr[$index])?$orignalstr[$index]:'');

                if($request->has('colors_active'))
                {
                    $str_elem_arr = explode('-',$type[$index]);
                    $str_elem_arr[0] = Color::where('code', $str_elem_arr[0])->first()->name;
                    $skuvalue = implode('-',$str_elem_arr);
                }
                else
                {
                    $skuvalue = $type[$index];
                }

                $ProductVariant->sku = $skuvalue;

                if(!empty($price[$index]))
                {
                    $ProductVariant->price = BackEndHelper::systemcurrency_to_selectedcurrency(abs($price[$index]));
                }
                else
                {
                    $ProductVariant->price = 0;
                }

                $ProductVariant->qty = (!empty($qty[$index])?$qty[$index]:0);

                // if(!empty($price[$index]))
                // {
                //     $ProductVariant->discount   = BackEndHelper::systemcurrency_to_selectedcurrency(abs($discount[$index]));
                //     $ProductVariant->discount_percent = $precentage[$index];
                // }
                // else
                // {
                    // $ProductVariant->discount = 0;
                    // $ProductVariant->discount_percent = 0.00;
                // }


                // (!empty($startdate[$index]))?$VDStartDate = ($startdate[$index]):$VDStartDate = '';
                // (!empty($starttime[$index]))?$VDStartTime = $starttime[$index]:$VDStartTime = '';
                // if(!empty($VDStartDate) && !empty($VDStartTime)){
                //     $comStartDAte = $VDStartDate.' '.$VDStartTime;
                // }
                // else{
                //     $comStartDAte = 'null';
                // }

                // $ProductVariant->startDuration =  $comStartDAte;

                // (!empty($enddate[$index]))?$VDEndDate = ($enddate[$index]):$VDEndDate = '';
                // (!empty($endtime[$index]))?$VDEndTime = $endtime[$index]:$VDEndTime = '';
                // if(!empty($VDEndDate) && !empty($VDEndTime)){
                //     $comEndDAte = $VDEndDate.' '.$VDEndTime;
                // }
                // else{
                //     $comEndDAte = 'null';
                // }

                // $ProductVariant->endDuration =  $comEndDAte;

                // $ProductVariant->buyquantity = (!empty($buyquantity[$index])?$buyquantity[$index]:'NULL');
                // $ProductVariant->freequantity = (!empty($freequantity[$index])?$freequantity[$index]:'NULL');
                // $ProductVariant->item = (!empty($freeitem[$index])?json_encode($freeitem[$index]):'NULL');
                $ProductVariant->save();
            }
            Toastr::success('Updates have been made with success.');
        
        return back();
    }

    public function edit($id)
    {
            $product = Product::withoutGlobalScopes()->with('translations')->find($id);
            $sellerItems = Product::where(['user_id' => auth('seller')->id(),'added_by' => 'seller'])->get();

            if(empty($product->system_item_code))
            {
                $product->system_item_code = str_pad(auth('seller')->id(), 4, '0', STR_PAD_LEFT).'-'.str_pad(count($sellerItems), 5, '0', STR_PAD_LEFT);
            }

            if(!empty($product))
            {
                if($product->variant_product)
                {
                    $quant = 0;
                    foreach(ProductVariant::where('product_id',$product->id)->get() as $pV)
                    {
                        if($pV->isEnable)
                        {
                            $quant = $quant+$pV->qty;
                        }
                    }
                    $product->current_stock = $quant;
                }
            }

            // $product->unit_price =\App\CPU\Convert::default($product->unit_price);
            // $product->purchase_price =\App\CPU\Convert::default($product->purchase_price);

            $processedDiscountArray=[];
            $i=0;
            foreach ($product->productDiscount as $key => $value) {
                if($value->status!=1){
                    $disPer = ($value->discount/$product->unit_price)*100;
                    $processedDiscountArray[$i]['id'] = $value->id;
                    $processedDiscountArray[$i]['discount'] = $value->discount;

                    $processedDiscountArray[$i]['startDuration'] = $value->startDuration;
                    $processedDiscountArray[$i]['endDuration'] = $value->endDuration;

                    $processedDiscountArray[$i]['start_date'] = $value->start_date;
                    $processedDiscountArray[$i]['start_time'] = $value->start_time;
                    $processedDiscountArray[$i]['end_date'] = $value->end_date;
                    $processedDiscountArray[$i]['end_time'] = $value->end_time;
                    $processedDiscountArray[$i]['quantity'] = $value->quantity;
                    $processedDiscountArray[$i]['buy'] = $value->buy;
                    $processedDiscountArray[$i]['Item'] = $value->Item;
                    $processedDiscountArray[$i]['status'] = $value->status;
                    //$processedDiscountArray[$i]['calculatedDiscountPersent'] = convert::default($disPer);
                    $processedDiscountArray[$i]['calculatedDiscountPersent'] = $disPer;
                    $i++;
                }
            }

            $product_category = json_decode($product->category_ids);
            $elementCount  = count($product_category);
            $product->colors = json_decode($product->colors);
            $categories = Category::where('selected_cat','LIKE','%'.auth('seller')->id().'%')->where(['parent_id' => 0])->get();
            $allCats = Category::get();      

            $allowedIds = CategoryBlock::where(['seller_id' => auth('seller')->id(),'delete_status' => 0])->pluck('level0_id');
            if(!empty($allowedIds)){
                $allowedIds = $allowedIds->toArray();
            }else{
                $allowedIds = array();
            }


            $allowedBrandIds = Brandallowe::where(['seller_id' => auth('seller')->id(),'delete_status' => 0])->pluck('brand_id');
            if(!empty($allowedBrandIds)){
                $allowedBrandIds = $allowedBrandIds->toArray();
            }else{
                $allowedBrandIds = array();
            }

            $br = Brand::orderBY('name', 'ASC')->get();
            $unit = Unit::orderBY('id', 'ASC')->get();
            $current_unit= unit::find($product->unit);
            $allowedUnitIds = unitallowe::where(['seller_id' => auth('seller')->id(),'delete_status' => 0])->pluck('unit_id');
            if(!empty($allowedUnitIds)){
                $allowedUnitIds = $allowedUnitIds->toArray();
            }else{
                $allowedUnitIds = array();
            }
            //code for get inserted catagory,subcatagory,sub-sub-catagory----start---------------------------
            $brand_original = $product->brand;
            $brands = Brand::where('selected_seller','LIKE','%'.auth('seller')->id().'%')->get();
            $units = Unit::where('selected_seller','LIKE','%'.auth('seller')->id().'%')->get();
            //---------------------------------Catagory----------------------------------------------------     
            // $inserted_catagory = Category::whereIn($product->categor);
            //---------------------------------Catagory---------------------------------------------------- 

            //---------------------------------Sub-Catagory----------------------------------------------------- 
            // if(!empty($product_category[1]->id))
            //     $inserted_sub_catagory = category::find($product_category[1]->id);
            // else
            //     $inserted_sub_catagory = "";
            //---------------------------------Sub-Catagory-----------------------------------------------------

            //---------------------------------sub-Sub-Catagory------------------------------------------------------
            // if(!empty($product_category[2]->id))
            //     $inserted_sub_sub_catagory = category::find($product_category[2]->id);
            // else
            //     $inserted_sub_sub_catagory = "";
            //---------------------------------sub-Sub-Catagory------------------------------------------------------

            //end----------------------------------------------------------------------------------------------

            return view('seller-views.product.edit', compact('elementCount','unit','allowedIds','allowedBrandIds','allCats','categories', 'br', 'product', 'product_category','current_unit','allowedUnitIds','processedDiscountArray','brand_original','sellerItems','units','brands'));

    }

    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            // 'part_no' => [
            //     Rule::unique('products')->where(function($query) {
            //       $query->where('part_no', '!=', 'NULL');
            //   })
            // ],
            'name' => 'required',
            'item_code' => 'required',
            'category_ids' => 'required',
            //'tax' => 'required|min:0',
            // 'unit_price' => 'required|numeric|min:1',
            // 'purchase_price' => 'required|numeric|min:1',
        ], [
            'name.required' => 'Product name is required!',
            'item_code.required' => 'item code is required!',
            'category_ids.required' => 'category  is required!',
            // 'unit_price.required' => 'unit price  is required!',
            // 'unit_price.numeric' => 'unit price  is numeric!',
            // 'purchase_price.required' => 'purchase price  is required!',
            // 'purchase_price.numeric' => 'purchase price  is numeric!',
            'images.required' => 'Product images is required!',
            'image.required' => 'Product thumbnail is required!',
        ]);


        if ($request['discount_type'] == 'percent') {
            $dis = ($request['unit_price'] / 100) * $request['discount'];
        } else {
            $dis = $request['discount'];
        }

        if ($request['unit_price'] <= $dis) {
            $validator->after(function ($validator) {
                $validator->errors()->add('unit_price', 'Discount can not be more or equal to the price!');
            });
        }

        $product = Product::find($id);
        $product->name = $request->name[array_search('en', $request->lang)];
        $product->system_item_code = $request->system_item_code;

    

        $product->category_ids = json_encode($request->category_ids);
        $product->brand_id = $request->brand_id;
        $product->item_code = $request->item_code;
        $product->part_no = $request->part_no;
        $product->serial_no = $request->serial_no;
        $product->unit = $request->unit;
        $product->details = $request->description[array_search('en', $request->lang)];

        if ($request->has('colors_active') && $request->has('colors') && count($request->colors) > 0) {
            $product->colors = json_encode($request->colors);
        } else {
            $colors = [];
            $product->colors = json_encode($colors);
        }

        $choice_options = [];
        if ($request->has('choice')) {
            foreach ($request->choice_no as $key => $no) {
                $str = 'choice_options_' . $no;
                $item['name'] = 'choice_' . $no;
                $item['title'] = $request->choice[$key];
                $item['options'] = explode(',', implode('|', $request[$str]));
                array_push($choice_options, $item);
            }
        }
        $product->choice_options = json_encode($choice_options);


        $variations = [];
        //combinations start
        $options = [];
        if ($request->has('colors_active') && $request->has('colors') && count($request->colors) > 0) {
            $colors_active = 1;
            array_push($options, $request->colors);
        }
        if ($request->has('choice_no')) {
            foreach ($request->choice_no as $key => $no) {
                $name = 'choice_options_' . $no;
                $my_str = implode('|', $request[$name]);
                array_push($options, explode(',', $my_str));
            }
        }
        //Generates the combinations of customer choice options
        $combinations = Helpers::combinations($options);
        $checkPrice ='';$variations = [];$stock_count = 0;
        if (count($combinations[0]) > 0) {
            $unitPriceFlag = 1;
            foreach ($combinations as $key => $combination) {
                $str = '';
                foreach ($combination as $k => $item) {
                    if ($k > 0) {
                        $str .= '-' . str_replace(' ', '', $item);
                    } else {
                        if ($request->has('colors_active') && $request->has('colors') && count($request->colors) > 0) {
                            $color_name = Color::where('code', $item)->first()->name;
                            $str .= $color_name;
                        } else {
                            $str .= str_replace(' ', '', $item);
                        }
                    }
                }
                if(($request['verify_status_' . str_replace('.','_',$str)]==1 && !empty($request['price_' . str_replace('.', '_', $str)]) && abs($request['price_' . str_replace('.', '_', $str)]) > 0))
                {
                    $checkPrice = true;
                    if($unitPriceFlag == 1)
                    {
                        $unitPrice = $request['price_' . str_replace('.', '_', $str)];
                        $unitPriceFlag++;
                    }
                }
                $item = [];
                $item['type'] = $str;
                //$item['price'] = Convert::usd(abs($request['price_' . str_replace('.', '_', $str)]));
                // --change this to newly formed
                //$item['price'] = Convert::converToUsd(abs($request['price_' . str_replace('.', '_', $str)]),auth('seller')->id());
                $item['price'] = BackEndHelper::systemcurrency_to_selectedcurrency(abs($request['price_' . str_replace('.', '_', $str)]));
                $item['sku'] = $request['sku_' . str_replace('.', '_', $str)];
                $item['qty'] = abs($request['qty_' . str_replace('.', '_', $str)]);
                // $item['discount'] = BackEndHelper::systemcurrency_to_selectedcurrency(abs($request['discount_' . str_replace('.','_',$str)]));

                (!empty($request['discount_' . str_replace('.','_',$str)]))?$VDiscount = $request['discount_' . str_replace('.','_',$str)]:$VDiscount = 0;
                    $item['discount'] = BackEndHelper::systemcurrency_to_selectedcurrency(abs($VDiscount));

                    (!empty($request['startdate_' . str_replace('.','_',$str)]))?$VDStartDate = $request['startdate_' . str_replace('.','_',$str)]:$VDStartDate = '';
                    (!empty($request['starttime_' . str_replace('.','_',$str)]))?$VDStartTime = $request['starttime_' . str_replace('.','_',$str)]:$VDStartTime = '';
                    if(!empty($VDStartDate) && !empty($VDStartTime)){
                        $comStartDAte = $VDStartDate.' '.$VDStartTime;
                    }
                    else{
                        $comStartDAte = 'null';
                    }

                    $item['startDuration'] =  $comStartDAte;

                    (!empty($request['enddate_' . str_replace('.','_',$str)]) && $request['enddate_' . str_replace('.','_',$str)] != '0000-00-00')?$VDEndDate = $request['enddate_' . str_replace('.','_',$str)]:$VDEndDate = '';
                    (!empty($request['endtime_' . str_replace('.','_',$str)] && $request['endtime_' . str_replace('.','_',$str)] != '00:00'))?$VDEndTime = $request['endtime_' . str_replace('.','_',$str)]:$VDEndTime = '';

                    if(!empty($VDEndDate) && !empty($VDEndTime)){
                        $comEndDAte = $VDEndDate.' '.$VDEndTime;
                    }
                    else{
                        $comEndDAte = 'null';
                    }
                    
                    $item['endDuration'] =  $comEndDAte;

                    $item['isverified_V_Discount'] =  $request['verify_status_' . str_replace('.','_',$str)];


                array_push($variations, $item);
                $stock_count += $item['qty'];
            }
        } 
        else 
        {
            if((empty($request->unit_price) || $request->unit_price == 0))
            {
                $checkPrice = false;
            }
            $unitPrice = $request->unit_price;
            $stock_count = (integer)$request['current_stock'];
        }
        if (!$checkPrice && $checkPrice != '') {
            $validator->after(function ($validator) {
                $validator->errors()->add(
                    'unit_price', 'Please assign Unit Price or Price For atleast One Variant as a verified Variant!'
                );
            });
        }

        if ($validator->errors()->count() > 0) {
            return response()->json(['errors' => Helpers::error_processor($validator)]);
        }

        //combinations end
        $product->variation = json_encode($variations);

        $product->unit_price = BackEndHelper::systemcurrency_to_selectedcurrency($unitPrice);
        //$product->unit_price = Helpers::currency_converter($request->unit_price);
        //$product->unit_price = Convert::usd($request->unit_price);
        //$product->unit_price = BackEndHelper::usd_to_currency($request->unit_price);

        (!empty($request->purchase_price))?$purchasePrice = $request->purchase_price:$purchasePrice = 0;
        $product->purchase_price = BackEndHelper::systemcurrency_to_selectedcurrency($purchasePrice);
        //$product->purchase_price = Helpers::currency_converter($request->purchase_price);
        //$product->purchase_price = Convert::usd($request->purchase_price);
        //$product->purchase_price = BackEndHelper::usd_to_currency($request->purchase_price);
        $product->tax = $request->tax;
        $product->tax_type = $request->tax_type;
        // $product->discount = $request->discount_type == 'flat' ? BackEndHelper::systemcurrency_to_selectedcurrency($request->discount) : $request->discount;
        $product->attributes = json_encode($request->choice_attributes);
        $product->discount_type = $request->discount_type;
        $product->current_stock = abs($stock_count);

        $product->video_provider = 'youtube';
        $product->video_url = $request->video_link;
        if ($product->request_status == 2) {
            $product->request_status = 0;
        }

        if ($request->ajax()) {
            return response()->json([], 200);
        } else {
            $product_images = json_decode($product->images);
            if ($request->file('images')) {
                foreach ($request->file('images') as $img) {
                    $product_images[] = ImageManager::upload('product/', 'png', $img);
                }
                $product->images = json_encode($product_images);
            }

            if ($request->file('image')) {
                $product->thumbnail = ImageManager::update('product/thumbnail/', $product->thumbnail, 'png', $request->file('image'));
            }

            $product->meta_title = $request->meta_title;
            $product->meta_description = $request->meta_description;
            if ($request->file('meta_image')) {
                $product->meta_image = ImageManager::update('product/meta/', $product->meta_image, 'png', $request->file('meta_image'));
            }

            $product->save();

             $disco=$request->discount_amt;
            if(!empty($disco) &&  $disco )
            {
                $answers = [];
                ProductDiscount::where("product_id", $product->id)->update(["status" => 1]);
                for ($i = 0; $i < count($disco); $i++) {
                    if($disco[$i] > 0)
                    {
                        $comEndDAte = 'null';$comStartDAte = 'null';
                        (!empty($request->startdate[$i]))?$VDStartDate = $request->startdate[$i]:$VDStartDate = '';
                        (!empty($request->starttime[$i]))?$VDStartTime = $request->starttime[$i]:$VDStartTime = '';
                        if(!empty($VDStartDate) && !empty($VDStartTime)){
                            $comStartDAte = $VDStartDate.' '.$VDStartTime;
                            $comStartDAte = date('Y-m-d H:i:s', strtotime($comStartDAte));
                        }
                        else{
                            $comStartDAte = 'null';
                        }


                        (!empty($request->enddate[$i]))?$VDEndDate = $request->enddate[$i]:$VDEndDate = '';
                        (!empty($request->endtime[$i]))?$VDEndTime = $request->endtime[$i]:$VDEndTime = '';
                        if(!empty($VDEndDate) && !empty($VDEndTime)){
                            $comEndDAte = $VDEndDate.' '.$VDEndTime;
                            $comStartDAte = date('Y-m-d H:i:s', strtotime($comEndDAte));
                        }
                        else{
                            $comEndDAte = 'null';
                        }



                        $answers[] = [
                            'product_id'    => $product->id,
                            'discount'      => BackEndHelper::systemcurrency_to_selectedcurrency($disco[$i]),

                            'start_date'    => $request->startdate[$i],
                            'start_time'    => $request->starttime[$i],
                            'end_date'      => $request->enddate[$i],
                            'end_time'      => $request->endtime[$i],


                            'startDuration' => $comStartDAte,
                            'endDuration'   => $comEndDAte,

                            'quantity'      => $request->quantity[$i],
                            'Buy'           => $request->buy[$i],
                            'Item'          => $request->item[$i],
                        ];
                    }
                }
                if(count($answers) > 0)
                {
                    ProductDiscount::insert($answers);
                }
            }

            foreach ($request->lang as $index => $key) {
                if ($request->name[$index] && $key != 'en') {
                    Translation::updateOrInsert(
                        ['translationable_type' => 'App\Model\Product',
                            'translationable_id' => $product->id,
                            'locale' => $key,
                            'key' => 'name'],
                        ['value' => $request->name[$index]]
                    );
                }
                if ($request->description[$index] && $key != 'en') {
                    Translation::updateOrInsert(
                        ['translationable_type' => 'App\Model\Product',
                            'translationable_id' => $product->id,
                            'locale' => $key,
                            'key' => 'description'],
                        ['value' => $request->description[$index]]
                    );
                }
            }
            Toastr::success('Product updated successfully.');
            return back();
        }
    }

    public function view($id)
    {
        $product = Product::with(['reviews'])->where(['id' => $id])->first();
        $reviews = Review::where(['product_id' => $id])->paginate(Helpers::pagination_limit());
        return view('seller-views.product.view', compact('product', 'reviews'));
    }

    public function remove_image(Request $request)
    {
        ImageManager::delete('/product/' . $request['image']);
        $product = Product::find($request['id']);
        $array = [];
        if (count(json_decode($product['images'])) < 2) {
            Toastr::warning('You cannot delete all images!');
            return back();
        }
        foreach (json_decode($product['images']) as $image) {
            if ($image != $request['name']) {
                array_push($array, $image);
            }
        }
        Product::where('id', $request['id'])->update([
            'images' => json_encode($array),
        ]);
        Toastr::success('Product image removed successfully!');
        return back();
    }

    public function delete($id)
    {
        $product = Product::find($id);
        Cart::where('product_id', $product->id)->delete();
        foreach (json_decode($product['images'], true) as $image) {
            ImageManager::delete('/product/' . $image);
        }
        ImageManager::delete('/product/thumbnail/' . $product['thumbnail']);
        $product->delete();
        FlashDealProduct::where(['product_id' => $id])->delete();
        DealOfTheDay::where(['product_id' => $id])->delete();
        Toastr::success('Product removed successfully!');
        return back();
    }

    public function bulk_import_index()
    {
        return view('seller-views.product.bulk-import');
    }

    public function bulk_import_data(Request $request)
    {
        try {
            $collections = (new FastExcel)->import($request->file('products_file'));
        } catch (\Exception $exception) {
            Toastr::error('You have uploaded a wrong format file, please upload the right file.');
            return back();
        }
        // echo "<pre>";print_r($collections);die;
        $skip = ['youtube_video_url','details','unit','part_no','serial_no','brand_id','sub_sub_category_id','discount','discount_type',];
        foreach ($collections as $collection) {
            if($collection['product_name'] == ''){
                Toastr::error('Product Name is blank in file please fill and try again');
                return back();
            }
            if($collection['item_code'] == ''){
                Toastr::error('Item Code is blank in file please fill and try again');
                return back();
            }
            if($collection['part_no'] == ''){
                Toastr::error('Part Number is blank in file please fill and try again');
                return back();
            }
            if($collection['categories'] == ''){
                Toastr::error('Category is blank in file please fill and try again');
                return back();
            }
            if($collection['brand'] == ''){
                Toastr::error('Brand is blank in file please fill and try again');
                return back();
            }
            if($collection['unit'] == ''){
                Toastr::error('Unit is blank in file please fill and try again');
                return back();
            }
            if($collection['tax'] == ''){
                Toastr::error('Tax is blank in file please fill and try again');
                return back();
            }
            if($collection['current_stock'] == ''){
                Toastr::error('Current Stock is blank in file please fill and try again');
                return back();
            }


            $ccs = explode(',',$collection['categories']);
            if($request->is_opb == 1){
                $dprod = Product::where('name',$collection['product_name'])->first();
                if($dprod){
                    $product = Product::where('id',$dprod->id)->first();
                    $product->name = $collection['product_name'];
                    $product->item_code = $collection['item_code'];
                    $product->part_no = $collection['item_code'];
                    $product->serial_no = $collection['serial_no'];
                    $product->slug = Str::slug($collection['product_name'], '-') . '-' . Str::random(6);
                    $product->category_ids = json_encode($ccs,true);
                    $product->brand_id = $collection['brand'];
                    $product->unit = $collection['unit'];
                    $product->tax = $collection['tax'];
                    $product->unit_price = $collection['unit_price'];
                    $product->current_stock = $collection['current_stock'];
                    $product->details = $collection['details'];
                    // $product->images = ImageManager::upload('product/', 'png', $collection['product_image']);
                    // $product->thumbnail = ImageManager::upload('product/thumbnail/', 'png', $request->file('thumbnail'));

                    $product->images = json_encode(['def.png']);
                    $product->thumbnail = 'def.png';
                    $product->status = 0;
                    $product->colors =json_encode([]);
                    $product->attributes = json_encode([]);
                    $product->choice_options = json_encode([]);
                    $product->variation = json_encode([]);
                    $product->featured_status = 1;
                    $product->added_by = 'Seller';
                    $product->user_id = auth('seller')->id();
                    $product->save();
                }else{
                    $product = new Product;
                    $product->name = $collection['product_name'];
                    $product->item_code = $collection['item_code'];
                    $product->part_no = $collection['item_code'];
                    $product->serial_no = $collection['serial_no'];
                    $product->slug = Str::slug($collection['product_name'], '-') . '-' . Str::random(6);
                    $product->category_ids = json_encode($ccs,true);
                    $product->brand_id = $collection['brand'];
                    $product->unit = $collection['unit'];
                    $product->tax = $collection['tax'];
                    $product->unit_price = $collection['unit_price'];
                    $product->current_stock = $collection['current_stock'];
                    $product->details = $collection['details'];
                    // $product->images = ImageManager::upload('product/', 'png', $collection['product_image']);
                    // $product->thumbnail = ImageManager::upload('product/thumbnail/', 'png', $request->file('thumbnail'));

                    $product->images = json_encode(['def.png']);
                    $product->thumbnail = 'def.png';
                    $product->status = 0;
                    $product->colors =json_encode([]);
                    $product->attributes = json_encode([]);
                    $product->choice_options = json_encode([]);
                    $product->variation = json_encode([]);
                    $product->featured_status = 1;
                    $product->added_by = 'Seller';
                    $product->user_id = auth('seller')->id();
                    $product->save();
                }
                $d = DB::table('balance_sheet')->where('product_id',$product->id)->orderBy('created_at','desc')->first();
                if(!$d){
                    $opb_sheet = array(
                        'product_id' => $product->id,
                        'opening_balance' => $collection['current_stock'],
                        'in_qty' => $collection['current_stock'],
                        'purchase_price' => $collection['unit_price'],
                        'in_qty_ref' => 'Opening Balance',
                        'out_qty' => 0,
                        'out_qty_ref' => '',
                        'balance_qty' => $collection['current_stock'],
                        'date' => $request->date,
                    );
                    DB::table('balance_sheet')->insert($opb_sheet);
                }else{
                    $opb_sheet = array(
                        'product_id' => $product->id,
                        'opening_balance' => $d->opening_balance,
                        'in_qty' => $collection['current_stock'],
                        'purchase_price' => $collection['unit_price'],
                        'in_qty_ref' => 'Stock Update',
                        'out_qty' => $d->out_qty,
                        'out_qty_ref' => $d->out_qty_ref,
                        'balance_qty' => ($d->balance_qty+$collection['current_stock']),
                        'date' => $d->date,
                    );
                    DB::table('balance_sheet')->insert($opb_sheet);
                }
            }else if($request->is_opb == 2){
                $dprod = Product::where('name',$collection['product_name'])->first();
                if($dprod){
                    $product = Product::where('id',$dprod->id)->first();
                    $product->name = $collection['product_name'];
                    $product->item_code = $collection['item_code'];
                    $product->part_no = $collection['item_code'];
                    $product->serial_no = $collection['serial_no'];
                    $product->slug = Str::slug($collection['product_name'], '-') . '-' . Str::random(6);
                    $product->category_ids = json_encode($ccs,true);
                    $product->brand_id = $collection['brand'];
                    $product->unit = $collection['unit'];
                    $product->tax = $collection['tax'];
                    $product->unit_price = $collection['unit_price'];
                    $product->current_stock = $collection['current_stock'];
                    $product->details = $collection['details'];
                    // $product->images = ImageManager::upload('product/', 'png', $collection['product_image']);
                    // $product->thumbnail = ImageManager::upload('product/thumbnail/', 'png', $request->file('thumbnail'));

                    $product->images = json_encode(['def.png']);
                    $product->thumbnail = 'def.png';
                    $product->status = 0;
                    $product->colors =json_encode([]);
                    $product->attributes = json_encode([]);
                    $product->choice_options = json_encode([]);
                    $product->variation = json_encode([]);
                    $product->featured_status = 1;
                    $product->added_by = 'Seller';
                    $product->user_id = auth('seller')->id();
                   $product->save();
                }else{
                    $product = new Product;
                    $product->name = $collection['product_name'];
                    $product->item_code = $collection['item_code'];
                    $product->part_no = $collection['item_code'];
                    $product->serial_no = $collection['serial_no'];
                    $product->slug = Str::slug($collection['product_name'], '-') . '-' . Str::random(6);
                    $product->category_ids = json_encode($ccs,true);
                    $product->brand_id = $collection['brand'];
                    $product->unit = $collection['unit'];
                    $product->tax = $collection['tax'];
                    $product->unit_price = $collection['unit_price'];
                    $product->current_stock = $collection['current_stock'];
                    $product->details = $collection['details'];
                    // $product->images = ImageManager::upload('product/', 'png', $collection['product_image']);
                    // $product->thumbnail = ImageManager::upload('product/thumbnail/', 'png', $request->file('thumbnail'));

                    $product->images = json_encode(['def.png']);
                    $product->thumbnail = 'def.png';
                    $product->status = 0;
                    $product->colors =json_encode([]);
                    $product->attributes = json_encode([]);
                    $product->choice_options = json_encode([]);
                    $product->variation = json_encode([]);
                    $product->featured_status = 1;
                    $product->added_by = 'Seller';
                    $product->user_id = auth('seller')->id();
                    $product->save();
                }
                $d = DB::table('balance_sheet')->where('product_id',$product->id)->orderBy('created_at','desc')->first();
                if(!$d){
                    $opb_sheet = array(
                        'product_id' => $product->id,
                        'opening_balance' => $collection['current_stock'],
                        'in_qty' => $collection['current_stock'],
                        'purchase_price' => $collection['unit_price'],
                        'in_qty_ref' => 'Stock Update',
                        'out_qty' => 0,
                        'out_qty_ref' => '',
                        'balance_qty' => $collection['current_stock'],
                        'date' => $request->date,
                    );
                    DB::table('balance_sheet')->insert($opb_sheet);
                }else{
                    $opb_sheet = array(
                        'product_id' => $product->id,
                        'opening_balance' => $d->opening_balance,
                        'in_qty' => $collection['current_stock'],
                        'purchase_price' => $collection['unit_price'],
                        'in_qty_ref' => 'Stock Update',
                        'out_qty' => $d->out_qty,
                        'out_qty_ref' => $d->out_qty_ref,
                        'balance_qty' => ($d->balance_qty+$collection['current_stock']),
                        'date' => $d->date,
                    );
                    DB::table('balance_sheet')->insert($opb_sheet);
                }
            }
        }
        Toastr::success(count($collections) . ' - Products imported successfully!');
        return back();
    }



    public function bulk_export_data()
    {
       $product = Product::where(['added_by'=>'seller','user_id'=>auth('seller')->id()])->with('variants')->with('brand')->with('productDiscount')->with('units')->get();
        $prod_sheet = array();
        $variant_sheet = array();
        $balance_sheet = array();
        if($product){
            foreach ($product as $key => $value) {
                $balance_s = DB::table('balance_sheet')->where('product_id',$value->id)->get();
                $cat = json_decode($value->category_ids,TRUE);
                $categ = Category::where('id',$cat)->get();
                $c = array();
                $addca = '';
                if($categ){
                    foreach ($categ as $ksd => $car) {
                        array_push($c,$car->name); 
                    }
                    $addca = implode(' | ', $c);
                }
                if($value->variant_product == 1){ $var = 'Yes'; $unit_price = 'Check Vairants'; $stock = 'Check Variants'; }else{ $var = 'No'; $unit_price = $value->unit_price; $stock = $value->current_stock; }
              
                if(!empty($value->brand)){
                    $bran = $value->brand->name;
                }else{
                    $bran = '';
                }
                $uni = Unit::where('id',$value->unit)->first();
                $prod_sheet[] = array(
                    'id' => $value->id,
                    'name' => $value->name,
                    'system_item_code' => $value->system_item_code,
                    'item_code' => $value->item_code,
                    'part_no' => $value->part_no,
                    'categories' => $addca,
                    'brand' => $bran,
                    'unit' => $uni->name,
                    'thumbnail' => url('thumbnail/'.$value->thumbnail),
                    'colors' => $value->colors,
                    'variants' => $var,
                    'unit_price' => $unit_price,
                    'current_stock' => $stock,
                    'created_at' => date('d M, y H:i',strtotime($value->created_at)),
                );
                if(!empty($value->variants)){
                    foreach ($value->variants as $k => $vdd) {
                        $variant_sheet[] = array(
                            'id' => $vdd->id,
                            'product' => $value->name,
                            'variant' => str_replace('-',',',$vdd->sku),
                            'quantity' => $vdd->qty,
                            'price' => $vdd->price, 
                        );
                    }
                }
                if(!empty($balance_s)){
                    foreach ($balance_s as $b => $blnc) {
                        $balance_sheet[] = array(
                            'Id' => $blnc->id,
                            'Product' => $value->name,
                            'Opening Balance' => $blnc->opening_balance,
                            'In Qty' => $blnc->in_qty,
                            'Purchase Price' => $blnc->purchase_price,
                            'In Reference' => $blnc->in_qty_ref,
                            'Out Qty' => $blnc->out_qty,
                            'Out Qty Reference' => $blnc->out_qty_ref,
                            'Balance Qty' => $blnc->balance_qty,
                            'Date' => date('d/M/y',strtotime($blnc->created_at)), 
                        );
                    }
                }
            }
        }
        $sheets = new SheetCollection([
            'Products Data' => $prod_sheet,
            'Products Variants' => $variant_sheet,
            'Product Balance Sheet' => $balance_sheet,
        ]);
        return (new FastExcel($sheets))->download('Products.xlsx');
    }

     //new code 13_05_22

    public function brand_export()
    {
        $brands = Brand::where(['status' => 1])->get();
        //export from product
        $brandsarray = [];
        foreach ($brands as $item) {
            $brandsarray[] = [
                 'id' => $item->id,
                'name' => $item->name
            ];
        }
        return (new FastExcel($brandsarray))->download('brands.xlsx');
    }

    public function seller_guide()
    {
        $items = Category::where('parent_id',0)->where('selected_cat','LIKE','%'.auth('seller')->id().'%')->get();
        $brands = Brand::where('selected_seller','LIKE','%'.auth('seller')->id().'%')->get();
        $units = Unit::where('selected_seller','LIKE','%'.auth('seller')->id().'%')->get();
        return view('seller-views.product.csv_instruction', compact('items','brands','units'));
    }

    public function category_export()
    {
        $Category = Category::where(['position' => 0])->get();
        //export from product
        $Categoryarray = [];
        foreach ($Category as $item) {
            $Categoryarray[] = [
                'id' => $item->id,
                'name' => $item->name,
                'slug' => $item->slug
            ];
        }
        return (new FastExcel($Categoryarray))->download('Category.xlsx');
    }

    public function sub_category_export()
    {
        $SubCategory = Category::where(['position' => 1])->get();
        //export from product
        $SubCategoryarray = [];
        foreach ($SubCategory as $item) {
            $SubCategoryarray[] = [
                'id' => $item->id,
                'name' => $item->name,
                'slug' => $item->slug
            ];
        }
        return (new FastExcel($SubCategoryarray))->download('Subcategory.xlsx');
    }

    public function sub_sub_category_export()
    {
        $SubSubCategory = Category::where(['position' => 2])->get();
        //export from product
        $SubSubCategoryarray = [];
        foreach ($SubSubCategory as $item) {
            $SubSubCategoryarray[] = [
                'id' => $item->id,
                'name' => $item->name,
                'slug' => $item->slug
            ];
        }
        return (new FastExcel($SubSubCategoryarray))->download('Subsubcategory.xlsx');
    }
}
