<?php

namespace App\Http\Controllers\Seller;

use App\CPU\Helpers;
use App\CPU\ImageManager;
use App\Http\Controllers\Controller;
use App\Model\Admin;
use App\Model\Unit;
use App\Model\Unitallowe;
use Brian2694\Toastr\Facades\Toastr;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Model\Translation;


class UnitController extends Controller
{
    public function store(Request $request)
    {
        foreach($request->lang as $index=>$key)
        {
            if($request->name[$index] && $key != 'en')
            {
                Translation::updateOrInsert(
                    ['translationable_type'  => 'App\Model\Unit',
                        'translationable_id'    => $unit->id,
                        'locale'                => $key,
                        'key'                   => 'name'],
                    ['value'                 => $request->name[$index]]
                );
            }
        }

        $unit = new Unit;
        $unit->name = $request->name;
        $unit->symbol = $request->symbol;
        $unit->status = 1;
        $r = $unit->save();

        $Unitallowe = new Unitallowe;
        $Unitallowe->seller_id = auth('seller')->id();
        $Unitallowe->unit_id = $unit->id;
        $s = $Unitallowe->save();

        if($r && $s)
        {
            $allowedUnitIds = Unitallowe::where(['seller_id' => auth('seller')->id(),'delete_status' => 0])->pluck('unit_id');
            if(!empty($allowedUnitIds)){
                $allowedUnitIds = $allowedUnitIds->toArray();
            }else{
                $allowedUnitIds = array();
            }
            $allUnit = unit::get();
            $i=0;
            $selectedUnit = array();
            foreach ($allUnit as $key => $item) {
                if (in_array($item->id, $allowedUnitIds))
                {
                    $selectedUnit[$i] = $item;
                    $i++;
                }
            }
            $data = array('status' => 1,'unit' => $selectedUnit, 'allowedUnitIds' => $allowedUnitIds,'allUnit' => $allUnit);
            return response()->json($data);  
        }
    }

}
