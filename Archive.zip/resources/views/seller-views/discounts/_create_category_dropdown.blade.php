@php
$value = '--';
for ($i=0; $i < count($child_category->childes); $i++){
$value .= '--';
}
@endphp
<option value="{{ $child_category->id }}" pid="{{ $child_category->parent_id }}">{{ $value." ".$child_category->name }}</option>
@if ($child_category->categories)
@foreach ($child_category->categories as $childCategory)
@include('categories.child_category', ['child_category' => $childCategory])
@endforeach
@endif
