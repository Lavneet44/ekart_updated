
@foreach($variant as $key => $value)
    <table  class="table table-bordered" style="width: 100%">
        <thead style="background: #eee;">
            <tr>
                <th>
                    {{ str_replace('-', ' ', $value->sku) }}
                </th>
                <th>
                    Selling Price : {{ $value->price }}
                </th>
                @if($key == 0)
                <th>
                    <label class="switch">
                        <input type="checkbox" class="apply_all" id="apply_to_all" @if($dis->apply_for_all == 1){{ "checked" }}@endif name="apply_for_all" value="1" data-key="{{$key}}">
                        <span class="slider round"></span>
                    </label>
                </th>
                @endif
            </tr>
        </thead>
        @php
            $product = \App\Model\Product::where(['user_id' => auth('seller')->id(),'added_by' => 'seller'])->get();
            $discounted_variations = \App\Model\ProductDiscount::where('discount_master_id',$dis->id)->where('product_id',$dis->product_id)->where('variant_id',$value->id)->first();
        @endphp
        <tbody>
            <tr class="apply_all_checked_{{$key}} checked_apply" data-key="{{$key}}" data-active="{{$dis->apply_for_all}}">
                <td colspan="@if($key == 0){{'3'}}@else{{'2'}}@endif">
                    <div class="row">
                         <div class="col-md-3">
                            <div class="form-group">
                                <label>Select Type</label>
                                <select class="form-control" name="type[]">
                                    <option @if($discounted_variations->type == 'Each'){{ 'selected' }} @endif>Each</option>
                                    <option @if($discounted_variations->type == 'Open'){{ 'selected' }} @endif>Open</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <label>Buy Qty.</label>
                            <input type="hidden" id="qty_{{$key}}" name="qty[]" value="{{$value->qty}}">
                            <input type="hidden" name="base_price[]" id="base_price_{{$key}}" value="{{$value->price}}">
                            <input type="number" name="buyquantity[]" max="1000000" value="{{ $discounted_variations->buy }}" step="1" placeholder="Quantity" class="form-control common">
                        </div>
                        <div class="col-md-3">
                            <label>Discount Amount</label>
                            <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="basic-addon1">BHD</span>
                                </div>
                                <input type="number" id="discount_amount_{{$key}}" name="discount[]" data-key="{{$key}}" value="{{ $discounted_variations->discount }}" placeholder="Discounted Amount" class="form-control common discountedVal">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <label>Discount Percentage</label>
                            <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="basic-addon1">%</span>
                                </div>
                                <input type="double" id="discount_percent_{{$key}}" name="discount_percent[]" data-key="{{$key}}" value="{{ $discounted_variations->discount_percent }}" placeholder="Discounted Percentage" class="form-control common discountedPercentage" >
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-3">
                            <label>Start Date</label>
                            <input type="date" name="startdate[]" value="{{ date('Y-m-d', strtotime($discounted_variations->start_date)) }}" class="form-control startdate common"  placeholder="Start Date">
                        </div>
                        <div class="col-md-3">
                            <label>Start time</label>
                            <input type="time" name="starttime[]"  value="{{ date('H:i',strtotime($discounted_variations->start_time)) }}" class="form-control starttime common" placeholder="Start Time">
                        </div>
                        <div class="col-md-3">
                            <label>End Date</label>
                            <input type="date" name="enddate[]" data-val="{{ date('Y-m-d', strtotime($discounted_variations->end_date)) }}" value="{{ date('Y-m-d', strtotime($discounted_variations->end_date)) }}" class="form-control enddate common" placeholder="End Date">
                        </div>
                        <div class="col-md-3">
                            <label>End time</label>
                            <input type="time" name="endtime[]"  value="{{ date('H:i',strtotime($discounted_variations->end_time)) }}" class="form-control endtime common" placeholder="End time">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div id="subsitute_box_{{$key}}">
                                @php
                                    $explo = explode(',',$discounted_variations->free_qty);
                                    $im = explode(',',$discounted_variations->Item);
                                @endphp
                                @if(!empty($explo))
                                @foreach($explo as $ll => $ex)
                                @if($ll == 0)
                                <div class="subsitute subsitute_box{{$ll}}" style="padding:0px;">
                                    <div class="row mt-2">
                                        <div class="col-md-5">
                                            <label>Free Qty</label>
                                            <input type="text" name="freequantity[{{$key}}][]" value="{{$ex}}" class="form-control"  placeholder="Free Quantity">
                                        </div>
                                        <div class="col-md-5">
                                            <label>Select Item</label>
                                            <select class="form-control" name="item[{{$key}}][]">
                                                <option value="">None</option>
                                                @foreach($product as $sp)
                                                <option @if($im[$ll] == $sp->id){{'selected'}} @endif value="{{ $sp->id }}">{{ $sp->name }}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                        <div class="col-md-2" style="padding-left:0px;">
                                            <button type="button" style="padding:10px 15px;margin-top: 28px;" class="btn btn-primary add_subsitute"  data-key="{{$key}}"><i class="tio-add-circle"></i> Add</button>
                                        </div>
                                    </div>
                                </div>
                                @else
                                <div class="subsitute subsitute_box{{$ll}}" style="padding:0px;">
                                    <div class="row mt-2">
                                        <div class="col-md-5">
                                            <label>Free Qty</label>
                                            <input type="text" name="freequantity[{{$key}}][]" value="{{$ex}}" class="form-control"  placeholder="Free Quantity">
                                        </div>
                                        <div class="col-md-5">
                                            <label>Select Item</label>
                                            <select class="form-control" name="item[{{$key}}][]">
                                                <option value="">None</option>
                                                @foreach($product as $sp)
                                                <option @if($im[$ll] == $sp->id){{'selected'}} @endif value="{{ $sp->id }}">{{ $sp->name }}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                        <div class="col-md-2" style="padding-left:0px;">
                                             <a href="javascript:void(0)" data-item="{{$ll}}" style="padding:10px 15px;margin-top:28px;" class="btn btn-danger remove_subsitute" data-key="{{$key}}"><i class="tio-remove-from-trash"></i> remove</a>
                                        </div>
                                    </div>
                                </div>
                                @endif
                                @endforeach
                                @else
                                <div class="subsitute subsitute_box" style="padding:0px;">
                                    <div class="row mt-2">
                                        <div class="col-md-5">
                                            <label>Free Qty</label>
                                            <input type="text" name="freequantity[{{$key}}][]" class="form-control"  placeholder="Free Quantity">
                                        </div>
                                        <div class="col-md-5">
                                            <label>Select Item</label>
                                            <select class="form-control" name="item[{{$key}}][]">
                                                <option value="">None</option>
                                                @foreach($product as $sp)
                                                <option value="{{ $sp->id }}">{{ $sp->name }}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                        <div class="col-md-2" style="padding-left:0px;">
                                            <button type="button" style="padding:10px 15px;margin-top: 28px;"  class="btn btn-primary add_subsitute"  data-key="{{$key}}"><i class="tio-add-circle"></i> Add</button>
                                        </div>
                                    </div>
                                </div>
                                @endif
                            </div>
                        </div>
                    </div>
                </td>
            </tr>
        </tbody>
    </table>
    
@endforeach
<script type="text/javascript">

    $('.checked_apply').each(function(){
        var active = $(this).attr('data-active');
        var key = $(this).attr('data-key');
        if(active == 1 && key != 0){
            $(this).hide();
        }
    });

    $('#apply_to_all').on('change',function(){
        if($(this).is(':checked')){
            $('.checked_apply').each(function(){
                var key = $(this).attr('data-key');
                if(key != 0){
                    $('.apply_all_checked_'+key).hide();
                }
            });
        }else{
            $('.checked_apply').show();
        }
    });

    $('.apply_all').on('change',function(){
        var index = $(this).attr('data-key');
        if ($(this).is(':checked')) {
            if(index != 0){
                $('.apply_all_checked_'+index).hide();
            }
        }else{
            $('.apply_all_checked_'+index).show();
        }
    });
    $('.discountedVal').on('keyup',function(){
        var val = $(this).val();
        var key = $(this).attr('data-key');
        var base_price = $('#base_price_'+key).val();
        var percent = (parseInt(val) / parseInt(base_price)) * 100;
        $('#discount_percent_'+key).val(percent);

    });
    $('.discountedPercentage').on('keyup',function(){
        var val = $(this).val();
        var key = $(this).attr('data-key');
        var base_price = $('#base_price_'+key).val();
        var percent = (parseInt(val) / 100) * parseInt(base_price);
        $('#discount_amount_'+key).val(percent);
    });

    $('.add_subsitute').on('click',function(){
        var key = $(this).attr('data-key');
        console.log(key);
        var count = $("#subsitute_box_"+key+" .subsitute").length;
        var subsitute = '<div class="subsitute subsitute_box'+count+'" style="margin-top:10px;padding:0px;">\
                            <div class="row mt-2">\
                                <div class="col-sm-5">\
                                    <label>Free Qty</label>\
                                    <input type="text" name="freequantity['+key+'][]" class="form-control"  placeholder="Free Quantity">\
                                </div>\
                                <div class="col-sm-5">\
                                    <label>Select Item</label>\
                                    <select class="form-control" name="item['+key+'][]">\
                                        <option value="">None</option>'+
                                        '@foreach($product as $pro)'+
                                        '<option value="{{ $pro->id }}">{{ $pro->name }}</option>'+
                                        '@endforeach'
                                    +'</select>\
                                </div>\
                                <div class="col-md-1" style="padding-left:0px;">\
                                    <a href="javascript:void(0)" data-item="'+count+'" style="padding:10px 15px;margin-top:28px;" onclick="remove_subsitute('+count+','+key+')" class="btn btn-danger remove_subsitute" data-key="'+key+'"><i class="tio-remove-from-trash"></i> remove</a>\
                                </div>\
                            </div>\
                        </div>';

        $("#subsitute_box_"+key).append(subsitute);
    });

    function remove_subsitute(count,key)
    {
        $("#subsitute_box_"+key+" .subsitute_box"+count).remove();
    }

    $('.remove_subsitute').on('click',function(){
        var key = $(this).attr('data-key');
        var itm = $(this).attr('data-item');
        $("#subsitute_box_"+key+" .subsitute_box"+itm).remove();
    });
</script>

