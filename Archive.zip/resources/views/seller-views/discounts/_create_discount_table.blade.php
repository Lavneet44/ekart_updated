@foreach($variant as $key => $value)
    <table  class="table table-bordered" style="width: 100%">
        <thead style="background: #eee;">
            <tr>
                <th>
                    {{ str_replace('-', ' ', $value->sku) }}
                </th>
                <th>
                    Selling Price : {{ $value->price }}
                </th>
                @if($key == 0)
                <th>
                    <label class="switch">
                        <input type="checkbox" class="apply_all" id="apply_to_all" name="apply_for_all" value="1" data-key="{{$key}}">
                        <span class="slider round"></span>
                    </label>
                </th>
                @endif
            </tr>
        </thead>
        <tbody>
            <tr class="apply_all_checked_{{$key}} checked_apply" data-key="{{$key}}">
                <td colspan="@if($key == 0){{'3'}}@else{{'2'}}@endif">
                    <div class="row">
                         <div class="col-md-3">
                            <div class="form-group">
                                <label>Select Type</label>
                                <select class="form-control" name="type[]">
                                    <option>Each</option>
                                    <option>Open</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <label>Buy Qty.</label>
                            <input type="hidden" name="qty[]" id="qty_{{$key}}" value="{{$value->qty}}">
                            <input type="hidden" name="base_price[]" id="base_price_{{$key}}" value="{{$value->price}}">
                            <input type="number" name="buyquantity[]" max="1000000" step="1" placeholder="Quantity" class="form-control common">
                        </div>
                        <div class="col-md-3">
                            <label>Discount Amount</label>
                            <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="basic-addon1">BHD</span>
                                </div>
                                <input type="number" id="discount_amount_{{$key}}" data-key="{{$key}}" name="discount[]" placeholder="Discounted Amount" class="form-control common discountedVal">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <label>Discount Percentage</label>
                            <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="basic-addon1">%</span>
                                </div>
                                <input type="double" id="discount_percent_{{$key}}" data-key="{{$key}}" name="discount_percent[]" placeholder="Discounted Percentage" class="form-control common discountedPercentage" >
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-3">
                            <label>Start Date</label>
                            <input type="date" name="startdate[]" class="form-control startdate common"  placeholder="Start Date">
                        </div>
                        <div class="col-md-3">
                            <label>Start time</label>
                            <input type="time" name="starttime[]" class="form-control starttime common" placeholder="Start Time">
                        </div>
                        <div class="col-md-3">
                            <label>End Date</label>
                            <input type="date" name="enddate[]" class="form-control enddate common" placeholder="End Date">
                        </div>
                        <div class="col-md-3">
                            <label>End time</label>
                            <input type="time" name="endtime[]" class="form-control endtime common" placeholder="End time">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div id="subsitute_box_{{$key}}">
                                <div class="subsitute subsitute_box" style="padding:0px;">
                                    <div class="row mt-2">
                                        <div class="col-md-5">
                                            <label>Free Qty</label>
                                            <input type="text" name="freequantity[{{$key}}][]" class="form-control"  placeholder="Free Quantity">
                                        </div>
                                        <div class="col-md-5">
                                            <label>Select Item</label>
                                            <select class="form-control" name="item[{{$key}}][]">
                                                <option value="">None</option>
                                                @foreach($product as $sp)
                                                <option value="{{ $sp->id }}">{{ $sp->name }}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                        <div class="col-md-2" style="padding-left:0px;">
                                            <button type="button" style="padding:10px 15px;margin-top: 28px;" class="btn btn-primary add_subsitute"  data-key="{{$key}}"><i class="tio-add-circle"></i> Add</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </td>
            </tr>
        </tbody>
    </table>
    
@endforeach
<script type="text/javascript">
     $('#apply_to_all').on('change',function(){
        console.log('ok');
        if($(this).is(':checked')){
            $('.checked_apply').each(function(){
                var key = $(this).attr('data-key');
                if(key != 0){
                    $('.apply_all_checked_'+key).hide();
                }
            });
        }else{
            $('.checked_apply').show();
        }
    });

    $('.discountedVal').on('keyup',function(){
        var val = $(this).val();
        var key = $(this).attr('data-key');
        var base_price = $('#base_price_'+key).val();

        var percent = (parseInt(val) / parseInt(base_price)) * 100;
        console.log(percent);
        $('#discount_percent_'+key).val(percent);

    });
    $('.discountedPercentage').on('keyup',function(){
        var val = $(this).val();
        var key = $(this).attr('data-key');
        var base_price = $('#base_price_'+key).val();
        var percent = (parseInt(val) / 100) * parseInt(base_price);
        console.log(percent);   
        $('#discount_amount_'+key).val(percent);
    });


    $('body').on('click','.apply_all',function(){
        var index = $(this).attr('data-key');
        if (!$(this).is(':checked')) {
            if(index != 0){
                $('.apply_all_checked_'+index).hide();
            }
        }else{
            $('.apply_all_checked_'+index).show();
        }
    });


    $('.add_subsitute').on('click',function(){
        var key = $(this).attr('data-key');
        console.log(key);
        var count = $("#subsitute_box_"+key+" .subsitute").length;
        var subsitute = '<div class="subsitute warning subsitute_box'+count+'" style="margin-top:10px;padding:0px;">\
                            <div class="row mt-2">\
                                <div class="col-sm-5">\
                                    <label>Free Qty</label>\
                                    <input type="text" name="freequantity['+key+'][]" class="form-control"  placeholder="Free Quantity">\
                                </div>\
                                <div class="col-sm-5">\
                                    <label>Select Item</label>\
                                    <select class="form-control" name="item['+key+'][]">\
                                        <option value="">None</option>'+
                                        '@foreach($product as $pro)'+
                                        '<option value="{{ $pro->id }}">{{ $pro->name }}</option>'+
                                        '@endforeach'
                                    +'</select>\
                                </div>\
                                <div class="col-md-1" style="padding-left:0px;">\
                                    <a href="javascript:void(0)" style="padding:10px 15px;margin-top:28px;" class="btn btn-danger remove_subsitute" data-key="'+key+'"><i class="tio-remove-from-trash"></i> remove</a>\
                                </div>\
                            </div>\
                        </div>';

        $("#subsitute_box_"+key).append(subsitute);
    });


    $('.remove_subsitute').on('click',function(){
        var key = $(this).attr('data-key');
        $("#subsitute_box_"+key+" .subsitute_box"+no).remove();
    });
</script>

