@extends('layouts.back-end.app-seller')

@section('title', \App\CPU\translate('Discount List'))

@push('css_or_js')

@endpush

@section('content')
    <div class="content container-fluid">

        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-2">
            <h1 class="h3 mb-0 text-black-50" style="width:100%;">{{\App\CPU\translate('Discounts')}}
            <span class="float-right">
                <a href="{{ route('seller.discount.discount-create') }}"  class="btn btn-primary">Add Discount</a>
            </span>
            </h1>
        </div>

        <div class="row" style="margin-top: 20px">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h1 style="width: 100%;">Discounts</h1>
                        
                        
                        <!-- End Search -->
                    </div>
                    <div class="card-body" style="padding: 0">
                        <div class="table-responsive">
                            <table style="text-align: {{Session::get('direction') === "rtl" ? 'right' : 'left'}};"
                                class="table table-bordered table-thead-bordered table-nowrap table-align-middle card-table">
                                <thead class="thead-light">
                                <tr>
                                    <th scope="col" style="width: 100px">
                                    {{ \App\CPU\translate('#')}}
                                    </th>
                                    <th scope="col">{{ \App\CPU\translate('Label')}}</th>
                                    <th scope="col">{{ \App\CPU\translate('Date of Creation')}}</th>
                                   
                                    <th scope="col">Active</th>
                                    <th scope="col">Hide/Unhide</th>
                                    <th scope="col" style="width: 100px" class="text-center">
                                        {{ \App\CPU\translate('action')}}
                                    </th>
                                </tr>
                                </thead>
                                <tbody>
                                    @foreach($discount as $key => $value)
                                    <tr>
                                        <td>{{ $key+1 }}</td>
                                        <td>{{ $value->discount_label }}</td>
                                        <td>{{ date('Y-m-d H:i:s',strtotime($value->created_at)) }}</td>
                                        
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox" data-id="{{ $value->id }}" @if($value->status == 1) {{ "checked" }} @endif class="change_status" name="status">
                                                <span class="slider round"></span>
                                            </label>
                                        </td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox" data-id="{{ $value->id }}" @if($value->is_hide == 1) {{ "checked" }} @endif class="change_hidden" name="is_hide">
                                                <span class="slider round"></span>
                                            </label>
                                        </td>
                                        <td>
                                            <div class="dropdown">
                                                <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i class="tio-settings-vs"></i>
                                                </button>
                                                <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
                                                    <a href="{{ route('seller.discount.edit-discount',['id'=> $value->id]) }}" class="dropdown-item">Edit</a>
                                                    <a href="javascript:void(0)" data-id="{{ $value->id }}" class="dropdown-item delete_discount">Delete</a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>

                        </div>
                    </div>
                    <div class="card-footer">
                        
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
@endsection

@push('script')
<script>
    $(document).ready(function(){
        $('#product_id').on('change',function(){
            var id = $(this).val();
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                }
            });
            $.ajax({
                url: "{{ route('seller.discount.get-variant') }}",
                method: "POST",
                data: "id="+id,
                success:function(response){
                    console.log(response);
                    $('#variant_id').append(response);
                },
            });
        });
        $('#variant_id').on('change',function(){
            var price = $(this).find(':selected').attr('data-val');
            var qty = $(this).find(':selected').attr('data-qty');
            $('#price_add').val(price);
            $('#add_qty').val(qty);
        });

        $('.change_status').on('change',function(){
            var id = $(this).attr('data-id');
            if ($(this).is(':checked')){
                var status = 1;
            }else{
                var status = 0;
            }
             $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                }
            });
            $.ajax({
                url: "{{ route('seller.discount.update-status') }}",
                method: "POST",
                data: "id="+id+"&status="+status,
                success:function(response){
                    location.reload();
                },
            });
        });

        $('.change_hidden').on('change',function(){
            var id = $(this).attr('data-id');
            if ($(this).is(':checked')){
                var status = 1;
            }else{
                var status = 0;
            }
             $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                }
            });
            $.ajax({
                url: "{{ route('seller.discount.update-hidden') }}",
                method: "POST",
                data: "id="+id+"&is_hide="+status,
                success:function(response){
                    location.reload();
                },
            });
        });

        $('.delete_discount').on('click',function(){
            var id = $(this).attr('data-id');
            var ok = confirm('Are you sure to delete');
            if(ok){
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                    }
                });
                $.ajax({
                    url: "{{ route('seller.discount.delete-discount') }}",
                    method: "POST",
                    data: "id="+id,
                    success:function(response){
                        location.reload();
                    },
                });
            }
        });

        $('.discountedVal').on('keyup',function(){
            var val = $(this).val();
            var base = $('#price_add').val();
            var percent = (parseInt(val) / parseInt(base)) * 100;
            $('#discount_percent').val(percent);

        });
        $('.discountedPercentage').on('keyup',function(){
            var val = $(this).val();
            var base = $('#price_add').val();
            var percent = (parseInt(val) / 100) * parseInt(base);
            $('#discount_amount').val(percent);

        });


        $("#add_subsitute").on("click",function(){
            var count = $(".subsitute").length;
            var subsitute = '<div class="subsitute warning subsitute_box'+count+'" style="margin-top:10px;padding:0px;">\
                                <div class="row mt-2">\
                                    <div class="col-sm-5">\
                                        <label>Free Qty</label>\
                                        <input type="text" name="freequantity[]" class="form-control"  placeholder="Free Quantity">\
                                    </div>\
                                    <div class="col-sm-5">\
                                        <label>Select Item</label>\
                                        <select class="form-control js-example-responsive" name="item[]">\
                                            <option value="">None</option>'+
                                            '@foreach($product as $pro)'+
                                            '<option value="{{ $pro->id }}">{{ $pro->name }}</option>'+
                                            '@endforeach'
                                        +'</select>\
                                    </div>\
                                    <div class="col-md-1" style="padding-left:0px;">\
                                        <a href="javascript:void(0)" style="padding:10px 15px;margin-top:28px;" onClick="remove_subsitute('+count+')" class="btn btn-danger remove_subsitute"><i class="tio-remove-from-trash"></i> remove</a>\
                                    </div>\
                                </div>\
                            </div>';

            $("#subsitute_box").append(subsitute);
        });
    });

    function remove_subsitute(no){
        $(".subsitute_box"+no).remove();
    };

    
</script>
@endpush