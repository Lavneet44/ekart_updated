@extends('layouts.back-end.app-seller')

@section('title', \App\CPU\translate('Discount List'))

@push('css_or_js')

@endpush

@section('content')
    <div class="content container-fluid">

        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-2">
            <h1 class="h3 mb-0 text-black-50" style="width:100%;">{{\App\CPU\translate('Discounts')}}
            <span class="float-right">
                <a href="{{ route('seller.discount.index') }}" class="btn btn-primary">Discounts</a>
            </span>
            </h1>
        </div>

        <div class="row" style="margin-top: 20px">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h1 style="width: 100%;">Add Discounts</h1>
                    </div>
                    <div class="card-body" style="padding: 0">
                       <form method="post" action="{{ route('seller.discount.store') }}" id="addDiscountForm" class="p-4">
                        @csrf
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Label</label>
                                    <input type="text" name="discount_label" class="form-control" placeholder="Discount Label">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>Select Categories</label>
                                    <select class="form-control js-example-responsive" id="category-selection" name="category[]" multiple>
                                        
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>Select Brands</label>
                                    <select name="brand" id="brand_selection" class="form-control">
                                        <option value="">Select</option>
                                        @foreach($brands as $bp)
                                        <option value="{{ $bp->id }}">{{ $bp->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>Select Product</label>
                                    <select name="product_id" id="product_id" class="form-control">
                                        <option value="">Select</option>
                                        @foreach($product as $lp)
                                        <option value="{{ $lp->id }}">{{ $lp->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>Select Variant</label>
                                    <!-- <input type="hidden" name="price" id="price_add"> -->
                                    <!-- <input type="hidden" name="qty" id="add_qty"> -->
                                    <select name="variant_id[]" id="variant_id" class="form-control js-example-responsive" multiple>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-12" id="variations_data"></div>
                        </div>
                        <div class="col-md-12 mt-4">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@push('script')
<script>


    $(document).ready(function(){
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
            }
        });
        $.ajax({
            url: "{{ route('seller.discount.selection.cat') }}",
            method: "post",
            data: "id=1",
            success:function(response){
                $('#category-selection').append(response);
            },
        });
    });

    $(document).ready(function(){

        $('#category-selection').on('change',function(){
            var val = $(this).val();
            var brand = $('#brand_selection').val();
            $('#variant_id').val('');
            $('#variant_id').html('');
            $('#variations_data').html('');
            getProductData(val,brand);
        });

        $('#brand_selection').on('change',function(){
            var val = $(this).val();
            $('#variant_id').val('');
            $('#variant_id').html('');
            $('#variations_data').html('');
            var cat = $('#category-selection').val();
            getProductData(cat,val);
        });

        function getProductData(cat,brand)
        {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                }
            });
            $.ajax({
                url: "{{ route('seller.discount.products.selection') }}",
                method: "POST",
                data: "category="+cat+"&brand="+brand,
                success:function(response){
                    console.log(response);
                    $('#product_id').html(response);
                },
            });
        }

        $('#product_id').on('change',function(){
            var id = $(this).val();
            $('#variant_id').val('');
            $('#variant_id').html('');
            $('#variations_data').html('');
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                }
            });
            $.ajax({
                url: "{{ route('seller.discount.get-variant') }}",
                method: "POST",
                data: "id="+id,
                success:function(response){
                    $('#variant_id').html(response);
                },
            });
        });


        $('#variant_id').on('change',function(){
            var id = $(this).val();
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                }
            });
            $.ajax({
                url: "{{ route('seller.discount.variations.products') }}",
                method: "POST",
                data: "id="+id,
                success:function(response){
                    $('#variations_data').html(response.view);
                },
            });
        });

        $('.change_status').on('change',function(){
            var id = $(this).attr('data-id');
            if ($(this).is(':checked')){
                var status = 1;
            }else{
                var status = 0;
            }
             $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                }
            });
            $.ajax({
                url: "{{ route('seller.discount.update-status') }}",
                method: "POST",
                data: "id="+id+"&status="+status,
                success:function(response){
                    location.reload();
                },
            });
        });
        


        $('.delete_discount').on('click',function(){
            var id = $(this).attr('data-id');
            var ok = confirm('Are you sure to delete');
            if(ok){
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                    }
                });
                $.ajax({
                    url: "{{ route('seller.discount.delete-discount') }}",
                    method: "POST",
                    data: "id="+id,
                    success:function(response){
                        location.reload();
                    },
                });
            }
        });

        $('.discountedVal').on('keyup',function(){
            var val = $(this).val();
            var base = $('#price_add').val();
            var percent = (parseInt(val) / parseInt(base)) * 100;
            $('#discount_percent').val(percent);

        });
        $('.discountedPercentage').on('keyup',function(){
            var val = $(this).val();
            var base = $('#price_add').val();
            var percent = (parseInt(val) / 100) * parseInt(base);
            $('#discount_amount').val(percent);

        });

    });

    // function remove_subsitute(no){
    //     $(".subsitute_box"+no).remove();
    // };
    $(".js-example-responsive").select2({
    });


    
</script>
@endpush