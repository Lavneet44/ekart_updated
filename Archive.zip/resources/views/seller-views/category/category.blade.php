@extends('layouts.back-end.app-seller')

@section('title', \App\CPU\translate('Categories'))

@push('css_or_js')
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script type="text/javascript">
       function deleteCategory(id){
        var id = id;
        Swal.fire({
                title: '{{\App\CPU\translate('Are you sure')}}?',
                text: '',
                type: 'warning',
                showCancelButton: true,
                cancelButtonColor: 'default',
                confirmButtonColor: '#377dff',
                cancelButtonText: 'No',
                confirmButtonText: 'Yes',
                reverseButtons: true
            }).then((result) => {
                window.location.href="{{ url('seller/product/delete-catgory')}}/"+id;
            })
       }
    </script>
@endpush

@section('content')
    <div class="content container-fluid">
        <nav class="row" aria-label="breadcrumb">
            <div class="col-md-12">
                <ol class="breadcrumb float-left">
                    <li class="breadcrumb-item"><a href="{{route('seller.dashboard.index')}}">{{\App\CPU\translate('Dashboard')}}</a>
                    </li>
                    <li class="breadcrumb-item"><a href="{{route('seller.product.categories')}}">{{\App\CPU\translate('Categories')}}</a>
                    </li>
                </ol>
                <a href="{{ route('seller.product.add-category') }}" class="btn btn-primary float-right mb-2">Add Sub Category</a>
                <a href="javascript:void(0)" data-toggle="modal" data-target="#parentCategoryModel" class="btn btn-primary float-right mb-2 mr-2">Parents Category</a>
            </div>
        </nav>

        <!-- Content Row -->
        <div class="row">
            
            <!-- <div class="col-md-5">
                <div class="card">
                    <div class="card-header">
                        {{ \App\CPU\translate('Categories')}}
                    </div>
                    <div class="card-body">
                        <form action="{{ route('seller.product.create-category') }}" method="post">
                            @csrf
                            <div class="form-group">
                                <label>Select Parent Category</label>
                                <div>
                                    <ul style="list-style: none;">
                                        @php \App\Http\Controllers\Seller\ProductController::generateParentCategoryTree($category) @endphp
                                    </ul>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Category Name</label>
                                <input type="text" name="name" class="form-control" placeholder="Category Name">
                            </div>
                            <div class="form-group">
                                <button class="btn btn-primary" type="submit">Save</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div> -->
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        {{ \App\CPU\translate('Categories') }}
                    </div>
                    <div class="card-body">
                        <!-- <ul style="list-style:none;padding-left: 0;padding-right: 5px;height: 500px;overflow-y: scroll;">
                            @php \App\Http\Controllers\Seller\ProductController::generateCategoryTree($category) @endphp
                        </ul> -->
                        <div class="table-responsive">
                            <table id="datatable"
                                   style="text-align: {{Session::get('direction') === "rtl" ? 'right' : 'left'}};"
                                   class="table table-hover table-bordered table-thead-bordered table-nowrap table-align-middle card-table"
                                   style="width: 100%">
                                <thead class="thead-light">
                                <tr>
                                    <th>{{\App\CPU\translate('Category Name')}}</th>
                                    <!-- <th>{{\App\CPU\translate('Category Icon')}}</th> -->
                                    <th>{{\App\CPU\translate('Parent Category')}}</th>
                                    <th style="width: 5px" class="text-center">{{\App\CPU\translate('Action')}}</th>
                                </tr>
                                </thead>
                                <tbody>
                                    @php \App\Http\Controllers\Seller\ProductController::generateCategoryTree($category) @endphp
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="parentCategoryModel" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">{{\App\CPU\translate('Select Parent Category')}}</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <form action="{{route('seller.product.update-parent-category')}}" method="POST"  enctype="multipart/form-data">
          <div class="modal-body">
                @csrf
                <div class="row">
                    @foreach($categories as $key => $value)
                    <div class="col-md-4">
                        <div class="form-group">
                            <input type="checkbox" name="id[]" value="{{ $value->id }}" <?php if($value->selected_cat!=''){ $selected = json_decode($value->selected_cat,true); if(!empty($selected)){ $seller = auth('seller')->id(); if(in_array($seller,$selected)){ echo 'checked'; } } } ?>>
                            <label for="name">{{ \App\CPU\translate($value->name)}}</label>
                        </div>
                    </div>
                    @endforeach
                </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-danger">{{\App\CPU\translate('submit')}}</button>
          </div>
          </form>
        </div>
      </div>
    </div>
    
@endsection