@extends('layouts.back-end.app-seller')

@section('title',\App\CPU\translate('Product List'))

@push('css_or_js')
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
@endpush

@section('content')
    <div class="content container-fluid">
        <nav class="row" aria-label="breadcrumb">
            <div class="col-lg-12">
                <ol class="breadcrumb float-left">
                    <li class="breadcrumb-item"><a href="{{route('seller.dashboard.index')}}">{{\App\CPU\translate('Dashboard')}}</a>
                    </li>
                    <li class="breadcrumb-item" aria-current="page">{{\App\CPU\translate('Products')}}</li>

                </ol>
                <a href="{{ route('seller.product.list') }}"  class="btn btn-danger float-right mb-2">Reset</a>
                <a href="javascript:void(0)" data-toggle="modal" data-target="#searchModalpop" class="btn btn-primary float-right mb-2 mr-2">Search</a>
            </div>
        </nav>

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="flex-start">
                            <h5>{{ \App\CPU\translate('Product')}} {{ \App\CPU\translate('Table')}}</h5>
                        </div>

                        <div class="row justify-content-between align-items-center flex-grow-1">
                            <div class="col-lg-2"></div>
                            <div class="col-lg-6 mb-3 mb-lg-0">
                                
                            </div>
                            <div class="col-lg-4">
                                <a href="{{route('seller.product.add-new')}}" class="btn btn-primary float-{{Session::get('direction') === "rtl" ? 'left' : 'right'}}">
                                    <i class="tio-add-circle"></i>
                                    <span class="text">{{\App\CPU\translate('Add new product')}}</span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="card-body" style="padding: 0">
                        <div class="table-responsive">
                            <table id="datatable"
                                   style="text-align: {{Session::get('direction') === "rtl" ? 'right' : 'left'}};"
                                   class="table table-hover table-borderless table-thead-bordered table-nowrap table-align-middle card-table"
                                   style="width: 100%">
                                <thead class="thead-light">
                                <tr>
                                    <th>{{\App\CPU\translate('SL#')}}</th>
                                    <th>{{\App\CPU\translate('Product Name')}}</th>
                                    <th>{{\App\CPU\translate('purchase_price')}}</th>
                                    <th>{{\App\CPU\translate('selling_price')}}</th>
                                    <th>{{\App\CPU\translate('verify_status')}}</th>
                                    <th>{{\App\CPU\translate('Active')}} {{\App\CPU\translate('status')}}</th>
                                    <!-- <th>{{\App\CPU\translate('discount')}}</th> -->
                                    <th style="width: 5px" class="text-center">{{\App\CPU\translate('Action')}}<sub class="text-danger">( Edit and variant are under Implimentation.)</sub></th>
                                </tr>
                                </thead>
                                <tbody>
                                @foreach($products as $k=>$p)
                                    <tr>
                                        <th scope="row">{{$products->firstitem()+ $k}}</th>
                                        <td><a href="{{route('seller.product.view',[$p['id']])}}">
                                                {{$p['name']}}
                                            </a></td>
                                        <td>
                                            <!-- {{\App\CPU\BackEndHelper::set_symbol(\App\CPU\BackEndHelper::usd_to_currency($p['purchase_price']))}} -->
                                            {{App\CPU\Helpers::currency_converter_forbackend($p['purchase_price'])}}
                                        </td>
                                        <td>
                                            <!-- {{ \App\CPU\BackEndHelper::set_symbol(\App\CPU\BackEndHelper::usd_to_currency($p['unit_price']))}} -->
                                            {{App\CPU\Helpers::currency_converter_forbackend($p['unit_price'])}}
                                        </td>
                                        <td>
                                            @if($p->request_status == 0)
                                                <label class="badge badge-warning">{{\App\CPU\translate('New Request')}}</label>
                                            @elseif($p->request_status == 1)
                                                <label class="badge badge-success">{{\App\CPU\translate('Approved')}}</label>
                                            @elseif($p->request_status == 2)
                                                <label class="badge badge-danger">{{\App\CPU\translate('Denied')}}</label>
                                            @endif
                                        </td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox" class="status"
                                                       id="{{$p['id']}}" {{$p->status == 1?'checked':''}}>
                                                <span class="slider round"></span>
                                            </label>
                                        </td>
                                        <!-- <td> -->
                                           <!--  <button type="button" class="btn btn-info btn-sm" data-toggle="modal"  data-target="#discountModel_{{$p['id']}}">
                                            {{\App\CPU\translate('add_discount')}}
                                          </button> -->
                                            <!-- discount model Start-->
                                                <!-- <div class="modal fade" id="discountModel_{{$p['id']}}" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                  <div class="modal-dialog modal-dialog-centered modal-lg" style="margin: 0.75rem auto;" role="document">
                                                    <div class="modal-content">
                                                      <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">{{\App\CPU\translate('Add_Brand')}}</h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                          <span aria-hidden="true">&times;</span>
                                                        </button>
                                                      </div>
                                                      <form action="{{route('seller.add-discount')}}" name="discountform" id="discountform" method="POST"  enctype="multipart/form-data">
                                                      <div class="modal-body">
                                                            @csrf
                                                            <input type="hidden" name="product_id" value="{{$p['id']}}">
                                                                <div class="row">
                                                                    <div class="col-md-6">
                                                                        <label class="control-label">{{\App\CPU\translate('Discount')}}</label>
                                                                        <input type="number" min="0" value="0" step="0.01"
                                                                               placeholder="{{\App\CPU\translate('Discount')}}" name="discount" value="{{old('discount')}}"
                                                                               class="form-control">
                                                                    </div>
                                                                    <div class="col-md-6" style="padding-top: 30px;">
                                                                        <select
                                                                            class="form-control js-select2-custom"
                                                                            name="discount_type">
                                                                            <option value="flat">{{\App\CPU\translate('Flat')}}</option>
                                                                            <option value="percent">{{\App\CPU\translate('Percent')}}</option>
                                                                        </select>
                                                                    </div>
                                                                     <div class="col-md-6" style="padding-top: 30px;">
                                                                        <label class="control-label">{{\App\CPU\translate('Start_date')}}</label>
                                                                        <input type="datetime-local" class="form-control" id="startdate" name="startdate">
                                                                    </div>

                                                                    <div class="col-md-6" style="padding-top: 30px;">
                                                                        <label class="control-label">{{\App\CPU\translate('End_date')}}</label>
                                                                        <input type="datetime-local" class="form-control" id="enddate"name="enddate">
                                                                    </div>
                                                                </div>
                                                      </div>
                                                      <div class="modal-footer">
                                                        <div class="container">
                                                          <div class="row" style="color:red;font-size: 10px">
                                                            * ({{\App\CPU\translate('select_discount_dates_other_than_below_range')}})
                                                          </div>
                                                          <div class="row">
                                                            <div class="col-8">
                                                                <ul>
                                                                @if(!empty($p->productDiscount->id))
                                                                    @foreach($p->productDiscount as $key => $dis)
                                                                    <li  style="color:red; float: left;text-align: center;padding-right: 7px;margin-left: 7px;margin-right: 7px;">{{(!empty($dis->start_date))?date('d/m/y H:i',$dis->start_date):'N/A'}}-::-{{(!empty($dis->end_date))?date('d/m/y H:i',$dis->end_date):'N/A'}}</li>
                                                                    @endforeach
                                                                @endif
                                                                </ul>
                                                            </div>
                                                            <div class="col-4" style="text-align: right;">
                                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                                <button type="submit" class="btn btn-danger">{{\App\CPU\translate('submit')}}</button>
                                                            </div>
                                                          </div>
                                                        </div>
                                                      </form>
                                                    </div>
                                                  </div>
                                                </div> -->
                                            <!-- discount model End-->
                                        <!-- </td> -->
                                        <td>
                                            <a class="btn btn-primary btn-sm"
                                               href="{{route('seller.product.variant',[$p['id']])}}" target="_blank">
                                                <i class="tio-edit" ></i>{{\App\CPU\translate('Variant')}}
                                            </a>
                                            <a class="btn btn-primary btn-sm"
                                               href="{{route('seller.product.edit',[$p['id']])}}">
                                                <i class="tio-edit"></i>{{\App\CPU\translate('Edit')}}
                                            </a>
                                            <!-- <a class="btn btn-primary btn-sm"
                                               href="{{route('seller.product.variant',[$p['id']])}}" target="_blank">
                                                <i class="tio-edit" ></i>{{\App\CPU\translate('Variant')}}
                                            </a>
                                            <a class="btn btn-primary btn-sm"
                                               href="{{route('seller.product.edit',[$p['id']])}}">
                                                <i class="tio-edit"></i>{{\App\CPU\translate('Edit')}}
                                            </a> -->
                                            <a class="btn btn-danger btn-sm" href="javascript:"
                                               onclick="form_alert('product-{{$p['id']}}','{{\App\CPU\translate("Want to delete this item")}} ?')">
                                               <i class="tio-add-to-trash"></i> {{\App\CPU\translate('Delete')}}
                                            </a>
                                            <form action="{{route('seller.product.delete',[$p['id']])}}"
                                                  method="post" id="product-{{$p['id']}}">
                                                @csrf @method('delete')
                                            </form>
                                        </td>
                                    </tr>

                                @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- Footer -->
                     <div class="card-footer">
                        {{$products->links()}}
                    </div>
                    @if(count($products)==0)
                        <div class="text-center p-4">
                            <img class="mb-3" src="{{asset('public/assets/back-end')}}/svg/illustrations/sorry.svg" alt="Image Description" style="width: 7rem;">
                            <p class="mb-0">{{\App\CPU\translate('No data to show')}}</p>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>

    @include('seller-views.product.partials._search_filter_modal')
@endsection

@push('script')
    <!-- Page level plugins -->
    <script src="{{asset('public/assets/back-end')}}/vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="{{asset('public/assets/back-end')}}/vendor/datatables/dataTables.bootstrap4.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
      <script type="text/javascript"> 
     $(document).ready(function(){
        $('.navbar-vertical-aside-has-menu').click(function(){
            var className = $(this).attr("class");
            console.log(className);
            var RequiredClass = 'show';
            if(className.indexOf(RequiredClass) != -1){
                $(this).removeClass(RequiredClass);
            }else{
                $(this).addClass(RequiredClass);
            }
        });
    });</script>
    <script>
            flatpickr("#startdate",{
                enableTime: true,
                minTime: "09:00",
                minDate: "today"
            });
            flatpickr("#enddate",{           
                enableTime: true,
                minTime: "09:00",
                minDate: "today"
            });
        </script>
    <script>
        // Call the dataTables jQuery plugin

        $(document).ready(function () {

            $('#dataTable').DataTable();

            $("form[name='discountform']").validate({
            
                rules: {
                },
                errorPlacement: function(error,element){
                },
                messages: {
                },
                submitHandler: function(form) {
                  var url = '{{route('seller.add-discount')}}';
                  var form_data = new FormData(form);
                  $.ajax({
                        url: url,
                        type: 'POST',
                        processData: false,
                        contentType: false,
                        data: form_data,
                        success: function(result){
                            console.log(result);

                            var status = result.status;
                            var message = result.message;
                            var proid = result.proid;
                            if(status == 1){
                                Swal.fire({
                                icon: 'success',
                                title: 'Add Discount',
                                text: message,
                                }).then(function(){ 
                                  $("#discountform")[0].reset();
                                  $('#discountModel_'+proid).modal('hide');
                                });
                            }else{
                                Swal.fire({
                                  icon: 'error',
                                  title: 'Add Discount',
                                  text: message,
                                }).then(function(){ 
                                      $('#startdate').val('');
                                      $('#enddate').val('');
                                });
                            }
                        }
                    });
                }
             });
        });

        $(document).on('change', '.status', function () {
            var id = $(this).attr("id");
            if ($(this).prop("checked") == true) {
                var status = 1;
            } else if ($(this).prop("checked") == false) {
                var status = 0;
            }
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                }
            });
            $.ajax({
                url: "{{route('seller.product.status-update')}}",
                method: 'POST',
                data: {
                    id: id,
                    status: status
                },
                success: function (data) {
                    if(data.success == true) {
                        toastr.success('{{\App\CPU\translate('Status updated successfully')}}');
                    }
                    else if(data.success == false) {
                        toastr.error('{{\App\CPU\translate('Status updated failed. Product must be approved')}}');
                        location.reload();
                    }
                }
            });
        });
    </script>
@endpush
