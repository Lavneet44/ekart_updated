@extends('layouts.back-end.app-seller')

@section('title',\App\CPU\translate('Product List'))

@push('css_or_js')
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
@endpush

@section('content')
    <div class="content container-fluid">
        <nav class="row" aria-label="breadcrumb">
            <div class="col-lg-12">
                <ol class="breadcrumb float-left">
                    <li class="breadcrumb-item"><a href="{{route('seller.dashboard.index')}}">{{\App\CPU\translate('Dashboard')}}</a>
                    </li>
                    <li class="breadcrumb-item" aria-current="page">{{\App\CPU\translate('Products')}}</li>

                </ol>
                <a href="{{ route('seller.product.list') }}"  class="btn btn-danger float-right mb-2">Reset</a>
                <a href="javascript:void(0)" data-toggle="modal" data-target="#searchModalpop" class="btn btn-primary float-right mb-2 mr-2">Search</a>
            </div>
        </nav>

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="flex-start">
                            <h5>{{ \App\CPU\translate('Product')}} {{ \App\CPU\translate('Table')}}</h5>
                        </div>

                        <div class="row justify-content-between align-items-center flex-grow-1">
                            <div class="col-lg-2"></div>
                            <div class="col-lg-6 mb-3 mb-lg-0">
                                
                            </div>
                            <div class="col-lg-4">
                                <a href="{{route('seller.product.add-new')}}" class="btn btn-primary float-{{Session::get('direction') === "rtl" ? 'left' : 'right'}}">
                                    <i class="tio-add-circle"></i>
                                    <span class="text">{{\App\CPU\translate('Add new product')}}</span>
                                </a>
                                <select onchange="change_this_things(this)" style="width: 136px;height: 41px;">
                                    <option value="0">Select Option</option>
                                    <option value="1">Active / Inactive</option>
                                    <option value="2">Delete</option>
                                    <option value="3">Export</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="card-body" style="padding: 0">
                        <div class="table-responsive">
                            <table id="datatable"
                                   style="text-align: {{Session::get('direction') === "rtl" ? 'right' : 'left'}};"
                                   class="table table-hover table-borderless table-thead-bordered table-nowrap table-align-middle card-table"
                                   style="width: 100%">
                                <thead class="thead-light">
                                <tr>
                                    <th><input type="checkbox" class="check_all_product"></th>
                                    <th>{{\App\CPU\translate('SL#')}}</th>
                                    <th>{{\App\CPU\translate('Product Name')}}</th>
                                    <th>{{\App\CPU\translate('purchase_price')}}</th>
                                    <th>{{\App\CPU\translate('selling_price')}}</th>
                                    <th>{{\App\CPU\translate('verify_status')}}</th>
                                    <th>{{\App\CPU\translate('Active')}} {{\App\CPU\translate('status')}}</th>
                                    <!-- <th>{{\App\CPU\translate('discount')}}</th> -->
                                    <th style="width: 5px" class="text-center">{{\App\CPU\translate('Action')}}</th>
                                </tr>
                                </thead>
                                <tbody>
                                @foreach($products as $k=>$p)
                                    <tr>
                                        <td><input type="checkbox" name="checked_product" class="check_prod" value="{{$p['id']}}"></td>
                                        <td scope="row">{{$products->firstitem()+ $k}}</td>
                                        <td><a href="{{route('seller.product.view',[$p['id']])}}">
                                                {{$p['name']}}  
                                            </a>
                                        </td>
                                        <td>
                                            <!-- {{\App\CPU\BackEndHelper::set_symbol(\App\CPU\BackEndHelper::usd_to_currency($p['purchase_price']))}} -->
                                            {{App\CPU\Helpers::currency_converter_forbackend($p['purchase_price'])}}
                                        </td>
                                        <td>
                                            <!-- {{ \App\CPU\BackEndHelper::set_symbol(\App\CPU\BackEndHelper::usd_to_currency($p['unit_price']))}} -->
                                            {{App\CPU\Helpers::currency_converter_forbackend($p['unit_price'])}}
                                        </td>
                                        <td>
                                            @if($p->request_status == 0)
                                                <label class="badge badge-warning">{{\App\CPU\translate('New Request')}}</label>
                                            @elseif($p->request_status == 1)
                                                <label class="badge badge-success">{{\App\CPU\translate('Approved')}}</label>
                                            @elseif($p->request_status == 2)
                                                <label class="badge badge-danger">{{\App\CPU\translate('Denied')}}</label>
                                            @endif
                                        </td>
                                        <td>
                                            <label class="switch">
                                                <input type="checkbox" class="status"
                                                       id="{{$p['id']}}" {{$p->status == 1?'checked':''}}>
                                                <span class="slider round"></span>
                                            </label>
                                        </td>
                                        <td>
                                            

                                            <div class="dropdown">
                                                <a class="btn btn-primary btn-sm"
                                               href="{{route('seller.product.variant',[$p['id']])}}" target="_blank">
                                                <i class="tio-edit" ></i>{{\App\CPU\translate('Variant')}}
                                            </a>
                                                <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i class="tio-settings-vs"></i>
                                                </button>
                                                <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
                                                    <a href="{{route('seller.product.edit',[$p['id']])}}" class="dropdown-item">Edit</a>
                                                    <a href="javascript:" onclick="form_alert('product-{{$p['id']}}','{{\App\CPU\translate("Want to delete this item")}} ?')" class="dropdown-item delete_discount">Delete</a>

                                                    <a href="javascript:void(0)" class="dropdown-item showVariant" data-key="{{$p->id}}">Show / Hide Variants</a>
                                                </div>
                                            </div>
                                            <form action="{{route('seller.product.delete',[$p['id']])}}"
                                                  method="post" id="product-{{$p['id']}}">
                                                @csrf @method('delete')
                                            </form>
                                        </td>
                                    </tr>
                                    @if(!empty($p->variants))
                                    <tr class="variant_{{$p->id}}" style="display: none;">
                                        <td colspan="6" class="m-auto">
                                            <table style="width: 100%;">
                                                <thead>
                                                    <tr>
                                                        <th>Variant SKU</th>
                                                        <th>Price</th>
                                                        <th>Qty</th>
                                                        <th>Status</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody> 
                                                    @foreach($p->variants as $var=> $vari)
                                                    <tr>
                                                        <td>{{ str_replace('-',' ',$vari->sku) }}</td>
                                                        <td>{{ $vari->price }}</td>
                                                        <td>{{ $vari->qty }}</td>
                                                        <td><label class="switch">
                                                                <input type="checkbox" class="status_variant"
                                                                       id="{{$vari->id}}" {{$vari->isEnable == 1?'checked':''}}>
                                                                <span class="slider round"></span>
                                                            </label>
                                                        </td>
                                                        <td></td>
                                                    </tr>
                                                    @endforeach
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>
                                    @endif
                                @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- Footer -->
                     <div class="card-footer">
                        {{$products->links()}}
                    </div>
                    @if(count($products)==0)
                        <div class="text-center p-4">
                            <img class="mb-3" src="{{asset('public/assets/back-end')}}/svg/illustrations/sorry.svg" alt="Image Description" style="width: 7rem;">
                            <p class="mb-0">{{\App\CPU\translate('No data to show')}}</p>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>

    @include('seller-views.product.partials._search_filter_modal')
@endsection

@push('script')
    <!-- Page level plugins -->
    <script src="{{asset('public/assets/back-end')}}/vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="{{asset('public/assets/back-end')}}/vendor/datatables/dataTables.bootstrap4.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
      <script type="text/javascript"> 
        function change_this_things(e){
            var vl = $(e).val();
            var check = [];
            $("input:checkbox[name=checked_product]:checked").each(function(){
                check.push($(this).val());
            });
            if(vl == 1){
                var rou = "{{ route('seller.product.active-inactive') }}";
            }else if(vl == 2){
                var rou = "{{ route('seller.product.delete-selected') }}";
            }else{
                var rou = "{{ route('seller.product.export-selected') }}";
            }
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                }
            });
            $.ajax({
                url: rou,
                method: 'POST',
                data: {
                    checked: check
                },
                success: function (data) {
                    console.log(data);
                    if(data.code == 1) {
                        toastr.success('{{\App\CPU\translate('Successfully Done')}}');
                        location.reload();
                    }
                    else if(data.code == 0) {
                        toastr.error('{{\App\CPU\translate('Something Went Wrong')}}');
                        location.reload();
                    }
                }
            });
        }

        $('.showVariant').on('click',function(){
            var key = $(this).attr('data-key');
            $('.variant_'+key).toggle();
        });
        $('.status_variant').on('change',function(){
            var id = $(this).attr('id');
            if ($(this).prop("checked") == true) {
                var status = 1;
            } else if ($(this).prop("checked") == false) {
                var status = 0;
            }
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                }
            });
            $.ajax({
                url: "{{route('seller.product.status-update-variant')}}",
                method: 'POST',
                data: {
                    id: id,
                    status: status
                },
                success: function (data) {
                    if(data.success == true) {
                        toastr.success('{{\App\CPU\translate('Variant Status updated successfully')}}');
                    }
                    else if(data.success == false) {
                        toastr.error('{{\App\CPU\translate('Variant Status updated failed. Product must be approved')}}');
                        location.reload();
                    }
                }
            });
        });

     $(document).ready(function(){
        $('.navbar-vertical-aside-has-menu').click(function(){
            var className = $(this).attr("class");
            console.log(className);
            var RequiredClass = 'show';
            if(className.indexOf(RequiredClass) != -1){
                $(this).removeClass(RequiredClass);
            }else{
                $(this).addClass(RequiredClass);
            }
        });
    });</script>
    <script>
            flatpickr("#startdate",{
                enableTime: true,
                minTime: "09:00",
                minDate: "today"
            });
            flatpickr("#enddate",{           
                enableTime: true,
                minTime: "09:00",
                minDate: "today"
            });
        </script>
    <script>
        // Call the dataTables jQuery plugin
        $('.check_all_product').on('click',function(){
            $('.check_prod').prop('checked',true);
        });
        $(document).ready(function () {

            $('#dataTable').DataTable();

            $("form[name='discountform']").validate({
            
                rules: {
                },
                errorPlacement: function(error,element){
                },
                messages: {
                },
                submitHandler: function(form) {
                  var url = '{{route('seller.add-discount')}}';
                  var form_data = new FormData(form);
                  $.ajax({
                        url: url,
                        type: 'POST',
                        processData: false,
                        contentType: false,
                        data: form_data,
                        success: function(result){
                            console.log(result);

                            var status = result.status;
                            var message = result.message;
                            var proid = result.proid;
                            if(status == 1){
                                Swal.fire({
                                icon: 'success',
                                title: 'Add Discount',
                                text: message,
                                }).then(function(){ 
                                  $("#discountform")[0].reset();
                                  $('#discountModel_'+proid).modal('hide');
                                });
                            }else{
                                Swal.fire({
                                  icon: 'error',
                                  title: 'Add Discount',
                                  text: message,
                                }).then(function(){ 
                                      $('#startdate').val('');
                                      $('#enddate').val('');
                                });
                            }
                        }
                    });
                }
             });
        });
        

        $(document).on('change', '.status', function () {
            var id = $(this).attr("id");
            if ($(this).prop("checked") == true) {
                var status = 1;
            } else if ($(this).prop("checked") == false) {
                var status = 0;
            }
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                }
            });
            $.ajax({
                url: "{{route('seller.product.status-update')}}",
                method: 'POST',
                data: {
                    id: id,
                    status: status
                },
                success: function (data) {
                    if(data.success == true) {
                        toastr.success('{{\App\CPU\translate('Status updated successfully')}}');
                    }
                    else if(data.success == false) {
                        toastr.error('{{\App\CPU\translate('Status updated failed. Product must be approved')}}');
                        location.reload();
                    }
                }
            });
        });
    </script>
@endpush
