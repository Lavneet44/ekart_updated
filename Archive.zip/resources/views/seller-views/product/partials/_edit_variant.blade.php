@push('css')
<style type="text/css">
    .checktr {
        background: #eee;
    }
</style>
@endpush
@if(count($variantsObject['combinations']) > 0)
<table class="table table-bordered" id="sku-table">
    <thead>
        <tr>
                <td class="text-center" >
                    <label for="" class="control-label">{{\App\CPU\translate('Variant Combinations')}}</label>
                </td>
                <td class="text-center">
                    <label for="" class="control-label">{{\App\CPU\translate('Variant')}}</label>
                </td>
                </td>
                <td class="text-center">
                    <label for="" class="control-label">{{\App\CPU\translate('SKU')}}</label>
                <td class="text-center">
                    <label for="" class="control-label">{{\App\CPU\translate('Apply Discount')}}</label>
                </td>
        </tr>
        <tr >
            <td colspan="5">
                <!-- <ul style="font-size: 14px;padding-left: 13px;color: #ff5e00c7;">
                    <strong>Note:-Instructions to create product variant.</strong>
                    <li style="color: #ff5e00c7;font-size: 14px;">The minimum quantity for a product variant should be one. Otherwise, let it be zero.</li>
                    <li style="color: #ff5e00c7;font-size: 14px;">If a discount is applied to the product variant, then its value should be in a flat amount (not in per centage).</li>
                    <li>If a discount is being applied to the product variant, kindly state either the start period or both the start and end periods.</li>
                    <li  style="color: #ff5e00c7;font-size: 14px;"><strong>Click the "Verify discount duration" button</strong> to double-check the start and end duration after entering all the necessary information for the variant. If you don't, the discount won't be applied.</li>
                </ul> -->
            </td>
        </tr>
        <tr class="errorblock">
        </tr>
    </thead>
    <tbody>
        @foreach ($variantsObject['combinations'] as $key => $combination)
        	<!-- the position of {{ $key }} not changable -->
        <tr class="checktr" style="background-color: #eee;" >
            <td>
                <table>
                    <tr class="nn_{{$key}}">
                        <?php
                            $str = $combination['type'];
                            $strArray = [];
                            $strArray = explode('-', $str);
                            foreach($strArray as $i => $sA)
                            {
                                $strArray[$i] = trim($sA);
                            }
                        ?>
                        @foreach($variantsObject['selectColoumn'] as $keys => $sc)
                        <td>
                            <label class="control-label">{{$sc[0]}}</label>
                            <select class="form-control" data-row="{{ $key }}" data-col="{{!empty($variantsObject['selectColoumn'])?count($variantsObject['selectColoumn']):0}}" onchange="checkVariant(this,'{{$key}}')" id="{{$key}}{{$keys}}" >
                                    <option value="">None</option>
                                    @foreach($sc as $in => $s)
                                        @if($in)
                                        <option {{(in_array(str_replace(' ', '', $s), $strArray))?'selected':''}} value="{{str_replace(' ', '', $s)}}">{{($sc[0]=='color')?\App\Model\Color::where('code', $s)->first()->name:$s}}</option>
                                        @endif
                                    @endforeach
                            </select>
                        </td>
                        @endforeach
                    </tr>
                </table>
            </td>
            <td colspan="2">
                    <?php
                        $compiledStr = '';
                        $compiledSku = '';
                        $compiledSku = \App\Model\Product::where('id',$combination['product_id'])->first()->name;
                        foreach($strArray as $compStrIndex => $cStrElement)
                        {
                            if(!empty($cStrElement))
                            { 
                                if($compStrIndex > 0 ){
                                    $compiledStr .= '-'.str_replace(' ', '', $cStrElement);
                                    $compiledSku .='-'.str_replace(' ', '', $cStrElement);
                                }
                                else
                                {
                                    if($variantsObject['colors_active'] == 1){
                                        if(!empty($cStrElement))
                                        {
                                            $color_name = $cStrElement;
                                            $color= \App\Model\Color::where('code', $cStrElement)->first();
                                            if(!empty($color))
                                            {
                                                $color_name = $color->name;
                                            }
                                            $compiledStr .= $color_name;
                                            $compiledSku .='-'.$color_name;
                                        }
                                    }
                                    else{
                                        if(!empty($cStrElement))
                                        {
                                            $compiledStr .= str_replace(' ', '', $cStrElement);
                                            $compiledSku .='-'.str_replace(' ', '', $cStrElement);
                                        }
                                    }
                                }
                            }
                        }
                    ?>
                <input type="text" value="{{ $compiledStr }}" id="strShow_{{ $key }}" class="form-control common str" readonly>

                <input type="hidden" name="original_str[]" value="{{ $combination['orignalstr'] }}" id="strInput_{{ $key }}" class="form-control common skuCombination_{{ $key }}">

                <input type="hidden" name="changed_str[]" value="{{ $combination['type'] }}" id="data_{{ $key }}" class="form-control common skuCombination_{{ $key }}"  data-orignalText = "{{ $compiledStr }}" data-orignalVal = "{{ $str }}">
            </td>
            <td>
                <input type="text" value="{{ $compiledSku }}" name="sku[]" id="sku_{{ $key }}" class="form-control common" >
            </td>
            <td>
                <label class="switch">
                    <input type="checkbox" @if($combination['verify_status'] == 1) {{ "checked" }} @endif class="status" name="active_discount" value="{{old('colors_active')}}" data-key="{{$combination['verify_status']}}" onchange="showDiscountParameters('{{ $key }}',this);">
                    <span class="slider round"></span>
                </label>
                <?php if($combination['verify_status'] == 1){ $displayString="display:none"; }else{ $displayString="";}?>
                <i class="tio-checkmark-square-outlined comman topStatus_{{ $key }}" style="font-size: xx-large;color: chartreuse;float: right;'{{$displayString}}'"></i>
            </td>
        </tr>
        <tr class="common_key {{$key}}"  data-active="{{$combination['verify_status']}}">
            <td colspan="3">
                <label>Variant Price</label>
                <input type="number" id="price_{{ $key }}" value='{{($combination["price"] != 0)?App\CPU\Helpers::currency_converter_forbackend($combination["price"],"yes"):""}}' name="price[]" step="0.01" class="form-control common" placeholder="Variant Price" >
            </td>

            <td colspan="3">
                <label>Quantity</label>
                <input type="number" name="qty[]" id="qty_{{ $key }}" min="0" max="1000000" step="1" value="{{ $combination['qty'] }}" class="form-control common">
                <input type="hidden" id="verify_status_{{ $key }}" value="{{$combination['verify_status']}}" name="verify_status[]"  >
            </td>
        </tr>
        @endforeach
    </tbody>
</table>
@endif


@push('script')
<script type="text/javascript">

    $(document).ready(function(){
        $('.common_key').each(function(){
            var kk = $(this).attr('data-active');
            if(kk == 0){
                $(this).hide();
                
            }else{
                $(this).show();
            }
        });
    });

    $('input[name=active_discount]').on('change',function(){
        var kk = $(this).attr('data-key');
        if($(this).is(':checked')){
            $('#verify_status_'+kk).val(1);
        }else{
            $('#verify_status_'+kk).val(0);
        }
    });

    $('.discountedVal').on('keyup',function(){
        var id = $(this).attr('data-key');
        var val = $(this).val();
        console.log(val);
        var base = $('#price_'+id).val();
        console.log('base '+base);
        var percent = (parseInt(val) / parseInt(base)) * 100;
        console.log(percent);
        $('#discount_'+id+'_percent').val(percent);

    });
    $('.discountedPercentage').on('keyup',function(){
        var id = $(this).attr('data-key');
        var val = $(this).val();
        console.log(val);
        var base = $('#price_'+id).val();
        console.log('base '+base);
        var percent = (parseInt(val) / 100) * parseInt(base);
        console.log(percent);
        $('#discount_'+id).val(percent);

    });
</script>
@endpush