<div class="modal fade" id="searchModalpop" tabindex="-1" role="dialog" aria-labelledby="searchModalpopLabel" aria-hidden="true">
  <div class="modal-dialog" role="document" style="max-width: 70%; margin-top: 0;">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Search</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="GET" action="{{ url()->current() }}">
          <div class="row">
            <div class="col-md-6 form-group">
              <label>Product Name</label>
              <input type="text" name="name" class="form-control" value="@if(isset($_GET['name'])){{ $_GET['name'] }} @endif" placeholder="Product Name">
            </div>
            <div class="col-md-3 form-group">
              <label>Item Code</label>
              <input type="text" name="item_code" value="@if(isset($_GET['item_code'])){{ $_GET['item_code'] }} @endif" class="form-control" placeholder="Item Name">
            </div>
            <div class="col-md-3 form-group">
              <label>Product Part Number</label>
              <input type="text" name="part_no" value="@if(isset($_GET['part_no'])){{ $_GET['part_no'] }} @endif" class="form-control" placeholder="Part Number">
            </div>
            <div class="col-md-3 form-group">
              <label>Categories</label>
              <select name="categories[]" class="form-control js-select2-custom" multiple>
                <option value="">Select Categories</option>
                @php
                 if(isset($_GET['categories']) && $_GET['categories']){
                  $cadd = $_GET['categories'];
                 }else{
                  $cadd = array();
                 }
                 \App\Http\Controllers\Seller\ProductController::selectionCategorySearch($categories,$cadd) 
                @endphp
              </select>
            </div>
            <div class="col-md-3 form-group">
              <label>Brands</label>
              <select name="brands[]" class="form-control js-select2-custom" multiple>
                <option value="">Select Brands</option>
                @foreach($brand as $cat)
                <option @if(isset($_GET['brands']) && in_array($cat->id,$_GET['brands'])) selected  @endif value="{{ $cat->id }}">{{ $cat->name }}</option>
                @endforeach
              </select>
            </div>
            <div class="col-md-3 form-group">
              <label>Units</label>
              <select name="units[]" class="form-control js-select2-custom" multiple>
                <option value="">Select Units</option>
                @foreach($unit as $cat)
                <option @if(isset($_GET['units']) && in_array($cat->id,$_GET['units'])) selected  @endif value="{{ $cat->id }}">{{ $cat->name }}</option>
                @endforeach
              </select>
            </div>
            <div class="col-md-3 form-group">
              <label>Attributes</label>
              <select name="attributes[]" class="form-control js-select2-custom" multiple>
                <option value="">Select Attributes</option>
                @foreach($attribute as $cat)
                <option @if(isset($_GET['attributes']) && in_array($cat->id,$_GET['attributes'])) selected  @endif value="{{ $cat->id }}">{{ $cat->name }}</option>
                @endforeach
              </select>
            </div>
            <div class="col-md-12 form-group">
                <button type="submit" class="btn btn-primary">Search</button>
                <button type="button" class="btn btn-danger" data-dismiss="modal">Reset</button>
            </div>
          </div>
          
        </form>
      </div>
    </div>
  </div>
</div>