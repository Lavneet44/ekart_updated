
<div class="modal fade" id="add_category_modal_open" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">{{\App\CPU\translate('Create Category')}}</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="" name="create_category_form" id="creat_category_form" method="POST"  enctype="multipart/form-data">
      <div class="modal-body">
            @csrf
            <div class="form-group">
                <label>Select Parent Category</label>
                <div style="border: 1px solid #eee;padding:5px;">
                    <ul id="updateCategoryDataModal" style="list-style: none;height: 250px;overflow-y: scroll;">
                        @php \App\Http\Controllers\Seller\ProductController::generateParentCategoryPTree($categories) @endphp
                    </ul>
                </div>
            </div>
            <div class="form-group">
                <label>Category Name</label>
                <input type="text" name="name" required class="form-control" placeholder="Category Name">
            </div>
            
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-danger">{{\App\CPU\translate('submit')}}</button>
      </div>
      </form>
    </div>
  </div>
</div>
<div class="modal fade" id="add_brand_modal_open" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">{{\App\CPU\translate('Create Brand')}}</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="" name="create_brand_form" id="creat_brand_form" method="POST"  enctype="multipart/form-data">
      <div class="modal-body">
            @csrf
            @php($language=\App\Model\BusinessSetting::where('type','pnc_language')->first())
            @php($language = $language->value ?? null)
            @php($default_lang = 'en')

            @php($default_lang = json_decode($language)[0])
            <ul class="nav nav-tabs mb-4">
                @foreach(json_decode($language) as $lang)
                    <li class="nav-item">
                        <a class="nav-link lang_link {{$lang == $default_lang? 'active':''}}"
                            href="#"
                            id="{{$lang}}-link">{{\App\CPU\Helpers::get_language_name($lang).'('.strtoupper($lang).')'}}</a>
                    </li>
                @endforeach
            </ul>
            <div class="row">
                <div class="col-md-6">
                    @foreach(json_decode($language) as $lang)
                        <div class="form-group {{$lang != $default_lang ? 'd-none':''}} lang_form"
                                id="{{$lang}}-form">
                            <label for="name">{{ \App\CPU\translate('name')}} ({{strtoupper($lang)}})</label>
                            <input type="text" name="name[]" required class="form-control" id="name" value="{{old('name')}}" placeholder="{{\App\CPU\translate('Ex')}} : {{\App\CPU\translate('LUX')}}" {{$lang == $default_lang? 'required':''}}>
                        </div>
                        <input type="hidden" name="lang[]" value="{{$lang}}">
                    @endforeach
                    <div class="form-group">
                        <label for="name">{{ \App\CPU\translate('brand_logo')}}</label><span class="badge badge-soft-danger">( {{\App\CPU\translate('ratio')}} 1:1 )</span>
                        <div class="custom-file" style="text-align: left" required>
                            <input type="file" name="image" id="customFileUpload" class="custom-file-input"
                                accept=".jpg, .png, .jpeg, .gif, .bmp, .tif, .tiff|image/*">
                            <label class="custom-file-label" for="customFileUpload">{{\App\CPU\translate('choose')}} {{\App\CPU\translate('file')}}</label>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <center>
                        <img style="border-radius: 10px; max-height:200px;" id="viewer"
                            src="{{asset('public\assets\back-end\img\400x400\img2.jpg')}}" alt="banner image"/>
                    </center>
                </div>
            </div>


            <div class="card-footer">
                <button type="submit" class="btn btn-primary">{{ \App\CPU\translate('save')}}</button>
            </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-danger">{{\App\CPU\translate('submit')}}</button>
      </div>
      </form>
    </div>
  </div>
</div>
<div class="modal fade" id="add_unit_modal_open" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">{{\App\CPU\translate('Create Units')}}</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="" name="create_unit_form" id="creat_units_form" method="POST"  enctype="multipart/form-data">
      <div class="modal-body">
                @csrf
                    @php($language=\App\Model\BusinessSetting::where('type','pnc_language')->first())
                    @php($language = $language->value ?? null)
                    @php($default_lang = 'en')

                    @php($default_lang = json_decode($language)[0])
                    <ul class="nav nav-tabs mb-4">
                        @foreach(json_decode($language) as $lang)
                            <li class="nav-item">
                                <a class="nav-link lang_link {{$lang == $default_lang? 'active':''}}"
                                    href="#"
                                    id="{{$lang}}-link">{{\App\CPU\Helpers::get_language_name($lang).'('.strtoupper($lang).')'}}</a>
                            </li>
                        @endforeach
                    </ul>
                    <div class="row">
                        <div class="col-md-12">
                            @foreach(json_decode($language) as $lang)
                                <div class="form-group {{$lang != $default_lang ? 'd-none':''}} lang_form"
                                        id="{{$lang}}-form">
                                    <label for="name">{{ \App\CPU\translate('Units')}} ({{strtoupper($lang)}})</label>
                                    <input type="hidden" name="id" id="EditUpdateid">
                                    <input type="text" name="name" required class="form-control" id="EditUpdateName" value="{{old('name')}}" placeholder="{{\App\CPU\translate('Ex')}} : {{\App\CPU\translate('Kilogram')}}" {{$lang == $default_lang? 'required':''}}>
                                </div>
                                <div class="form-group {{$lang != $default_lang ? 'd-none':''}} lang_form"
                                        id="{{$lang}}-form">
                                    <label for="name">{{ \App\CPU\translate('Units')}} ({{strtoupper($lang)}})</label>
                                    <input type="text" name="symbol" class="form-control" id="EditUpdateSym" value="{{old('symbol')}}" placeholder="{{\App\CPU\translate('Ex')}} : {{\App\CPU\translate('Kg')}}" {{$lang == $default_lang? 'required':''}}>
                                </div>
                                <input type="hidden" name="lang[]" value="{{$lang}}">
                            @endforeach
                           
                        </div>
                       
                    </div>
          </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-danger">{{\App\CPU\translate('submit')}}</button>
      </div>
      </form>
    </div>
  </div>
</div>
<div class="modal fade" id="add_attributes_modal_open" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">{{\App\CPU\translate('Create Attributes')}}</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="" name="create_attributes_form" id="creat_attributes_form" method="POST"  enctype="multipart/form-data">
      <div class="modal-body">
                @csrf
                    @php($language=\App\Model\BusinessSetting::where('type','pnc_language')->first())
                    @php($language = $language->value ?? null)
                    @php($default_lang = 'en')

                    @php($default_lang = json_decode($language)[0])
                    <ul class="nav nav-tabs mb-4">
                        @foreach(json_decode($language) as $lang)
                            <li class="nav-item">
                                <a class="nav-link lang_link {{$lang == $default_lang? 'active':''}}"
                                    href="#"
                                    id="{{$lang}}-link">{{\App\CPU\Helpers::get_language_name($lang).'('.strtoupper($lang).')'}}</a>
                            </li>
                        @endforeach
                    </ul>
                    <div class="row">
                        <div class="col-md-12">
                            @foreach(json_decode($language) as $lang)
                                <div class="form-group {{$lang != $default_lang ? 'd-none':''}} lang_form"
                                        id="{{$lang}}-form">
                                    <label for="name">{{ \App\CPU\translate('Attributes')}} ({{strtoupper($lang)}})</label>
                                    <input type="text" name="name" required class="form-control" id="Checkname" value="{{old('name')}}" placeholder="" {{$lang == $default_lang? 'required':''}}>
                                </div>
                            
                                <input type="hidden" name="lang[]" value="{{$lang}}">
                            @endforeach
                           
                        </div>
                       
                    </div>
          </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-danger">{{\App\CPU\translate('submit')}}</button>
      </div>
      </form>
    </div>
  </div>
</div>