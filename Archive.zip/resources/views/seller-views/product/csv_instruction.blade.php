@extends('layouts.back-end.app-seller')

@section('title', \App\CPU\translate('Product Bulk Import'))

@push('css_or_js')

@endpush

@section('content')
    <div class="content container-fluid">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{route('seller.dashboard.index')}}">{{\App\CPU\translate('Dashboard')}}</a>
                </li>
                <li class="breadcrumb-item" aria-current="page"><a
                        href="{{route('seller.product.list')}}">{{\App\CPU\translate('Product')}}</a>
                </li>
                <li class="breadcrumb-item">{{\App\CPU\translate('Instructions')}} </li>
            </ol>
        </nav>

        <!-- Content Row -->
        <div class="row" style="text-align: {{Session::get('direction') === "rtl" ? 'right' : 'left'}};">
            <div class="col-12">
                <div class="jumbotron" style="background: white;padding: 0.5rem 0.5rem !important;">
                    <h1 class="display-4">{{\App\CPU\translate('Instructions')}} : </h1>
                    <h5 class="text-danger">{{\App\CPU\translate('Use the below information to create a product CSV.')}}</h5>
                </div>
                <div class="card">
                    <div class="card-header">
                        <div class="flex-start">
                            <h5>{{ \App\CPU\translate('Your chosen category tree')}} </h5><br/>
                        </div>
                        <div><h6 class="text-danger">{{\App\CPU\translate('Formate')}} :- ({{\App\CPU\translate('child-id')}}) <sub  style="font-size: 9px;">[{{\App\CPU\translate('parent-id')}}]</sub></h6></div>
                    </div>

                    <div class="card-body" style="padding: 0">
                            <div class="row mb-3 ml-2">
                                <div class="col-md-2"><strong>{{\App\CPU\translate('category')}}</strong></div>
                                <div class="col-md-5"><strong>{{\App\CPU\translate('sub-category')}}</strong></div>
                                <div class="col-md-5"><strong>{{\App\CPU\translate('sub-sub-category')}}</strong></div>
                            </div>
                            <hr/>
                            <div class="row  ml-1">

                            </div>
                    </div>
                    <!-- Footer -->
                     <div class="card-footer">
                    </div>
                </div>

                <div class="card mt-5">
                    <div class="card-header">
                        <div class="flex-start">
                            <h5>{{ \App\CPU\translate('your selected Brands')}}</h5>
                        </div>
                    </div>

                    <div class="card-body" style="padding: 0">
                            <div class="row mb-3 ml-2">
                                <div class="col-md-6"><strong>{{\App\CPU\translate('Brand Name')}}</strong></div>
                                <div class="col-md-6"><strong>{{\App\CPU\translate('id')}}</strong></div>
                            </div>
                            @if(!empty($brands))
                                @foreach($brands as $keys => $brand)
                                <div class="row  ml-2 mb-1">
                                    <div class="col-md-6">{{$brand->name}}</div>
                                    <div class="col-md-6">({{$brand->id}})</div>
                                </div>
                                @endforeach
                            @else
                                <div class="row  ml-2 mb-1">{{\App\CPU\translate('No brands to show')}}</div>
                            @endif
                    </div>
                    <!-- Footer -->
                     <div class="card-footer">
                    </div>
                </div>


                <div class="card mt-5">
                    <div class="card-header">
                        <div class="flex-start">
                            <h5>{{ \App\CPU\translate('your selected Units')}}</h5>
                        </div>
                    </div>

                    <div class="card-body" style="padding: 0">
                            <div class="row mb-3 ml-2">
                                <div class="col-md-4"><strong>{{\App\CPU\translate('Unit Name')}}</strong></div>
                                <div class="col-md-4"><strong>{{\App\CPU\translate('Unit symbol')}}</strong></div>
                                <div class="col-md-4"><strong>{{\App\CPU\translate('id')}}</strong></div>
                            </div>
                            @if(!empty($units))
                            @foreach($units as $keys => $unit)
                            <div class="row  ml-2 mb-1">
                                <div class="col-md-4">{{$unit->name}}</div>
                                <div class="col-md-4">{{$unit->symbol}}</div>
                                <div class="col-md-4">({{$unit->id}})</div>
                            </div>
                            @endforeach
                            @else
                                <div class="row  ml-2 mb-1">{{\App\CPU\translate('No units to show')}}</div>
                            @endif
                    </div>
                    <!-- Footer -->
                     <div class="card-footer">
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@push('script')

@endpush
