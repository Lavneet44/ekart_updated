@extends('layouts.front-end.app')
 
@section('title',\App\CPU\translate('Seller Apply'))

@push('css_or_js')
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"/>
<link href="{{asset('public/assets/back-end')}}/css/select2.min.css" rel="stylesheet"/>
<link href="{{asset('public/assets/back-end/css/croppie.css')}}" rel="stylesheet">
<meta name="csrf-token" content="{{ csrf_token() }}">
<style type="text/css">
      body{
      padding: 0;
      margin: 0;
      }
      .modal-header{
      background: #1B4F72;
      color: #fff;
      }
      h5{
      padding-top: 10px;
      padding-bottom: 10px;
      font-size: 30px;
      display: block;
      margin: 0 auto;
      }
      .modal-header .close{
      height: 50px;
      width:50px;
      background: #fff;
      border-radius: 50%;
      font-size: 30px;
      padding: 0;
      position: absolute;
      left: auto;
      right: -5px;
      top: -5px;
      }
      .myclass {
         justify-content: center;
      }
      .btn-custom{
      background: #1B4F72;
      border-radius: 30px;
      color: #fff;
      padding: 4px 6px;
      margin: 5px auto;
      display: block;
      font-size: 15px;
      font-weight: 700;
      }
      .btn-custom:hover{
      color: #fff;
      }
      h3{
      text-align: center;
      font-size: 40px;
      padding-top: 20px;
      letter-spacing: 2px;
      line-height: 40px;
      }
      .fa-ul{
        padding-top: 20px;
        list-style-type: disc;
        text-align: left;
        line-height: 30px;
      }
      p{
      text-align: center;
      font-size: 20px;
      padding-top: 20px;
      margin: 0;
      }
      .card-body h1 {
        font-size: 1.5rem;
      }
      .shadow-lg{
        box-shadow: 0 1.5rem 1.525rem -0.400rem rgb(0 0 0 / 40%) !important;
      }
      @media(max-width: 575px){
      .modal-dialog{
      margin: 1.5rem;
      }
      h5{
      padding-top: 20px;
      padding-bottom: 20px;
      font-size: 50px;
      }
      h3{
      font-size: 45px;
      }
      }
    </style>
@endpush


@section('content')

<div class="container main-card rtl" style="text-align: {{Session::get('direction') === "rtl" ? 'right' : 'left'}};">

    <div class="card o-hidden border-0 shadow-lg my-4">
        <div class="card-body">
            <!-- Nested Row within Card Body -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="p-5">
                        <div class="text-center mb-2 ">
                            <h3 class="" > {{\App\CPU\translate('Seller')}} {{\App\CPU\translate('Plans')}}</h3>
                            <hr>
                            <section class="col-lg-12">
                                <!-- Products grid-->
                                <div class="row mx-n2" style="min-height: 200px">
                                     @if(!empty($plan) && count($plan)>0)
                                          @foreach($plan as $key => $p)
                                          <div class="col-lg-4" style="margin-top: 10px;margin-bottom: 10px;">
                                            <div class="card mb-5 mb-lg-0">
                                              <div class="card-body shadow-lg">
                                                <h5 style="background-color:#1b7fed;color: white !important;border-radius: 30px" class="card-title text-muted text-uppercase text-center">{{$p->title}}</h5>
                                                <h1 class="card-price text-center">
                                                    <span>
                                                        {{\App\CPU\BackEndHelper::set_plan_currency($p->price,$p->currency_id)}}
                                                    </span>
                                                    /
                                                    {{\App\CPU\BackEndHelper::set_plan_duration($p->duration,$p->duration_type)}}
                                                </h1>
                                                <hr>
                                                <ul class="fa-ul">
                                                  <li>
                                                    Allowed Number of Products:- 
                                                    <b>
                                                        {{ $p->allowed_products }}
                                                    </b> 
                                                  </li>
                                                  <li>
                                                    Allowed Number of Invoices Per Month:- 
                                                    <b>
                                                        {{\App\CPU\BackEndHelper::set_plan_currency($p->allowed_invoice,$p->currency_id)}}
                                                    </b>
                                                  </li>
                                                  <li>
                                                    Expected Volume Of Business:- <b>
                                                        {{\App\CPU\BackEndHelper::set_plan_currency($p->expected_volume_of_business,$p->currency_id)}}
                                                    </b>
                                                  </li>
                                                </ul>
                                                <div class="d-grid">
                                                    <div class="row myclass">
                                                        <div class="row col-md-12">
                                                            <div class="col-md-3"></div>
                                                            <div class="col-md-6">
                                                                <a class="btn btn-custom" style="color:white !important;padding:-10px !important;" href="{{route('shop.apply')}}/{{$p->id}}" >Buy Plan</a>
                                                            </div>
                                                            <div class="col-md-3"></div>
                                                        </div>
                                                        @if(!empty($p->validOffers) && $p->validOffers->count()>0 && $p->offstatus ==1)

                                                            <div class="col-md-12" style="text-align: right;">
                                                                <button type="button" data-toggle="modal" data-target="#exampleModal_{{$p->id}}" class="btn btn-outline-danger btn-floating" data-mdb-ripple-color="dark" style="border-radius: 1.25rem;transform: rotate(-36deg);">Offer</button> 
                                                            </div>
                                                                    <!-- Modal -->
                                                            <div class="modal fade" id="exampleModal_{{$p->id}}" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                              <div class="modal-dialog" role="document">
                                                                <div class="modal-content">
                                                                  <div class="modal-header">
                                                                    <h5 style="color:white;" class="modal-title text-center" id="exampleModalLabel">{{$p->title}}</h5>
                                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                    </button>
                                                                  </div>
                                                                  <div class="modal-body">
                                                                    @foreach($p->validOffers as $k => $offer)
                                                                        @if(date('Y-m-d') <= $offer->offer_enddate)
                                                                            <p style="color:red;">{{$offer->offer_title}}</p>
                                                                            <h3>{{(($p->price-$offer->new_ammount)/$p->price)*100}}% Off</h3>
                                                                            <h5 style="color:red">{{\App\CPU\BackEndHelper::set_plan_currency($offer->new_ammount,$p->currency_id)}} <sub style="color: #778899;"><del>{{\App\CPU\BackEndHelper::set_plan_currency($p->price,$p->currency_id)}}</del></sub></h5>
                                                                            <p>Offer Starts From {{date("d/m/Y",strtotime($offer->offer_startdate))}}</p>
                                                                            @if(!empty($offer->offer_enddate))
                                                                            <p>to {{date("d/m/Y",strtotime($offer->offer_enddate))}}</p>
                                                                            @endif
                                                                            @if(!empty($offer->note))
                                                                            <p>{{ucfirst($offer->note)}}</p>
                                                                            @endif
                                                                            <div class="row">
                                                                                <div class="col-md-2"></div>
                                                                                <div class="col-md-8">
                                                                                </div>
                                                                                <div class="col-md-2"></div>
                                                                            </div>
                                                                            <hr>
                                                                        @endif
                                                                    @endforeach
                                                                  </div>

                                                                </div>
                                                              </div>
                                                            </div>
                                                        @endif
                                                    </div>
                                                </div>
                                              </div>
                                            </div>
                                          </div>
                                          @endforeach
                                      @else
                                          <div class="col-lg-12" style="margin-top: 10px;margin-bottom: 10px;">
                                            <div class="card mb-5 mb-lg-0">
                                              <div class="card-body">
                                                <h5 class="card-title text-muted text-uppercase text-center">No Seller Plan available now...</h5>
                                              </div>
                                            </div>
                                          </div>
                                      @endif
                                </div>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> 
</div> 
@endsection
@push('script')
@if ($errors->any())
    <script>
        @foreach($errors->all() as $error)
        toastr.error('{{$error}}', Error, {
            CloseButton: true,
            ProgressBar: true
        });
        @endforeach
    </script>
@endif
<script>
    $('#exampleInputPassword ,#exampleRepeatPassword').on('keyup',function () {
        var pass = $("#exampleInputPassword").val();
        var passRepeat = $("#exampleRepeatPassword").val();
        if (pass==passRepeat){
            $('.pass').hide();
        }
        else{
            $('.pass').show();
        }
    });
    $('#apply').on('click',function () {

        var image = $("#image-set").val();
        if (image=="")
        {
            $('.image').show();
            return false;
        }
        var pass = $("#exampleInputPassword").val();
        var passRepeat = $("#exampleRepeatPassword").val();
        if (pass!=passRepeat){
            $('.pass').show();
            return false;
        }


    });
    function Validate(file) {
        var x;
        var le = file.length;
        var poin = file.lastIndexOf(".");
        var accu1 = file.substring(poin, le);
        var accu = accu1.toLowerCase();
        if ((accu != '.png') && (accu != '.jpg') && (accu != '.jpeg')) {
            x = 1;
            return x;
        } else {
            x = 0;
            return x;
        }
    }

    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#viewer').attr('src', e.target.result);
            }

            reader.readAsDataURL(input.files[0]);
        }
    }

    $("#customFileUpload").change(function () {
        readURL(this);
    });

    function readlogoURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#viewerLogo').attr('src', e.target.result);
            }

            reader.readAsDataURL(input.files[0]);
        }
    }

    function readBannerURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#viewerBanner').attr('src', e.target.result);
            }

            reader.readAsDataURL(input.files[0]);
        }
    }

    $("#LogoUpload").change(function () {
        readlogoURL(this);
    });
    $("#BannerUpload").change(function () {
        readBannerURL(this);
    });
</script>
@endpush
