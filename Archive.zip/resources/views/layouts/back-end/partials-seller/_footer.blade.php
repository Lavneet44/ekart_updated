{{-- <footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; Your Website 2020</span>
        </div>
    </div>
</footer> --}}

<div class="footer">
    <div class="row justify-content-between align-items-center">
        <div class="col mt-3">
            <span>{{\App\CPU\translate('Copyright')}} &copy; {{url('/')}} {{date('Y')}}</span>
        </div>
    </div>
</div>
