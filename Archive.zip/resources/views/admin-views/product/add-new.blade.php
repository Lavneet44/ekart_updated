@extends('layouts.back-end.app')

@section('title', \App\CPU\translate('Product Add'))

@push('css_or_js')
    <link href="{{asset('public/assets/back-end/css/tags-input.min.css')}}" rel="stylesheet">
    <link href="{{ asset('public/assets/select2/css/select2.min.css')}}" rel="stylesheet">
    <meta name="csrf-token" content="{{ csrf_token() }}">
@endpush

@section('content')
    <div class="content container-fluid">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{route('admin.dashboard')}}">{{\App\CPU\translate('Dashboard')}}</a>
                </li>
                <li class="breadcrumb-item" aria-current="page"><a
                        href="{{route('admin.product.list', 'in_house')}}">{{\App\CPU\translate('Product')}}</a>
                </li>
                <li class="breadcrumb-item">{{\App\CPU\translate('Add')}} {{\App\CPU\translate('New')}} </li>
            </ol>
        </nav>

        <!-- Content Row -->
        <div class="row">
            <div class="col-md-12">
                <form class="product-form" action="{{route('admin.product.store')}}" method="POST"
                      style="text-align: {{Session::get('direction') === "rtl" ? 'right' : 'left'}};"
                      enctype="multipart/form-data"
                      id="product_form">
                    @csrf
                    <div class="card">
                        <div class="card-header">
                            @php($language=\App\Model\BusinessSetting::where('type','pnc_language')->first())
                            @php($language = $language->value ?? null)
                            @php($default_lang = 'en')

                            @php($default_lang = json_decode($language)[0])
                            <ul class="nav nav-tabs mb-4">
                                @foreach(json_decode($language) as $lang)
                                    <li class="nav-item">
                                        <a class="nav-link lang_link {{$lang == $default_lang? 'active':''}}" href="#"
                                           id="{{$lang}}-link">{{\App\CPU\Helpers::get_language_name($lang).'('.strtoupper($lang).')'}}</a>
                                    </li>
                                @endforeach
                            </ul>
                        </div>

                        <div class="card-body">
                            @foreach(json_decode($language) as $lang)
                                <div class="{{$lang != $default_lang ? 'd-none':''}} lang_form"
                                     id="{{$lang}}-form">
                                    <div class="form-group">
                                        <label class="input-label" for="{{$lang}}_name">{{\App\CPU\translate('name')}}
                                            ({{strtoupper($lang)}})</label>
                                        <input type="text" {{$lang == $default_lang? 'required':''}} name="name[]"
                                               id="{{$lang}}_name" class="form-control" placeholder="New Product" required>
                                    </div>
                                     <div class="form-group">
                                        <div class="row">
                                            <div class="col-md-4">
                                                <label class="input-label" for="{{$lang}}_name">{{\App\CPU\translate('item code')}}
                                                    ({{strtoupper($lang)}})</label>
                                                <input type="text" {{$lang == $default_lang? 'required':''}} name="item_code" id="" class="form-control" placeholder="ex:- ABC123" required>
                                            </div>
                                            <div class="col-md-4">
                                                <label class="input-label" for="{{$lang}}_name">{{\App\CPU\translate('part no')}}
                                                    ({{strtoupper($lang)}})</label>
                                                <input type="text" {{$lang == $default_lang? 'required':''}} name="part_no" id="" class="form-control" placeholder="ex:- A678123">
                                            </div>
                                            <div class="col-md-4">
                                                <label class="input-label" for="{{$lang}}_name">{{\App\CPU\translate('serial no')}}
                                                    ({{strtoupper($lang)}})</label>
                                                <input type="text" {{$lang == $default_lang? 'required':''}} name="serial_no" id="" class="form-control" placeholder="ex:- ABC123" >
                                            </div>
                                        </div>
                                    </div>
                                    <input type="hidden" name="lang[]" value="{{$lang}}">
                                    <div class="form-group pt-4">
                                        <label class="input-label"
                                               for="{{$lang}}_description">{{\App\CPU\translate('description')}}
                                            ({{strtoupper($lang)}})</label>
                                        <textarea name="description[]" class="editor textarea" cols="30"
                                                  rows="10" required>{{old('details')}}</textarea>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    </div>

                    <div class="card mt-2 rest-part">
                        <div class="card-header">
                            <h4>{{\App\CPU\translate('General_info')}}</h4>
                        </div>
                        <div class="card-body">
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-md-4">
                                        <label for="name">{{\App\CPU\translate('Category')}}</label>
                                        <select
                                            class="js-example-basic-multiple form-control"
                                            name="category_id" id="cat_id"
                                            onchange="getRequest('{{url('/')}}/admin/product/get-categories?parent_id='+this.value,'sub-category-select','select',1)"
                                            required>
                                            <option value="{{old('category_id')}}" selected disabled>---{{\App\CPU\translate('Select')}}---</option>
                                            @foreach($allCats as $c)
                                                @if(in_array($c['id'], $allowedIds) && $c['position'] == 0)
                                                <option value="{{$c['id']}}" {{old('name')==$c['id']? 'selected': ''}}>
                                                    {{$c['name']}}
                                                </option>
                                                @endif
                                            @endforeach
                                        </select>
                                    </div>
                                    <div class="col-md-4">
                                        <label for="name">{{\App\CPU\translate('Sub_category')}}</label>
                                        <select class="js-example-basic-multiple form-control"
                                                name="sub_category_id" id="sub-category-select"
                                                onchange="getRequest('{{url('/')}}/admin/product/get-categories?parent_id='+this.value,'sub-sub-category-select','select',2)" required>
                                        </select>
                                    </div>
                                   
                                    <div class="col-md-4">
                                        <label for="name">{{\App\CPU\translate('Sub_sub_category')}}</label>
                                        <select
                                            class="js-example-basic-multiple form-control"
                                            name="sub_sub_category_id" id="sub-sub-category-select">
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="row mt-3">
                                         <div class="col-md-1">
                                      </div>
                                        <div class="col-md-2">
                                            <button type="button" class="btn btn-outline-success btn-lg btn-block pt-2 pb-2" id="blockCategory" onclick="allCatCommonModel(0);"><i style="font-size: 23px;" class="tio-selection" data-toggle="tooltip" data-placement="right" title="Collapse"></i>&nbsp;{{\App\CPU\translate('Select_category')}}</button>
                                        </div>
                                         <div class="col-md-2">
                                      </div>
                                         <div class="col-md-2">
                                        <button type="button" class="btn btn-outline-danger btn-lg btn-block pt-2 pb-2" data-toggle="modal" data-target="#subcategorymodel"><i style="font-size: 23px; width: 20px;" class="tio-add-circle" data-toggle="tooltip" data-placement="right" title="Collapse"></i>
                                            Add
                                          </button>
                                    </div>
                                     <div class="col-md-2">
                                      </div>
                                    <div class="col-md-2">
                                        <button type="button" class="btn btn-outline-danger btn-lg btn-block pt-2 pb-2" data-toggle="modal" onclick="resetform('subsubcategoryform');" data-target="#subsubcategory"><i style="font-size: 23px;" class="tio-add-circle" data-toggle="tooltip" data-placement="right" title="Collapse"></i>
                                            Add
                                          </button>
                                    </div>
                                     <div class="col-md-1">
                                      </div>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="row">
                                    <div class="col-md-6">
                                        <label for="name">{{\App\CPU\translate('Brand')}}</label>
                                        <select 
                                            class="js-example-basic-multiple js-states js-example-responsive form-control"
                                            name="brand_id" id="branddrop" required>
                                            <option value="{{null}}" selected disabled>---{{\App\CPU\translate('Select')}}---</option>
                                            @foreach($br as $b)
                                                @if(in_array($b['id'], $allowedBrandIds))
                                                    <option value="{{$b['id']}}">{{$b['name']}}</option>
                                                @endif
                                            @endforeach
                                        </select>
                                    </div>

                                    <div class="col-md-6">
                                        <label for="name">{{\App\CPU\translate('Unit')}}</label>
                                        <select
                                            class="js-example-basic-multiple js-states js-example-responsive form-control"
                                            name="unit" id="unitsdrop">
                                            <option  value="{{null}}">---{{\App\CPU\translate('Select')}}---</option >
                                            @foreach($unit as $b)
                                            @if(in_array($b['id'], $allowedUnitIds))
                                                <option value="{{$b['id']}}">{{$b['name']}}</option>
                                                 @endif
                                            @endforeach
                                        </select>
                                    </div>

                                    
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="row mt-3">
                                      <div class="col-md-1">
                                      </div>
                                    <div class="col-md-2">
                                        <button type="button" class="btn btn-outline-success btn-lg btn-block pt-2 pb-2" id="blockCategory" onclick="allbrands();"><i style="font-size: 23px;" class="tio-selection" data-toggle="tooltip" data-placement="right" title="Collapse"></i>&nbsp;{{\App\CPU\translate('Select_brand')}}</button>
                                    </div>
                                      <div class="col-md-2">
                                        <button type="button" class="btn btn-outline-danger btn-lg btn-block pt-2 pb-2" data-toggle="modal" data-target="#productbrandModel"><i style="font-size: 23px;" class="tio-add-circle" data-toggle="tooltip" data-placement="right" title="Collapse"></i>
                                            add
                                          </button>
                                    </div>
                                     <div class="col-md-2">
                                      </div>
                                     <div class="col-md-2">
                                        <button type="button" class="btn btn-outline-danger btn-lg btn-block pt-2 pb-2" data-toggle="modal" data-target="#productunitModel"><i style="font-size: 23px;" class="tio-add-circle" data-toggle="tooltip" data-placement="right" title="Collapse"></i>
                                            add
                                          </button>
                                    </div>
                                     <div class="col-md-2">
                                        <button type="button" class="btn btn-outline-success btn-lg btn-block pt-2 pb-2" id="blockunit" onclick="allunits();"><i style="font-size: 23px;" class="tio-selection" data-toggle="tooltip" data-placement="right" title="Collapse"></i>&nbsp;{{\App\CPU\translate('Select_unit')}}</button>
                                    </div>
                                     <div class="col-md-1">
                                      </div>
                                </div>
                            </div>

                        </div>
                    </div>

                  
                    <div class="card mt-2 rest-part">
                        <div class="card-header">
                            <h4>{{\App\CPU\translate('Variations')}}</h4>
                        </div>
                        <div class="card-body">
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-md-6">
                                        <label for="colors">
                                            {{\App\CPU\translate('Colors')}} :
                                        </label>
                                        <label class="switch">
                                            <input type="checkbox" class="status" name="colors_active" value="{{old('colors_active')}}" >
                                            <span class="slider round"></span>
                                        </label>
                                        <select
                                            class="js-example-basic-multiple js-states js-example-responsive form-control color-var-select"
                                            name="colors[]" multiple="multiple" id="colors-selector" disabled>
                                            @foreach (\App\Model\Color::orderBy('name', 'asc')->get() as $key => $color)
                                                <option value="{{ $color->code }}">
                                                    {{$color['name']}}
                                                </option>
                                            @endforeach
                                        </select>
                                    </div>

                                    <div class="col-md-6">
                                        <label for="attributes" style="padding-bottom: 3px">
                                            {{\App\CPU\translate('Attributes')}} :
                                        </label>
                                        <select
                                            class="js-example-basic-multiple js-states js-example-responsive form-control"
                                            name="choice_attributes[]" id="choice_attributes" multiple="multiple">
                                            @foreach (\App\Model\Attribute::orderBy('name', 'asc')->get() as $key => $a)
                                                <option value="{{ $a['id']}}">
                                                    {{$a['name']}}
                                                </option>
                                            @endforeach
                                        </select>
                                    </div>

                                    <div class="col-md-12 mt-2 mb-2">
                                        <div class="customer_choice_options" id="customer_choice_options">

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                  

                        <div class="card mt-2 rest-part">
                        <div class="card-header">
                            <h4>{{\App\CPU\translate('Product_price_&_stock')}}</h4>
                        </div>
                        <!-- onchange="setCurrency(this,'unit_price');" -->
                        <div class="card-body">
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-md-6">
                                        <label class="control-label">{{\App\CPU\translate('Unit_price')}}</label>

                                        <div class="input-group mb-3">
                                          <div class="input-group-prepend">
                                            <span class="input-group-text">{{session('system_default_currency_info')->symbol}}</span>
                                          </div>
                                          <input type="text" id="unit_price"  value="0" placeholder="{{\App\CPU\translate('Unit_price')}}"
                                               name="unit_price" value="{{old('unit_price')}}"  class="form-control cBalance" required>
                                          <div class="input-group-append">
                                            <span class="input-group-text">.{{(!empty(session('system_default_currency_info')->currency_formate))?str_repeat('0',session('system_default_currency_info')->currency_formate):'00'}}</span>
                                          </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <label
                                            class="control-label">{{\App\CPU\translate('Purchase_price')}}</label>
                                        <div class="input-group mb-3">
                                          <div class="input-group-prepend">
                                            <span class="input-group-text">{{session('system_default_currency_info')->symbol}}</span>
                                          </div>
                                          <input type="number" min="0" value="0" step="0.01"
                                               placeholder="{{\App\CPU\translate('Purchase_price')}}"
                                               name="purchase_price" id="purchase_price"
                                                value="{{old('purchase_price')}}"  class="form-control" required>
                                          <div class="input-group-append">
                                            <span class="input-group-text">.{{(!empty(session('system_default_currency_info')->currency_formate))?str_repeat('0',session('system_default_currency_info')->currency_formate):'00'}}</span>
                                          </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                               <div class="pt-4 col-12 sku_combination" id="sku_combination">

                                    </div>
                                   
                                <div class=" pt-1 col-md-6">
                                        <label class="control-label">{{\App\CPU\translate('Tax')}}</label>
                                        <label class="badge badge-info">{{\App\CPU\translate('Percent')}} ( % )</label>
                                        <input type="number" min="0" value="0" step="0.01"
                                               placeholder="{{\App\CPU\translate('Tax')}}" name="tax" value="{{old('tax')}}"
                                               class="form-control">
                                        <input name="tax_type" value="percent" style="display: none">
                                    </div>

                                    <div class=" pt-1 col-md-6" id="quantity">
                                        <label class="control-label">{{\App\CPU\translate('total')}} {{\App\CPU\translate('Quantity')}}</label>
                                        <input type="number" min="0" value="0" step="1"
                                               placeholder="{{\App\CPU\translate('Quantity')}}"
                                               name="current_stock" value="{{old('current_stock')}}" id="current_stock" class="form-control" required>
                                    </div>

                                </div>

                                </div>
                                
                            </div>


                        </div>
                   
                     <div class="card mt-2 rest-part">
                        <div class="card-header">
                            <h4>{{\App\CPU\translate('Discount & Offer')}}</h4>
                        </div>
                        <!-- onchange="setCurrency(this,'unit_price');" -->
                        <div class="card-body">
                            <div class="form-group">
                               

                                <div class="row pt-4">      
                                    <div class="col-md-6">
                                        <label class="control-label">{{\App\CPU\translate('Discount Amount')}}</label>
                                        <div class="input-group mb-3">
                                          <div class="input-group-prepend">
                                            <span class="input-group-text">{{session('system_default_currency_info')->symbol}}</span>
                                          </div>
                                          <input type="text"  value="0" 
                                               placeholder="{{\App\CPU\translate('Discount amount')}}"
                                               name="discoun_amt" id="discoun_amt" onChange="claculatepercentage()"
                                                value="{{old('discount')}}"  class="form-control" >
                                          <div class="input-group-append">
                                             <span class="input-group-text">.{{(!empty(session('system_default_currency_info')->currency_formate))?str_repeat('0',session('system_default_currency_info')->currency_formate):'00'}}</span>
                                          </div>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <label class="control-label">{{\App\CPU\translate('Discount percentage')}}</label>
                                        <input type="text" 
                                               placeholder="{{\App\CPU\translate('Discount percentage')}}" name="dis_percent" id="dis_percent" onChange="claculateamount()" value="{{old('discount')}}"
                                               class="form-control">
                                    </div>
                                    </div>
                                    <div class="row pt-4">
                                     <div class="col-md-3">
                                        <label class="control-label">{{\App\CPU\translate('Start Date')}}</label>
                                        <input type="datetime-local" 
                                               placeholder="{{\App\CPU\translate('Start Date')}}" id="startdate" name="start_date" value="{{old('start_date')}}"
                                               class="form-control">
                                    </div>
                                    <div class="col-md-3">
                                        <label class="control-label">{{\App\CPU\translate('Start time')}}</label>
                                        <input type="datetime-local" 
                                               placeholder="{{\App\CPU\translate('Start time')}}" id="starttime" name="start_time" value="{{old('start_date')}}"
                                               class="form-control">
                                    </div>
                                     <div class="col-md-3">
                                        <label class="control-label">{{\App\CPU\translate('End Date')}}</label>
                                        <input type="datetime-local" 
                                               placeholder="{{\App\CPU\translate('End Date')}}" id="enddate" name="end_date" value="{{old('end_date')}}"
                                               class="form-control">
                                    </div>
                                    <div class="col-md-3">
                                        <label class="control-label">{{\App\CPU\translate('End time')}}</label>
                                        <input type="datetime-local" 
                                               placeholder="{{\App\CPU\translate('End time')}}" id="endtime" name="end_time" value="{{old('end_date')}}"
                                               class="form-control">
                                    </div>
                                </div>
                                

                                <div class="row pt-4">  
                                    <div class="col-md-4">
                                        <label class="control-label">{{\App\CPU\translate('buy')}}</label>
                                        <input type="number" 
                                        placeholder="{{\App\CPU\translate('buy')}}" onchange="freequantity(this)" id="buy" name="buy" value="{{old('buy')}}"
                                        class="form-control">
                                    </div>    
                                    <div class="col-md-4" id="divquantity">
                                        <label class="control-label">{{\App\CPU\translate('free quantity')}}</label>
                                        <input type="number" 
                                               placeholder="{{\App\CPU\translate('quantity')}}" onchange="freequantity(this)" id="quantityinp" name="quantity" value="{{old('quantity')}}"
                                               class="form-control">
                                    </div>
                                     <div class="col-md-4" id="divitem">
                                        <label class="control-label">{{\App\CPU\translate('item')}}</label>
                                        <input type="text" 
                                               placeholder="{{\App\CPU\translate('item')}}" onchange="freequantity(this)" id="item" name="item" value="{{old('item')}}"
                                               class="form-control">
                                    </div>
                                    
                                </div>
                               
                            </div>


                        </div>
                    </div>

                    <div class="card mt-2 mb-2 rest-part">
                        <div class="card-header">
                            <h4>{{\App\CPU\translate('seo_section')}}</h4>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-12 mb-4">
                                    <label class="control-label">{{\App\CPU\translate('Meta Title')}}</label>
                                    <input type="text" name="meta_title" placeholder="" class="form-control">
                                </div>

                                <div class="col-md-8 mb-4">
                                    <label class="control-label">{{\App\CPU\translate('Meta Description')}}</label>
                                    <textarea rows="10" type="text" name="meta_description" class="form-control"></textarea>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group mb-0">
                                        <label>{{\App\CPU\translate('Meta Image')}}</label>
                                    </div>
                                    <div class="border border-dashed">
                                        <div class="row" id="meta_img"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card mt-2 rest-part">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-12 mb-4">
                                    <label class="control-label">{{\App\CPU\translate('Youtube video link')}}</label>
                                    <small class="badge badge-soft-danger"> ( {{\App\CPU\translate('optional, please provide embed link not direct link')}}. )</small>
                                    <input type="text" name="video_link" placeholder="{{\App\CPU\translate('EX')}} : https://www.youtube.com/embed/5R06LRdUCSE" class="form-control" required>
                                </div>

                                <div class="col-md-8">
                                    <div class="form-group">
                                        <label>{{\App\CPU\translate('Upload product images')}}</label><small
                                            style="color: red">* ( {{\App\CPU\translate('ratio')}} 1:1 )</small>
                                    </div>
                                    <div class="p-2 border border-dashed" style="max-width:430px;">
                                        <div class="row" id="coba"></div>
                                    </div>

                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="name">{{\App\CPU\translate('Upload thumbnail')}}</label><small
                                            style="color: red">* ( {{\App\CPU\translate('ratio')}} 1:1 )</small>
                                    </div>
                                    <div style="max-width:200px;">
                                        <div class="row" id="thumbnail"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card card-footer">
                        <div class="row">
                            <div class="col-md-12" style="padding-top: 20px">
                                <button type="button" onclick="check()" class="btn btn-primary">{{\App\CPU\translate('Submit')}}</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="modal fade" id="subcategorymodel" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Sub Category</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="" method="POST" name="subcategory" id="subcategoryform">
      <div class="modal-body">
            @csrf
            <input type="hidden" name="subcat_product_belong_to_user" value="{{auth('admin')->id()}}">
            <input type="hidden" name="subcat_product_belong_to_usertype" value="admin">

            @php($language=\App\Model\BusinessSetting::where('type','pnc_language')->first())
            @php($language = $language->value ?? null)
            @php($default_lang = 'en')
            @php($default_lang = json_decode($language)[0])
            <ul class="nav nav-tabs mb-4">
                @foreach(json_decode($language) as $lang)
                    <li class="nav-item">
                        <a class="nav-link lang_link {{$lang == $default_lang? 'active':''}}"
                           href="#"
                           id="{{$lang}}-link">{{\App\CPU\Helpers::get_language_name($lang).'('.strtoupper($lang).')'}}</a>
                    </li>
                @endforeach
            </ul>
            <div class="row">
                <div class="col-6">
                    @foreach(json_decode($language) as $lang)
                        <div class="form-group {{$lang != $default_lang ? 'd-none':''}} lang_form"
                             id="{{$lang}}-form">
                            <label class="input-label"
                                   for="exampleFormControlInput1">{{\App\CPU\translate('sub_category')}} {{\App\CPU\translate('name')}}
                                ({{strtoupper($lang)}})</label>
                            <input type="text" name="name[]" class="form-control"
                                   placeholder="{{\App\CPU\translate('New')}} {{\App\CPU\translate('Sub_Category')}}" {{$lang == $default_lang? 'required':''}}>
                        </div>
                        <input type="hidden" name="lang[]" value="{{$lang}}">
                    @endforeach
                    <input name="position" value="1" style="display: none">
                </div>
                <div class="col-6">
                    <div class="form-group">
                        <label class="input-label"
                               for="exampleFormControlSelect1">{{\App\CPU\translate('main')}} {{\App\CPU\translate('category')}}
                            <span class="input-label-secondary">*</span></label>
                        <select id="exampleFormControlSelect1" name="parent_id"
                                class="form-control" required>
                                <option value="">--{{\App\CPU\translate('select')}}--</option>
                            @foreach($allCats as $category)
                                @if(in_array($category['id'], $allowedIds) && $category['position'] == 0)
                                    <option value="{{$category['id']}}">{{$category['name']}}</option>
                                @endif
                            @endforeach
                        </select>
                    </div>
                </div>
            </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-danger">{{\App\CPU\translate('submit')}}</button>
      </div>
      </form>
    </div>
  </div>
</div>

<div class="modal fade" id="subsubcategory" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Sub Sub Category</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="" name="subsubcategory" id="subsubcategoryform" method="POST">
      <div class="modal-body">
            @csrf
             <input type="hidden" name="subsubcat_product_belong_to_user" value="{{auth('admin')->id()}}">
        <input type="hidden" name="subsubcat_product_belong_to_usertype" value="admin">
            @php($language=\App\Model\BusinessSetting::where('type','pnc_language')->first())
            @php($language = $language->value ?? null)
            @php($default_lang = 'en')
            @if($language)
                @php($default_lang = json_decode($language)[0])
                <ul class="nav nav-tabs mb-4">
                    @foreach(json_decode($language) as $lang)
                        <li class="nav-item">
                            <a class="nav-link lang_link {{$lang == $default_lang? 'active':''}}"
                               href="#"
                               id="{{$lang}}-link">{{\App\CPU\Helpers::get_language_name($lang).'('.strtoupper($lang).')'}}</a>
                        </li>
                    @endforeach
                </ul>
                <div class="row">
                    @foreach(json_decode($language) as $lang)
                        <div
                            class="col-12 form-group {{$lang != $default_lang ? 'd-none':''}} lang_form"
                            id="{{$lang}}-form">
                            <label class="input-label"
                                   for="exampleFormControlInput1">{{\App\CPU\translate('Sub_sub_category')}} {{\App\CPU\translate('name')}}
                                ({{strtoupper($lang)}})</label>
                            <input type="text" name="name[]" class="form-control"
                                   placeholder="{{\App\CPU\translate('New_Sub_Sub_Category')}}" {{$lang == $default_lang? 'required':''}}>
                        </div>
                        <input type="hidden" name="lang[]" value="{{$lang}}">
                    @endforeach
                    @else
                        <div class="col-12">
                            <div class="form-group lang_form" id="{{$default_lang}}-form">
                                <label
                                    class="input-label">{{\App\CPU\translate('Sub_sub_category')}} {{\App\CPU\translate('name')}}
                                    ({{strtoupper($lang)}})</label>
                                <input type="text" name="name[]" class="form-control"
                                       placeholder="{{\App\CPU\translate('New_Sub_Category')}}" required>
                            </div>
                            <input type="hidden" name="lang[]" value="{{$default_lang}}">
                        </div>
                    @endif

                    <div class="col-6">
                        <div class="form-group">
                            <label
                                class="input-label">{{\App\CPU\translate('main')}} {{\App\CPU\translate('category')}}
                                <span class="input-label-secondary">*</span></label>
                            <select class="form-control" id="sub_sub_cat_id" required>
                                <option value="0">---{{\App\CPU\translate('select')}}---</option>
                                @foreach($allCats as $category)
                                    @if(in_array($category['id'], $allowedIds) && $category['position'] == 0)
                                        <option value="{{$category['id']}}">{{$category['name']}}</option>
                                    @endif
                                @endforeach
                            </select>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <label
                            for="name">{{\App\CPU\translate('sub_category')}} {{\App\CPU\translate('name')}}</label>
                        <select name="parent_id" id="parent_id" class="form-control" required>

                        </select>
                    </div>
                </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-danger">{{\App\CPU\translate('submit')}}</button>
      </div>
      </form>
    </div>
  </div>
</div>

<div class="modal fade" id="productbrandModel" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">{{\App\CPU\translate('Add_Brand')}}</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="{{route('admin.brand.add-brand')}}" name="addproductbrandform" id="idproductbrandform" method="POST"  enctype="multipart/form-data">
      <div class="modal-body">
            @csrf
                <input type="hidden" name="product_belong_to_user"  value="{{auth('admin')->id()}}">
                 <input type="hidden" name="product_belong_to_usertype"  value="admin">
                @php($language=\App\Model\BusinessSetting::where('type','pnc_language')->first())
                @php($language = $language->value ?? null)
                @php($default_lang = 'en')

                @php($default_lang = json_decode($language)[0])
                <ul class="nav nav-tabs mb-4">
                    @foreach(json_decode($language) as $lang)
                        <li class="nav-item">
                            <a class="nav-link lang_link {{$lang == $default_lang? 'active':''}}"
                                href="#"
                                id="{{$lang}}-link">{{\App\CPU\Helpers::get_language_name($lang).'('.strtoupper($lang).')'}}</a>
                        </li>
                    @endforeach
                </ul>
                <div class="row">
                    <div class="col-md-6">
                        @foreach(json_decode($language) as $lang)
                            <div class="form-group {{$lang != $default_lang ? 'd-none':''}} lang_form"
                                    id="{{$lang}}-form">
                                <label for="name">{{ \App\CPU\translate('name')}} ({{strtoupper($lang)}})</label>
                                <input type="text" name="name[]" class="form-control" id="checkbrandname" value="{{old('name')}}" placeholder="{{\App\CPU\translate('Ex')}} : {{\App\CPU\translate('LUX')}}" {{$lang == $default_lang? 'required':''}}>
                            </div>
                            <input type="hidden" name="lang[]" value="{{$lang}}">
                        @endforeach
                        <div class="form-group">
                            <label for="name">{{ \App\CPU\translate('brand_logo')}}</label><span class="badge badge-soft-danger">( {{\App\CPU\translate('ratio')}} 1:1 )</span>
                            <div class="custom-file" style="text-align: left" required>
                                <input type="file" name="image" id="customFileUpload" class="custom-file-input"
                                    accept=".jpg, .png, .jpeg, .gif, .bmp, .tif, .tiff|image/*">
                                <label class="custom-file-label" for="customFileUpload">{{\App\CPU\translate('choose')}} {{\App\CPU\translate('file')}}</label>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <center>
                            <img style="border-radius: 10px; max-height:200px;" id="viewer"
                                src="{{asset('public\assets\back-end\img\400x400\img2.jpg')}}" alt="banner image"/>
                        </center>
                    </div>
                </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-danger">{{\App\CPU\translate('submit')}}</button>
      </div>
      </form>
    </div>
  </div>
</div>

<div class="modal fade" id="productunitModel" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">{{\App\CPU\translate('Add_Brand')}}</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="{{route('admin.unit.add-unit')}}" name="productunitform" id="idproductunitform" method="POST"  enctype="multipart/form-data">
      <div class="modal-body">
            @csrf
              <input type="hidden" name="product_belong_to_user"  value="{{auth('admin')->id()}}"> 
              <input type="hidden" name="product_belong_to_usertype"  value="admin">
                @php($language=\App\Model\BusinessSetting::where('type','pnc_language')->first())
                @php($language = $language->value ?? null)
                @php($default_lang = 'en')

                @php($default_lang = json_decode($language)[0])
                <ul class="nav nav-tabs mb-4">
                    @foreach(json_decode($language) as $lang)
                        <li class="nav-item">
                            <a class="nav-link lang_link {{$lang == $default_lang? 'active':''}}"
                                href="#"
                                id="{{$lang}}-link">{{\App\CPU\Helpers::get_language_name($lang).'('.strtoupper($lang).')'}}</a>
                        </li>
                    @endforeach
                </ul>
                <div class="row">
                    <div class="col-md-12">
                        @foreach(json_decode($language) as $lang)
                            <div class="form-group {{$lang != $default_lang ? 'd-none':''}} lang_form"
                                    id="{{$lang}}-form">
                                <label for="name">{{ \App\CPU\translate('Units')}} ({{strtoupper($lang)}})</label>
                                <input type="text" name="name" class="form-control" id="Checkname" value="{{old('name')}}" placeholder="{{\App\CPU\translate('Ex')}} : {{\App\CPU\translate('Kilogram')}}" {{$lang == $default_lang? 'required':''}}>
                            </div>
                            <div class="form-group {{$lang != $default_lang ? 'd-none':''}} lang_form"
                                    id="{{$lang}}-form">
                                <label for="name">{{ \App\CPU\translate('Units')}} ({{strtoupper($lang)}})</label>
                                <input type="text" name="symbol" class="form-control" id="symbol" value="{{old('symbol')}}" placeholder="{{\App\CPU\translate('Ex')}} : {{\App\CPU\translate('Kg')}}" {{$lang == $default_lang? 'required':''}}>
                            </div>
                            <input type="hidden" name="lang[]" value="{{$lang}}">
                        @endforeach
                       
                    </div>
                   
                </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-danger">{{\App\CPU\translate('submit')}}</button>
      </div>
      </form>
    </div>
  </div>
</div>

<div class="modal" id="modelblockCategory" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document" style="max-width: 1000px;">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">{{\App\CPU\translate('Select_items')}}</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>

        <form action="" method="POST" name="blockcat">
          <div class="modal-body">
                  <div class="modal-body">
                        <span class="text-info">{{\App\CPU\translate('Note')}}</span>:-<span class="text-danger">{{\App\CPU\translate('please_select_that_category_subcategory_subsubcategory_that_you_want_to_add_to_your_portfolio')}}</span>
                        <br/>
                        <span class="text-danger" id="alert" style="font-size: 16px;">
                        </span>
                        <br/>
                        @csrf
                        <input type="hidden" name="product_belong_to_user" id="product_belong_to_user" value="{{auth('admin')->id()}}">
                        <input type="hidden" name="product_belong_to_usertype" id="product_belong_to_usertype" value="admin">
                        <input type="hidden" name="position" id="checkboxposition">
                        <div class="row mb-5">
                            <div class="col-md-4"><b class="text-warning">Category</b></div><div class="col-md-4"><b class="text-warning">Sub-category</b></div><div class="col-md-4"><b class="text-warning">Sub-sub-category</b></div>
                        </div>
                        <div class="row">
                            <div id="checkboxid" class="col-md-4">
                                <!-- body comming from jquery -->
                            </div>
                            <div id="subChild" class="col-md-4">
                                <!-- body comming from jquery -->
                            </div>
                            <div id="subSubChild" class="col-md-4">
                                <!-- body comming from jquery -->
                            </div>
                        </div>
                  </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" id="catsubbutton" class="btn btn-success">{{\App\CPU\translate('Select')}}</button>
          </div>
        </form>
    </div>
  </div>
</div>

<div class="modal brandclose" id="modelallowedBrand" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document" style="max-width: 1000px;">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">{{\App\CPU\translate('Select_items')}}</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
        <form action="" method="" name="selectedBrands">
          <div class="modal-body">
                  <div class="modal-body">
                        <span class="text-info">{{\App\CPU\translate('Note')}}</span>:-<span class="text-danger">{{\App\CPU\translate('please_select_that_brands_that_you_want_to_add_to_your_portfolio')}}</span>
                        <br/>
                        <span class="text-danger"  id="alert2"></span>
                        <span id="statusofaction"></span>
                        <br/>
                        <br/>
                        @csrf
                        <input type="hidden" name="product_belong_to_user"  value="{{auth('admin')->id()}}"> 
                        <input type="hidden" name="product_belong_to_usertype"  value="admin">
                        <div class="row">
                        <div class="col-md-4">
                        <input id="myInput" class="form-control" type="text" placeholder="Search..">
                        </div>
                        </div>
                <br><br>
                        <label><input type="checkbox"  id="checkallbrands" > <b class="text-warning">check all</b></label>
                   
                        <div class="row" id="branddata">
                        </div>
                  </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-success">{{\App\CPU\translate('Select')}}</button>
          </div>
        </form>
    </div>
  </div>
</div>

<div class="modal brandclose" id="modelallowedunit" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document" style="max-width: 1000px;">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">{{\App\CPU\translate('Select_items')}}</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
        <form action="" method="" name="selectedUnits">
          <div class="modal-body">
                  <div class="modal-body">
                        <span class="text-info">{{\App\CPU\translate('Note')}}</span>:-<span class="text-danger">{{\App\CPU\translate('please_select_that_brands_that_you_want_to_add_to_your_portfolio')}}</span>
                        <br/>
                        <span class="text-danger"  id="alert3"></span>
                        <span id="statusofaction"></span>
                        <br/>
                        <br/>
                        @csrf
                        <input type="hidden" name="product_belong_to_user"  value="{{auth('admin')->id()}}"> <input type="hidden" name="product_belong_to_usertype"  value="admin">
                        <div class="row">
                            <div class="col-md-4">
                            <input id="myInput" class="form-control" type="text" placeholder="Search..">
                            </div>
                        </div>
                <br><br>
                        <label><input type="checkbox"  id="checkallunits" > <b class="text-warning">check all</b></label>
                   
                        <div class="row" id="unitdata">
                        </div>
                  </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-success">{{\App\CPU\translate('Select')}}</button>
          </div>
        </form>
    </div>
  </div>
</div>

@endsection

@push('script')
   <script src="{{asset('public/assets/back-end')}}/js/tags-input.min.js"></script>
    <script src="{{ asset('public/assets/select2/js/select2.min.js')}}"></script>
    <script src="{{asset('public/assets/back-end/js/spartan-multi-image-picker.js')}}"></script>
    <script src="{{asset('/')}}vendor/ckeditor/ckeditor/ckeditor.js"></script>
    <script src="{{asset('/')}}vendor/ckeditor/ckeditor/adapters/jquery.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <script type="text/javascript">
          $("#starttime").attr('disabled', true);
          $("#enddate").attr('disabled', true);
          $("#endtime").attr('disabled', true);

          function checkuniamtfordis(){
            var unitPrice = $('#unit_price').val();
            var disAmmount = $('#discoun_amt').val();
            if(unitPrice != 0){
                if(parseInt(disAmmount)>parseInt(unitPrice)){
                    $('#discoun_amt').val('');
                    $('#dis_percent').val('').focus();
                    swal.fire({
                        icon: 'error',
                        html: '<h5 style="color:red">Discounted amount should always be less than unit price</h5>'
                    });
                    stop();
                }
            }
            else{
                 swal.fire({
                    icon: 'error',
                    html: '<h5 style="color:red">Please fill the unit price</h5>'
                });
                 $('#discoun_amt').val('');
                 $('#dis_percent').val('');
                 stop();
            }
       }
        
        function claculateamount()
        {
            var unitPrice = $('.cBalance').val();
            var disAmmount = $('#dis_percent').val();
            var result = (disAmmount/100)*unitPrice;
            $('#discoun_amt').val((result).toFixed(2));
            checkuniamtfordis();
        }
        function claculatepercentage()
        {
            var unitPrice = $('.cBalance').val();
            var disAmmount = $('#discoun_amt').val();
            var result = (disAmmount/unitPrice)*100;
            $('#dis_percent').val((result).toFixed(2));
            checkuniamtfordis();
        }

        function freequantity(that) {

            var buy = $("#buy");
            var current_stock = $('#current_stock');
            var quantityOrItem = $(that);
            if(buy.val()==0 && quantityOrItem.val()>0)
            {
                quantityOrItem.val('');
                buy.focus();
                Swal.fire({
                    icon: 'error',
                    title: 'Current Stock',
                    html: '<h5 style="color:red">Please Fill buy quantity field First</h5>'
                });
            }
            if((parseInt(current_stock.val())+1) <= parseInt(buy.val())){
                $("#quantityinp").prop('readonly', true);
                $("#item").prop('readonly', true); 
                buy.val('').focus(); 
                Swal.fire({
                    icon: 'error',
                    title: 'Current Stock',
                    html: '<h5 style="color:red">Value In Buy filed Should be less Than Total Stock</h5>'
                });
            }else{
                $("#quantityinp").removeAttr('readonly');
                $("#item").removeAttr('readonly'); 
            }
        }

        flatpickr("#startdate",{
            //enableTime: true,
            dateFormat: "Y-m-d",
            minDate: "today",
            onChange : function()
            {
                $("#starttime").attr('disabled', false);
            }
        });

        flatpickr("#starttime",{
            enableTime: true,
            noCalendar: true,
            dateFormat: "H:i",
            defaultDate: "00:00",
            onChange : function() {
                $("#enddate").attr('disabled', false);
            }
        });

        flatpickr("#enddate",{           
            //enableTime: true,
            minDate: "today",
            dateFormat: "Y-m-d",
            onChange : function() {
                $("#endtime").attr('disabled', false);
                // $("#endtime").prop('required', true);
            }
        });
        flatpickr("#endtime",{
            enableTime: true,
            noCalendar: true,
            dateFormat: "H:i",
            defaultDate: "11:00",
            onChange : function() {
                toValidateForStartEndDate(this);
            }
        });

        function toValidateForStartEndDate(that)
        {
                var staDate = $('#startdate').val();
                var staTim = $('#starttime').val();
                var endDate = $('#enddate').val();
                var endTim = $('#endtime').val();

           var staDat = staDate+' '+staTim;
           var endDat = endDate+' '+endTim;

            if(staDat.length<1 && endDat.length>0){
                swal.fire({
                    icon: 'error',
                    html: '<h5 style="color:red">Please fill the start date first!</h5>'
                });
                 $('#enddate').val('');
                 $('#endtime').val('');
            }
               if(endDat.length>0){
                 if (staDat > endDat) {
                  swal.fire({
                    icon: 'error',
                    html: '<h5 style="color:red">end date shoud be greater than start date</h5>'
                });
                  $('#enddate').val('');
                  $('#endtime').val('');
                }
            }
    }

       
// ------------------------------------START UNIT CODE 07/06/20222------------------------------------------

   
    $(document).ready(function(){

      

        $("#quantityinp").prop('readonly', true);
        $("#item").prop('readonly', true);
        
        $('.navbar-vertical-aside-has-menu').click(function(){
            var className = $(this).attr("class");
            console.log(className);
            var RequiredClass = 'show';
            if(className.indexOf(RequiredClass) != -1){
                $(this).removeClass(RequiredClass);
            }else{
                $(this).addClass(RequiredClass);
            }
        });
    });

   $("form[name='selectedUnits']").validate({
             rules: {
                'checkboxs[]': {
                    required:true
                }
            },
            errorPlacement: function(error,element){
                error.appendTo('#alert3');
            },
            messages: {
                'checkboxs[]' :{ 
                    required:"Please check at least 1 box"
                }
            },
            submitHandler: function(form) {
              var url = '{{route('admin.product.selected-units-add')}}';
              var form_data = new FormData(form);
              $.ajax({
                    url: url,
                    type: 'POST',
                    processData: false,
                    contentType: false,
                    data: form_data,
                    success: function(result){
                        var status = result.status;
                        var data = result.unit;

                        //--to update all brand along with newly added brand--//
                        if(status==1)
                        {
                            var options;
                            options='<option value="" selected>---Select---</option>';
                            options+= $.map(data, function (a) { 
                                return '<option value="' + a.id + '">' + a.name + '</option>';
                            });
                            $('#unitsdrop').html('');
                            $('#unitsdrop').append(options);
                            
                            $("#idproductunitform")[0].reset();
                            //--to update all brand along with newly added brand--//

                            Swal.fire({
                              icon: 'success',
                              title: 'Add unit',
                              text: 'unit Added successfully',
                            }).then(function(){ 
                               allunits();
                               setTimeout(function(){
                                    $('#modelallowedunit').modal('hide');
                                    $('#unitsubbutton').attr('disabled',false);
                                }, 2000);
                               
                            });
                        }else{
                            Swal.fire({
                              icon: 'error',
                              title: 'Oops',
                              text: 'Oops! Problem with unit add',
                            });
                        }
                    }
                });
            }
        });

     $("form[name='productunitform']").validate({
            rules: {
            },
            messages: {
            },

            submitHandler: function(form) {
              var url = '{{route('admin.unit.add-unit')}}';
              var form_data = new FormData(form);
              $.ajax({
                url: url,
                type: 'POST',
                processData: false,
                contentType: false,
                data: form_data,
                success: function(result){
                    console.log(result);

                    var data = result.unit;
                    var status = result.status;
                    var allUnit = result.allUnit;
                    var allowedUnitIds = result.allowedUnitIds;

                    if(status==1)
                    {
                        var options;
                        options='<option value="" selected>---Select---</option>';
                        options+= $.map(data, function (a) { 
                            return '<option value="' + a.id + '">' + a.name + '</option>';
                        });
                        $('#unitsdrop').html('');
                    }
                    $('#unitsdrop').append(options);
                    $("#idproductunitform")[0].reset();
                    $('#productunitModel').modal('toggle');
                    $('#modelallowedunit').modal('show');
                       var allowedUnit = $.map(allUnit, function (b, index) { 
                            var structure='';
                            structure+='<div  class="col-md-4">';
                            if(jQuery.inArray(b.id, allowedUnitIds) === -1){
                                    structure+='<div class="form-check"><input class="form-check-input" type="checkbox" name="checkboxs[]" value="' + b.id + '" id="flexCheckDefault" /><label class="form-check-label" for="flexCheckDefault">' + b.name + '</label></div>';
                            }else{
                                structure+='<div class="form-check"><input class="form-check-input" type="checkbox" name="checkboxs[]" checked value="' + b.id + '" id="flexCheckDefault" /><label class="form-check-label" for="flexCheckDefault">' + b.name + '</label></div>';
                            }
                            structure+='</div>';
                            return structure;
                        });
                        console.log({allowedUnit});
                        
                        $('#unitdata').empty().append(allowedUnit);


                       setTimeout(function(){
                            $('#productunitModel').modal('hide');
                            $('#modelallowedunit').modal('hide');
                            $("#idproductunitform")[0].reset();
                            $('#productunitform').attr('disabled',false);
                        }, 2000);
                }
              });
               
            }
        });



 $('#checkallunits').prop('checked', false);
        $('#checkallunits').click(function () {    
            $('.unitcommancheck').prop('checked', this.checked);    
        });

 $("#myInputunit").on("keyup", function() {
                var value = $(this).val().toLowerCase();
                $("#unitdata .col-md-4").filter(function() {
                  $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                });
            });

        function allunits(){
            $('#checkallunits').prop('checked', false);
            var data = '';var status = '';var allUnit = '';var allowedUnitIds = '';
            var url = "{{url('admin/product/get-unit')}}"
                $.ajax({
                    type: 'get',
                    url: url,
                    success: function (result) {
                        console.log(result);
                        data = result.unit;
                        status = result.status;
                        allUnit = result.allUnit;
                        allowedUnitIds = result.allowedUnitIds;
                        $('#modelallowedunit').modal('show');
                        var allowedunit = $.map(allUnit, function (b, index) { 
                            var structure='';
                            structure+='<div  class="col-md-4">';
                            if(jQuery.inArray(b.id, allowedUnitIds) === -1){
                                    structure+='<div class="form-check"><input class="form-check-input unitcommancheck" type="checkbox" name="checkboxs[]" value="' + b.id + '" id="flexCheckDefault" /><label class="form-check-label" for="flexCheckDefault">' + b.name + '</label></div>';
                            }else{
                                structure+='<div class="form-check"><input class="form-check-input unitcommancheck" type="checkbox" name="checkboxs[]" checked value="' + b.id + '" id="flexCheckDefault" /><label class="form-check-label" for="flexCheckDefault">' + b.name + '</label></div>';
                            }
                            structure+='</div>';
                            return structure;
                        });
                        console.log({allowedunit});
                        $('#unitdata').empty().append(allowedunit);
                    }
                });
        }



        // ------------------------------------END UNIT CODE 07/06/20222------------------------------------------

           $(document).ready(function() {
          
           
            $("#myInput").on("keyup", function() {
                var value = $(this).val().toLowerCase();
                $("#branddata .col-md-4").filter(function() {
                  $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                });
            });

            // color select select2
            $('.color-var-select').select2({
                templateResult: colorCodeSelect,
                templateSelection: colorCodeSelect,
                escapeMarkup: function (m) {
                    return m;
                }
            });

            function colorCodeSelect(state) {
                var colorCode = $(state.element).val();
                if (!colorCode) return state.text;
                return "<span class='color-preview' style='background-color:" + colorCode + ";'></span>" + state.text;
            }
        });


        $('#checkallbrands').prop('checked', false);
        $('#checkallbrands').click(function () {    
            $('.brandcommancheck').prop('checked', this.checked);    
        });
        
        
    
        

        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#viewer').attr('src', e.target.result);
                }

                reader.readAsDataURL(input.files[0]);
            }
        }

        $("#customFileUpload").change(function () {
            readURL(this);
        });

        $(function () {
            $("#coba").spartanMultiImagePicker({
                fieldName: 'images[]',
                maxCount: 4,
                rowHeight: 'auto',
                groupClassName: 'col-6',
                maxFileSize: '',
                placeholderImage: {
                    image: '{{asset('public/assets/back-end/img/400x400/img2.jpg')}}',
                    width: '100%',
                },
                dropFileLabel: "Drop Here",
                onAddRow: function (index, file) {

                },
                onRenderedPreview: function (index) {

                },
                onRemoveRow: function (index) {

                },
                onExtensionErr: function (index, file) {
                    toastr.error('{{\App\CPU\translate('Please only input png or jpg type file')}}', {
                        CloseButton: true,
                        ProgressBar: true
                    });
                },
                onSizeErr: function (index, file) {
                    toastr.error('{{\App\CPU\translate('File size too big')}}', {
                        CloseButton: true,
                        ProgressBar: true
                    });
                }
            });

            $("#thumbnail").spartanMultiImagePicker({
                fieldName: 'image',
                maxCount: 1,
                rowHeight: 'auto',
                groupClassName: 'col-12',
                maxFileSize: '',
                placeholderImage: {
                    image: '{{asset('public/assets/back-end/img/400x400/img2.jpg')}}',
                    width: '100%',
                },
                dropFileLabel: "Drop Here",
                onAddRow: function (index, file) {

                },
                onRenderedPreview: function (index) {

                },
                onRemoveRow: function (index) {

                },
                onExtensionErr: function (index, file) {
                    toastr.error('{{\App\CPU\translate('Please only input png or jpg type file')}}', {
                        CloseButton: true,
                        ProgressBar: true
                    });
                },
                onSizeErr: function (index, file) {
                    toastr.error('{{\App\CPU\translate('File size too big')}}', {
                        CloseButton: true,
                        ProgressBar: true
                    });
                }
            });

            $("#meta_img").spartanMultiImagePicker({
                fieldName: 'meta_image',
                maxCount: 1,
                rowHeight: '280px',
                groupClassName: 'col-12',
                maxFileSize: '',
                placeholderImage: {
                    image: '{{asset('public/assets/back-end/img/400x400/img2.jpg')}}',
                    width: '90%',
                },
                dropFileLabel: "Drop Here",
                onAddRow: function (index, file) {

                },
                onRenderedPreview: function (index) {

                },
                onRemoveRow: function (index) {

                },
                onExtensionErr: function (index, file) {
                    toastr.error('{{\App\CPU\translate('Please only input png or jpg type file')}}', {
                        CloseButton: true,
                        ProgressBar: true
                    });
                },
                onSizeErr: function (index, file) {
                    toastr.error('{{\App\CPU\translate('File size too big')}}', {
                        CloseButton: true,
                        ProgressBar: true
                    });
                }
            });
        });

        $(".js-example-theme-single").select2({
            theme: "classic"
        });

        $(".js-example-responsive").select2({
            width: 'resolve'
        });

        function resetform(formid)
        {
            $("#"+formid+' #parent_id').html('');
        }
        function allCatCommonModel(position) {
            
            //ajax data variables
            var dataAllowedIds,dataAllCats = '';
            //operational variables
            var ids,allcategory,chackedSubCategory,chackedSubSubCategory = '';

            var url = "{{url('admin/product/get-seller-cat-data')}}"
                $.ajax({
                    type: 'get',
                    url: url,
                    success: function (result) {

                        console.log(result);
                        dataAllowedIds = result.allowedIds;
                        dataAllCats = result.allCats;
                        $('#modelblockCategory').modal('show');
                        ids = $.map(dataAllowedIds, function (sub) { 
                            return parseInt(sub);
                        });

                        allcategory = $.map(dataAllCats, function (val, index) { 
                            if(parseInt(val.position)==0){
                                return {
                                    id : parseInt(val.id),
                                    catName : val.name,
                                    position : val.position
                                }
                            }
                        });

                        chackedSubCategory = $.map(dataAllCats, function (val, index) {
                            if(parseInt(val.position)==1){
                                return {
                                    id : parseInt(val.id),
                                    catName : val.name,
                                    position : val.position,
                                    parentid : val.parent_id
                                }
                            }
                        });
                        
                        chackedSubSubCategory = $.map(dataAllCats, function (val, index) {
                            if(parseInt(val.position)==2){
                                return {
                                    id : parseInt(val.id),
                                    catName : val.name,
                                    position : val.position,
                                    parentid : val.parent_id
                                }
                            }
                        });

                        var allowedCategory = $.map(allcategory, function (c) { 
                            if(jQuery.inArray(c.id, ids) === -1){
                                return '<div class="form-check"><input class="form-check-input" type="checkbox" name="checkboxs[]" data-position="'+ c.position +'" onclick="getsubchild(this);" value="' + c.id + '" id="flexCheckDefault" /><label class="form-check-label" for="flexCheckDefault">' + c.catName + '</label></div>';
                            }else{
                                return '<div class="form-check"><input class="form-check-input" type="checkbox" name="checkboxs[]" data-position="'+ c.position +'" onclick="getsubchild(this);" checked value="' + c.id + '" id="flexCheckDefault" /><label class="form-check-label" for="flexCheckDefault">' + c.catName + '</label></div>';
                            }
                        });
                        var allowedSubCategory = $.map(chackedSubCategory, function (sc) { 
                            if(jQuery.inArray(sc.id, ids) !== -1)
                            {
                                return '<div margin-block-end:-1px; class="form-check parent_'+ sc.parentid +'"><input class="form-check-input" type="checkbox" name="checkboxs[]" data-position="'+ sc.position +'" onclick="getsubchild(this);" checked value="' + sc.id + '" id="flexCheckDefault" /><label class="form-check-label" for="flexCheckDefault">' + sc.catName + '</label></div>';
                            }
                        });
                        var allowedSubSubCategory = $.map(chackedSubSubCategory, function (ssc) { 
                            if(jQuery.inArray(ssc.id, ids) !== -1)
                            {
                                return '<div class="form-check parent_'+ ssc.parentid +'"><input class="form-check-input" type="checkbox" name="checkboxs[]" data-position="'+ ssc.position +'" onclick="getsubchild(this);" checked value="' + ssc.id + '" id="flexCheckDefault" /><label class="form-check-label" for="flexCheckDefault">' + ssc.catName + '</label></div>';
                            }
                        });

                        $('#checkboxposition').empty().val(position);
                        $('#checkboxid').empty().append(allowedCategory);
                        $('#subChild').empty().append(allowedSubCategory);
                        $('#subSubChild').empty().append(allowedSubSubCategory);
                    }
                });
        }

        function allbrands(){
           
            $('#checkallbrands').prop('checked', false);
            var data = '';var status = '';var allBrand = '';var allowedBrandIds = '';
            var url = "{{url('admin/product/get-latestbrand')}}"
                $.ajax({
                    type: 'get',
                    url: url,
                    success: function (result) {
                        console.log(result);
                        data = result.brand;
                        status = result.status;
                        allBrand = result.allBrand;
                        allowedBrandIds = result.allowedBrandIds;
                        $('#modelallowedBrand').modal('show');
                        var allowedBrand = $.map(allBrand, function (b, index) { 
                            var structure='';
                            structure+='<div  class="col-md-4">';
                            if(jQuery.inArray(b.id, allowedBrandIds) === -1){
                                    structure+='<div class="form-check"><input class="form-check-input brandcommancheck" type="checkbox" name="checkboxs[]" value="' + b.id + '" id="flexCheckDefault" /><label class="form-check-label" for="flexCheckDefault">' + b.name + '</label></div>';
                            }else{
                                structure+='<div class="form-check"><input class="form-check-input brandcommancheck" type="checkbox" name="checkboxs[]" checked value="' + b.id + '" id="flexCheckDefault" /><label class="form-check-label" for="flexCheckDefault">' + b.name + '</label></div>';
                            }
                            structure+='</div>';
                            return structure;
                        });
                        console.log({allowedBrand});
                        $('#branddata').empty().append(allowedBrand);
                    }
                });
        }

        //=====function to get sub cat and sub sub cat on click start=====//
        function getsubchild(that){
            if($(that).is(':checked')){
                    var id = $(that).attr('value');
                    var position = $(that).attr('data-position');
                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                    });

                    $.ajax({
                        type: "POST",
                        url: "{{route('admin.product.get-child')}}",
                        data: {parent_id:id, position:position},
                        dataType:"json",
                        success: function (data) {
                            var rowdata = data.row;
                            if(rowdata.length==0){
                                if(position==0)
                                {
                                    toastr.warning('No Sub-Category Available for This Category');
                                }
                                if(position==1)
                                {
                                    toastr.error('No Sub-Sub-Category Available for This Sub-Category');
                                }  
                            }
                            var createCheckBoxs = $.map(rowdata, function (val, index) { 
                                if(val.id){
                                    return '<div style="margin-block-end: -1px;" class="form-check parent_'+ id +'"><input class="form-check-input" type="checkbox" name="checkboxs[]" data-position="'+ val.position +'" onclick="getsubchild(this);" value="' + val.id + '" /><label class="form-check-label" for="flexCheckDefault">' + val.name + '</label></div>';
                                }
                            });
                            if(position==0){
                                $('#subChild').append(createCheckBoxs);
                            }
                            if(position==1){
                                $('#subSubChild').append(createCheckBoxs);
                            }

                        }
                    });

            }
            else
            {
                var removechild = 'parent_'+$(that).attr('value');
                $(that).each(function() {
                   var remove_id = this.value;
                   var remove_position = $(this).attr('data-position');
                   $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                    });

                    $.ajax({
                        type: "POST",
                        url: "{{route('admin.product.get-child')}}",
                        data: {parent_id:remove_id, position:remove_position},
                        dataType:"json",
                        success: function (data) {
                            var rowdata = data.row;
                            if(rowdata.length>0)
                            { 
                                $.map(rowdata, function (val, index) {
                                    $('.parent_'+val.id).remove();
                                });
                            }

                        }
                    });

                });
                $('.'+removechild).remove();
            }
        }
        //=====function to get sub cat and sub sub cat on click end=====//

        function updateCatInProduct(filteredCat)
        {
            var options;
            options='<option value="" selected>---Select Category---</option>';
            options+= $.map(filteredCat, function (a) { 
                return '<option value="' + a.id + '">' + a.name + '</option>';
            });
            $('#cat_id').html('');
            $('#cat_id').append(options);

            $('#subcategoryform #exampleFormControlSelect1').html('');
            $('#subcategoryform #exampleFormControlSelect1').append(options);

            $('#subsubcategoryform #sub_sub_cat_id').html('');
            $('#subsubcategoryform #sub_sub_cat_id').append(options);
        }

        $("form[name='blockcat']").validate({
            
            rules: {
                'checkboxs[]': {
                    required:true
                }
            },
            errorPlacement: function(error,element){
                error.appendTo('#alert');
            },
            messages: {
                'checkboxs[]' :{ 
                    required:"Please check at least 1 box"
                }
            },
            submitHandler: function(form) {
              var url = '{{route('admin.product.block-ids')}}';
              var form_data = new FormData(form);
              $.ajax({
                    url: url,
                    type: 'POST',
                    processData: false,
                    contentType: false,
                    data: form_data,
                    success: function(result){
                            var status = result.status;
                            var cat = result.cat;
                            $('#modelblockCategory').modal('toggle');
                           if(status == 1){
                                Swal.fire({
                                  icon: 'success',
                                  title: 'Category portfolio',
                                  text: 'Category portfolio updated successfully',
                                }).then(function(){ 
                                   //location.reload();
                                   $('#cat_id').val('');
                                   $('#sub-category-select').html('');
                                   $('#sub-sub-category-select').html('');
                                   $('#subsubcategoryform #parent_id').val('');
                                   updateCatInProduct(cat);
                                   allCatCommonModel();
                                   setTimeout(function(){
                                        $('#modelblockCategory').modal('hide');
                                        $('#catsubbutton').attr('disabled',false);
                                    }, 2000);
                                });
                            }else{
                              Swal.fire({
                                  icon: 'error',
                                  title: 'Category portfolio',
                                  text: 'Problem in update Category portfolio',
                                });
                            }

                           //  var newArray = '<option value="">--select--</option>'
                           //  newArray += jQuery.map(cat, function(val) {
                           //      return '<option value="'+val.id+'">'+val.name+'</option>';
                           //  });
                           //  $('#cat_id').html(newArray);
                           //  location.reload();
                           //  $('#en_name').val(en_name);

                    }
                });
            }
        });

        //--Add Sub Category Start--//
        $("form[name='subcategory']").validate({
            rules: {
            },
            messages: {
            },

            submitHandler: function(form) {
              var url = '{{route('admin.sub-category.sub-category-store')}}';
              var form_data = new FormData(form);
              $.ajax({
                url: url,
                type: 'POST',
                processData: false,
                contentType: false,
                data: form_data,
                success: function(result){
                        var status = result.status;
                        var cat = result.cat;
                        //var cat = result.cat;
                       if(status == 1){ 
                            Swal.fire({
                              icon: 'success',
                              title: 'Sub Category',
                              text: 'Sub Category Added successfully',
                            }).then(function(){
                                    allCatCommonModel();
                                    //updateCatInProduct(cat);
                                   //location.reload();
                                   $('#cat_id').val('');
                                   $('#sub-category-select').html('');
                                   $('#sub-sub-category-select').html('');
                                   $('#subsubcategoryform #parent_id').val('');
                                   $('#catsubbutton').attr('disabled',true);
                                   setTimeout(function(){
                                        $("#subcategoryform")[0].reset();
                                        $('#modelblockCategory').modal('hide');
                                        $('#catsubbutton').attr('disabled',false);
                                    }, 2000);
                            });
                        }else{
                          Swal.fire({
                              icon: 'error',
                              title: 'Oops',
                              text: 'Sub Category Added successfully',
                            });
                        }
                        $('#subcategorymodel').modal('hide');
                    }
                });
            }
        });
        //--Add Sub Category End--//
        

        //--Add Sub sub Category Start--//
        $("form[name='subsubcategory']").validate({
            rules: {
            },
            messages: {
            },
            submitHandler: function(form) {
              var url = '{{route('admin.sub-sub-category.sub-sub-category-store')}}';
              var form_data = new FormData(form);
              $.ajax({
                url: url,
                type: 'POST',
                processData: false,
                contentType: false,
                data: form_data,
                success: function(result){

                        var status = result.status;
                        //var cat = result.cat;
                        var cat = <?php echo json_encode($allCats); ?>;
                       if(status == 1){
                            Swal.fire({
                              icon: 'success',
                              title: 'Sub Category',
                              text: 'Sub Category Added successfully',
                            }).then(function(){ 
                                   allCatCommonModel();
                                   //location.reload();
                                   $('#cat_id').val('');
                                   $('#sub-category-select').html('');
                                   $('#sub-sub-category-select').html('');
                                   $('#subsubcategoryform #parent_id').val('');
                                   $('#catsubbutton').attr('disabled',true);
                                   setTimeout(function(){
                                        $("#subsubcategoryform")[0].reset();
                                        $('#modelblockCategory').modal('hide');
                                        $('#catsubbutton').attr('disabled',false);
                                    }, 2000);
                            });
                        }else{
                          Swal.fire({
                              icon: 'error',
                              title: 'Oops',
                              text: 'Sub Category Added successfully',
                            });
                        }
                        $('#subsubcategory').modal('toggle');
                    }
                });
            }
        });
        //--Add Sub Sub Category End--//


        $('#sub_sub_cat_id').on('change', function () {
            var id = $(this).val();
            var IdOfAdminOrSeller = "{{auth('admin')->id()}}";
            var TypeOfAdminOrSeller = "admin";
            if (id) {
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                    }
                });
                $.ajax({
                    type: 'POST',
                    url: '{{route('admin.sub-sub-category.getSubCategory')}}',
                    data: {
                        id: id,IdOfAdminOrSeller:IdOfAdminOrSeller,TypeOfAdminOrSeller:TypeOfAdminOrSeller
                    },
                    success: function (result) {
                        $("#parent_id").html(result);
                    }
                });
            }
        });

        $('#Checkname').on('change', function () {
            var unitname = $(this).val();
            var url = "{{url('admin/product/units')}}/"+unitname
            if (unitname) {
                $.ajax({
                    type: 'get',
                    url: url,
                    success: function (result) {
                        console.log(result);
                        if(result==1){
                            Swal.fire({
                              icon: 'error',
                              title: 'Oops',
                              text: 'Unit name already present',
                            });
                            $('#Checkname').val('').focus();
                        }
                    }
                });
            }
        });

        //--Brand-- Operations-- Start--//
        $('#checkbrandname').on('change', function () {
            var brandname = $(this).val();
            var url = "{{url('admin/product/brand-duplicate')}}/"+brandname
            if (brandname) {
                $.ajax({
                    type: 'get',
                    url: url,
                    success: function (result) {
                        console.log(result);
                        if(result==1){
                            Swal.fire({
                              icon: 'error',
                              title: 'Oops',
                              text: 'Brand name already present',
                            });
                            $('#brandname').val('').focus();
                        }
                    }
                });
            }
        });

        $("form[name='selectedBrands']").validate({
             rules: {
                'checkboxs[]': {
                    required:true
                }
            },
            errorPlacement: function(error,element){
                error.appendTo('#alert2');
            },
            messages: {
                'checkboxs[]' :{ 
                    required:"Please check at least 1 box"
                }
            },
            submitHandler: function(form) {
              var url = '{{route('admin.product.selected-brands-add')}}';
              var form_data = new FormData(form);
              $.ajax({
                    url: url,
                    type: 'POST',
                    processData: false,
                    contentType: false,
                    data: form_data,
                    success: function(result){
                        var status = result.status;
                        var data = result.brand;

                        //--to update all brand along with newly added brand--//
                        if(status==1)
                        {
                            var options;
                            options='<option value="" selected>---Select---</option>';
                            options+= $.map(data, function (a) { 
                                return '<option value="' + a.id + '">' + a.name + '</option>';
                            });
                            $('#branddrop').html('');
                            $('#branddrop').append(options);
                            
                            $("#idproductbrandform")[0].reset();
                            //--to update all brand along with newly added brand--//

                            Swal.fire({
                              icon: 'success',
                              title: 'Add Brand',
                              text: 'Brand Added successfully',
                            }).then(function(){ 
                               allbrands();
                               setTimeout(function(){
                                    $('#modelallowedBrand').modal('hide');
                                    $('#brandsubbutton').attr('disabled',false);
                                }, 2000);
                               
                            });
                        }else{
                            Swal.fire({
                              icon: 'error',
                              title: 'Oops',
                              text: 'Oops! Problem with Brand add',
                            });
                        }
                    }
                });
            }
        });

        $("form[name='addproductbrandform']").validate({
            rules: {
            },
            messages: {
            },

            submitHandler: function(form) {
              var url = '{{route('admin.brand.add-brand')}}';
              var form_data = new FormData(form);
              $.ajax({
                url: url,
                type: 'POST',
                processData: false,
                contentType: false,
                data: form_data,
                success: function(result){
                    console.log(result);

                    var data = result.brand;
                    var status = result.status;
                    var allBrand = result.allBrand;
                    var allowedBrandIds = result.allowedBrandIds;

                    if(status==1)
                    {
                        var options;
                        options='<option value="" selected>---Select---</option>';
                        options+= $.map(data, function (a) { 
                            return '<option value="' + a.id + '">' + a.name + '</option>';
                        });
                        $('#branddrop').html('');
                    }
                    $('#branddrop').append(options);
                    $("#idproductbrandform")[0].reset();
                    $('#productbrandModel').modal('toggle');
                    $('#modelallowedBrand').modal('show');
                       var allowedBrand = $.map(allBrand, function (b, index) { 
                            var structure='';
                            structure+='<div  class="col-md-4">';
                            if(jQuery.inArray(b.id, allowedBrandIds) === -1){
                                    structure+='<div class="form-check"><input class="form-check-input" type="checkbox" name="checkboxs[]" value="' + b.id + '" id="flexCheckDefault" /><label class="form-check-label" for="flexCheckDefault">' + b.name + '</label></div>';
                            }else{
                                structure+='<div class="form-check"><input class="form-check-input" type="checkbox" name="checkboxs[]" checked value="' + b.id + '" id="flexCheckDefault" /><label class="form-check-label" for="flexCheckDefault">' + b.name + '</label></div>';
                            }
                            structure+='</div>';
                            return structure;
                        });
                        console.log({allowedBrand});
                        
                        $('#branddata').empty().append(allowedBrand);


                       setTimeout(function(){
                            $('#productbrandModel').modal('hide');
                            $('#modelallowedBrand').modal('hide');
                            $("#idproductbrandform")[0].reset();
                            $('#brandsubbutton').attr('disabled',false);
                        }, 2000);
                }
              });
               
            }
        });
        //--Brand-- Operations-- End--//

        function getRequest(route, id, type, position) {
            $('#sub-sub-category-select').html('<option value="" disabled selected>---Select---</option>');
            var blockids
            var url = "{{url('admin/product/get-seller-cat-data')}}"
                $.ajax({
                    type: 'get',
                    url: url,
                    success: function (result) {
                        blockids = result.allowedIds;
                        $.get({
                            url: route,
                            dataType: 'json',
                            success: function (data) {
                                var options;
                                options='<option value="" disabled selected>---Select---</option>';
                                options+= $.map(data.row, function (a) { 
                                    if(jQuery.inArray(a.id, blockids) !== -1){
                                        return '<option value="' + a.id + '">' + a.name + '</option>';
                                    }
                                });
                                if (type == 'select') {
                                    $('#' + id).empty().append(options);
                                }
                            },
                        });
                    }
                });
        }

        $('input[name="colors_active"]').on('change', function () {
            if (!$('input[name="colors_active"]').is(':checked')) {
                $('#colors-selector').prop('disabled', true);
            } else {
                $('#colors-selector').prop('disabled', false);
            }
        });

        $('#choice_attributes').on('change', function () {
            $('#customer_choice_options').html(null);
            $.each($("#choice_attributes option:selected"), function () {
                //console.log($(this).val());
                add_more_customer_choice_option($(this).val(), $(this).text());
            });
        });

        function add_more_customer_choice_option(i, name) {
            let n = name.split(' ').join('');
            $('#customer_choice_options').append('<div class="row"><div class="col-md-3"><input type="hidden" name="choice_no[]" value="' + i + '"><input type="text" class="form-control" name="choice[]" value="' + n + '" placeholder="{{trans('Choice Title') }}" readonly></div><div class="col-lg-9"><input type="text" class="form-control" name="choice_options_' + i + '[]" placeholder="{{trans('Enter choice values') }}" data-role="tagsinput" onchange="update_sku()"></div></div>');

            $("input[data-role=tagsinput], select[multiple][data-role=tagsinput]").tagsinput();
        }
        $('#colors-selector').on('change', function () {
            update_sku();
        });

        $('input[name="unit_price"]').on('keyup', function () {
            update_sku();
        });

        // function setCurrency(that,attribute)
        // {
        //     var processedData = "{{session('sellercurrencysymbol')}}"+$(that).val().replace(/[^0-9]/g,'');
        //     $("#"+attribute).prop("type", "text");
        //     $('input[name="'+attribute+'"]').val(processedData);
        // }

        function update_sku() {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            $.ajax({
                type: "POST",
                url: '{{route('admin.product.sku-combination')}}',
                data: $('#product_form').serialize(),
                success: function (data) {
                    $('#sku_combination').html(data.view);
                    $('#sku_combination').addClass('pt-4');
                    if (data.length > 1) {
                        $('#quantity').hide();
                    } else {
                        $('#quantity').show();
                    }
                }
            });
        };


    
        function check(){
            Swal.fire({
                title: '{{\App\CPU\translate('Are you sure')}}?',
                text: '',
                type: 'warning',
                showCancelButton: true,
                cancelButtonColor: 'default',
                confirmButtonColor: '#377dff',
                cancelButtonText: 'No',
                confirmButtonText: 'Yes',
                reverseButtons: true
            }).then((result) => {
                for ( instance in CKEDITOR.instances ) {
                    CKEDITOR.instances[instance].updateElement();
                }

                
                var formData = new FormData(document.getElementById('product_form'));
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.post({
                    url: '{{route('admin.product.store')}}',
                    data: formData,
                    contentType: false,
                    processData: false,
                    success: function (data) {
                        if (data.errors) {
                            for (var i = 0; i < data.errors.length; i++) {
                                toastr.error(data.errors[i].message, {
                                    CloseButton: true,
                                    ProgressBar: true
                                });
                            }
                        } else {
                            toastr.success('{{\App\CPU\translate('product updated successfully!')}}', {
                                CloseButton: true,
                                ProgressBar: true
                            });
                            $('#product_form').submit();
                        }
                    }
                });
            })
        };
   
        $(".lang_link").click(function (e) {
            e.preventDefault();
            $(".lang_link").removeClass('active');
            $(".lang_form").addClass('d-none');
            $(this).addClass('active');

            let form_id = this.id;
            let lang = form_id.split("-")[0];
            console.log(lang);
            $("#" + lang + "-form").removeClass('d-none');
            if (lang == '{{$default_lang}}') {
                $(".rest-part").removeClass('d-none');
            } else {
                $(".rest-part").addClass('d-none');
            }
        })
    
        //-- Rought code BY RAHUL J (Start)--//
        $('#sub_sub_cat_id2').on('change', function () {
            var id = $(this).val();
            if (id) {
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                    }
                });
                $.ajax({
                    type: 'POST',
                    url: '{{route('admin.sub-sub-category.getSubCategory')}}',
                    data: {
                        id: id
                    },
                    success: function (result) {
                        $("#parent_id2").html(result);
                    }
                });
            }
        });

        
        $('#sub_sub_cat_id3').on('change', function () {
            var id = $(this).val();
            if (id) {
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                    }
                });
                $.ajax({
                    type: 'POST',
                    url: '{{route('admin.sub-sub-category.getSubCategory')}}',
                    data: {
                        id: id
                    },
                    success: function (result) {
                        $("#parent_id3").html(result);
                    }
                });
            }
        });

        $('#parent_id3').on('change', function () {
            var id = $(this).val();
            if (id) {
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                    }
                });
                $.ajax({
                    type: 'POST',
                    url: '{{route('admin.sub-sub-category.getSubCategory')}}',
                    data: {
                        id: id
                    },
                    success: function (result) {
                        $("#parent_child_id3").html(result);
                    }
                });
            }
        });

        //-- Rought code BY RAHUL J (End)--//

    </script>

    {{--ck editor--}}
    
    <script>
        $('.textarea').ckeditor({
            contentsLangDirection : '{{Session::get('direction')}}',
        });
    </script>

    {{--ck editor--}}
@endpush
