@if(count($variantsObject['combinations']) > 0)
<table class="table table-bordered" id="sku-table">
    <thead>
        <tr>
                <td class="text-center" colspan="2">
                    <label for="" class="control-label">{{\App\CPU\translate('Variant Combinations')}}</label>
                </td>
                <td class="text-center">
                    <label for="" class="control-label">{{\App\CPU\translate('Variant')}}</label>
                </td>
                </td>
                <td class="text-center">
                    <label for="" class="control-label">{{\App\CPU\translate('SKU')}}</label>
                <td class="text-center">
                    
                    <label for="" class="control-label">{{\App\CPU\translate('Apply Discount')}}</label>
                </td>
        </tr>
        <tr >
            <td colspan="5">
                <ul style="font-size: 14px;padding-left: 13px;color: #ff5e00c7;">
                    <strong>Note:-Instructions to create product variant.</strong>
                    <li style="color: #ff5e00c7;font-size: 14px;">The minimum quantity for a product variant should be one. Otherwise, let it be zero.</li>
                    <li style="color: #ff5e00c7;font-size: 14px;">If a discount is applied to the product variant, then its value should be in a flat amount (not in per centage).</li>
                    <li>If a discount is being applied to the product variant, kindly state either the start period or both the start and end periods.</li>
                    <li  style="color: #ff5e00c7;font-size: 14px;"><strong>Click the "Verify discount duration" button</strong> to double-check the start and end duration after entering all the necessary information for the variant. If you don't, the discount won't be applied.</li>
                </ul>
            </td>
        </tr>
        <tr class="errorblock">
        </tr>
    </thead>
    <tbody>
    @endif
    @foreach ($variantsObject['combinations'] as $key => $combination)

    @php $str = $combination['type']; @endphp
        <tr class="checktr">
            <td colspan="2">
                    <table>
                        <tr>
                            @php
                                $strArray = [];
                                $strArray = explode('-', $str);
                                foreach($strArray as $i => $sA)
                                {
                                    $strArray[$i] = trim($sA);
                                }
                            @endphp
                            @foreach($variantsObject['selectColoumn'] as $keys => $sc)
                            <td>
                                <label class="control-label">{{$sc[0]}}</label>
                                <select class="form-control" data-row="{{ $key }}" data-col="{{ (!empty($selectColoumn))?count($selectColoumn):0 }}" onchange="checkVariant('{{ $keys }}',this,'{{ $key }}')" id="{{$key}}{{$keys}}" >
                                        <option value="">None</option>
                                        @foreach($sc as $in => $s)
                                            @if($in)
                                            <option {{(in_array(str_replace(' ', '', $s), $strArray))?'selected':''}} value="{{str_replace(' ', '', $s)}}">{{($sc[0]=='color')?\App\Model\Color::where('code', $s)->first()->name:$s}}</option>
                                            @endif
                                        @endforeach
                                </select>
                            </td>
                            @endforeach
                        </tr>
                    </table>
            </td>
            <td>
                    @php
                        $compiledStr = '';
                        $compiledSku = '';
                        $compiledSku = $product->name;
                        foreach($strArray as $compStrIndex => $cStrElement)
                        {
                            if(!empty($cStrElement))
                            { 
                                if($compStrIndex > 0 ){
                                    $compiledStr .= '-'.str_replace(' ', '', $cStrElement);
                                    $compiledSku .='-'.str_replace(' ', '', $cStrElement);
                                }
                                else
                                {
                                    if($variantsObject['colors_active'] == 1){
                                        if(!empty($cStrElement))
                                        {
                                            $color_name = $cStrElement;
                                            $color= \App\Model\Color::where('code', $cStrElement)->first();
                                            if(!empty($color))
                                            {
                                                $color_name = $color->name;
                                            }
                                            $compiledStr .= $color_name;
                                            $compiledSku .='-'.$color_name;
                                        }
                                    }
                                    else{
                                        if(!empty($cStrElement))
                                        {
                                            $compiledStr .= str_replace(' ', '', $cStrElement);
                                            $compiledSku .='-'.str_replace(' ', '', $cStrElement);
                                        }
                                    }
                                }
                            }
                        }
                    @endphp
                <input type="text" value="{{ $compiledStr }}" id="strShow_{{ $key }}" class="form-control common str" data-originalstr ="{{ $str }}" readonly>
                <input type="hidden" name="str[]" value="{{ $str }}" id="strInput_{{ $key }}" class="form-control common skuCombination_{{ $key }}">
            </td>
            <td>
                <input type="text" value="{{ $compiledSku }}" name="sku[]" id="sku_{{ $key }}" class="form-control common" onchange="changeDisDetailsAfterVerified('{{ $key }}')">
            </td>
            <td>
                <label class="switch">
                    <input type="checkbox" class="status" name="active_discount" value="{{old('colors_active')}}" onchange="showDiscountParameters('{{$str}}',this);">
                    <span class="slider round"></span>
                </label>
                @php if($combination['verify_status'] == 1){ $displayString="display:none"; }else{ $displayString="";}@endphp
                <i class="tio-checkmark-square-outlined comman topStatus_{{ $key }}" style="font-size: xx-large;color: chartreuse;float: right;'{{$displayString}}'"></i>
            </td>
        </tr>
        <tr class="{{ $str }} comman {{ $key }} forEdit">
            @php
                if((!empty($combination['startDuration']) && $combination['startDuration'] !='Null'))
                {
                    $startArray = explode(" ", $combination['startDuration']);
                    $startDatePresent = true;
                }
                else
                {
                    $startDatePresent = false;
                }
                if((!empty($combination['endDuration']) && $combination['endDuration'] !='Null'))
                {
                    $endArray = explode(" ", $combination['endDuration']);
                    $endDatePresent = true;
                }
                else
                {
                    $endDatePresent = false;
                }

            @endphp
            <td>
                <input type="number" id="price_{{ $key }}" value='{{($combination["price"] != 0)?App\CPU\Helpers::currency_converter_forbackend($combination["price"],"yes"):""}}' name="price[]" step="0.01" class="form-control common" placeholder="Variant Price" onchange="changeDisDetailsAfterVerified('{{ $key }}')">
            </td>

            <td>
                <input type="number" name="qty_{{ $str }}" id="qty_{{ $str }}" min="0" max="1000000" step="1" value="{{ $combination['qty'] }}" class="form-control common" onchange="changeDisDetailsAfterVerified('{{ $str }}')" required>
            </td>

            <td>
                <input type="number" value="{{ ($combination['discount'] != 0)?$combination['discount']:'' }}" name="discount_{{ $str }}" id="discount_{{ $str }}" placeholder="Discount Amount" class="form-control common" onchange="changeDisDetailsAfterVerified('{{ $str }}')">
            </td>
            <td>
                <input type="text" value="{{ ($startDatePresent)?$startArray[0]:'' }}" name="startdate_{{ $str }}" id="startdate_{{ $str }}" class="form-control startdate common" placeholder="Start Date" onchange="changeDisDetailsAfterVerified('{{ $str }}')">
            </td>
            <td>
                <input type="text" value="{{ ($startDatePresent)?$startArray[1]:'' }}" name="starttime_{{ $str }}" id="starttime_{{ $str }}" class="form-control starttime common"  placeholder="Start Time" onchange="changeDisDetailsAfterVerified('{{ $str }}')">
            </td>
        </tr>
        <tr class="{{ $str }} comman {{ $key }}" id="verifyrow_{{ $str }}">

            <td>
                <input type="text" value="{{ ($endDatePresent)?$endArray[0]:'' }}" name="enddate_{{ $str }}" id="enddate_{{ $str }}" class="form-control enddate common"  placeholder="End Date" onchange="changeDisDetailsAfterVerified('{{ $str }}')">
            </td>
            <td>
                <input type="text" value="{{ ($endDatePresent)?$endArray[1]:'' }}" name="endtime_{{ $str }}" id="endtime_{{ $str }}" class="form-control endtime common"  placeholder="End Date" onchange="changeDisDetailsAfterVerified('{{ $str }}')">
            </td>
            <td>
                <input type="text" name="buyquantity_{{ $str }}" class="form-control"  placeholder="Buy Quantity">
            </td>
            <td>
                <input type="text" name="freequantity_{{ $str }}" class="form-control"  placeholder="Free Quantity">
            </td>
            <td>
                <input type="text" name="item_{{ $str }}" class="form-control"  placeholder="Item">
            </td>
        </tr>

        <tr  class="comman {{ $key }}">
            <td colspan="5" >
                <i class="tio-checkmark-circle-outlined correct_{{ $key }}" style="font-size: xx-large;color: chartreuse;margin-left:1px"></i>
                <div class="wrong_{{ $str }}" style="padding-left: 5 px">
                    <i class="tio-clear-circle-outlined cross_{{ $key }}" style="font-size: xx-large;color: salmon;"></i>
                    <a href="JavaScript:void(0)" class="verify_{{ $key }}" onclick="checkDisDates('{{ $key }}')" >
                        <svg xmlns="http://www.w3.org/2000/svg"  width="30" height="30" fill="currentColor" class="bi bi-patch-check" viewBox="0 0 16 16" style="font-size: xx-large;color: powderblue;margin-top: -10px;">
                        <path fill-rule="evenodd" d="M10.354 6.146a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708 0l-1.5-1.5a.5.5 0 1 1 .708-.708L7 8.793l2.646-2.647a.5.5 0 0 1 .708 0z"/>
                        <path d="m10.273 2.513-.921-.944.715-.698.622.637.89-.011a2.89 2.89 0 0 1 2.924 2.924l-.01.89.636.622a2.89 2.89 0 0 1 0 4.134l-.637.622.011.89a2.89 2.89 0 0 1-2.924 2.924l-.89-.01-.622.636a2.89 2.89 0 0 1-4.134 0l-.622-.637-.89.011a2.89 2.89 0 0 1-2.924-2.924l.01-.89-.636-.622a2.89 2.89 0 0 1 0-4.134l.637-.622-.011-.89a2.89 2.89 0 0 1 2.924-2.924l.89.01.622-.636a2.89 2.89 0 0 1 4.134 0l-.715.698a1.89 1.89 0 0 0-2.704 0l-.92.944-1.32-.016a1.89 1.89 0 0 0-1.911 1.912l.016 1.318-.944.921a1.89 1.89 0 0 0 0 2.704l.944.92-.016 1.32a1.89 1.89 0 0 0 1.912 1.911l1.318-.016.921.944a1.89 1.89 0 0 0 2.704 0l.92-.944 1.32.016a1.89 1.89 0 0 0 1.911-1.912l-.016-1.318.944-.921a1.89 1.89 0 0 0 0-2.704l-.944-.92.016-1.32a1.89 1.89 0 0 0-1.912-1.911l-1.318.016z"/>
                    </svg>
                    </a>
                    <span class="verify_{{ $key }}">Verify discount duration</span>
                </div>
                <input type="hidden" id="verify_status_{{ $key }}" value="1" name="verify_status[]"  >
            </td>
        </tr>

    @endforeach
    </tbody>
</table>

<script type="text/javascript">

    //--comman in add page--//
    function checkDisDates(str)
    {
        compStartDate="";compEndDate="";meg ="";
        var price = $('#price_'+str).val();
        var sku = $('#sku_'+str).val();
        var qty = $('#qty_'+str).val();
        var disAmmount = $('#discount_'+str).val();
        var staDat = $('#startdate_'+str).val();
        var staTim = $('#starttime_'+str).val();
        var endDat = $('#enddate_'+str).val();
        var endTim = $('#endtime_'+str).val();
        compStartDate = staDat+' '+staTim;
        compEndDate = endDat+' '+endTim;
        errorstatus = '0'
        $('.common').removeClass('showdanger');
        meg = meg + '<td colspan="5"><ul  style="font-size: 12px;padding-left: 13px;padding-top: 5px;color: #ff5e00c7; font-size: 12px;">';

        if (Number(price) == 0 || Number(price) < 0 || price =="") {
            meg = meg + "<li>("+str+"):-Price is required field and must be higher than 0.</li>";
            $('#price_'+str).val('').addClass('showdanger');
            errorstatus = '1'
        }
        if (sku =="") {
            meg = meg + "<li>("+str+"):-Sku is required field.</li>";
            $('#sku_'+str).val('').addClass('showdanger');
            errorstatus = '1'
        }
        if (Number(qty) == 0 || qty < 0 || qty =="") {
            meg = meg + "<li>("+str+"):-Quantity is required field and must be higher than 0.</li>";
            $('#qty_'+str).val('').addClass('showdanger');
            errorstatus = '1'
        }
        if(disAmmount != "")
        {
            if (Number(disAmmount) <= 0) {
                meg = meg + "<li>("+str+"):- The Discount Amount is a positive number with value, greater than 0.</li>";
                $('#discount_'+str).val('').addClass('showdanger');
                errorstatus = '1'
            }
            else if (Number(disAmmount) > Number(price)) {
                meg = meg + "<li>("+str+"):-The discounted price should be equal to or less than the variant price.</li>";
                $('#discount_'+str).val('').addClass('showdanger');
                errorstatus = '1'
            }
            else if (staDat == '')
            {
                meg = meg + "<li>("+str+"):-Please fill in the Discount Start Date and time for the Vatriant.</li>";
                $('#startdate_'+str).addClass('showdanger');
                errorstatus = '1'
            }
            else if(staTim == '')
            {
                meg = meg + "<li>("+str+"):-Please enter the Discount Start Time.</li>";
                $('#starttime_'+str).addClass('showdanger');
                errorstatus = '1'
            }
        }

        if(endTim != '')
        {
            if (endDat == '')
            {
                meg = meg + "<li>("+str+"):-Please enter the end date and time also.</li>";
                $('#enddate_'+str).addClass('showdanger');
                errorstatus = 1;
            }
        }

        if(endDat != '')
        {
            if (endTim == '')
            {
                meg = meg + "<li>("+str+"):-Please fill in the end time.</li>";
                $('#endtime_'+str).addClass('showdanger');
                errorstatus = 1;
            }
        }

        if(compEndDate.length>0){
             if ( new Date(compStartDate.replace(/-/g,'/')) >= new Date(compEndDate.replace(/-/g,'/')) ) {
                meg = meg + "<li>("+str+"):-The End Date should be greater than the Start Date.</li>";
                $('#enddate_'+str).val('').addClass('showdanger');
                $('#endtime_'+str).val('').addClass('showdanger');
                errorstatus = '1'
            }
        }

        meg = meg + '</ul></td>';
        if(errorstatus == '1')
        {
            $("#sku-table tbody tr#verifyrow_"+str+" td#operationBck_"+str+" a.wrong_"+str).show();
            $("#sku-table tbody tr#verifyrow_"+str+" td#operationBck_"+str+" div i.cross_"+str).show();
            $("#sku-table tbody tr#verifyrow_"+str+" td#operationBck_"+str+" i.correct_"+str).hide();
            $("#sku-table tbody tr#verifyrow_"+str+" td#operationBck_"+str+" input#verify_status_"+str).val('0');
            $("#sku-table thead tr.errorblock").html('').html(meg).show();
        }
        else
        {
            $("#sku-table tbody tr#verifyrow_"+str+" td#operationBck_"+str+" div i.cross_"+str).hide();
            $("#sku-table tbody tr#verifyrow_"+str+" td#operationBck_"+str+" div.wrong_"+str).hide();
            $("#sku-table tbody tr#verifyrow_"+str+" td#operationBck_"+str+" i.correct_"+str).show();
            $("#sku-table tbody tr#verifyrow_"+str+" td#operationBck_"+str+" input#verify_status_"+str).val('1');
            $("#sku-table thead tr.errorblock").html('').hide();
        }
    }

    //--comman in add page--//
    function changeDisDetailsAfterVerified(str)
    {
        if($('#verify_status_'+str).val() == '1')
        {
            $('#verify_status_'+str).val('0');
            toastr.info("Please Verify again to log this Variant Discount Parameters", {
                CloseButton: true,
                ProgressBar: true
            });
            $("#sku-table tbody tr#verifyrow_"+str+" td#operationBck_"+str+" div i.cross_"+str).hide();
            $('#topStatus_'+str).hide();
            $("#sku-table tbody tr#verifyrow_"+str+" td#operationBck_"+str+" i.correct_"+str).hide();
            $("#sku-table tbody tr#verifyrow_"+str+" td#operationBck_"+str+" div.wrong_"+str).show();
            $("#sku-table tbody tr#verifyrow_"+str+" td#operationBck_"+str+" div.wrong_"+str+" a.verify_"+str).show();
        }
    }

    //--comman in add page--//
    function showDiscountParameters(str,that)
    {
        if($('#verify_status_'+str).val() == '1')
        {
            $('#topStatus_'+str).show();
        }
        else
        {
            $('#topStatus_'+str).hide();
        }

        if (!$(that).is(':checked')) {
            $('.'+str).hide();
        } else {
            $('.'+str).show();
            flatpickr("#startdate_"+str,{
                //enableTime: true,
                dateFormat: "Y-m-d",
                minDate: "today",
            });

            flatpickr("#starttime_"+str,{
                enableTime: true,
                noCalendar: true,
                dateFormat: "H:i",
            });

            flatpickr("#enddate_"+str,{           
                //enableTime: true,
                minDate: "today",
                dateFormat: "Y-m-d",
            });
            flatpickr("#endtime_"+str,{
                enableTime: true,
                noCalendar: true,
                dateFormat: "H:i",
            });
        }
    }
</script>