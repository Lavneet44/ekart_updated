@extends('layouts.back-end.app')

@section('title', \App\CPU\translate('Update Currency'))

@push('css_or_js')

@endpush

@section('content')
    @php($currency_model=\App\CPU\Helpers::get_business_settings('currency_model'))
    <div class="content container-fluid">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a
                        href="{{route('admin.dashboard')}}">{{\App\CPU\translate('Dashboard')}}</a>
                </li>
                <li class="breadcrumb-item" aria-current="page">{{\App\CPU\translate('Currency')}}</li>
            </ol>
        </nav>
        <!-- Page Heading -->

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h5 class="text-center">
                            <i class="tio-money"></i>
                            {{\App\CPU\translate('Update Currency')}}
                        </h5>
                    </div>
                    <div class="card-body">
                        <form action="{{route('admin.currency.update',[$data['id']])}}" method="post"
                              style="text-align: {{Session::get('direction') === "rtl" ? 'right' : 'left'}};">
                            @csrf
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-md-6">
                                        <label>{{\App\CPU\translate('Currency Name')}} :</label>
                                        <input type="text" name="name"
                                               placeholder="{{\App\CPU\translate('Currency Name')}}"
                                               class="form-control" id="name"
                                               value="{{$data->name}}">
                                    </div>
                                    <div class="col-md-6">
                                        <label>{{\App\CPU\translate('Currency Symbol')}} :</label>
                                        <input type="text" name="symbol"
                                               placeholder="{{\App\CPU\translate('Currency Symbol')}}"
                                               class="form-control" id="symbol"
                                               value="{{$data->symbol}}">
                                    </div>
                                </div>

                            </div>
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-md-6">
                                        <label>{{\App\CPU\translate('Currency Code')}} :</label>
                                        <input type="text" name="code"
                                               placeholder="{{\App\CPU\translate('Currency Code')}}"
                                               class="form-control" id="code"
                                               value="{{$data->code}}">
                                    </div>
                                    @if($currency_model=='multi_currency')
                                        <div class="col-md-6">
                                            <label>{{\App\CPU\translate('Exchange Rate')}} :</label>
                                            <input type="number" min="0" max="1000000"
                                                   name="exchange_rate" step="0.00000001"
                                                   placeholder="{{\App\CPU\translate('Exchange Rate')}}"
                                                   class="form-control" id="exchange_rate"
                                                   value="{{$data->exchange_rate}}">
                                        </div>
                                    @endif
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-md-6">
                                        <label>{{\App\CPU\translate('currency_formate')}} :</label>
                                        <input type="number" onchange="checkCurrenctFormate();" min="0" max="3" step="1" name="currency_formate" class="form-control" id="currency_formate" placeholder="{{\App\CPU\translate('Enter no. of decimal places')}}" value="{{$data->currency_formate}}">
                                    </div>
                                </div>
                            </div>

                            <div class="form-group text-center">
                                <button type="submit" id="add" class="btn btn-primary"
                                        style="color: white">{{\App\CPU\translate('Update')}}
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@push('script')
<script type="text/javascript">
    function checkCurrenctFormate()
        {
            var myInteger = $('#currency_formate').val();
            if( !(parseInt( myInteger ) == myInteger && myInteger > 0 && 4 > myInteger) )
            {
                $('#currency_formate').val('');
                $('#currency_formate').focus();
                toastr.error('{{\App\CPU\translate('Please fill Positive Integer Value less than 4 in currency formate field')}}');
            }
        }
</script>
@endpush
