@extends('layouts.back-end.app')

@section('title', 'Plan View')

@push('css_or_js')
<link href="{{ asset('public/assets/select2/css/select2forplanadmin.min.css')}}" rel="stylesheet">
@endpush

@section('content')
<div class="content container-fluid">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{route('admin.dashboard.index')}}">{{\App\CPU\translate('Dashboard')}}</a>
                </li>
                <li class="breadcrumb-item"><a href="{{route('admin.plan.plan-list')}}">{{\App\CPU\translate('seller_plans')}}</a>
                </li>
                <li class="breadcrumb-item" aria-current="page">{{\App\CPU\translate('Plan_Details')}}</li>
            </ol>
        </nav>

        <!-- Page Heading -->
    
        <!-- Page Header -->
   
        <!-- End Page Header -->
        <div class="row">
            <div class="col-md-12 mt-3">
                <form action="" method="post" id="viewplan">
                    @csrf
                    <div class="card">
                        <div class="card-header">
                            <h5>{{\App\CPU\translate('view_plan')}}</h5>
                        </div>
                        <input type="hidden" class="form-control" name="plan_id"  value="{{$SubscriptionPlan->id}}">
                        <div class="card-body">
                            <div class="input-group">
                                <div class="form-group col-md-6">
                                    <label>{{\App\CPU\translate('title')}}</label> <span class="text-danger">*</span>
                                    <input type="text" class="form-control" name="title" value="{{$SubscriptionPlan->title}}" disabled>
                                </div>
                                <div class="form-group col-md-6">
                                    <label>{{\App\CPU\translate('currency')}}</label> <span class="text-danger">*</span>
                                    <select class="form-control selectcurrencyy" name="currency_id" id="currencyId" disabled>
                                        <option value="">--{{\App\CPU\translate('select_currency')}}--</option>
                                        @foreach($Currency as $cu)
                                        <option value="{{$cu->id}}" {{($SubscriptionPlan->currency_id == $cu->id)?'selected':''}}>{{$cu->code}} ({{$cu->symbol}})----({{ucfirst($cu->name)}}) </option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="input-group">
                                <div class="form-group col-md-6">
                                    <label>{{\App\CPU\translate('price')}}</label> <span class="text-danger">*</span>
                                    <input type="text" class="form-control" name="price"  value="{{$SubscriptionPlan->price}}" disabled>
                                </div>

                                <div class="form-group col-md-6">
                                        <label>{{\App\CPU\translate('duration')}}</label> <span class="text-danger">*</span>
                                        <div class="row">
                                            <div class="col-md-6 mb-5">
                                                <input type="text" class="form-control" name="duration" value="{{$SubscriptionPlan->duration}}" disabled>
                                            </div>
                                            <div class="col-md-6">
                                                <select class="form-control" id="duration_type" name="duration_type" style="margin-right: 0px;" disabled>
                                                    <option value="">-- {{\App\CPU\translate('select_duration_type')}} --</option>
                                                    <!-- <option  value="1" selected="{{($SubscriptionPlan->duration_type == '1')?'selected':''}}">Days</option>
                                                    <option  value="2" selected="{{($SubscriptionPlan->duration_type == '2')?'selected':''}}">Months</option>
                                                    <option value="3" selected="{{($SubscriptionPlan->duration_type == '3')?'selected':''}}">Year</option> -->
                                                    <option  value="2" selected="selected">Months</option>
                                                </select>
                                            </div>
                                        </div>
                                </div>
                            </div>
                            <div class="input-group">
                                <div class="form-group  col-md-6">
                                    <label>{{\App\CPU\translate('allowed_products')}}</label> <span class="text-danger">*</span>
                                    <input type="text" class="form-control" name="allowed_products" value="{{$SubscriptionPlan->allowed_products}}" disabled>
                                </div>
                                <div class="form-group col-md-6">
                                    <label>{{\App\CPU\translate('allowed_invoice')}}</label> <span class="text-danger">*</span>
                                    <input type="text" class="form-control" name="allowed_invoice" value="{{$SubscriptionPlan->allowed_invoice}}" disabled>
                                </div>
                            </div>
                            <div class="input-group">
                            <div class="input-group">
                                <div class="form-group  col-md-6">
                                    <div class="col-md-12" style="padding-right: 0px;padding-left: 0px;">
                                        <label>{{\App\CPU\translate('expected_volume_of_business')}}</label> <span class="text-danger">*</span>
                                    </div>
                                    <div class="input-group">
                                        <div class="myclass col-md-11" style="padding-right: 0px;padding-left: 0px;">
                                            <input type="text" class="form-control" id="expectedVolumeOfBusiness" name="expected_volume_of_business" value="{{$SubscriptionPlan->expected_volume_of_business}}" style="width:100%;" disabled>
                                        </div>
                                        <div id="choise1" class="col-md-1" style="justify-content: center;text-align: center;padding: 2px 4px;font-size: 20px;background-color: #e7eaf3;border: 0.5px solid #e7eaf3;border-radius: 0px 8px 8px 0px;height: 40px;">
                                            <span id="choise" style="font-size: 12px;"></span>
                                        </div>
                                    </div>
                                </div>
                                <!-- <div class="col-md-6">
                                    <div class="input-group">
                                    <small class="badge badge-soft-danger mb-3">
                                        Click at Enable, To add <b>Offer</b> at the Plan.
                                    </small>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="input-group">
                                        <div class="form-group  col-md-3">
                                        <label>Start Offer : </label>
                                        </div>
                                        <div class="form-group  col-md-2">
                                        <label class="switch ml-3">
                                            <input type="checkbox" id="offer_status" name="offer_status"
                                                   class="status"
                                                   value="1">
                                            <span class="slider round"></span>
                                        </label>
                                        </div>
                                        </div>
                                    </div>
                                </div> -->
                            </div>
                            <!-- <div class="input-group" id="offeritems">
                                <div class="form-group col-md-6">
                                    <label>Offer Start Date</label>
                                        <input type="text" id="datepicker" class="form-control" name="offer_startdate" autocomplete="off">
                                </div>
                                <div class="col-md-6">
                                    <div class="input-group">
                                    <small class="badge badge-soft-danger mb-3">
                                        Click at Enable, To Hold <b>Offer</b> For This Plan.
                                    </small>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="input-group">
                                        <div class="form-group  col-md-3">
                                        <label>Hold Offer :</label>
                                        </div>
                                        <div class="form-group  col-md-2">
                                        <label class="switch ml-3">
                                            <input type="checkbox" id="offer_hold" name="offer_hold"
                                                   class="status"
                                                   value="1">
                                            <span class="slider round"></span>
                                        </label>
                                        </div>
                                        </div>
                                    </div>
                                </div>
                            </div> -->
                            <!-- <button type="submit" class="btn btn-primary">Update</button> -->
                        </div>
                    </div>
                </form>
            </div>
        </div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script>
    $('#choise1').hide();
    $('.myclass').removeClass("col-md-11");
    $('.myclass').addClass("col-md-12");

    if($('#currencyId option:selected').text()){
        $('#choise1').show();
        $('.myclass').removeClass("col-md-12");
        $('.myclass').addClass("col-md-11");
        let selected = $('#currencyId option:selected').text()
        let symbole = selected.match(/\(([^)]+)\)/)[1];
        $("#choise").html(symbole);
    }

    $(document).ready(function() {
      
      $('#currencyId').change(function(event) {
        $('#choise1').show();
        $('.myclass').removeClass("col-md-12");
        $('.myclass').addClass("col-md-11");
        let selected = $('#currencyId option:selected').text();
        let symbole = selected.match(/\(([^)]+)\)/)[1];
        $("#choise").html(symbole);
      });
    });
    $(document).ready(function () {
        $('.selectcurrencyy').select2({
            theme: "classic"
        }).addClass("form-control");

        $('#duration_type').select2({
            theme: "classic"
        }).addClass("form-control");
    });
    $(document).ready(function () {

         //come by default
         if('{{$SubscriptionPlan->offer_status}}'=='1'){
            $("#offer_status").prop('checked', true);
            $("#offeritems").show();
            $("#datepicker" ).datepicker({ dateFormat: 'dd/mm/yy',minDate: 0, });
            $("#datepicker" ).val('{{date("d/m/Y", strtotime($SubscriptionPlan->offer_startdate))}}');
            //if hold is enabled for offer then
            if('{{$SubscriptionPlan->offer_hold}}'=='1'){
                $("#offer_hold").prop('checked', true);
            }
         }else{
            $("#offeritems").hide();
         }

         //on click offer
         $('#offer_status').click( function(){
            if ($('#offer_status').is(":checked"))
            {
                $("#offeritems").show();
                $("#datepicker" ).datepicker({ dateFormat: 'dd/mm/yy',minDate: 0, });
                if('{{$SubscriptionPlan->offer_startdate}}' != ''){
                    $("#datepicker" ).val('{{date("d/m/Y", strtotime($SubscriptionPlan->offer_startdate))}}');
                }
                if('{{$SubscriptionPlan->offer_hold}}'=='1'){
                    $("#offer_hold").prop('checked', true);
                }
            }
            else
            {
                $("#offeritems").hide();
                $("#datepicker").val('');
                $("#offer_hold").prop('checked', false);
            }
        });

        $("#viewplan").validate({
                rules: {
                        title: {
                            required: true,
                        },
                        currency_id: {
                            required: true,
                        },
                        price: {
                            required: true,
                            number: true,
                        },
                        duration: {
                            required: true,
                            number: true,
                        },
                        duration_type: {
                            required: true,
                        },
                        allowed_products: {
                            required: true,
                            number: true,
                        },
                        allowed_invoice: {
                            required: true,
                            number: true,
                        },
                        expected_volume_of_business: {
                            required: true,
                            number: true,
                        }
                },
                messages: {
                     title:{
                      required: function() { toastr.error('Title field is required') },
                      },
                     currency_id:{
                      required: function() { toastr.error('Currency field is required') },
                      },
                     price:{
                      required: function() { toastr.error('Price field is required') },
                      number: function() { toastr.error('Price should be in Number Formate') },
                      },
                     duration:{
                      required: function() { toastr.error('Please Select Duration for plan') },
                      number: function() { toastr.error('Plan Duration should be in Number Formate') },
                      },
                     duration_type:{
                      required: function() { toastr.error('Please Select Duration Type for plan') },
                      },
                     allowed_products:{
                      required: function() { toastr.error('Please Select Allowed Products for plan') },
                      number: function() { toastr.error('Allowed Products should be in Number Formate') },
                      },
                     allowed_invoice:{
                      required: function() { toastr.error('Please Select Allowed Invoice for plan') },
                      number: function() { toastr.error('Allowed Invoice should be in Number Formate') },
                      },
                     expected_volume_of_business:{
                      required: function() { toastr.error('Please Select Expected Volume Of Business for plan') },
                      number: function() { toastr.error('Expected Volume Of Business should be in Number Formate') },
                      },
                },
                submitHandler: function(form){
                  
                  //var url = SITEURL+'/admin/engineers/update';
                  var form_data = new FormData(form);
                  //var file_data = $("#profile_image").prop("files")[0];
                  //form_data.append("file", file_data);

                  $.ajax({
                    url: '{{url("admin/plan/update-plan")}}',
                    type: 'POST',
                    processData: false,
                    contentType: false,
                    data: form_data,
                    success: function(result){

                        console.log(result);

                      var res = $.parseJSON(result);
                      console.log(res);
                      var message = res.message;
                      console.log(message);
                              //console.log(message);

                            if(res.message == true){
                              //   $.notify({
                              //     message: message 
                              // },{
                              //     type: 'success'
                              // });
                              toastr.success('{{\App\CPU\translate('Plan updated successfully!')}}', {
                                CloseButton: true,
                                ProgressBar: true
                              });
                                window.location.replace('{{url("admin/plan/plan-list")}}');
                            }else{
                              // $.notify({
                              //     message: message 
                              // },{
                              //     type: 'danger'
                              // });
                              toastr.error('{{\App\CPU\translate('Oops Something went wrong!')}}', {
                                CloseButton: true,
                                ProgressBar: true
                              });
                              window.location.replace('{{url("admin/plan/plan-list")}}');
                            }
                        }
                    });
                }
                         
        });

    });
</script>


@endsection

@push('script')

@endpush
