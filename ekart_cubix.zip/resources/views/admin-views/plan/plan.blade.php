@extends('layouts.back-end.app')

@section('title', \App\CPU\translate('Plan'))

@push('css_or_js')
    <meta name="csrf-token" content="{{ csrf_token() }}">
@endpush

@section('content')
    <div class="content container-fluid">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{route('admin.dashboard')}}">{{\App\CPU\translate('Dashboard')}}</a>
                </li>
                <li class="breadcrumb-item" aria-current="page">{{\App\CPU\translate('Plan')}}  </li>
            </ol>
        </nav>

        <div class="row" style="margin-top: 20px">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">

                        <h5>{{ \App\CPU\translate('seller_plans')}}</h5>
                        <!-- <select name="withdraw_status_filter" onchange="status_filter(this.value)" class="custom-select float-right" style="width: 200px">
                            <option value="all" {{session()->has('withdraw_status_filter') && session('withdraw_status_filter') == 'all'?'selected':''}}>{{\App\CPU\translate('All')}}</option>
                            <option value="approved" {{session()->has('withdraw_status_filter') && session('withdraw_status_filter') == 'approved'?'selected':''}}>{{\App\CPU\translate('Approved')}}</option>
                            <option value="denied" {{session()->has('withdraw_status_filter') && session('withdraw_status_filter') == 'denied'?'selected':''}}>{{\App\CPU\translate('Denied')}}</option>
                            <option value="pending" {{session()->has('withdraw_status_filter') && session('withdraw_status_filter') == 'pending'?'selected':''}}>{{\App\CPU\translate('Pending')}}</option>
                        </select> -->

                        
                        <a href="{{route('admin.plan.add-plan')}}" class="btn btn-primary  float-right">
                            <i class="tio-add-circle"></i>
                            <span class="text">{{\App\CPU\translate('add_new_plan')}}</span>
                        </a>
                    </div>
                    <div class="card-body" style="padding: 0">
                        <div class="table-responsive">
                            <table id="datatable"
                                   style="text-align: {{Session::get('direction') === "rtl" ? 'right' : 'left'}};"
                                   class="table table-hover table-borderless table-thead-bordered table-nowrap table-align-middle card-table"
                                   style="width: 100%">
                                <thead class="thead-light">
                                <tr>
                                    <th>{{\App\CPU\translate('SL#')}}</th>
                                    <th>{{\App\CPU\translate('plan_name')}}</th>
                                    <th>{{\App\CPU\translate('plan_price') }}</th>
                                    <th>{{\App\CPU\translate('plan_duration')}}</th>
                                    <th>{{\App\CPU\translate('allowed_no._of_products')}}</th>
                                    <th>{{\App\CPU\translate('allowed_no._of_invoices/month')}}</th>
                                    <th>{{\App\CPU\translate('offer_status')}}</th>
                                    <th style="width: 5px">{{\App\CPU\translate('Action')}}</th>
                                </tr>
                                </thead>
                                <tbody>
                                @foreach($plan_req as $k=>$pr)
                                    <tr>
                                        <td scope="row">{{$k+1}}</td>
                                        <td>{{Ucfirst($pr->title)}}</td>
                                        <td>{{\App\CPU\BackEndHelper::set_plan_currency($pr['price'],$pr['currency_id'])}}</td>
                                        @if($pr['duration']==1)
                                            <td>{{$pr['duration']}}Month</td>
                                        @else
                                            <td>{{\App\CPU\BackEndHelper::set_plan_duration($pr['duration'],$pr['duration_type'])}}</td>
                                        @endif
                                        <td>{{$pr->allowed_products}}</td>
                                        <td>{{$pr->allowed_invoice}}</td>
                                        <td>
                                            @if(empty($pr->validOffers[0]))
                                                <label class="badge badge-primary">{{\App\CPU\translate('No Offer')}}</label>
                                            @else
                                                <label class="badge badge-success">{{\App\CPU\translate('offer_on')}}</label>
                                            @endif
                                        </td>
                                        <td>
                                            <a href="{{route('admin.plan.view',['id'=>$pr->id])}}"
                                               class="btn btn-primary btn-sm">
                                                {{\App\CPU\translate('View')}}
                                            </a> | <a href="javascript:void(0)"
                                               class="btn btn-primary btn-sm" onclick="Swal.fire({title: 'Do you Delete this Plan?',showDenyButton: true,showCancelButton: true,confirmButtonColor: '#377dff',cancelButtonColor: '#363636',confirmButtonText: `Yes`,denyButtonText: `Don't Logout`,}).then((result) => { if (result.value) 
                                                         {
                                                            deletePlan('{{$pr->id}}');
                                                         } else{
                                                            Swal.fire('Canceled', '', 'info')
                                                         }
                                                     })">
                                                {{\App\CPU\translate('Delete')}}
                                            </a> 
                                        </td>
                                    </tr>
                                @endforeach
                                </tbody>
                            </table>
                            @if(count($plan_req)==0)
                                <div class="text-center p-4">
                                    <img class="mb-3"
                                         src="{{asset('public/assets/back-end')}}/svg/illustrations/sorry.svg"
                                         alt="Image Description" style="width: 7rem;">
                                    <p class="mb-0">{{\App\CPU\translate('No_data_to_show')}}</p>
                                </div>
                        @endif
                        </div>
                    </div>
                    <div class="card-footer">
                    </div>
                </div>
            </div>

        </div>
    </div>
@endsection


@push('script_2')
  <script>
      function status_filter(type) {
          $.ajaxSetup({
              headers: {
                  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
              }
          });
          $.post({
              url: '{{route('admin.withdraw.status-filter')}}',
              data: {
                  withdraw_status_filter: type
              },
              beforeSend: function () {
                  $('#loading').show()
              },
              success: function (data) {
                 location.reload();
              },
              complete: function () {
                  $('#loading').hide()
              }
          });
      }

      function deletePlan(pid){
        $.ajax({
                    url: '{{url("admin/plan/delete-plan")}}/'+pid,
                    type: 'GET',
                    success: function(result){

                        console.log(result);

                      var res = $.parseJSON(result);
                      console.log(res);
                      var message = res.message;
                      console.log(message);
                              //console.log(message);

                            if(res.message == true){
                              toastr.success('{{\App\CPU\translate('Plan deleted successfully!')}}', {
                                CloseButton: true,
                                ProgressBar: true
                              });
                                window.location.replace('{{url("admin/plan/plan-list")}}');
                            }else{
                              toastr.error('{{\App\CPU\translate('Oops Something went wrong!')}}', {
                                CloseButton: true,
                                ProgressBar: true
                              });
                              window.location.replace('{{url("admin/plan/plan-list")}}');
                            }
                        }
                    });
      }
  </script>
@endpush
