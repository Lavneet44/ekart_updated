@extends('layouts.back-end.app-seller')

@section('title', \App\CPU\translate('Categories'))

@push('css_or_js')

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script type="text/javascript">
   function deleteCategory(id){
    var id = id;
    Swal.fire({
            title: '{{\App\CPU\translate('Are you sure')}}?',
            text: '',
            type: 'warning',
            showCancelButton: true,
            cancelButtonColor: 'default',
            confirmButtonColor: '#377dff',
            cancelButtonText: 'No',
            confirmButtonText: 'Yes',
            reverseButtons: true
        }).then((result) => {
            window.location.href="{{ url('seller/product/delete-catgory')}}/"+id;
        })
   }
   $(document).ready(function(){
    $('.collapse').addClass('show');
   });
</script>

@endpush

@section('content')
    <div class="content container-fluid">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{route('seller.dashboard.index')}}">{{\App\CPU\translate('Dashboard')}}</a>
                </li>
                <li class="breadcrumb-item"><a href="{{route('seller.product.categories')}}">{{\App\CPU\translate('Categories')}}</a>
                </li>
            </ol>
        </nav>

        <!-- Content Row -->
        <div class="row">
            
            <div class="col-md-8 mx-auto">
                <div class="card">
                    <div class="card-header">
                        {{ \App\CPU\translate('Add Category')}}
                    </div>
                    <div class="card-body">
                        <form action="{{ route('seller.product.create-category') }}" method="post">
                            @csrf
                            <div class="form-group">
                                <label>Select Parent Category</label>
                                <div style="border: 1px solid #eee;padding:5px;">
                                    <ul style="list-style: none;height: 250px;overflow-y: scroll;">
                                        @php \App\Http\Controllers\Seller\ProductController::generateParentCategoryTree($category,$selected_id) @endphp
                                    </ul>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Category Name</label>
                                <input type="text" name="name" class="form-control" placeholder="Category Name">
                            </div>
                            <!-- <div class="form-group">
                                <label>Category Icon</label>
                                <input type="file" name="image" class="form-control">
                            </div> -->
                            <div class="form-group">
                                <button class="btn btn-primary" type="submit">Save</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

        </div>
    </div>
@endsection
