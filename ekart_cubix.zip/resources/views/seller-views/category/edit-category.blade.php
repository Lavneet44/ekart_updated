@extends('layouts.back-end.app-seller')

@section('title', \App\CPU\translate('Categories'))

@push('css_or_js')

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script type="text/javascript">
       function deleteCategory(id){
        var id = id;
        Swal.fire({
                title: '{{\App\CPU\translate('Are you sure')}}?',
                text: '',
                type: 'warning',
                showCancelButton: true,
                cancelButtonColor: 'default',
                confirmButtonColor: '#377dff',
                cancelButtonText: 'No',
                confirmButtonText: 'Yes',
                reverseButtons: true
            }).then((result) => {
                window.location.href="{{ url('seller/product/delete-catgory')}}/"+id;
            })
       }
    </script>

@endpush

@section('content')
    <div class="content container-fluid">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{route('seller.dashboard.index')}}">{{\App\CPU\translate('Dashboard')}}</a>
                </li>
                <li class="breadcrumb-item"><a href="{{route('seller.product.categories')}}">{{\App\CPU\translate('Categories')}}</a>
                </li>
            </ol>
        </nav>

        <!-- Content Row -->
        <div class="row">
            
            <div class="col-md-8 mx-auto">
                <div class="card">
                    <div class="card-header">
                        {{ \App\CPU\translate('Edit Categories')}}
                    </div>
                    <div class="card-body">
                        <form action="{{ route('seller.product.edit-category') }}" method="post">
                            @csrf
                            <input type="hidden" name="id" value="{{ $edit_cat->id }}">
                            <div class="form-group">
                                <label>Select Parent Category</label>
                                <div>
                                    <ul style="list-style: none;">
                                        @php \App\Http\Controllers\Seller\ProductController::generateParentCategoryTree($category,$edit_cat->parent_id,$edit_cat->id) @endphp
                                    </ul>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Category Name</label>
                                <input type="text" name="name" class="form-control" placeholder="Category Name" value="{{ $edit_cat->name }}">
                            </div>
                            <!-- <div class="form-group">
                                <label>Category Icon</label>
                                <input type="file" name="image" class="form-control">
                            </div>
                            <div class="col-12 from_part_2">
                                <div class="form-group">
                                    <hr>
                                    <center>
                                        <img style="width: 30%;border: 1px solid; border-radius: 10px;"
                                             id="viewer"
                                             src="{{asset('storage/app/public/category')}}/{{$edit_cat->icon}}"
                                             alt=""/>
                                    </center>
                                </div>
                            </div> -->
                            <div class="form-group">
                                <button class="btn btn-primary" type="submit">Save</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLongTitle">Modal title</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            ...
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="button" class="btn btn-primary">Save changes</button>
          </div>
        </div>
      </div>
    </div>
@endsection
