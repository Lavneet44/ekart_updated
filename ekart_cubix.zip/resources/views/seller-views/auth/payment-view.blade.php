<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required Meta Tags Always Come First -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Title -->
    <title>{{\App\CPU\translate('PLan_Payment')}}</title>

    <!-- Favicon -->
    <link rel="shortcut icon" href="favicon.ico">

    <!-- Font -->
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&amp;display=swap" rel="stylesheet">
    <!-- CSS Implementing Plugins -->
    <link rel="stylesheet" href="{{asset('public/assets/back-end')}}/css/vendor.min.css">
    <link rel="stylesheet" href="{{asset('public/assets/back-end')}}/vendor/icon-set/style.css">
    <!-- CSS Front Template -->
    <link rel="stylesheet" href="{{asset('public/assets/back-end')}}/css/theme.minc619.css?v=1.0">
    <link rel="stylesheet" href="{{asset('public/assets/back-end')}}/css/toastr.css">
</head>

<body>
<!-- ========== MAIN CONTENT ========== -->
<main id="content" role="main" class="main">
    <div class="position-fixed top-0 right-0 left-0 bg-img-hero"
         style="height: 32rem; background-image: url({{asset('public/assets/admin')}}/svg/components/abstract-bg-4.svg);">
        <!-- SVG Bottom Shape -->
        <figure class="position-absolute right-0 bottom-0 left-0">
            <svg preserveAspectRatio="none" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 1921 273">
                <polygon fill="#fff" points="0,273 1921,273 1921,0 "/>
            </svg>
        </figure>
        <!-- End SVG Bottom Shape -->
    </div>

    <!-- Content -->
    <div class="container py-5 py-sm-7">
        @php($e_commerce_logo=\App\Model\BusinessSetting::where(['type'=>'company_web_logo'])->first()->value)
        <a class="d-flex justify-content-center mb-5" href="javascript:">
            <img class="z-index-2"  src="{{asset("storage/app/public/company/".$e_commerce_logo)}}" alt="Logo"
                 onerror="this.src='{{asset('public/assets/back-end/img/400x400/img2.jpg')}}'"
                 style="width: 8rem;">
        </a>

        <div class="row justify-content-center">
            <div class="col-lg-8 col-md-10">
                <h2 class="h3 mb-4">{{\App\CPU\translate('plan_payment_window?')}}</h2>
                <div class="card py-2 mt-4">
                    @if(!empty($seller->ontips))
                        <div class="alert alert-info ml-2 mr-2 mt-1" role="alert">
                            <span>{{\App\CPU\translate('Please copy this one Time Password')}} :- </span>
                            <span style="background-color: red;" class="pl-3 pr-3">{{(!empty($seller->ontips))?$seller->ontips:''}}</span>
                            <br/>
                            <span style="font-size:15px">NOTE:-later as Mail Module Done we will By-Pass this section and send OTP at user's mail Only</span>
                        </div>
                    @endif
                    <form class="card-body needs-validation" action="{{route('seller.auth.payment-process')}}"
                          method="post">
                        <input type="hidden" name="plan_data" value="{{$seller->pd}}">
                        @csrf
                        <div class="input-group">
                            <div class="form-group col-md-6">
                                <label for="recover-email">{{\App\CPU\translate('name')}}</label>
                                <input class="form-control" type="text" id="name" value="{{$seller->f_name}} {{$seller->l_name}}" disabled>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="recover-email">{{\App\CPU\translate('phone')}}</label>
                                <input class="form-control" type="text" name="phone" id="recover-email" value="{{$seller->phone}}" disabled>
                            </div>
                        </div>
                        <div class="input-group">
                            <div class="form-group col-md-6">
                                <label for="recover-email">{{\App\CPU\translate('email')}}</label>
                                <input class="form-control" type="text" id="email" value="{{$seller->email}}" disabled>
                            </div>

                            <div class="form-group col-md-6">
                                <label for="recover-email">{{\App\CPU\translate('plan_duration')}}</label>
                                <input class="form-control" type="text" id="purchase_plan" value="{{(\App\CPU\BackEndHelper::set_plan_duration($seller->registerSellerPlanRequest->duration,$seller->registerSellerPlanRequest->duration_type)=='Month')?'Monthly Plan':\App\CPU\BackEndHelper::set_plan_duration($seller->registerSellerPlanRequest->duration,$seller->registerSellerPlanRequest->duration_type).' Plan'}}" disabled>
                            </div>
                            @if(!empty($seller->registerSellerPlanRequestOffer))
                            <div class="form-group col-md-6">
                                <label for="recover-email">{{\App\CPU\translate('Plan_price')}}, {{\App\CPU\translate('after offer')}} !</label>
                                <input class="form-control" type="text" id="finalprice" value="{{$seller->registerSellerPlanRequest->planCurrency->symbol}} {{$seller->finalprice}}" disabled>
                            </div>
                            @endif
                            <div class="form-group col-md-6">
                                <label for="recover-email">{{\App\CPU\translate('purchase_plan')}}</label>
                                <input class="form-control" type="text" id="purchase_plan" value=" {{$seller->registerSellerPlanRequest->planCurrency->symbol}} {{$seller->registerSellerPlanRequest->price}}" disabled>
                            </div>
                        </div>
                        <button class="btn btn-primary" {{(!empty($seller->ontips))?'disabled':''}} type="submit">{{\App\CPU\translate('Pay')}}</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- End Content -->
</main>
<!-- ========== END MAIN CONTENT ========== -->


<!-- JS Implementing Plugins -->
<script src="{{asset('public/assets/back-end')}}/js/vendor.min.js"></script>

<!-- JS Front -->
<script src="{{asset('public/assets/back-end')}}/js/theme.min.js"></script>
<script src="{{asset('public/assets/back-end')}}/js/toastr.js"></script>
{!! Toastr::message() !!}

@if ($errors->any())
    <script>
        @foreach($errors->all() as $error)
        toastr.error('{{$error}}', Error, {
            CloseButton: true,
            ProgressBar: true
        });
        @endforeach
    </script>
@endif

<!-- JS Plugins Init. -->
<script>
    $(document).on('ready', function () {
        // INITIALIZATION OF SHOW PASSWORD
        // =======================================================
        $('.js-toggle-password').each(function () {
            new HSTogglePassword(this).init()
        });

        // INITIALIZATION OF FORM VALIDATION
        // =======================================================
        $('.js-validate').each(function () {
            $.HSCore.components.HSValidation.init($(this));
        });
    });
</script>

<!-- IE Support -->
<script>
    if (/MSIE \d|Trident.*rv:/.test(navigator.userAgent)) document.write('<script src="{{asset('public/assets/admin')}}/vendor/babel-polyfill/polyfill.min.js"><\/script>');
</script>
</body>
</html>

