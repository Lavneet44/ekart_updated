<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class PossibleVariant extends Model
{
    protected $table = 'possible_variant';

}