<?php

namespace App\Http\Controllers\Seller;

use App\CPU\Helpers;
use App\Http\Controllers\Controller;
use App\Model\Order;
use App\Model\CreditPermission;
use App\User;
use Brian2694\Toastr\Facades\Toastr;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CustomerController extends Controller
{
    public function customer_list(Request $request)
    {
        $query_param = [];
        $search = $request['search'];
        if ($request->has('search')) {
            $key = explode(' ', $request['search']);
            //$customers = User::with(['orders','creditpermission'])
            $customers = User::with(['orders'])
                ->where(function ($q) use ($key) {
                    foreach ($key as $value) {
                        $q->orWhere('f_name', 'like', "%{$value}%")
                            ->orWhere('l_name', 'like', "%{$value}%")
                            ->orWhere('phone', 'like', "%{$value}%")
                            ->orWhere('email', 'like', "%{$value}%");
                    }
                });
            $query_param = ['search' => $request['search']];
        } else {
            //$customers = User::with(['orders','creditpermission']);
            $customers = User::with(['orders']);
        }
        $customers = $customers->latest()->paginate(Helpers::pagination_limit())->appends($query_param);
        return view('seller-views.customer.list', compact('customers', 'search'));
    }

    public function credit_permission_update(Request $request)
    {
        $status = 0;
        $CreditPermission = CreditPermission::where(['customer_id' => $request['id'],'seller_id' => auth('seller')->id()])->first();
        if(!empty($CreditPermission)){
            CreditPermission::where(['customer_id' => $request['id'],'seller_id' => auth('seller')->id()])->update(['credit_permission' => $request['status'], 'updated_at' => date('Y-m-d H:i:s')]);
            $status = 1;
        }else{
            CreditPermission::insert(
                [
                    'customer_id' => $request['id'],
                    'seller_id' => auth('seller')->id(),
                    'credit_permission' => $request['status'],
                    'credit_permission' => $request['status'],
                    'created_at' => date('Y-m-d H:i:s')
                ]
            );
            $status =1;
        }
        return response()->json(['status' => $status], 200);


    }

}
