<?php

namespace App\Http\Controllers\Seller;

use App\Http\Controllers\Controller;
use App\Model\Brand;
use App\Model\Order;
use App\Model\OrderDetail;
use App\Model\OrderTransaction;
use App\Model\Product;
use App\Model\SubscriptionPlan;
use App\Model\SellerWallet;
use App\Model\Shop;
use App\Model\Seller;
use App\Model\SellerPlan;
use App\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Session;

class PlanController extends Controller
{
    public function getAllPlans()
    {
        $data['plan'] = SubscriptionPlan::all(); 
        return view('seller-views.system.planwindow', compact('data'));
    }

    public function purchasePlan(Request $request)
    {
        $SellerPlan = new SellerPlan;
        $SellerPlan->seller_id = auth('seller')->id();
        $SellerPlan->subscription_plan_id = $request->pid;
        if($SellerPlan->save()){
            $plans = array();
            $SellerPlan = SellerPlan::where('seller_id', auth('seller')->id())->get();
            if(!empty($SellerPlan)){
                foreach($SellerPlan as $key =>$sp){
                    $plans[$key] = $sp->subscription_plan_id;

                    print_r($sp);
                } 
            }
            session()->put('PlanId', $plans);
            $responce = array(['success' => 1]);
        }else{
            $responce = array(['success' => 0]);
        }
        echo json_encode($responce);
    }
}
