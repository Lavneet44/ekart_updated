@extends('layouts.back-end.app')

@section('title', 'Offer')   

@push('css_or_js')
@endpush

<style type="text/css">
.parent {
  align-items: center;
  border: 1px solid black;
  display: flex;
  justify-content: center;
  height: 250px;
  width: 250px;
} 

.child {
  border: 1px solid black;
  height: 50px;
  width: 50px;
}
</style>
@section('content')
<div class="content container-fluid">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{route('admin.dashboard.index')}}">{{\App\CPU\translate('Dashboard')}}</a>
                </li>
                <li class="breadcrumb-item"><a href="{{route('admin.plan.offer-list')}}">{{\App\CPU\translate('offer_list')}}</a>
                </li>
                <li class="breadcrumb-item" aria-current="page">{{\App\CPU\translate('edit_offer')}}</li>
            </ol>
        </nav>

        <!-- Page Heading -->
    
        <!-- Page Header -->
   
        <!-- End Page Header -->
        <div class="row">
            <div class="col-md-12 mt-3">
                <form action="" method="post" id="addoffer">
                    @csrf
                    <input type="hidden" class="form-control" name="id_offer" style="width:100%;" value="{{$offer->id}}">
                    <input type="hidden" class="form-control" name="plan_id" style="width:100%;" value="{{$offer->plan_id}}">
                    <div class="card">
                        <div class="card-header">
                            <h5>{{\App\CPU\translate('view_list')}}</h5>
                        </div>
                        <div class="card-body">
                            <div class="input-group">
                                <div class="form-group  col-md-12">
                                    <label>{{\App\CPU\translate('offer_title')}}</label> <span class="text-danger">*</span>
                                    <input type="text" class="form-control" name="offer_title" style="width:100%;" value="{{$offer->offer_title}}" disabled>
                                </div>
                                <div class="form-group col-md-6">
                                    <label>{{\App\CPU\translate('Plans')}}</label> <span class="text-danger">*</span>
                                    <select class="form-control selectcurrencyy" name="plan_id" style="width:100%;" disabled>
                                        <option value="">--Select Plan--</option>
                                        @foreach($SubscriptionPlans as $pl)
                                        <option  data-price="{{$pl->price}}" data-currency="{{$pl->planCurrency->symbol}}"  {{($pl->id==$offer->plan_id)?'selected':''}} value="{{$pl->id}}">{{$pl->title}}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group  col-md-6" >
                                    <label>{{\App\CPU\translate('Plan_price')}}</label>
                                    <input  type="text" id="plan_price" class="form-control" style="width:100%;" autocomplete="off" disabled>
                                </div>
                            <div class="input-group offeritems">

                                <div class="form-group  col-md-6">
                                    <label>{{\App\CPU\translate('offer_ammount')}}</label> <span class="text-danger">*</span>
                                    <input type="text" class="form-control" name="offer_ammount" style="width:100%;" value="{{$offer->new_ammount}}" disabled>
                                </div>
                                <div class="form-group  col-md-6" >
                                    <label>{{\App\CPU\translate('offer_start_date')}}</label> <span class="text-danger">*</span>
                                    <input type="text" id="datepicker" class="form-control" name="offer_startdate" style="width:100%;" autocomplete="off" disabled>
                                </div>
                                <div class="form-group  col-md-6">
                                    <label>{{\App\CPU\translate('offer_end_date')}}</label>
                                    <input type="text" id="offerenddatepicker" class="form-control" name="offer_enddate" style="width:100%;" autocomplete="off">
                                </div>
                            </div>
                            </div>
                            <div class="input-group">
                                <div class="col-md-6">
                                    <div class="input-group">
                                    <small class="badge badge-soft-danger mb-3">
                                        Click at Enable, To Hold <b>Offer</b> For This Plan.
                                    </small>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="input-group">
                                        <div class="form-group  col-md-3">
                                        <label>Hold Offer :</label>
                                        </div>
                                        <div class="form-group  col-md-2">
                                        <label class="switch ml-3">
                                            <input type="checkbox" id="offer_hold" name="offer_hold"
                                                   class="status"
                                                   value="1">
                                            <span class="slider round"></span>
                                        </label>
                                        </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="input-group">
                                <div class="form-group  col-md-12">
                                    <label class="input-label">{{\App\CPU\translate('description')}} </label>
                                    <textarea class="form-control" name="note" id="editorid" class="editor textarea" cols="30" rows="10" required>{{(!empty($offer->note))?$offer->note:''}}</textarea>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary">Update</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script>
    $(document).ready(function () {
         if($('.selectcurrencyy option:selected').text()){
            var price = $('.selectcurrencyy').find(':selected').attr('data-price');
            var curr = $('.selectcurrencyy').find(':selected').attr('data-currency');
            $('#plan_price').val(curr+' '+price);
        }

         $("#datepicker").val('{{date("d/m/Y",strtotime($offer->offer_startdate))}}');
         if('{{$offer->offer_enddate}}'!=''){
            $("#offerenddatepicker").val('{{date("d/m/Y",strtotime($offer->offer_enddate))}}');
         }

          if($("#datepicker").val()!=''){
            var edittime_end_d = $('#offerenddatepicker');
            var edittimestartdate = '{{date("d/m/Y",strtotime($offer->offer_startdate))}}';
            var from = edittimestartdate.split('/');
            var d = new Date(from[2],from[1]-1,from[0]);
            var day = d.getDate();
            var month = d.getMonth()+1;
            var year = d.getFullYear();
            $('#offerenddatepicker').datepicker("destroy");
            console.log(edittime_end_d);
            $('#offerenddatepicker').datepicker({
                dateFormat: 'dd/mm/yy',
                minDate: new Date(month+"-"+day+"-"+year)
            });
          }

         if('{{$offer->hold}}'==1){
            $('#offer_hold').prop("checked",true);
         }else{
            $('#offer_hold').prop("checked",false);
         }


         var start_d=$('#datepicker');
         var end_d=$('#offerenddatepicker');
         start_d.datepicker({
            dateFormat: 'dd/mm/yy',
            minDate: 0,
            onSelect: function (selectedDate){
                console.log(selectedDate);
                var from = $('#datepicker').val().split('/');
                var d = new Date(from[2],from[1]-1,from[0]);
                var day = d.getDate();
                var month = d.getMonth()+1;
                var year = d.getFullYear();
                end_d.datepicker("destroy");
                end_d.datepicker({
                    dateFormat: 'dd/mm/yy',
                    minDate: new Date(month+"-"+day+"-"+year)
                });
            }
        });

        $('#offerenddatepicker').on('click', function (selected) {
              if ($("#datepicker").val()=='') {
                toastr.error('Please Select Start Date first')
                $('#offerenddatepicker').val('');
                $('#datepicker').focus();
                return false;
              }
        });

        $("#addoffer").validate({
                rules: {
                        offer_title: {
                            required: true,
                        },
                        offer_ammount: {
                            required: true,
                            digits: true,
                        },
                        plan_id: {
                            required: true,
                        },
                        offer_startdate: {
                            required: true,
                        }
                },
                messages: {
                     offer_title:{
                      required: function() { toastr.error('Please Fill offer Title') },
                      },
                     offer_ammount:{
                      required: function() { toastr.error('Please Fill offer ammount') },
                      number: function() { toastr.error('Price should be in Number Formate') },
                      },
                     plan_id:{
                      required: function() { toastr.error('Please select a plan') },
                      },
                     offer_startdate:{
                      required: function() { toastr.error('Please select offer start date') },
                      },
                },
                submitHandler: function(form){
                  var form_data = new FormData(form);
                  $.ajax({
                    url: '{{url("admin/plan/update-offer")}}',
                    type: 'POST',
                    processData: false,
                    contentType: false,
                    data: form_data,
                    success: function(result){
                      var res = $.parseJSON(result);
                      console.log(res);
                      var message = res.message;
                            if(res.message == true){
                              toastr.success('{{\App\CPU\translate('Plan updated successfully!')}}', {
                                CloseButton: true,
                                ProgressBar: true
                              });
                             window.location.replace('{{url("admin/plan/offer-list")}}');
                            }else{
                              toastr.error('{{\App\CPU\translate('Oops Something went wrong!')}}', {
                                CloseButton: true,
                                ProgressBar: true
                              });
                              window.location.replace('{{url("admin/plan/offer-list")}}');
                            }
                        }
                    });
                }
                         
        });

    });
</script>


@endsection

@push('script')

@endpush
