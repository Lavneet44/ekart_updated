@extends('layouts.back-end.app')

@section('title', 'Plan View')

@push('css_or_js')
@endpush

<style type="text/css">
.parent {
  align-items: center;
  border: 1px solid black;
  display: flex;
  justify-content: center;
  height: 250px;
  width: 250px;
}

.child {
  border: 1px solid black;
  height: 50px;
  width: 50px;
}
</style>
@section('content')
<div class="content container-fluid">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{route('admin.dashboard.index')}}">{{\App\CPU\translate('Dashboard')}}</a>
                </li>
                <li class="breadcrumb-item"><a href="{{route('admin.plan.plan-list')}}">{{\App\CPU\translate('seller_plans')}}</a>
                </li>
                <li class="breadcrumb-item" aria-current="page">{{\App\CPU\translate('Plan_Details')}}</li>
            </ol>
        </nav>

        <!-- Page Heading -->
    
        <!-- Page Header -->
   
        <!-- End Page Header -->
        <div class="row">
            <div class="col-md-12 mt-3">
                <form action="" method="post" id="samplecode">
                    @csrf
                    <div class="card">
                        <div class="card-header">
                            <h5>Add Plan</h5>
                        </div>
                        <div class="card-body">
                            <div class="input-group">
                                <div class="form-group col-md-6">
                                    <label>Title</label> <span class="text-danger">*</span>
                                    <input type="text" class="form-control" name="title" style="width:100%;">
                                </div>
                                <div class="form-group  col-md-6">
                                    <label>Currency</label> <span class="text-danger">*</span>
                                    <select class="form-control selectcurrencyy" name="currency_id" style="width:100%;">
                                        <option value="">--Select Currency--</option>
                                        @foreach($Currency as $cu)
                                        <option value="{{$cu->id}}">{{$cu->code}} ({{$cu->symbol}})</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="input-group">
                                <div class="form-group  col-md-6">
                                    <label>Price</label> <span class="text-danger">*</span>
                                    <input type="text" class="form-control" name="price" style="width:100%;">
                                </div>
                                <div class="col-md-6">
                                <label>Duration</label> <span class="text-danger">*</span>
                                <div class="row">
                                    <div class="col-md-6 mb-5">
                                        <input type="text" class="form-control" name="duration">
                                    </div>
                                    <div class="col-md-6">
                                        <select class="form-control" name="duration_type">
                                            <option value="">-- Select Duration Type --</option>
                                            <option value="1">Days</option>
                                            <option value="2">Months</option>
                                            <option value="3">Year</option>
                                        </select>
                                    </div>
                                </div>
                                </div>
                            </div>
                            <div class="input-group">
                                <div class="form-group  col-md-6">
                                    <label>Allowed Products</label> <span class="text-danger">*</span>
                                    <input type="text" class="form-control" name="allowed_products" style="width:100%;">
                                </div>
                                <div class="form-group col-md-6">
                                    <label>Allowed Invoice</label> <span class="text-danger">*</span>
                                    <input type="text" class="form-control" name="allowed_invoice" style="width:100%;">
                                </div>
                            </div>
                            <div class="input-group">
                                <div class="form-group  col-md-6">
                                    <label>Expected Volume Of Business</label> <span class="text-danger">*</span>
                                    <input type="text" class="form-control" name="expected_volume_of_business" style="width:100%;">
                                </div>
                                <div class="col-md-6">
                                    <div class="input-group">
                                    <small class="badge badge-soft-danger mb-3">
                                        Click at Enable, To add <b>Offer</b> at the Plan.
                                    </small>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="input-group">
                                        <div class="form-group  col-md-3">
                                        <label>Start Offer : </label>
                                        </div>
                                        <div class="form-group  col-md-2">
                                        <label class="switch ml-3">
                                            <input type="checkbox" id="offer_status" name="offer_status"
                                                   class="status"
                                                   value="1">
                                            <span class="slider round"></span>
                                        </label>
                                        </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group  col-md-6" id="offeritems">
                                <label>Offer Start Date</label>
                                <input type="text" id="datepicker" class="form-control" name="offer_startdate" style="width:100%;" autocomplete="off">
                            </div>
                            <button type="submit" class="btn btn-primary">Create</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script>
    $(document).ready(function () {

        $('.selectcurrency').select2({
            theme: "classic"
        }).addClass("form-control");;

         $("#offeritems").hide();
         $('#offer_status').click( function(){
            if ($('#offer_status').is(":checked"))
            {
                $("#offeritems").show();
                setTimeout(function () {
                     $("#datepicker").focus();
                 }, 2500);
                $("#datepicker" ).datepicker({ dateFormat: 'dd/mm/yy',minDate: 0, });
            }
            else
            {
                $("#offeritems").hide();
                $("#datepicker").val('');
            }
        });

        $("#samplecode").validate({
                rules: {
                        title: {
                            required: true,
                        },
                        currency_id: {
                            required: true,
                        },
                        price: {
                            required: true,
                            number: true,
                        },
                        duration: {
                            required: true,
                            number: true,
                        },
                        duration_type: {
                            required: true,
                        },
                        allowed_products: {
                            required: true,
                            number: true,
                        },
                        allowed_invoice: {
                            required: true,
                            number: true,
                        },
                        expected_volume_of_business: {
                            required: true,
                            number: true,
                        }
                },
                messages: {
                     title:{
                      required: function() { toastr.error('Title field is required') },
                      },
                     currency_id:{
                      required: function() { toastr.error('Currency field is required') },
                      },
                     price:{
                      required: function() { toastr.error('Price field is required') },
                      number: function() { toastr.error('Price should be in Number Formate') },
                      },
                     duration:{
                      required: function() { toastr.error('Please Select Duration for plan') },
                      number: function() { toastr.error('Plan Duration should be in Number Formate') },
                      },
                     duration_type:{
                      required: function() { toastr.error('Please Select Duration Type for plan') },
                      },
                     allowed_products:{
                      required: function() { toastr.error('Please Select Allowed Products for plan') },
                      number: function() { toastr.error('Allowed Products should be in Number Formate') },
                      },
                     allowed_invoice:{
                      required: function() { toastr.error('Please Select Allowed Invoice for plan') },
                      number: function() { toastr.error('Allowed Invoice should be in Number Formate') },
                      },
                     expected_volume_of_business:{
                      required: function() { toastr.error('Please Select Expected Volume Of Business for plan') },
                      number: function() { toastr.error('Expected Volume Of Business should be in Number Formate') },
                      },
                },
                submitHandler: function(form){
                  
                  //var url = SITEURL+'/admin/engineers/update';
                  var form_data = new FormData(form);
                  //var file_data = $("#profile_image").prop("files")[0];
                  //form_data.append("file", file_data);

                  $.ajax({
                    url: '{{url("admin/plan/add-new")}}',
                    type: 'POST',
                    processData: false,
                    contentType: false,
                    data: form_data,
                    success: function(result){

                        console.log(result);

                      var res = $.parseJSON(result);
                      console.log(res);
                      var message = res.message;
                      console.log(message);
                              //console.log(message);

                            if(res.message == true){
                              //   $.notify({
                              //     message: message 
                              // },{
                              //     type: 'success'
                              // });
                              toastr.success('{{\App\CPU\translate('Plan updated successfully!')}}', {
                                CloseButton: true,
                                ProgressBar: true
                              });
                                window.location.replace('{{url("admin/plan/plan-list")}}');
                            }else{
                              // $.notify({
                              //     message: message 
                              // },{
                              //     type: 'danger'
                              // });
                              toastr.error('{{\App\CPU\translate('Oops Something went wrong!')}}', {
                                CloseButton: true,
                                ProgressBar: true
                              });
                              window.location.replace('{{url("admin/plan/plan-list")}}');
                            }
                        }
                    });
                }
                         
        });

    });
</script>


@endsection

@push('script')

@endpush
