@extends('layouts.back-end.app')

@section('title', \App\CPU\translate('Product Edit'))

@push('css_or_js')
    <link href="{{asset('public/assets/back-end/css/tags-input.min.css')}}" rel="stylesheet">
    <link href="{{ asset('public/assets/select2/css/select2.min.css')}}" rel="stylesheet">
    <meta name="csrf-token" content="{{ csrf_token() }}">
@endpush

@section('content')
    <!-- Page Heading -->
    <div class="content container-fluid">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{route('admin.dashboard')}}">{{\App\CPU\translate('Dashboard')}}</a>
                </li>
                <li class="breadcrumb-item" aria-current="page"><a
                        href="{{route('admin.product.list', ['in_house', ''])}}">{{\App\CPU\translate('Product')}}</a></li>
                <li class="breadcrumb-item" aria-current="page">{{\App\CPU\translate('Edit')}}</li>
            </ol>
        </nav>

        <!-- Content Row -->
        <div class="row">
            <div class="col-md-12">
                <form class="product-form" action="{{route('admin.product.update',$product->id)}}" method="post"
                      style="text-align: {{Session::get('direction') === "rtl" ? 'right' : 'left'}};"
                      enctype="multipart/form-data"
                      id="product_form">
                    @csrf

                    <div class="card">
                        <div class="card-header">
                            @php($language=\App\Model\BusinessSetting::where('type','pnc_language')->first())
                            @php($language = $language->value ?? null)
                            @php($default_lang = 'en')

                            @php($default_lang = json_decode($language)[0])
                            <ul class="nav nav-tabs mb-4">
                                @foreach(json_decode($language) as $lang)
                                    <li class="nav-item">
                                        <a class="nav-link lang_link {{$lang == $default_lang? 'active':''}}" href="#"
                                           id="{{$lang}}-link">{{\App\CPU\Helpers::get_language_name($lang).'('.strtoupper($lang).')'}}</a>
                                    </li>
                                @endforeach
                            </ul>
                        </div>

                        <div class="card-body">
                            @foreach(json_decode($language) as $lang)
                                <?php
                                if (count($product['translations'])) {
                                    $translate = [];
                                    foreach ($product['translations'] as $t) {

                                        if ($t->locale == $lang && $t->key == "name") {
                                            $translate[$lang]['name'] = $t->value;
                                        }
                                        if ($t->locale == $lang && $t->key == "description") {
                                            $translate[$lang]['description'] = $t->value;
                                        }

                                    }
                                }
                                ?>
                                <div class="{{$lang != 'en'? 'd-none':''}} lang_form" id="{{$lang}}-form">
                                    <div class="form-group">
                                        <label class="input-label" for="{{$lang}}_name">{{\App\CPU\translate('name')}}
                                            ({{strtoupper($lang)}})</label>
                                        <input type="text" {{$lang == 'en'? 'required':''}} name="name[]"
                                               id="{{$lang}}_name"
                                               value="{{$translate[$lang]['name']??$product['name']}}"
                                               class="form-control" placeholder="{{\App\CPU\translate('New Product')}}" required>
                                    </div>
                                     <div class="form-group">
                                        <div class="row">
                                            <div class="col-md-4">
                                                <label class="input-label" for="{{$lang}}_name">{{\App\CPU\translate('item code')}}
                                                    ({{strtoupper($lang)}})</label>
                                                <input type="text" {{$lang == $default_lang? 'required':''}} name="item_code" id=""  value="{{$translate[$lang]['name']??$product['item_code']}}" class="form-control" placeholder="ex:- ABC123" required>
                                            </div>
                                            <div class="col-md-4">
                                                <label class="input-label" for="{{$lang}}_name">{{\App\CPU\translate('part no')}}
                                                    ({{strtoupper($lang)}})</label>
                                                <input type="text" {{$lang == $default_lang? :''}} name="part_no" id=""  value="{{$translate[$lang]['name']??$product['part_no']}}" class="form-control" placeholder="ex:- A678123">
                                            </div>
                                            <div class="col-md-4">
                                                <label class="input-label" for="{{$lang}}_name">{{\App\CPU\translate('serial no')}}
                                                    ({{strtoupper($lang)}})</label>
                                                <input type="text" {{$lang == $default_lang? :''}} name="serial_no" id=""  value="{{$translate[$lang]['name']??$product['serial_no']}}" class="form-control" placeholder="ex:- ABC123" >
                                            </div>
                                        </div>
                                    </div>
                                    <input type="hidden" name="lang[]" value="{{$lang}}">
                                    <div class="form-group pt-4">
                                        <label class="input-label">{{\App\CPU\translate('description')}}
                                            ({{strtoupper($lang)}})</label>
                                        <textarea name="description[]" style="display:none" class="textarea"
                                                  required>{!! $translate[$lang]['description']??$product['details'] !!}</textarea>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    </div>

                    <div class="card mt-2 rest-part">
                        <div class="card-header">
                            <h4>{{ \App\CPU\translate('General Info')}}</h4>
                        </div>
                        <div class="card-body">
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-md-4">
                                        <label for="name">{{ \App\CPU\translate('Category')}}</label>
                                        <select
                                            class="js-example-basic-multiple js-states js-example-responsive form-control"
                                            name="category_id"
                                            id="cat_id"
                                            onchange="getRequest('{{url('/')}}/admin/product/get-categories?parent_id='+this.value,'sub-category-select','select')" required>
                                              @if($inserted_catagory != NULL)
                                             <option
                                                    value="{{$inserted_catagory->id}}" {{ $inserted_catagory->id==$product_category[0]->id ? 'selected' : ''}} >{{$inserted_catagory->name}}</option>
                                            @foreach($categories as $category)
                                             @if(in_array($category['id'], $allowedIds) && $category['position'] == 0)
                                              @if($category['name']!= $inserted_catagory->name)
                                                <option
                                                    value="{{$category['id']}}" {{ $category->id==$product_category[0]->id ? 'selected' : ''}} >{{$category['name']}}</option>
                                             @endif
                                             @endif
                                            @endforeach
                                            @else
                                                 <option  value="{{null}}" selected disabled>---{{\App\CPU\translate('Select')}}---</option>
                                            @foreach($categories as $category)
                                             @if(in_array($category['id'], $allowedIds) && $category['position'] == 0)
                                                <option
                                                    value="{{$category['id']}}" {{ $category->id==$product_category[0]->id ? 'selected' : ''}} >{{$category['name']}}</option>
                                             @endif
                                            @endforeach
                                            @endif
                                        </select>
                                    </div>
                                    <div class="col-md-4">
                                        <label for="name">{{ \App\CPU\translate('Sub_category')}}</label>
                                        <select
                                            class="js-example-basic-multiple form-control"
                                            name="sub_category_id" id="sub-category-select"
                                            data-id="{{count($product_category)>=1?$product_category[0]->id:''}}"
                                            onchange="getRequest('{{url('/')}}/admin/product/get-categories?parent_id='+this.value,'sub-sub-category-select','select')" required>
                                             @if($inserted_sub_catagory != NULL)
                                             <option
                                                    value="{{$inserted_sub_catagory->id}}" {{ $inserted_sub_catagory->id==$product_category[0]->id ? 'selected' : ''}}>{{$inserted_sub_catagory->name}}</option>

                                              @foreach($allCats as $category)
                                             @if(in_array($category['id'], $allowedIds) && $category['position'] == 1)
                                             @if($elementCount >= 2)
                                             @if( $product_category[1]->id == $category['id'])
                                             @if($category['name']!= $inserted_sub_catagory->name)
                                                <option
                                                    value="{{$category['id']}}" {{ $category->id==$product_category[0]->id ? 'selected' : ''}} >{{$category['name']}}</option>
                                               @endif
                                                @endif
                                                @endif
                                             @endif
                                            @endforeach
                                            @else   
                                             <option  value="{{null}}" selected disabled>---{{\App\CPU\translate('Select')}}---</option>

                                              @foreach($allCats as $category)
                                             @if(in_array($category['id'], $allowedIds) && $category['position'] == 1)
                                             @if($elementCount >= 2)
                                             @if( $product_category[1]->id == $category['id'])
                                    
                                                <option
                                                    value="{{$category['id']}}" {{ $category->id==$product_category[0]->id ? 'selected' : ''}} >{{$category['name']}}</option>
                                              
                                                @endif
                                                @endif
                                             @endif
                                            @endforeach

                                             @endif
                                        </select>
                                    </div>
                                    
                                    <div class="col-md-4">
                                        <label for="name">{{ \App\CPU\translate('Sub_sub_category')}}</label>

                                        <select
                                            class="js-example-basic-multiple form-control"
                                            data-id="{{count($product_category)>=2?$product_category[1]->id:''}}"
                                            name="sub_sub_category_id" id="sub-sub-category-select">
                                            @if($inserted_sub_sub_catagory != NULL)
                                                   <option
                                                    value="{{$inserted_sub_sub_catagory->id}}" {{ $inserted_sub_sub_catagory->id==$product_category[0]->id ? 'selected' : ''}} selected>{{$inserted_sub_sub_catagory->name}}</option>

                                            @foreach($allCats as $category)
                                               @if($elementCount == 3)
                                             @if(in_array($category['id'], $allowedIds) && $category['position'] == 2)
                                               @if( $product_category[2]->id == $category['id'])
                                                @if($category['name']!= $inserted_sub_sub_catagory->name)
                                                <option
                                                    value="{{$category['id']}}" {{ $category->id==$product_category[0]->id ? 'selected' : ''}} >{{$category['name']}}</option>
                                                     @endif
                                                    @endif
                                                     @endif
                                             @endif
                                            @endforeach
                                             @else   
                                             <option  value="{{null}}" selected disabled>---{{\App\CPU\translate('Select')}}---</option>
                                            @foreach($allCats as $category)
                                               @if($elementCount == 3)
                                             @if(in_array($category['id'], $allowedIds) && $category['position'] == 2)
                                               @if( $product_category[2]->id == $category['id'])
                                                <option
                                                    value="{{$category['id']}}" {{ $category->id==$product_category[0]->id ? 'selected' : ''}} >{{$category['name']}}</option>
                                                    @endif
                                                     @endif
                                             @endif
                                            @endforeach
                                            @endif
                                        </select>
                                    </div>

                                </div>

                                 <div class="form-group">
                                    <div class="row mt-3">
                                        <div class="col-md-1">
                                      </div>
                                        <div class="col-md-2">
                                            <button type="button" class="btn btn-outline-success btn-lg btn-block pt-2 pb-2" id="blockCategory" onclick="allCatCommonModel(0);"><i style="font-size: 23px;" class="tio-selection" data-toggle="tooltip" data-placement="right" title="Collapse"></i>&nbsp;{{\App\CPU\translate('Select_category')}}</button>
                                        </div>
                                        <div class="col-md-2">
                                      </div>
                                        <div class="col-md-2">
                                        <button type="button" class="btn btn-outline-danger btn-lg btn-block pt-2 pb-2" data-toggle="modal" data-target="#subcategorymodel"><i style="font-size: 23px;" class="tio-add-circle" data-toggle="tooltip" data-placement="right" title="Collapse"></i>
                                            add
                                          </button>
                                    </div>
                                    <div class="col-md-2">
                                      </div>
                                    <div class="col-md-2">
                                        <button type="button" class="btn btn-outline-danger btn-lg btn-block pt-2 pb-2" data-toggle="modal" onclick="resetform('subsubcategoryform');" data-target="#subsubcategory"><i style="font-size: 23px;" class="tio-add-circle" data-toggle="tooltip" data-placement="right" title="Collapse"></i>
                                            add
                                          </button>
                                    </div>
                                    <div class="col-md-1">
                                      </div>
                                    </div>
                                </div>

                            </div>

                            <div class="form-group">
                                <div class="row">

                                    <div class="col-md-6">
                                        <label for="name">{{\App\CPU\translate('Brand')}}</label>
                                        <select
                                            class="js-example-basic-multiple js-states js-example-responsive form-control"
                                            name="brand_id" id="branddrop" >
                                             @if($brand_original != NULL)
                                            <option value="{{$brand_original->id}}" selected >{{$brand_original->name}}</option>
                                            @foreach($br as $b)
                                             @if(in_array($b['id'], $allowedBrandIds))
                                             @if($b['name']!= $brand_original->name)
                                                <option
                                                    value="{{$b['id']}}" {{ $b->id==$product->brand_id ? 'selected' : ''}} >{{$b['name']}}</option>
                                                      @endif
                                                      @endif
                                            @endforeach

                                             @else
                                              <option value="{{null}}" selected disabled>---{{ \App\CPU\translate('Select')}}---</option>
                                              @foreach($br as $b)
                                               @if(in_array($b['id'], $allowedBrandIds))
                                             <option
                                                    value="{{$b['id']}}" {{ $b->id==$product->brand_id ? 'selected' : ''}} >{{$b['name']}}</option>
                                             @endif
                                            @endforeach
                                             @endif
                                        </select>
                                    </div>

                                   <div class="col-md-6">
                                        <label for="name">{{\App\CPU\translate('Unit')}}</label>
                                        <select
                                            class="js-example-basic-multiple js-states js-example-responsive form-control"
                                            name="unit" id="unitsdrop">

                                            @if($current_unit != NULL)
                                             <option value="{{$current_unit->id}}" selected>{{$current_unit->name}}</option>
                                            @foreach($unit as $b)
                                             @if(in_array($b['id'], $allowedUnitIds))
                                            @if($b['name']!=$current_unit->name)
                                             <option value="{{$b['id']}}"{{ $product->unit==$b ? 'selected' : ''}}> {{$b['name']}}</option>
                                              @endif
                                               @endif
                                            @endforeach
                                          
                                            @else
                                              <option value="{{null}}" selected disabled>---{{ \App\CPU\translate('Select')}}---</option>
                                             @foreach($unit as $b)
                                              @if(in_array($b['id'], $allowedUnitIds))
                                             <option value="{{$b['id']}}"{{ $product->unit==$b ? 'selected' : ''}}> {{$b['name']}}</option>
                                             @endif
                                            @endforeach
                                                @endif
                                        </select>
                                    </div>
                                </div>
                            </div>

                                <div class="form-group">
                                <div class="row mt-3">
                                    <div class="col-md-1">
                                      </div>
                                    <div class="col-md-2">
                                        <button type="button" class="btn btn-outline-success btn-lg btn-block pt-2 pb-2" id="blockCategory" onclick="allbrands();"><i style="font-size: 23px;" class="tio-selection" data-toggle="tooltip" data-placement="right" title="Collapse"></i>&nbsp;{{\App\CPU\translate('Select_brand')}}</button>
                                    </div>
                                     <div class="col-md-2">
                                        <button type="button" class="btn btn-outline-danger btn-lg btn-block pt-2 pb-2" data-toggle="modal" data-target="#productbrandModel"><i style="font-size: 23px;" class="tio-add-circle" data-toggle="tooltip" data-placement="right" title="Collapse"></i>
                                            add
                                          </button>
                                    </div>
                                     <div class="col-md-2">
                                      </div>
                                      <div class="col-md-2">
                                        <button type="button" class="btn btn-outline-danger btn-lg btn-block pt-2 pb-2" data-toggle="modal" data-target="#productunitModel"><i style="font-size: 23px;" class="tio-add-circle" data-toggle="tooltip" data-placement="right" title="Collapse"></i>
                                            add
                                          </button>
                                    </div>
                                     <div class="col-md-2">
                                        <button type="button" class="btn btn-outline-success btn-lg btn-block pt-2 pb-2" id="blockunit" onclick="allunits();"><i style="font-size: 23px;" class="tio-selection" data-toggle="tooltip" data-placement="right" title="Collapse"></i>&nbsp;{{\App\CPU\translate('Select_unit')}}</button>
                                    </div>
                                     <div class="col-md-1">
                                      </div>
                                </div>
                            </div>

                        </div>
                    </div>

                    <div class="card mt-2 rest-part">
                        <div class="card-header">
                            <h4>{{\App\CPU\translate('Variation')}}</h4>
                        </div>
                        <div class="card-body">

                            <div class="form-group">
                                <div class="row">
                                    <div class="col-md-6">

                                        <label for="colors">
                                            {{\App\CPU\translate('Colors')}} :
                                        </label>
                                        <label class="switch">
                                            <input type="checkbox" class="status"
                                                   name="colors_active" {{count($product['colors'])>0?'checked':''}}>
                                            <span class="slider round"></span>
                                        </label>

                                        <select
                                            class="js-example-basic-multiple js-states js-example-responsive form-control color-var-select"
                                            name="colors[]" multiple="multiple"
                                            id="colors-selector" {{count($product['colors'])>0?'':'disabled'}}>
                                            @foreach (\App\Model\Color::orderBy('name', 'asc')->get() as $key => $color)
                                                <option
                                                    value={{ $color->code }} {{in_array($color->code,$product['colors'])?'selected':''}}>
                                                    {{$color['name']}}
                                                </option>
                                            @endforeach
                                        </select>
                                    </div>

                                    <div class="col-md-6">
                                        <label for="attributes" style="padding-bottom: 3px">
                                            {{\App\CPU\translate('Attributes')}} :
                                        </label>
                                        <select
                                            class="js-example-basic-multiple js-states js-example-responsive form-control"
                                            name="choice_attributes[]" id="choice_attributes" multiple="multiple">
                                            @foreach (\App\Model\Attribute::orderBy('name', 'asc')->get() as $key => $a)
                                                @if($product['attributes']!='null')
                                                    <option
                                                        value="{{ $a['id']}}" {{in_array($a->id,json_decode($product['attributes'],true))?'selected':''}}>
                                                        {{$a['name']}}
                                                    </option>
                                                @else
                                                    <option value="{{ $a['id']}}">{{$a['name']}}</option>
                                                @endif
                                            @endforeach
                                        </select>
                                    </div>

                                    <div class="col-md-12 mt-2 mb-2">
                                        <div class="customer_choice_options" id="customer_choice_options">
                                            @include('admin-views.product.partials._choices',['choice_no'=>json_decode($product['attributes']),'choice_options'=>json_decode($product['choice_options'],true)])
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card mt-2 rest-part">
                        <div class="card-header">
                            <h4>{{\App\CPU\translate('Product price & stock')}}</h4>

                        </div>
                        <div class="card-body">
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-md-6">
                                        <label class="control-label">{{\App\CPU\translate('Unit_price')}}</label>

                                        <div class="input-group mb-3">
                                          <div class="input-group-prepend">
                                            <span class="input-group-text">{{session('system_default_currency_info')->symbol}}</span>
                                          </div>
                                          <input type="text" 
                                               placeholder="{{\App\CPU\translate('Unit price') }}"
                                               name="unit_price"
                                               id="unit_price" 
                                               class="form-control cBalance"
                                               onChange="unitchnage('{{\App\CPU\Convert::converFromUsdToDefault($product->unit_price)}}');" 
                                               value='{{\App\CPU\Convert::converFromUsdToDefault($product->unit_price)}}' required> 
                                          <div class="input-group-append">
                                            <span class="input-group-text">.00</span>
                                          </div>
                                        </div>
                                    </div>


                                    <div class="col-md-6">
                                        <label
                                            class="control-label">{{\App\CPU\translate('Purchase_price')}}</label>
                                        <div class="input-group mb-3">
                                          <div class="input-group-prepend">
                                            <span class="input-group-text">{{session('system_default_currency_info')->symbol}}</span>
                                          </div>
                                          <input type="text" 
                                               placeholder="{{\App\CPU\translate('Purchase price') }}"
                                               name="purchase_price" class="form-control"
                                                value='{{\App\CPU\Convert::converFromUsdToDefault($product->purchase_price)}}' required>
                                          <div class="input-group-append">
                                            <span class="input-group-text">.00</span>
                                          </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class=" pt-1 col-12 sku_combination pt-4" id="sku_combination">
                                     @include('admin-views.product.partials._edit_sku_combinations',['combinations'=>json_decode($product['variation'],true)])
                                </div>

                                    <div class=" pt-1 col-md-6">
                                        <label class="control-label">{{\App\CPU\translate('Tax')}}</label>
                                        <label class="badge badge-info">{{\App\CPU\translate('Percent')}} ( % )</label>
                                        <input type="number" min="0" value={{ $product->tax }} step="0.01"
                                               placeholder="{{\App\CPU\translate('Tax') }}" name="tax"
                                               class="form-control" required>
                                        <input name="tax_type" value="percent" style="display: none">
                                    </div>
                                    <div class=" pt-1 col-md-6" id="quantity">
                                        <label
                                            class="control-label">{{\App\CPU\translate('total')}} {{\App\CPU\translate('Quantity')}} </label>
                                        <input type="number" min="0" id="current_stock" name="current_stock" value={{ $product->current_stock }} step="1"
                                               placeholder="{{\App\CPU\translate('Quantity') }}"
                                                class="form-control" required>
                                    </div>
                                  
                                   
                                </div>
                                
                               
                            </div>
                        </div>
                    </div>

                      <div class="card mt-2 rest-part">
                        <div class="card-header">
                            <h4>{{\App\CPU\translate('Discount & Offer')}}</h4>
                        </div>
                        <div class="card-body">
                            <div class="form-group">
                              
                            <div id="newRow">
                                @foreach($processedDiscountArray as $key => $pd)
                                <div class="row pt-4 count {{$key+1}}"> 
                                     <div class="col-md-6">
                                        <label class="control-label">{{\App\CPU\translate('Discount Amount')}}</label>
                                        <div class="input-group mb-3">
                                          <div class="input-group-prepend">
                                            <span class="input-group-text">{{session('system_default_currency_info')->symbol}}</span>
                                          </div>
                                           <input type="text" onChange="claculatepercentage({{$key+1}});"  id="discoun_amt_{{$key+1}}" placeholder="{{\App\CPU\translate('Discount amount')}}" name="discount_amt[]" value="{{(!empty($pd['discount']))?\App\CPU\Convert::converFromUsdToDefault($pd['discount']):''}}" class="form-control result">
                                          <div class="input-group-append">
                                             <span class="input-group-text">.{{(!empty(session('system_default_currency_info')->currency_formate))?str_repeat('0',session('system_default_currency_info')->currency_formate):'00'}}</span>
                                          </div>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <label class="control-label">{{\App\CPU\translate('Discount percentage')}}</label>
                                        <input type="text" onChange="claculateamount({{$key+1}});" id="dis_percent_{{$key+1}}" placeholder="{{\App\CPU\translate('Discount percentage')}}" name="dis_percent[]" value="{{$pd['calculatedDiscountPersent']}}" class="form-control">
                                    </div>
                                     <div class="col-md-3">
                                        <label class="control-label">{{\App\CPU\translate('Start Date')}}</label>
                                        <input type="text" data-id="{{$key+1}}" class="form-control startdateclass" id="startdate_{{$key+1}}" name="startdate[]" value="{{(!empty($pd['start_date']))?$pd['start_date']:''}}">
                                    </div>
                                    <div class="col-md-3">
                                        <label class="control-label">{{\App\CPU\translate('Start Time')}}</label>
                                        <input type="text" data-id="{{$key+1}}" class="form-control startimeclass" id="starttime_{{$key+1}}" name="starttime[]" value="{{(!empty($pd['start_time']))?$pd['start_time']:''}}">
                                    </div>
                                     <div class="col-md-3">
                                        <label class="control-label">{{\App\CPU\translate('End Date')}}</label>
                                       <input type="text" data-id="{{$key+1}}" class="form-control enddateclass" id="enddate_{{$key+1}}" name="enddate[]" value="{{(!empty($pd['end_date']))?$pd['end_date']:''}}">
                                    </div>
                                    <div class="col-md-3">
                                        <label class="control-label">{{\App\CPU\translate('End Time')}}</label>
                                       <input type="text" data-id="{{$key+1}}" class="form-control endtimeclass" id="endtime_{{$key+1}}" name="endtime[]" value="{{(!empty($pd['end_time']))?$pd['end_time']:''}}">
                                    </div>
                                    <div class="col-md-3 mt-4">
                                        <label class="control-label">{{\App\CPU\translate('buy')}}</label>
                                        <input 
                                            type="number" 
                                            onchange="freequantity('{{$key+1}}')"
                                            data-id="{{$key+1}}"
                                            id="buy_{{$key+1}}"
                                            placeholder="{{\App\CPU\translate('buy')}}" 
                                            name="buy[]"
                                            class="form-control" 
                                            value="{{(!empty($pd['buy']))?$pd['buy']:''}}"
                                        >
                                    </div>
                                     <div class="col-md-3 mt-4">
                                        <label class="control-label">{{\App\CPU\translate('free quantity')}}</label>
                                        <input 
                                            type="number" 
                                            name="quantity[]"
                                            data-id="{{$key+1}}"
                                            id="quantityinp_{{$key+1}}" 
                                            placeholder="{{\App\CPU\translate('quantity')}}" 
                                            class="form-control disquality"
                                            value="{{(!empty($pd['quantity']))?$pd['quantity']:''}}"
                                        >
                                    </div>
                                     <div class="col-md-3 mt-4">
                                        <label class="control-label">{{\App\CPU\translate('item')}}</label>
                                        <input type="text"
                                         data-id="{{$key+1}}"
                                         id="item_{{$key+1}}" 
                                               placeholder="{{\App\CPU\translate('item')}}" name="item[]" 
                                               class="form-control disitem" value="{{(!empty($pd['Item']))?$pd['Item']:''}}">
                                    </div>
                                     <div class="col-md-3 mt-4">
                                        <div class="pt-5">
                                        <button type="button" onclick='deleteExistDiscount("{{$key+1}}",<?php echo $pd["id"]; ?>);' class="btn btn-danger btn-sm" data-toggle="modal"><i style="font-size: 1.95em;" class="tio-delete" data-toggle="tooltip" data-placement="right" title="Collapse"></i>
                                          </button>
                                        </div>
                                    </div>
                                    
                                </div>
                                @endforeach  
                            </div>
                            <div class="form-group">
                                <div class="row text-center" id="addmoreRemoveBlock">
                                    <div class="col-md-12  ml-1 mr-1" style="padding-top: 30px;">
                                        <button type="button" class="btn btn-outline-success btn-lg" data-toggle="modal" id="addRow"><i   class="tio-poi-add" data-toggle="tooltip" data-placement="right" title="Collapse"></i>
                                            {{\App\CPU\translate('Add More Discount')}}
                                          </button>
                                          <button type="button" class="btn btn-outline-danger btn-lg" data-toggle="modal"  id="removeRow"><i  class="tio-poi-remove" data-toggle="tooltip" data-placement="right" title="Collapse"></i>
                                            {{\App\CPU\translate('Remove')}}
                                          </button>
                                    </div>
                                </div>
                            </div>
                            </div>
                        </div>
                    </div>

                    <div class="card mt-2 mb-2 rest-part">
                        <div class="card-header">
                            <h4>{{\App\CPU\translate('seo_section')}}</h4>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-12 mb-4">
                                    <label class="control-label">{{\App\CPU\translate('Meta Title')}}</label>
                                    <input type="text" name="meta_title" value="{{$product['meta_title']}}" placeholder="" class="form-control">
                                </div>

                                <div class="col-md-8 mb-4">
                                    <label class="control-label">{{\App\CPU\translate('Meta Description')}}</label>
                                    <textarea rows="10" type="text" name="meta_description" class="form-control">{{$product['meta_description']}}</textarea>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group mb-0">
                                        <label>{{\App\CPU\translate('Meta Image')}}</label>
                                    </div>
                                    <div class="border-dashed">
                                        <div class="row" id="meta_img">
                                            <div class="col-6">
                                                <div class="card">
                                                    <div class="card-body">
                                                        <img style="width: 100%" height="auto"
                                                             onerror="this.src='{{asset('public/assets/front-end/img/image-place-holder.png')}}'"
                                                             src="{{asset("storage/app/public/product/meta")}}/{{$product['meta_image']}}"
                                                             alt="Meta image">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card mt-2 rest-part">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-12 mb-4">
                                    <label class="control-label">{{\App\CPU\translate('Youtube video link')}}</label>
                                    <small class="badge badge-soft-danger"> ( {{\App\CPU\translate('optional, please provide embed link not direct link')}}. )</small>
                                    <input type="text" value="{{$product['video_url']}}" name="video_link"
                                           placeholder="{{\App\CPU\translate('EX')}} : https://www.youtube.com/embed/5R06LRdUCSE"
                                           class="form-control" >
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>{{\App\CPU\translate('Upload product images')}}</label><small
                                            style="color: red">* ( {{\App\CPU\translate('ratio')}} 1:1 )</small>
                                    </div>
                                    <div class="p-2 border border-dashed" style="max-width:430px;">
                                        <div class="row" id="coba">
                                            @foreach (json_decode($product->images) as $key => $photo)
                                                <div class="col-6">
                                                    <div class="card">
                                                        <div class="card-body">
                                                            <img style="width: 100%" height="auto"
                                                                 onerror="this.src='{{asset('public/assets/front-end/img/image-place-holder.png')}}'"
                                                                 src="{{asset("storage/app/public/product/$photo")}}"
                                                                 alt="Product image">
                                                            <a href="{{route('admin.product.remove-image',['id'=>$product['id'],'name'=>$photo])}}"
                                                               class="btn btn-danger btn-block">{{\App\CPU\translate('Remove')}}</a>

                                                        </div>
                                                    </div>
                                                </div>
                                            @endforeach
                                        </div>
                                    </div>

                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="name">{{\App\CPU\translate('Upload thumbnail')}}</label><small
                                            style="color: red">* ( {{\App\CPU\translate('ratio')}} 1:1 )</small>
                                    </div>

                                    <div class="row" id="thumbnail">
                                        <div class="col-6">
                                            <div class="card">
                                                <div class="card-body">
                                                    <img style="width: 100%" height="auto"
                                                         onerror="this.src='{{asset('public/assets/front-end/img/image-place-holder.png')}}'"
                                                         src="{{asset("storage/app/public/product/thumbnail")}}/{{$product['thumbnail']}}"
                                                         alt="Product image">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card card-footer">
                        <div class="row">
                            <div class="col-md-12" style="padding-top: 20px">
                                @if($product->request_status == 2)
                                    <button type="submit" class="btn btn-primary">{{\App\CPU\translate('Update & Publish')}}</button>
                                @else
                                    <button type="submit" class="btn btn-primary">{{\App\CPU\translate('Update')}}</button>
                                @endif
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

<div class="modal fade" id="subcategorymodel" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Sub Category</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="" method="POST" name="subcategory" id="subcategoryform">
        <input type="hidden" name="subcat_product_belong_to_user" value="{{$product->user_id}}">
        <input type="hidden" name="subcat_product_belong_to_usertype" value="{{$product->added_by}}">
      <div class="modal-body">
            @csrf
            @php($language=\App\Model\BusinessSetting::where('type','pnc_language')->first())
            @php($language = $language->value ?? null)
            @php($default_lang = 'en')
            @php($default_lang = json_decode($language)[0])
            <ul class="nav nav-tabs mb-4">
                @foreach(json_decode($language) as $lang)
                    <li class="nav-item">
                        <a class="nav-link lang_link {{$lang == $default_lang? 'active':''}}"
                           href="#"
                           id="{{$lang}}-link">{{\App\CPU\Helpers::get_language_name($lang).'('.strtoupper($lang).')'}}</a>
                    </li>
                @endforeach
            </ul>
            <div class="row">
                <div class="col-6">
                    @foreach(json_decode($language) as $lang)
                        <div class="form-group {{$lang != $default_lang ? 'd-none':''}} lang_form"
                             id="{{$lang}}-form">
                            <label class="input-label"
                                   for="exampleFormControlInput1">{{\App\CPU\translate('sub_category')}} {{\App\CPU\translate('name')}}
                                ({{strtoupper($lang)}})</label>
                            <input type="text" name="name[]" class="form-control"
                                   placeholder="{{\App\CPU\translate('New')}} {{\App\CPU\translate('Sub_Category')}}" {{$lang == $default_lang? 'required':''}}>
                        </div>
                        <input type="hidden" name="lang[]" value="{{$lang}}">
                    @endforeach
                    <input name="position" value="1" style="display: none">
                </div>
                <div class="col-6">
                    <div class="form-group">
                        <label class="input-label"
                               for="exampleFormControlSelect1">{{\App\CPU\translate('main')}} {{\App\CPU\translate('category')}}
                            <span class="input-label-secondary">*</span></label>
                        <select id="exampleFormControlSelect1" name="parent_id"
                                class="form-control" required>
                                <option value="">--{{\App\CPU\translate('select')}}--</option>
                            @foreach($allCats as $category)
                                @if(in_array($category['id'], $allowedIds) && $category['position'] == 0)
                                    <option value="{{$category['id']}}">{{$category['name']}}</option>
                                @endif
                            @endforeach
                        </select>
                    </div>
                </div>
            </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-danger">{{\App\CPU\translate('submit')}}</button>
      </div>
      </form>
    </div>
  </div>
</div>

<div class="modal fade" id="subsubcategory" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Sub Sub Category</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="" name="subsubcategory" id="subsubcategoryform" method="POST">
        <input type="hidden" name="subsubcat_product_belong_to_user" value="{{$product->user_id}}">
        <input type="hidden" name="subsubcat_product_belong_to_usertype" value="{{$product->added_by}}">
      <div class="modal-body">
            @csrf
            @php($language=\App\Model\BusinessSetting::where('type','pnc_language')->first())
            @php($language = $language->value ?? null)
            @php($default_lang = 'en')
            @if($language)
                @php($default_lang = json_decode($language)[0])
                <ul class="nav nav-tabs mb-4">
                    @foreach(json_decode($language) as $lang)
                        <li class="nav-item">
                            <a class="nav-link lang_link {{$lang == $default_lang? 'active':''}}"
                               href="#"
                               id="{{$lang}}-link">{{\App\CPU\Helpers::get_language_name($lang).'('.strtoupper($lang).')'}}</a>
                        </li>
                    @endforeach
                </ul>
                <div class="row">
                    @foreach(json_decode($language) as $lang)
                        <div
                            class="col-12 form-group {{$lang != $default_lang ? 'd-none':''}} lang_form"
                            id="{{$lang}}-form">
                            <label class="input-label"
                                   for="exampleFormControlInput1">{{\App\CPU\translate('Sub_sub_category')}} {{\App\CPU\translate('name')}}
                                ({{strtoupper($lang)}})</label>
                            <input type="text" name="name[]" class="form-control"
                                   placeholder="{{\App\CPU\translate('New_Sub_Sub_Category')}}" {{$lang == $default_lang? 'required':''}}>
                        </div>
                        <input type="hidden" name="lang[]" value="{{$lang}}">
                    @endforeach
                    @else
                        <div class="col-12">
                            <div class="form-group lang_form" id="{{$default_lang}}-form">
                                <label
                                    class="input-label">{{\App\CPU\translate('Sub_sub_category')}} {{\App\CPU\translate('name')}}
                                    ({{strtoupper($lang)}})</label>
                                <input type="text" name="name[]" class="form-control"
                                       placeholder="{{\App\CPU\translate('New_Sub_Category')}}" required>
                            </div>
                            <input type="hidden" name="lang[]" value="{{$default_lang}}">
                        </div>
                    @endif

                    <div class="col-6">
                        <div class="form-group">
                            <label
                                class="input-label">{{\App\CPU\translate('main')}} {{\App\CPU\translate('category')}}
                                <span class="input-label-secondary">*</span></label>
                            <select class="form-control" id="sub_sub_cat_id" required>
                                <option value="0">---{{\App\CPU\translate('select')}}---</option>
                                @foreach($allCats as $category)
                                    @if(in_array($category['id'], $allowedIds) && $category['position'] == 0)
                                        <option value="{{$category['id']}}">{{$category['name']}}</option>
                                    @endif
                                @endforeach
                            </select>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <label
                            for="name">{{\App\CPU\translate('sub_category')}} {{\App\CPU\translate('name')}}</label>
                        <select name="parent_id" id="parent_id" class="form-control" required>

                        </select>
                    </div>
                </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-danger">{{\App\CPU\translate('submit')}}</button>
      </div>
      </form>
    </div>
  </div>
</div>

<div class="modal fade" id="productbrandModel" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">{{\App\CPU\translate('Add_Brand')}}</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="{{route('admin.brand.add-brand')}}" name="addproductbrandform" id="idproductbrandform" method="POST"  enctype="multipart/form-data">
      <div class="modal-body">
            @csrf
            <input type="hidden" name="addbrand_product_belong_to_user" value="{{$product->user_id}}">
            <input type="hidden" name="addbrand_product_belong_to_usertype" value="{{$product->added_by}}">
                @php($language=\App\Model\BusinessSetting::where('type','pnc_language')->first())
                @php($language = $language->value ?? null)
                @php($default_lang = 'en')

                @php($default_lang = json_decode($language)[0])
                <ul class="nav nav-tabs mb-4">
                    @foreach(json_decode($language) as $lang)
                        <li class="nav-item">
                            <a class="nav-link lang_link {{$lang == $default_lang? 'active':''}}"
                                href="#"
                                id="{{$lang}}-link">{{\App\CPU\Helpers::get_language_name($lang).'('.strtoupper($lang).')'}}</a>
                        </li>
                    @endforeach
                </ul>
                <div class="row">
                    <div class="col-md-6">
                        @foreach(json_decode($language) as $lang)
                            <div class="form-group {{$lang != $default_lang ? 'd-none':''}} lang_form"
                                    id="{{$lang}}-form">
                                <label for="name">{{ \App\CPU\translate('name')}} ({{strtoupper($lang)}})</label>
                                <input type="text" name="name[]" class="form-control" id="checkbrandname" value="{{old('name')}}" placeholder="{{\App\CPU\translate('Ex')}} : {{\App\CPU\translate('LUX')}}" {{$lang == $default_lang? 'required':''}}>
                            </div>
                            <input type="hidden" name="lang[]" value="{{$lang}}">
                        @endforeach
                        <div class="form-group">
                            <label for="name">{{ \App\CPU\translate('brand_logo')}}</label><span class="badge badge-soft-danger">( {{\App\CPU\translate('ratio')}} 1:1 )</span>
                            <div class="custom-file" style="text-align: left" required>
                                <input type="file" name="image" id="customFileUpload" class="custom-file-input"
                                    accept=".jpg, .png, .jpeg, .gif, .bmp, .tif, .tiff|image/*">
                                <label class="custom-file-label" for="customFileUpload">{{\App\CPU\translate('choose')}} {{\App\CPU\translate('file')}}</label>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <center>
                            <img style="border-radius: 10px; max-height:200px;" id="viewer"
                                src="{{asset('public\assets\back-end\img\400x400\img2.jpg')}}" alt="banner image"/>
                        </center>
                    </div>
                </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-danger">{{\App\CPU\translate('submit')}}</button>
      </div>
      </form>
    </div>
  </div>
</div>

<div class="modal fade" id="productunitModel" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">{{\App\CPU\translate('Add_Brand')}}</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="{{route('admin.unit.add-unit')}}" name="productunitform" id="idproductunitform" method="POST"  enctype="multipart/form-data">
      <div class="modal-body">
            @csrf
            <input type="hidden" name="addUnit_product_belong_to_user" value="{{$product->user_id}}">
            <input type="hidden" name="addUnit_product_belong_to_usertype" value="{{$product->added_by}}">
                @php($language=\App\Model\BusinessSetting::where('type','pnc_language')->first())
                @php($language = $language->value ?? null)
                @php($default_lang = 'en')

                @php($default_lang = json_decode($language)[0])
                <ul class="nav nav-tabs mb-4">
                    @foreach(json_decode($language) as $lang)
                        <li class="nav-item">
                            <a class="nav-link lang_link {{$lang == $default_lang? 'active':''}}"
                                href="#"
                                id="{{$lang}}-link">{{\App\CPU\Helpers::get_language_name($lang).'('.strtoupper($lang).')'}}</a>
                        </li>
                    @endforeach
                </ul>
                <div class="row">
                    <div class="col-md-12">
                        @foreach(json_decode($language) as $lang)
                            <div class="form-group {{$lang != $default_lang ? 'd-none':''}} lang_form"
                                    id="{{$lang}}-form">
                                <label for="name">{{ \App\CPU\translate('Units')}} ({{strtoupper($lang)}})</label>
                                <input type="text" name="name" class="form-control" id="Checkname" value="{{old('name')}}" placeholder="{{\App\CPU\translate('Ex')}} : {{\App\CPU\translate('Kilogram')}}" {{$lang == $default_lang? 'required':''}}>
                            </div>
                            <div class="form-group {{$lang != $default_lang ? 'd-none':''}} lang_form"
                                    id="{{$lang}}-form">
                                <label for="name">{{ \App\CPU\translate('Units')}} ({{strtoupper($lang)}})</label>
                                <input type="text" name="symbol" class="form-control" id="symbol" value="{{old('symbol')}}" placeholder="{{\App\CPU\translate('Ex')}} : {{\App\CPU\translate('Kg')}}" {{$lang == $default_lang? 'required':''}}>
                            </div>
                            <input type="hidden" name="lang[]" value="{{$lang}}">
                        @endforeach
                       
                    </div>
                   
                </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-danger">{{\App\CPU\translate('submit')}}</button>
      </div>
      </form>
    </div>
  </div>
</div>

<div class="modal" id="modelblockCategory" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document" style="max-width: 1000px;">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">{{\App\CPU\translate('Select_items')}}</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>

        <form action="" method="POST" name="blockcat">
          <div class="modal-body">
                  <div class="modal-body">
                        <input type="hidden" name="product_belong_to_user" id="product_belong_to_user">
                        <input type="hidden" name="product_belong_to_usertype" id="product_belong_to_usertype">
                        <span class="text-info">{{\App\CPU\translate('Note')}}</span>:-<span class="text-danger">{{\App\CPU\translate('please_select_that_category_subcategory_subsubcategory_that_you_want_to_add_to_your_portfolio')}}</span>
                        <br/>
                        <span class="text-danger" id="alert" style="font-size: 16px;">
                        </span>
                        <br/>
                        @csrf
                        <input type="hidden" name="position" id="checkboxposition">
                        <div class="row mb-5">
                            <div class="col-md-4"><b class="text-warning">Category</b></div><div class="col-md-4"><b class="text-warning">Sub-category</b></div><div class="col-md-4"><b class="text-warning">Sub-sub-category</b></div>
                        </div>
                        <div class="row">
                            <div id="checkboxid" class="col-md-4">
                                <!-- body comming from jquery -->
                            </div>
                            <div id="subChild" class="col-md-4">
                                <!-- body comming from jquery -->
                            </div>
                            <div id="subSubChild" class="col-md-4">
                                <!-- body comming from jquery -->
                            </div>
                        </div>
                  </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" id="catsubbutton" class="btn btn-success">{{\App\CPU\translate('Select')}}</button>
          </div>
        </form>
    </div>
  </div>
</div>

<div class="modal brandclose" id="modelallowedBrand" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document" style="max-width: 1000px;">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">{{\App\CPU\translate('Select_items')}}</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
        <form action="" method="" name="selectedBrands">
          <div class="modal-body">
                  <div class="modal-body">
                        <span class="text-info">{{\App\CPU\translate('Note')}}</span>:-<span class="text-danger">{{\App\CPU\translate('please_select_that_brands_that_you_want_to_add_to_your_portfolio')}}</span>
                        <br/>
                        <span class="text-danger"  id="alert2"></span>
                        <span id="statusofaction"></span>
                        <br/>
                        <br/>
                        @csrf

                        <input type="hidden" name="selectedBrand_belong_to_user" value="{{$product->user_id}}" id="product_belong_to_user">
                        <input type="hidden" name="selectedBrand_belong_to_usertype" value="{{$product->added_by}}" id="product_belong_to_usertype">

                        <div class="row">
                        <div class="col-md-4">
                        <input id="myInput" class="form-control" type="text" placeholder="Search..">
                        </div>
                        </div>
                <br><br>
                        <label><input type="checkbox"  id="checkallbrands" > <b class="text-warning">check all</b></label>
                   
                        <div class="row" id="branddata">
                        </div>
                  </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-success">{{\App\CPU\translate('Select')}}</button>
          </div>
        </form>
    </div>
  </div>
</div>

<div class="modal brandclose" id="modelallowedunit" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document" style="max-width: 1000px;">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">{{\App\CPU\translate('Select_items')}}</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
        <form action="" method="" name="selectedUnits">
          <div class="modal-body">
                  <div class="modal-body">
                        <span class="text-info">{{\App\CPU\translate('Note')}}</span>:-<span class="text-danger">{{\App\CPU\translate('please_select_that_brands_that_you_want_to_add_to_your_portfolio')}}</span>
                        <br/>
                        <span class="text-danger"  id="alert3"></span>
                        <span id="statusofaction"></span>
                        <br/>
                        <br/>
                        @csrf
                        
                         <input type="hidden" name="selectedUnit_belong_to_user" value="{{$product->user_id}}" id="product_belong_to_user">
                        <input type="hidden" name="selectedUnit_belong_to_usertype" value="{{$product->added_by}}" id="product_belong_to_usertype">

                        <div class="row">
                            <div class="col-md-4">
                            <input id="myInput" class="form-control" type="text" placeholder="Search..">
                            </div>
                        </div>
                <br><br>
                        <label><input type="checkbox"  id="checkallunits" > <b class="text-warning">check all</b></label>
                   
                        <div class="row" id="unitdata">
                        </div>
                  </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-success">{{\App\CPU\translate('Select')}}</button>
          </div>
        </form>
    </div>
  </div>
</div>

@endsection

@push('script_2')
    <script src="{{asset('public/assets/back-end')}}/js/tags-input.min.js"></script>
    <script src="{{ asset('public/assets/select2/js/select2.min.js')}}"></script>
    <script src="{{asset('public/assets/back-end/js/spartan-multi-image-picker.js')}}"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/flatpickr/4.6.13/flatpickr.min.js" integrity="sha512-K/oyQtMXpxI4+K0W7H25UopjM8pzq0yrVdFdG21Fh5dBe91I40pDd9A4lzNlHPHBIP2cwZuoxaUSX0GJSObvGA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script type="text/javascript">
         $(document).ready(function(){
          $('#removeRow').hide();     
        $(".disquality").prop('readonly', true);
        $(".disitem").prop('readonly', true);

        $('.navbar-vertical-aside-has-menu').click(function(){
            var className = $(this).attr("class");
            var RequiredClass = 'show';
            if(className.indexOf(RequiredClass) != -1){
                $(this).removeClass(RequiredClass);
            }else{
                $(this).addClass(RequiredClass);
            }
        });
    });
         // function unitchnage(convertedUnitPriceOfDB){
         //    var newUnitPriceInDefaultCurr = $('#unit_price').val();
         // }

         function unitchnage(convertedUnitPriceOfDB)
         {
            var newUnitPriceInDefaultCurr = $('#unit_price').val();
            if(parseInt(convertedUnitPriceOfDB) !== parseInt(newUnitPriceInDefaultCurr))
            {
                swal.fire({
                    icon: 'error',
                    title: 'On Change Of Unit Price',
                    html: '<h5 class="text-warning">Please Check the Discounted values</h5>'
                });
                stop();
            }
        }

        function checkuniamtfordis(index,unitPrice,disAmmount){
            if(unitPrice != 0){
                if(parseInt(disAmmount)>parseInt(unitPrice)){
                    $('#discoun_amt_'+index).val('').focus();
                    $('#dis_percent_'+index).val('').focus();
                swal.fire({
                    icon: 'error',
                    html: '<h5 style="color:red">Discounted amount should always be less than unit price</h5>'
                });
                stop();
            }
            }
            else{
                 swal.fire({
                    icon: 'error',
                    html: '<h5 style="color:red">Please fill the unit price</h5>'
                });
                 $('#discoun_amt_'+index).val('');
                 $('#dis_percent_'+index).val('');
                 stop();
            }
       }

        function claculateamount(index)
        {
            var unitPrice = $('.cBalance').val();
            var disAmmount = $('#dis_percent_'+index).val();
            var result = (disAmmount/100)*unitPrice;
            $('#discoun_amt_'+index).val((result).toFixed(2));
            checkuniamtfordis(index,unitPrice,result);
        }
        function claculatepercentage(index)
        {
            var unitPrice = $('.cBalance').val();
            var disAmmount = $('#discoun_amt_'+index).val();
            var result = (disAmmount/unitPrice)*100;
            $('#dis_percent_'+index).val((result).toFixed(2));
            checkuniamtfordis(index,unitPrice,result);
        }

        function freequantity(hitIndex) {
            var buy = $("#buy_"+hitIndex);
            var current_stock = $('#current_stock');
            var quantity =  $("#quantityinp_"+hitIndex);
            var item =  $("#item_"+hitIndex);

            if(quantity.length!='')
            {
                checkExistanceOfBuy(buy,quantity);
            }
            if(item.length!='')
            {
                checkExistanceOfBuy(buy,item);
            }


            if( (parseInt(current_stock.val() )+1) <= parseInt(buy.val()) ) {
                $("#quantityinp_"+hitIndex).prop('readonly', true);
                $("#item_"+hitIndex).prop('readonly', true); 
                buy.val('').focus(); 
                Swal.fire({
                    icon: 'error',
                    title: 'Current Stock',
                    html: '<h5 style="color:red">Value In Buy filed Should be less Than Total Stock</h5>'
                });
            }else{
                $("#quantityinp_"+hitIndex).prop('readonly', false);
               $("#item_"+hitIndex).prop('readonly', false);
            }
        }

        function checkExistanceOfBuy(buy,inputToCheck)
        {
            if(buy.val()==0 && inputToCheck.val()>0){
                inputToCheck.val('');
                buy.focus();
                Swal.fire({
                    icon: 'error',
                    title: 'Current Stock',
                    html: '<h5 style="color:red">Please Fill buy quantity field First</h5>'
                });
            }
        }


        //--------end of discount calculation-------------------------
        // --for first time on discount flatpicker--//

        function toValidateForStartEndDate(that)
        {
           
            var rangej = [];
            var index = $(that.element).attr("data-id");
            var numItems = $('#newRow .count').length;
            var staDate = $('#startdate_'+index).val();
            var endDate = $('#enddate_'+index).val();
            var staTim = $('#starttime_'+index).val();
            var endTim = $('#endtime_'+index).val();
            var staDat = staDate+' '+staTim;
            var endDat = endDate+' '+endTim;
            if(staDat.length<1){
                swal.fire({
                    icon: 'error',
                    html: '<h5 style="color:red">Please fill the start date first!</h5>'
                });
                 $('#enddate_'+index).val('');
                 $('#endtime_'+index).val('');
            }
                if(endDat.length>0){
                 if (staDat > endDat) {
                  swal.fire({
                    icon: 'error',
                    html: '<h5 style="color:red">end date shoud be greater than start date</h5>'
                });
                  $('#enddate_'+index).val('');
                  $('#endtime_'+index).val('');
                }
            }

             for(var i=1;i<=numItems;i++){
                 var d = $('#startdate_'+i).val();
            var e = $('#starttime_'+i).val();
            var a = d+' '+e;
            var f = $('#enddate_'+i).val();
            var g = $('#endtime_'+i).val();
            var b = f+' '+g;

                if (a.length > 0 && b.length > 0) {
                    rangej.push({std: a,end:  b});
                }
            }
             checkoverlapdate(rangej,index);
        }

        // function toValidateEndDate()
        // {
        //     var rangej = [];
        //     var numItems = $('#newRow .count').length;
        //     var index = $(this.element).attr("data-id");
        //     var staDat = $('#startdate_'+index).val();
        //     var endDat = $('#enddate_'+index).val();

        //     if(staDat.length<1){
        //          swal.fire({
        //         icon: 'error',
        //         html: '<h5 style="color:red">Please fill the start date first!</h5>'
        //     });
        //          $('#startdate_'+index).css("border-color", "cornflowerblue");
        //     }
        //     for(var i=1;i<=numItems;i++){
        //         let a =  $('#startdate_'+[i]).val();
        //         let b = $('#enddate_'+[i]).val();
        //         if (a.length > 0 && b.length > 0) {
        //             rangej.push({std: a,end:  b});
        //         }
        //     }
        //     checkoverlapdate(rangej,index);
        // }

        flatpickr(".startdateclass",{
            //enableTime: true,
            dateFormat: "Y-m-d",
            minTime: new Date(),
            minDate: "today",
        });

        flatpickr(".startimeclass",{
            enableTime: true,
            noCalendar: true,
            dateFormat: "H:i",
            onChange : function() {
                toValidateForStartEndDate(this);
            }
           
        });

        flatpickr(".endtimeclass",{
            enableTime: true,
            noCalendar: true,
            dateFormat: "H:i",
            onChange : function() {
                toValidateForStartEndDate(this);
            }
            
        });

        
        flatpickr(".enddateclass",{           
            //enableTime: true,
            dateFormat: "Y-m-d",
            minDate: "today",
        });
        // --for first time on discount flatpicker--//
        // add row
        $("#addRow").click(function () {
            $('#removeRow').show();
            const o = $('#newRow .count').last();
            var totalDiscountRow = parseInt(o.index()) + 2;
            
            $('#newRow').append('<div class="row pt-4 count" id="removethis"><div class="col-md-6"><label class="control-label">{{\App\CPU\translate('Discount Amount')}}</label><div class="input-group mb-3"><div class="input-group-prepend"><span class="input-group-text">{{session('sellercurrencysymbol')}}</span></div><input type="text"  placeholder="{{\App\CPU\translate('Discount amount')}}" onChange="claculatepercentage('+totalDiscountRow+');" id="discoun_amt_'+totalDiscountRow+'" name="discount_amt[]" value="{{old('discount')}}" class="form-control"><div class="input-group-append"><span class="input-group-text">.{{(!empty($Seller->SellerCurrency->currency_formate))?str_repeat('0',$Seller->SellerCurrency->currency_formate):"00"}}</span></div></div></div><div class="col-md-6"> <label class="control-label">{{\App\CPU\translate('Discount percentage')}}</label>  <input type="text"   placeholder="{{\App\CPU\translate('Discount percentage')}}" onChange="claculateamount('+totalDiscountRow+');" id="dis_percent_'+totalDiscountRow+'" name="dis_percent[]" value="{{old('discount')}}"  class="form-control"> </div><div class="col-md-3"> <label class="control-label">{{\App\CPU\translate('Start_Date')}}</label> <input type="datetime-local" class="form-control startflatpick" id="startdate_'+totalDiscountRow+'" name="startdate[]"  data-id="'+totalDiscountRow+'"> </div> <div class="col-md-3"> <label class="control-label">{{\App\CPU\translate('Start_Time')}}</label> <input type="datetime-local" class="form-control startflatpick" id="starttime_'+totalDiscountRow+'" name="starttime[]"  data-id="'+totalDiscountRow+'"> </div> <div class="col-md-3"> <label class="control-label">{{\App\CPU\translate('End_Date')}}</label> <input type="datetime-local" class="form-control endflatpick" data-id="'+totalDiscountRow+'" id="enddate_'+totalDiscountRow+'"name="enddate[]"> </div> <div class="col-md-3"> <label class="control-label">{{\App\CPU\translate('End_Date')}}</label> <input type="datetime-local" class="form-control endflatpick" data-id="'+totalDiscountRow+'" id="endtime_'+totalDiscountRow+'"name="endtime[]"> </div>  <div class="col-md-3 mt-4"> <label class="control-label">{{\App\CPU\translate('buy')}}</label> <input type="number" onchange="freequantity('+totalDiscountRow+')" id="buy_'+totalDiscountRow+'"   placeholder="{{\App\CPU\translate('buy')}}" name="buy[]" value="{{old('buy')}}" class="form-control"> </div><div class="col-md-3 mt-4"> <label class="control-label">{{\App\CPU\translate('free quantity')}}</label><input type="number" onchange="freequantity('+totalDiscountRow+')" id="quantityinp_'+totalDiscountRow+'"  placeholder="{{\App\CPU\translate('quantity')}}" name="quantity[]" value="{{old('quantity')}}" class="form-control disquality"> </div><div class="col-md-3 mt-4"> <label class="control-label">{{\App\CPU\translate('item')}}</label> <input type="text"  placeholder="{{\App\CPU\translate('item')}}" name="item[]" id="item_'+totalDiscountRow+'" onchange="freequantity('+totalDiscountRow+')" value="{{old('item')}}" class="form-control disitem"> </div> </div>'); 
                $(".disquality").prop('readonly', true);
                $(".disitem").prop('readonly', true);

                flatpickr("#startdate_"+totalDiscountRow,{
                   // enableTime: true,
                    dateFormat: "Y-m-d",
                    minDate: "today",
                });
                
                flatpickr("#starttime_"+totalDiscountRow,{
                enableTime: true,
                noCalendar: true,
                dateFormat: "H:i",
        });

                flatpickr("#enddate_"+totalDiscountRow,{
                   // enableTime: true,
                    dateFormat: "Y-m-d",
                    minDate: "today",
                });

                flatpickr("#endtime_"+totalDiscountRow,{
                enableTime: true,
                noCalendar: true,
                dateFormat: "H:i",
                onChange : function() {
                 toValidateForStartEndDate(this);
                }
        });
             });
            function checkoverlapdate(rangej,index){
                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                        }
                    });
                    $.ajax({
                        url: '{{route('admin.add-discount')}}',
                        method: 'POST',
                        data: {
                            reangeArray: rangej,
                        },
                        success: function (result) {
                            var status = result.status;
                            var message = result.message;
                            var proid = result.proid;
                            if(status == 1){
                                Swal.fire({
                                icon: 'success',
                                title: 'Add Discount',
                                html: '<h5 style="color:red">Please Assign Some other Dates For This Discount. This Date is Overlaped With Other Discount For the same Product</h5>'
                                });
                            }
                            if(status == 0){
                                Swal.fire({
                                  icon: 'error',
                                  title: 'Overlap',
                                  html: '<h5 style="color:red">Please Assign Some other Dates For This Discount. This Date is Overlaped With Other Discount For the same Product</h5>',
                                }).then(function(){ 
                                      $('#startdate_'+index).val('').css("border-color", "cornflowerblue");
                                      $('#enddate_'+index).val('').css("border-color", "cornflowerblue");
                                      $('#starttime_'+index).val('').css("border-color", "cornflowerblue");
                                      $('#endtime_'+index).val('').css("border-color", "cornflowerblue");
                                });
                            }
                        }
                    });
            }
        // remove row
        $(document).on('click', '#removeRow', function () {
            const o = $('#newRow .count').last();
            const p = o.index()+1;
            $('#startdate_'+p).closest('#removethis').remove();
            if($("div[id*='removethis']").length===0){
                $('#removeRow').hide();
            }
        });


        function deleteExistDiscount(deleteIndex,deleteId){
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                }
            });
            $.ajax({
                url: '{{route('admin.delete-discount')}}',
                method: 'POST',
                data: {
                    discountId: deleteId,
                },
                success: function (result) {
                    var status = result.status;
                    var message = result.message;
                    var icon=title=color='';
                    if(status == 1)
                    {
                        icon = 'success'; title = 'Add Discount'; color = 'green';
                        $('.'+deleteIndex).remove();
                    }
                    else
                    {
                        icon = 'error'; title = 'Add Discount'; color = 'red';
                    }

                    Swal.fire({
                      icon: icon,
                      title: title,
                      html: '<h5 style="color:'+color+'">'+message+'</h5>',
                    });
                }
            });
        }
        

//-----------------------------------discount code end 13/06/2022----------------------------------------------

</script>

    <script>


// ------------------------------------START UNIT CODE 07/06/20222------------------------------------------


    $("form[name='selectedUnits']").validate({
        rules: {
            'checkboxs[]': {
                required:true
            }
        },
        errorPlacement: function(error,element){
            error.appendTo('#alert3');
        },
        messages: {
            'checkboxs[]' :{ 
                required:"Please check at least 1 box"
            }
        },
        submitHandler: function(form) {
          var url = '{{route('admin.product.selected-units')}}';
          var form_data = new FormData(form);
          $.ajax({
                url: url,
                type: 'POST',
                processData: false,
                contentType: false,
                data: form_data,
                success: function(result){
                    var status = result.status;
                    var data = result.unit;

                    //--to update all brand along with newly added brand--//
                    if(status==1)
                    {
                        var options;
                        options='<option value="" selected>---Select---</option>';
                        options+= $.map(data, function (a) { 
                            return '<option value="' + a.id + '">' + a.name + '</option>';
                        });
                        $('#unitsdrop').html('');
                        $('#unitsdrop').append(options);
                        
                        $("#idproductunitform")[0].reset();
                        //--to update all brand along with newly added brand--//

                        Swal.fire({
                          icon: 'success',
                          title: 'Add unit',
                          text: 'unit Added successfully',
                        }).then(function(){ 
                           allunits();
                           setTimeout(function(){
                                $('#modelallowedunit').modal('hide');
                                $('#unitsubbutton').attr('disabled',false);
                            }, 2000);
                           
                        });
                    }else{
                        Swal.fire({
                          icon: 'error',
                          title: 'Oops',
                          text: 'Oops! Problem with unit add',
                        });
                    }
                }
            });
        }
    });

    $("form[name='productunitform']").validate({
        rules: {
        },
        messages: {
        },

        submitHandler: function(form) {
          var url = '{{route('admin.unit.add-unit')}}';
          var form_data = new FormData(form);
          $.ajax({
            url: url,
            type: 'POST',
            processData: false,
            contentType: false,
            data: form_data,
            success: function(result){
                console.log(result);

                var data = result.unit;
                var status = result.status;
                var allUnit = result.allUnit;
                var allowedUnitIds = result.allowedUnitIds;

                if(status==1)
                {
                    var options;
                    options='<option value="" selected>---Select---</option>';
                    options+= $.map(data, function (a) { 
                        return '<option value="' + a.id + '">' + a.name + '</option>';
                    });
                    $('#unitsdrop').html('');
                }
                $('#unitsdrop').append(options);
                $("#idproductunitform")[0].reset();
                $('#productunitModel').modal('toggle');
                $('#modelallowedunit').modal('show');
                   var allowedUnit = $.map(allUnit, function (b, index) { 
                        var structure='';
                        structure+='<div  class="col-md-4">';
                        if(jQuery.inArray(b.id, allowedUnitIds) === -1){
                                structure+='<div class="form-check"><input class="form-check-input" type="checkbox" name="checkboxs[]" value="' + b.id + '" id="flexCheckDefault" /><label class="form-check-label" for="flexCheckDefault">' + b.name + '</label></div>';
                        }else{
                            structure+='<div class="form-check"><input class="form-check-input" type="checkbox" name="checkboxs[]" checked value="' + b.id + '" id="flexCheckDefault" /><label class="form-check-label" for="flexCheckDefault">' + b.name + '</label></div>';
                        }
                        structure+='</div>';
                        return structure;
                    });
                    console.log({allowedUnit});
                    
                    $('#unitdata').empty().append(allowedUnit);


                   setTimeout(function(){
                        $('#productunitModel').modal('hide');
                        $('#modelallowedunit').modal('hide');
                        $("#idproductunitform")[0].reset();
                        $('#productunitform').attr('disabled',false);
                    }, 2000);
            }
          });
           
        }
    });



    $('#checkallunits').prop('checked', false);
    $('#checkallunits').click(function () {    
        $('.unitcommancheck').prop('checked', this.checked);    
    });

    $("#myInputunit").on("keyup", function() {
        var value = $(this).val().toLowerCase();
        $("#unitdata .col-md-4").filter(function() {
          $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
        });
    });

    function allunits(){
            var userID = "{{($product->user_id)?$product->user_id:''}}";
            var userType = "{{($product->added_by)?$product->added_by:''}}";

        $('#checkallunits').prop('checked', false);
        var data = '';var status = '';var allUnit = '';var allowedUnitIds = '';
        var url = "{{url('admin/product/get-unit')}}/"+userID+"/"+userType;
            $.ajax({
                type: 'get',
                url: url,
                success: function (result) {
                    console.log(result);
                    data = result.unit;
                    status = result.status;
                    allUnit = result.allUnit;
                    allowedUnitIds = result.allowedUnitIds;
                    $('#modelallowedunit').modal('show');
                    var allowedunit = $.map(allUnit, function (b, index) { 
                        var structure='';
                        structure+='<div  class="col-md-4">';
                        if(jQuery.inArray(b.id, allowedUnitIds) === -1){
                                structure+='<div class="form-check"><input class="form-check-input unitcommancheck" type="checkbox" name="checkboxs[]" value="' + b.id + '" id="flexCheckDefault" /><label class="form-check-label" for="flexCheckDefault">' + b.name + '</label></div>';
                        }else{
                            structure+='<div class="form-check"><input class="form-check-input unitcommancheck" type="checkbox" name="checkboxs[]" checked value="' + b.id + '" id="flexCheckDefault" /><label class="form-check-label" for="flexCheckDefault">' + b.name + '</label></div>';
                        }
                        structure+='</div>';
                        return structure;
                    });
                    console.log({allowedunit});
                    $('#unitdata').empty().append(allowedunit);
                }
            });
    }



        // ------------------------------------END UNIT CODE 07/06/20222------------------------------------------

    var imageCount = {{4-count(json_decode($product->images))}};
    var thumbnail = '{{\App\CPU\ProductManager::product_image_path('thumbnail').'/'.$product->thumbnail??asset('public/assets/back-end/img/400x400/img2.jpg')}}';
      

    $(function () {
        if (imageCount > 0) {
            $("#coba").spartanMultiImagePicker({
                fieldName: 'images[]',
                maxCount: imageCount,
                rowHeight: 'auto',
                groupClassName: 'col-6',
                maxFileSize: '',
                placeholderImage: {
                    image: '{{asset('public/assets/back-end/img/400x400/img2.jpg')}}',
                    width: '100%',
                },
                dropFileLabel: "Drop Here",
                onAddRow: function (index, file) {

                },
                onRenderedPreview: function (index) {

                },
                onRemoveRow: function (index) {

                },
                onExtensionErr: function (index, file) {
                    toastr.error('{{\App\CPU\translate('Please only input png or jpg type file')}}', {
                        CloseButton: true,
                        ProgressBar: true
                    });
                },
                onSizeErr: function (index, file) {
                    toastr.error('{{\App\CPU\translate('File size too big')}}', {
                        CloseButton: true,
                        ProgressBar: true
                    });
                }
            });
        }
        $("#thumbnail").spartanMultiImagePicker({
            fieldName: 'image',
            maxCount: 1,
            rowHeight: 'auto',
            groupClassName: 'col-12',
            maxFileSize: '',
            placeholderImage: {
                image: thumbnail,
                width: '100%',
            },
            dropFileLabel: "Drop Here",
            onAddRow: function (index, file) {

            },
            onRenderedPreview: function (index) {

            },
            onRemoveRow: function (index) {

            },
            onExtensionErr: function (index, file) {
                toastr.error('{{\App\CPU\translate('Please only input png or jpg type file')}}', {
                    CloseButton: true,
                    ProgressBar: true
                });
            },
            onSizeErr: function (index, file) {
                toastr.error('{{\App\CPU\translate('File size too big')}}', {
                    CloseButton: true,
                    ProgressBar: true
                });
            }
        });

        $("#meta_img").spartanMultiImagePicker({
            fieldName: 'meta_image',
            maxCount: 1,
            rowHeight: 'auto',
            groupClassName: 'col-6',
            maxFileSize: '',
            placeholderImage: {
                image: '{{asset('public/assets/back-end/img/400x400/img2.jpg')}}',
                width: '100%',
            },
            dropFileLabel: "Drop Here",
            onAddRow: function (index, file) {

            },
            onRenderedPreview: function (index) {

            },
            onRemoveRow: function (index) {

            },
            onExtensionErr: function (index, file) {
                toastr.error('{{\App\CPU\translate('Please only input png or jpg type file')}}', {
                    CloseButton: true,
                    ProgressBar: true
                });
            },
            onSizeErr: function (index, file) {
                toastr.error('{{\App\CPU\translate('File size too big')}}', {
                    CloseButton: true,
                    ProgressBar: true
                });
            }
        });
    });

    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#viewer').attr('src', e.target.result);
            }

            reader.readAsDataURL(input.files[0]);
        }
    }

    $("#customFileUpload").change(function () {
        readURL(this);
    });

    $(".js-example-theme-single").select2({
        theme: "classic"
    });

    $(".js-example-responsive").select2({
        width: 'resolve'
    });
    </script>

    <script>
       //  function getRequest(route, id, type) {
       //     $.get({
       //         url: route,
       //         dataType: 'json',
       //         success: function (data) {
       //             if (type == 'select') {
       //                 $('#' + id).empty().append(data.select_tag);
       //              }
       //         },
       //     });
       // }

    $('input[name="colors_active"]').on('change', function () {
        if (!$('input[name="colors_active"]').is(':checked')) {
            $('#colors-selector').prop('disabled', true);
        } else {
            $('#colors-selector').prop('disabled', false);
        }
    });

    function add_more_customer_choice_option(i, name) {
        let n = name.split(' ').join('');
        $('#customer_choice_options').append('<div class="row"><div class="col-md-3"><input type="hidden" name="choice_no[]" value="' + i + '"><input type="text" class="form-control" name="choice[]" value="' + n + '" placeholder="{{\App\CPU\translate('Choice Title') }}" readonly></div><div class="col-lg-9"><input type="text" class="form-control" name="choice_options_' + i + '[]" placeholder="{{\App\CPU\translate('Enter choice values') }}" data-role="tagsinput" onchange="update_sku()"></div></div>');
        $("input[data-role=tagsinput], select[multiple][data-role=tagsinput]").tagsinput();
    }

    setInterval(function () {
        $('.call-update-sku').on('change', function () {
            update_sku();
        });
    }, 2000)

    $('#colors-selector').on('change', function () {
        update_sku();
    });

    $('input[name="unit_price"]').on('keyup', function () {
        update_sku();
    });

    function update_sku() {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $.ajax({
            type: "POST",
            url: '{{route('admin.product.sku-combination')}}',
            data: $('#product_form').serialize(),
            success: function (data) {
                $('#sku_combination').html(data.view);
                if (data.length > 1) {
                    $('#quantity').hide();
                } else {
                    $('#quantity').show();
                }
            }
        });
    }

    $(document).ready(function () {
        let category = $("#cat_id").val();
        let sub_category = $("#sub-category-select").attr("data-id");
        let sub_sub_category = $("#sub-sub-category-select").attr("data-id");

        // this code will bring sub cat and sub sub cat so we comment this  start//
        // getRequest('{{url('/')}}/seller/product/get-categories?parent_id=' + category + '&sub_category=' + sub_category, 'sub-category-select', 'select');
        // getRequest('{{url('/')}}/seller/product/get-categories?parent_id=' + sub_category + '&sub_category=' + sub_sub_category, 'sub-sub-category-select', 'select');
          // this code will bring sub cat and sub sub cat so we comment this  start//

        // color select select2
        $('.color-var-select').select2({
            templateResult: colorCodeSelect,
            templateSelection: colorCodeSelect,
            escapeMarkup: function (m) {
                return m;
            }
        });

        function colorCodeSelect(state) {
            var colorCode = $(state.element).val();
            if (!colorCode) return state.text;
            return "<span class='color-preview' style='background-color:" + colorCode + ";'></span>" + state.text;
        }
    });
    </script>

    {{--ck editor--}}
    <script src="{{asset('/')}}vendor/ckeditor/ckeditor/ckeditor.js"></script>
    <script src="{{asset('/')}}vendor/ckeditor/ckeditor/adapters/jquery.js"></script>
    <script>
        $('.textarea').ckeditor({
            contentsLangDirection : '{{Session::get('direction')}}',
        });
    </script>
    {{--ck editor--}}

   
    <script>
        $('#product_form').submit(function(event){
            var numItems = $('#newRow .count').length;

            for(var i=1;i<=numItems;i++){
                let a =  $('#startdate_'+i).val();
                let endate =  $('#enddate_'+i).val();
                    if(endate.length==0){
                         for(var j=i+1;j<=numItems;j++){
                                let b =  $('#startdate_'+j).val();
                                if(a==b){
                                $('#startdate_'+j).val('');
                                 $('#startdate_'+j).focus();
                                 swal.fire({
                                    icon: 'error',
                                    html: '<h5 style="color:red">two or more start dates without end date can not be same please assign some other date</h5>'
                                });
                                  event.preventDefault();
                                 break;
                            }
                        }
                 }
            }

            for(var i=1;i<=numItems;i++){
                let a =  $('#startdate_'+i).val();
                let c =  $('#enddate_'+i).val();
                let b = $('#discoun_amt_'+i).val();
                if(a>=c && c.length>0){
                    $('#startdate_'+i).val('');
                    $('#enddate_'+i).val('');
                    $('#startdate_'+i).focus();
                    $('#enddate_'+i).focus();
                    event.preventDefault();
                }
                if(!a){
                    $('#startdate_'+i).focus();
                    event.preventDefault();
                }
                if(!b){
                    $('#discoun_amt_'+i).focus();
                    event.preventDefault();   
                }
            }


            for (instance in CKEDITOR.instances) {
                CKEDITOR.instances[instance].updateElement();
            }
            var formData = new FormData(document.getElementById('product_form'));
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.post({
                url: '{{route('admin.product.update',$product->id)}}',
                data: formData,
                contentType: false,
                processData: false,
                success: function (data) {
                    if(data.lenght>0){
                        if (data.errors) {
                            for (var i = 0; i < data.errors.length; i++) {
                                toastr.error(data.errors[i].message, {
                                    CloseButton: true,
                                    ProgressBar: true
                                });
                            }
                        } else {
                            toastr.success('{{\App\CPU\translate('product updated successfully!')}}', {
                                CloseButton: true,
                                ProgressBar: true
                            });
                            //$('#product_form').submit();
                        }
                    }
                }
            });
        });
    </script>

    <script type="text/javascript">



    // ---------------new code 25/05/2022--------------------------------



$('#sub_sub_cat_id').on('change', function () {
    var id = $(this).val();
    var IdOfAdminOrSeller = "{{$product->user_id}}";
    var TypeOfAdminOrSeller = "{{$product->added_by}}";
    if (id) {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
            }
        });
        $.ajax({
            type: 'POST',
            url: '{{route('admin.sub-sub-category.getSubCategory')}}',
            data: {
                id: id,IdOfAdminOrSeller:IdOfAdminOrSeller,TypeOfAdminOrSeller:TypeOfAdminOrSeller
            },
            success: function (result) {
                $("#parent_id").html(result);
            }
        });
    }
});

$('#sub_sub_cat_id2').on('change', function () {
    var id = $(this).val();
    if (id) {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
            }
        });
        $.ajax({
            type: 'POST',
            url: '{{route('admin.sub-sub-category.getSubCategory')}}',
            data: {
                id: id
            },
            success: function (result) {
                $("#parent_id2").html(result);
            }
        });
    }
});


$('#sub_sub_cat_id3').on('change', function () {
    var id = $(this).val();
    if (id) {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
            }
        });
        $.ajax({
            type: 'POST',
            url: '{{route('admin.sub-sub-category.getSubCategory')}}',
            data: {
                id: id
            },
            success: function (result) {
                $("#parent_id3").html(result);
            }
        });
    }
});



        function resetform(formid)
        {
            $("#"+formid+' #parent_id').html('');
        }


        $('#parent_id3').on('change', function () {
            var id = $(this).val();
            if (id) {
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                    }
                });
                $.ajax({
                    type: 'POST',
                    url: '{{route('admin.sub-sub-category.getSubCategory')}}',
                    data: {
                        id: id
                    },
                    success: function (result) {
                        $("#parent_child_id3").html(result);
                    }
                });
            }
        });

   //=====function to get sub cat and sub sub cat on click start=====//
        function getsubchild(that){
            if($(that).is(':checked')){
                    var id = $(that).attr('value');
                    var position = $(that).attr('data-position');
                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                    });

                    $.ajax({
                        type: "POST",
                        url: "{{route('admin.product.get-child')}}",
                        data: {parent_id:id, position:position},
                        dataType:"json",
                        success: function (data) {
                            var rowdata = data.row;
                            if(rowdata.length==0){
                                if(position==0)
                                {
                                    toastr.warning('No Sub-Category Available for This Category');
                                }
                                if(position==1)
                                {
                                    toastr.error('No Sub-Sub-Category Available for This Sub-Category');
                                }  
                            }
                            var createCheckBoxs = $.map(rowdata, function (val, index) { 
                                if(val.id){
                                    return '<div style="margin-block-end: -1px;" class="form-check parent_'+ id +'"><input class="form-check-input" type="checkbox" name="checkboxs[]" data-position="'+ val.position +'" onclick="getsubchild(this);" value="' + val.id + '" /><label class="form-check-label" for="flexCheckDefault">' + val.name + '</label></div>';
                                }
                            });
                            if(position==0){
                                $('#subChild').append(createCheckBoxs);
                            }
                            if(position==1){
                                $('#subSubChild').append(createCheckBoxs);
                            }

                        }
                    });

            }
            else
            {
                var removechild = 'parent_'+$(that).attr('value');
                $(that).each(function() {
                   var remove_id = this.value;
                   var remove_position = $(this).attr('data-position');
                   $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                    });

                    $.ajax({
                        type: "POST",
                        url: "{{route('admin.product.get-child')}}",
                        data: {parent_id:remove_id, position:remove_position},
                        dataType:"json",
                        success: function (data) {
                            var rowdata = data.row;
                            if(rowdata.length>0)
                            { 
                                $.map(rowdata, function (val, index) {
                                    $('.parent_'+val.id).remove();
                                });
                            }

                        }
                    });

                });
                $('.'+removechild).remove();
            }
        }
        //=====function to get sub cat and sub sub cat on click end=====//





    $("form[name='addproductbrandform']").validate({
            rules: {
            },
            messages: {
            },

            submitHandler: function(form) {
              var url = '{{route('admin.brand.add-brand')}}';
              var form_data = new FormData(form);
              $.ajax({
                url: url,
                type: 'POST',
                processData: false,
                contentType: false,
                data: form_data,
                success: function(result){
                    console.log(result);

                    var data = result.brand;
                    var status = result.status;
                    var allBrand = result.allBrand;
                    var allowedBrandIds = result.allowedBrandIds;

                    if(status==1)
                    {
                        var options;
                        options='<option value="" selected>---Select---</option>';
                        options+= $.map(data, function (a) { 
                            return '<option value="' + a.id + '">' + a.name + '</option>';
                        });
                        $('#branddrop').html('');
                    }
                    $('#branddrop').append(options);
                    $("#idproductbrandform")[0].reset();
                    $('#productbrandModel').modal('toggle');
                    $('#modelallowedBrand').modal('show');
                       var allowedBrand = $.map(allBrand, function (b, index) { 
                            var structure='';
                            structure+='<div  class="col-md-4">';
                            if(jQuery.inArray(b.id, allowedBrandIds) === -1){
                                    structure+='<div class="form-check"><input class="form-check-input" type="checkbox" name="checkboxs[]" value="' + b.id + '" id="flexCheckDefault" /><label class="form-check-label" for="flexCheckDefault">' + b.name + '</label></div>';
                            }else{
                                structure+='<div class="form-check"><input class="form-check-input" type="checkbox" name="checkboxs[]" checked value="' + b.id + '" id="flexCheckDefault" /><label class="form-check-label" for="flexCheckDefault">' + b.name + '</label></div>';
                            }
                            structure+='</div>';
                            return structure;
                        });
                        console.log({allowedBrand});
                        
                        $('#branddata').empty().append(allowedBrand);


                       setTimeout(function(){
                            $('#productbrandModel').modal('hide');
                            $('#modelallowedBrand').modal('hide');
                            $("#idproductbrandform")[0].reset();
                            $('#brandsubbutton').attr('disabled',false);
                        }, 2000);
                }
              });
               
            }
        });




 function updateCatInProduct(filteredCat)
        {
            console.log({filteredCat});

            var options;
            options='<option value="" selected>---Select Category---</option>';
            options+= $.map(filteredCat, function (a) { 
                return '<option value="' + a.id + '">' + a.name + '</option>';
            });
            $('#cat_id').html('');
            $('#cat_id').append(options);

            $('#subcategoryform #exampleFormControlSelect1').html('');
            $('#subcategoryform #exampleFormControlSelect1').append(options);

            $('#subsubcategoryform #sub_sub_cat_id').html('');
            $('#subsubcategoryform #sub_sub_cat_id').append(options);
        }


  $(document).ready(function() {
          
           
        $('#choice_attributes').on('change', function () {
            $('#customer_choice_options').html(null);
            $.each($("#choice_attributes option:selected"), function () {
                //console.log($(this).val());
                add_more_customer_choice_option($(this).val(), $(this).text());
            });
        });
            $("#myInput").on("keyup", function() {
                var value = $(this).val().toLowerCase();
                $("#branddata .col-md-4").filter(function() {
                  $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                });
            });

            // color select select2
            $('.color-var-select').select2({
                templateResult: colorCodeSelect,
                templateSelection: colorCodeSelect,
                escapeMarkup: function (m) {
                    return m;
                }
            });

            function colorCodeSelect(state) {
                var colorCode = $(state.element).val();
                if (!colorCode) return state.text;
                return "<span class='color-preview' style='background-color:" + colorCode + ";'></span>" + state.text;
            }
        });


        $('#checkallbrands').prop('checked', false);
        $('#checkallbrands').click(function () {    
            $('.brandcommancheck').prop('checked', this.checked);    
        });

function allbrands(){


            var userID = "{{($product->user_id)?$product->user_id:''}}";
            var userType = "{{($product->added_by)?$product->added_by:''}}";
            $('#checkallbrands').prop('checked', false);
            var data = '';var status = '';var allBrand = '';var allowedBrandIds = '';
            var url = "{{url('admin/product/get-latestbrand')}}/"+userID+"/"+userType;
                $.ajax({
                    type: 'get',
                    url: url,
                    success: function (result) {
                        console.log(result);
                        data = result.brand;
                        status = result.status;
                        allBrand = result.allBrand;
                        allowedBrandIds = result.allowedBrandIds;
                        $('#modelallowedBrand').modal('show');
                        var allowedBrand = $.map(allBrand, function (b, index) { 
                            var structure='';
                            structure+='<div  class="col-md-4">';
                            if(jQuery.inArray(b.id, allowedBrandIds) === -1){
                                    structure+='<div class="form-check"><input class="form-check-input brandcommancheck" type="checkbox" name="checkboxs[]" value="' + b.id + '" id="flexCheckDefault" /><label class="form-check-label" for="flexCheckDefault">' + b.name + '</label></div>';
                            }else{
                                structure+='<div class="form-check"><input class="form-check-input brandcommancheck" type="checkbox" name="checkboxs[]" checked value="' + b.id + '" id="flexCheckDefault" /><label class="form-check-label" for="flexCheckDefault">' + b.name + '</label></div>';
                            }
                            structure+='</div>';
                            return structure;
                        });
                        console.log({allowedBrand});
                        $('#branddata').empty().append(allowedBrand);
                    }
                });
        }

//--open with all and selected cat, sub-cat, sub-sub-cat(start)--//
function allCatCommonModel(position) {
    $('#product_belong_to_user').val('{{$product->user_id}}');
    $('#product_belong_to_usertype').val('{{$product->added_by}}');
    //ajax data variables
    var dataAllowedIds,dataAllCats = '';
    //operational variables
    var ids,allcategory,chackedSubCategory,chackedSubSubCategory = '';

    var url = "{{url('admin/product/get-seller-cat-data/')}}/{{($product->user_id)?$product->user_id:''}}/{{($product->added_by)?$product->added_by:''}}"
        $.ajax({
            type: 'get',
            url: url,
            success: function (result) {

                console.log(result);
                dataAllowedIds = result.allowedIds;
                dataAllCats = result.allCats;
                $('#modelblockCategory').modal('show');
                ids = $.map(dataAllowedIds, function (sub) { 
                    return parseInt(sub);
                });

                allcategory = $.map(dataAllCats, function (val, index) { 
                    if(parseInt(val.position)==0){
                        return {
                            id : parseInt(val.id),
                            catName : val.name,
                            position : val.position
                        }
                    }
                });

                chackedSubCategory = $.map(dataAllCats, function (val, index) {
                    if(parseInt(val.position)==1){
                        return {
                            id : parseInt(val.id),
                            catName : val.name,
                            position : val.position,
                            parentid : val.parent_id
                        }
                    }
                });
                
                chackedSubSubCategory = $.map(dataAllCats, function (val, index) {
                    if(parseInt(val.position)==2){
                        return {
                            id : parseInt(val.id),
                            catName : val.name,
                            position : val.position,
                            parentid : val.parent_id
                        }
                    }
                });

                var allowedCategory = $.map(allcategory, function (c) { 
                    if(jQuery.inArray(c.id, ids) === -1){
                        return '<div class="form-check"><input class="form-check-input" type="checkbox" name="checkboxs[]" data-position="'+ c.position +'" onclick="getsubchild(this);" value="' + c.id + '" id="flexCheckDefault" /><label class="form-check-label" for="flexCheckDefault">' + c.catName + '</label></div>';
                    }else{
                        return '<div class="form-check"><input class="form-check-input" type="checkbox" name="checkboxs[]" data-position="'+ c.position +'" onclick="getsubchild(this);" checked value="' + c.id + '" id="flexCheckDefault" /><label class="form-check-label" for="flexCheckDefault">' + c.catName + '</label></div>';
                    }
                });
                var allowedSubCategory = $.map(chackedSubCategory, function (sc) { 
                    if(jQuery.inArray(sc.id, ids) !== -1)
                    {
                        return '<div margin-block-end:-1px; class="form-check parent_'+ sc.parentid +'"><input class="form-check-input" type="checkbox" name="checkboxs[]" data-position="'+ sc.position +'" onclick="getsubchild(this);" checked value="' + sc.id + '" id="flexCheckDefault" /><label class="form-check-label" for="flexCheckDefault">' + sc.catName + '</label></div>';
                    }
                });
                var allowedSubSubCategory = $.map(chackedSubSubCategory, function (ssc) { 
                    if(jQuery.inArray(ssc.id, ids) !== -1)
                    {
                        return '<div class="form-check parent_'+ ssc.parentid +'"><input class="form-check-input" type="checkbox" name="checkboxs[]" data-position="'+ ssc.position +'" onclick="getsubchild(this);" checked value="' + ssc.id + '" id="flexCheckDefault" /><label class="form-check-label" for="flexCheckDefault">' + ssc.catName + '</label></div>';
                    }
                });

                $('#checkboxposition').empty().val(position);
                $('#checkboxid').empty().append(allowedCategory);
                $('#subChild').empty().append(allowedSubCategory);
                $('#subSubChild').empty().append(allowedSubSubCategory);
            }
        });
}

//--open with all and selected cat, sub-cat, sub-sub-cat(end)--//


//--work on submit desired cat, sub-cat, sub-sub-cat(start)--//
$("form[name='blockcat']").validate({
    rules: {
        'checkboxs[]': {
            required:true
        }
    },
    errorPlacement: function(error,element){
        error.appendTo('#alert');
    },
    messages: {
        'checkboxs[]' :{ 
            required:"Please check at least 1 box"
        }
    },
    submitHandler: function(form) {
        var url = '{{route('admin.product.block-ids')}}';
        var form_data = new FormData(form);
        $.ajax({
            url: url,
            type: 'POST',
            processData: false,
            contentType: false,
            data: form_data,
            success: function(result){
                var status = result.status;
                var cat = result.cat;
                $('#modelblockCategory').modal('toggle');
               if(status == 1){
                    Swal.fire({
                      icon: 'success',
                      title: 'Category portfolio',
                      text: 'Category portfolio updated successfully',
                    }).then(function(){ 
                       //location.reload();
                       $('#cat_id').val('');
                       $('#sub-category-select').html('');
                       $('#sub-sub-category-select').html('');
                       $('#subsubcategoryform #parent_id').val('');
                       updateCatInProduct(cat);
                       allCatCommonModel();
                       setTimeout(function(){
                            $('#modelblockCategory').modal('hide');
                            $('#catsubbutton').attr('disabled',false);
                        }, 2000);
                    });
                }else{
                  Swal.fire({
                      icon: 'error',
                      title: 'Category portfolio',
                      text: 'Problem in update Category portfolio',
                    });
                }

            }
        });
    }
});
//--work on submit desired cat, sub-cat, sub-sub-cat(end)--//


//--get sub-cat and sub-sub-cat on select any parent or child cat(start)--//
function getRequest(route, id, type, position) {
    $('#sub-sub-category-select').html('<option value="" disabled selected>---Select---</option>');
    var blockids
    var url = "{{url('admin/product/get-seller-cat-data')}}/{{($product->user_id)?$product->user_id:''}}/{{($product->added_by)?$product->added_by:''}}";
    $.ajax({
        type: 'get',
        url: url,
        success: function (result) {
            blockids = result.allowedIds;
            $.get({
                url: route,
                dataType: 'json',
                success: function (data) {
                    var options;
                    options='<option value="" disabled selected>---Select---</option>';
                    options+= $.map(data.row, function (a) { 
                        if(jQuery.inArray(a.id, blockids) !== -1){
                            return '<option value="' + a.id + '">' + a.name + '</option>';
                        }
                    });
                    if (type == 'select') {
                        $('#' + id).empty().append(options);
                    }
                },
            });
        }
    });
}
//--get sub-cat and sub-sub-cat on select any parent or child cat(end)--//

$("form[name='subcategory']").validate({
    rules: {
    },
    messages: {
    },

    submitHandler: function(form) {
      var url = '{{route('admin.sub-category.sub-category-store')}}';
      var form_data = new FormData(form);
      $.ajax({
        url: url,
        type: 'POST',
        processData: false,
        contentType: false,
        data: form_data,
        success: function(result){
                var status = result.status;
                var cat = result.cat;
                //var cat = result.cat;
               if(status == 1){ 
                    Swal.fire({
                      icon: 'success',
                      title: 'Sub Category',
                      text: 'Sub Category Added successfully',
                    }).then(function(){
                            allCatCommonModel();
                            //updateCatInProduct(cat);
                           //location.reload();
                           $('#cat_id').val('');
                           $('#sub-category-select').html('');
                           $('#sub-sub-category-select').html('');
                           $('#subsubcategoryform #parent_id').val('');
                           $('#catsubbutton').attr('disabled',true);
                           setTimeout(function(){
                                $("#subcategoryform")[0].reset();
                                $('#modelblockCategory').modal('hide');
                                $('#catsubbutton').attr('disabled',false);
                            }, 2000);
                    });
                }else{
                  Swal.fire({
                      icon: 'error',
                      title: 'Oops',
                      text: 'Sub Category Added successfully',
                    });
                }
                $('#subcategorymodel').modal('hide');
            }
        });
    }   
});

$("form[name='subsubcategory']").validate({
    rules: {
    },
    messages: {
    },
    submitHandler: function(form) {
      var url = '{{route('admin.sub-sub-category.sub-sub-category-store')}}';
      var form_data = new FormData(form);
      $.ajax({
        url: url,
        type: 'POST',
        processData: false,
        contentType: false,
        data: form_data,
        success: function(result){

                var status = result.status;
                //var cat = result.cat;
                var cat = <?php echo json_encode($allCats); ?>;
               if(status == 1){
                    Swal.fire({
                      icon: 'success',
                      title: 'Sub Category',
                      text: 'Sub Category Added successfully',
                    }).then(function(){ 
                           allCatCommonModel();
                           //location.reload();
                           $('#cat_id').val('');
                           $('#sub-category-select').html('');
                           $('#sub-sub-category-select').html('');
                           $('#subsubcategoryform #parent_id').val('');
                           $('#catsubbutton').attr('disabled',true);
                           setTimeout(function(){
                                $("#subsubcategoryform")[0].reset();
                                $('#modelblockCategory').modal('hide');
                                $('#catsubbutton').attr('disabled',false);
                            }, 2000);
                    });
                }else{
                  Swal.fire({
                      icon: 'error',
                      title: 'Oops',
                      text: 'Sub Category Added successfully',
                    });
                }
                $('#subsubcategory').modal('toggle');
            }
        });
    }
});

$("form[name='selectedBrands']").validate({
     rules: {
        'checkboxs[]': {
            required:true
        }
    },
    errorPlacement: function(error,element){
        error.appendTo('#alert2');
    },
    messages: {
        'checkboxs[]' :{ 
            required:"Please check at least 1 box"
        }
    },
    submitHandler: function(form) {
      var url = '{{route('admin.product.selected-brands')}}';
      var form_data = new FormData(form);
      $.ajax({
            url: url,
            type: 'POST',
            processData: false,
            contentType: false,
            data: form_data,
            success: function(result){
                var status = result.status;
                var data = result.brand;

                //--to update all brand along with newly added brand--//
                if(status==1)
                {
                    var options;
                    options='<option value="" selected>---Select---</option>';
                    options+= $.map(data, function (a) { 
                        return '<option value="' + a.id + '">' + a.name + '</option>';
                    });
                    $('#branddrop').html('');
                    $('#branddrop').append(options);
                    
                    $("#idproductbrandform")[0].reset();
                    //--to update all brand along with newly added brand--//

                    Swal.fire({
                      icon: 'success',
                      title: 'Add Brand',
                      text: 'Brand Added successfully',
                    }).then(function(){ 
                       allbrands();
                       setTimeout(function(){
                            $('#modelallowedBrand').modal('hide');
                            $('#brandsubbutton').attr('disabled',false);
                        }, 2000);
                       
                    });
                }else{
                    Swal.fire({
                      icon: 'error',
                      title: 'Oops',
                      text: 'Oops! Problem with Brand add',
                    });
                }
            }
        });
    }
});
// ---------------end code 25/05/2022--------------------------------</script>

    <script>
        update_qty();

        function update_qty() {
            var total_qty = 0;
            var qty_elements = $('input[name^="qty_"]');
            for (var i = 0; i < qty_elements.length; i++) {
                total_qty += parseInt(qty_elements.eq(i).val());
            }
            if (qty_elements.length > 0) {

                $('input[name="current_stock"]').attr("readonly", true);
                $('input[name="current_stock"]').val(total_qty);
            } else {
                $('input[name="current_stock"]').attr("readonly", false);
            }
        }

        $('input[name^="qty_"]').on('keyup', function () {
            var total_qty = 0;
            var qty_elements = $('input[name^="qty_"]');
            for (var i = 0; i < qty_elements.length; i++) {
                total_qty += parseInt(qty_elements.eq(i).val());
            }
            $('input[name="current_stock"]').val(total_qty);
        });


    </script>

    <script>
        $(".lang_link").click(function (e) {
            e.preventDefault();
            $(".lang_link").removeClass('active');
            $(".lang_form").addClass('d-none');
            $(this).addClass('active');

            let form_id = this.id;
            let lang = form_id.split("-")[0];
            console.log(lang);
            $("#" + lang + "-form").removeClass('d-none');
            if (lang == '{{$default_lang}}') {
                $(".rest-part").removeClass('d-none');
            } else {
                $(".rest-part").addClass('d-none');
            }
        })
    </script>
@endpush
