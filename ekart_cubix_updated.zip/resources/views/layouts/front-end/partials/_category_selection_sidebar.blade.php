
    @foreach($cat->childes as $child)
        <div class=" for-hover-lable card-header p-1 flex-between">
            <div>
                <label style="cursor: pointer"
                       onclick="location.href='{{route('products',['id'=> $child['id'],'data_from'=>'category','page'=>1])}}'">
                    {{$child['name']}}
                </label>
            </div>
            <div>
                <strong class="pull-right" style="cursor: pointer"
                        onclick="$('#collapsem-{{$child['id']}}').toggle(400)">
                    {{$child->childes->count()>0?'+':''}}
                </strong>
            </div>
        </div>
        @if($child->childes->count() > 0)
         <div class="card-body {{Session::get('direction') === "rtl" ? 'mr-2' : 'ml-2'}}" id="collapsem-{{$child['id']}}" style="display: none">
            @include('layouts.front-end.partials._category_selection_sidebar',['cat' => $child])
        </div>

        @endif
    @endforeach
