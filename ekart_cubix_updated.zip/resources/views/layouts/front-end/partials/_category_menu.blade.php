@if(!empty($cat->childes))
<ul class="dropdown-menu"
    style="right: 100%; text-align: {{Session::get('direction') === "rtl" ? 'right' : 'left'}};">
    @foreach($cat->childes as $child)
        <li class="dropdown">
            <a class="dropdown-item flex-between"
               <?php if ($child->childes->count() > 0) echo "data-toggle='dropdown'"?> href="javascript:"
               onclick="location.href='{{route('products',['id'=> $child['id'],'data_from'=>'category','page'=>1])}}'">
                <div>
                    <span
                        class="{{Session::get('direction') === "rtl" ? 'pr-3' : 'pl-3'}}">{{$child['name']}}</span>
                </div>
                @if ($child->childes->count() > 0)
                    <div>
                        <i class="czi-arrow-{{Session::get('direction') === "rtl" ? 'left' : 'right'}}"></i>
                    </div>
                @endif
            </a>
            @if($child->childes->count()>0)
                @include('layouts.front-end.partials._category_menu',['cat' => $child])
            @endif
        </li>
    @endforeach
</ul>
@endif