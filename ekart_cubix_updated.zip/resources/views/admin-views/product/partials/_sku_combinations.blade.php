@if(count($combinations[0]) > 0)
	<table class="table table-bordered" id="sku-table">
		<thead>
			<tr>
				<td class="text-center" colspan="2">
					<label for="" class="control-label">{{\App\CPU\translate('Variant Combinations')}}</label>
				</td>
				<td class="text-center">
					<label for="" class="control-label">{{\App\CPU\translate('Variant')}}</label>
				</td>
				<td class="text-center">
					<label for="" class="control-label">{{\App\CPU\translate('SKU')}}</label>
				</td>
				<td class="text-center">
					<label for="" class="control-label">{{\App\CPU\translate('Apply Discount')}}</label>
				</td>
				<td>
					<label class="switch">
                        <input type="checkbox" class="check_all_tag" value="1">
                        <span class="slider round"></span>
                    </label>
				</td>
			</tr>
			<tr class="errorblock">
			</tr>
		</thead>
		<tbody>
@endif
@php

$totalCombination = 0;
if(!empty($combinations))
{
	$totalCombination = count($combinations);
}
$ind = 0;
@endphp
@foreach (\App\model\PossibleVariant::where(['status' => 1,'seller_id' => auth('seller')->id()])->get() as $key => $str)
	@php
		$price = '';$qty = '';$discount = '';$startDate = '';$startTime = '';$endDate = '';$endTime = '';$verifyDisStatus = '';
		if(!empty($prod_id))
		{
			$product = \App\Model\Product::where(['id' => $prod_id,'status' => 1])->first();
			if(!empty($product))
			{
				$count = count(json_decode($product->variation));
	            for ($i = 0; $i < $count; $i++) {
	                if (json_decode($product->variation)[$i]->type == $str && $verifyDisStatus = json_decode($product->variation)[$i]->isverified_V_Discount == 1) {
	                    $price = json_decode($product->variation)[$i]->price;
	                    $qty = json_decode($product->variation)[$i]->qty;
	                    $discount = json_decode($product->variation)[$i]->discount;

	                    if(json_decode($product->variation)[$i]->endDuration != 'null')
	                    {
		                    $strDate = explode(" ", json_decode($product->variation)[$i]->startDuration);
	                    	$startDate = $strDate[0];
	                    	$startTime = $strDate[1];
	                    }
	                    else
	                    {
	                    	$startDate='';
	                    	$startTime='';
	                    }

	                    if(json_decode($product->variation)[$i]->endDuration != 'null')
	                    {
		                    $enDate = explode(" ", json_decode($product->variation)[$i]->endDuration);
		                    $endDate = $enDate[0];
		                    $endTime = $enDate[1];
	                    }
	                    else
	                    {
	                    	$endDate='';
	                    	$$endTime='';
	                    }
	                    $verifyDisStatus = json_decode($product->variation)[$i]->isverified_V_Discount;
	                }
	            }
			}
		}

	@endphp

	@if(strlen($str) > 0)
			<tr  class="checktr" style="background-color: whitesmoke;">
				<td colspan="3">
					<!-- <label for="" class="control-label">{{ $str }}</label> -->
					<table>
						<tr>
							@php
								$strArray = [];
								$strArray = explode('-', $str->str);
								$strArray = array_map('trim', $strArray);
								foreach($strArray as $i => $sA)
								{
									$strArray[$i] = trim($sA);
								}
							@endphp
							@foreach($selectColoumn as $keys => $sc)
							<td>
								<label class="control-label">{{$sc[0]}}</label>
								<select class="form-control" data-row="{{ $ind }}" data-col="{{ (!empty($selectColoumn))?count($selectColoumn):0 }}" onchange="checkVariant('{{ $keys }}',this,'{{ $key }}')" id="{{$ind}}{{$keys}}" >
										<option value="">None</option>
										@foreach($sc as $in => $s)
											@if($in)
											<option {{(in_array(str_replace(' ', '', $s), $strArray))?'selected':''}} value="{{str_replace(' ', '', $s)}}">{{($sc[0]=='color')?\App\Model\Color::where('code', $s)->first()->name:$s}}</option>
											@endif
										@endforeach
								</select>
							</td>
							@endforeach
						</tr>
					</table>
				</td>
				<td>
					@php
						$compiledStr = '';
						$compiledSku = '';
						foreach($strArray as $compStrIndex => $cStrElement)
						{
							if($compStrIndex > 0 ){
			                    $compiledStr .= '-'.str_replace(' ', '', $cStrElement);
			                    $compiledSku .='-'.str_replace(' ', '', $cStrElement);
			                }
			                else
			                {
			                    if($colors_active == 1){
			                        $color_name = \App\Model\Color::where('code', $cStrElement)->first()->name;
			                        $compiledStr .= $color_name;
			                        $compiledSku .='-'.$color_name;
			                    }
			                    else{
			                        $compiledStr .= str_replace(' ', '', $cStrElement);
			                        $compiledSku .='-'.str_replace(' ', '', $cStrElement);
			                    }
			                }
						}
					@endphp

					<!-- this three input are to be managed according to the edit variant by using data-attribute and last orignal_str is also to be saved with the modified/asit str to maintain record at edit time -->
					
					<input type="text" value="{{ $compiledStr }}" id="strShow_{{ $key }}" class="form-control common str" data-originalstr ="{{ $str->str }}" readonly>
					<input type="hidden" name="str[]" value="{{ $str->str }}" id="strInput_{{ $key }}" class="form-control common skuCombination_{{ $ind }}">
					<input type="hidden" name="orignal_str[]" value="{{ $str->str }}" id="orignal_str_{{ $key }}" class="form-control common skuCombination_{{ $ind }}">
				</td>
				<td>
					<input type="text" name="sku[]" id="sku_{{ $key }}" class="form-control common" onchange="changeDisDetailsAfterVerified('{{ $key }}')" readonly>
				</td>
				<td>
                    <label class="switch">
                        <input type="checkbox" id="active_dis_{{$key}}" class="status active_dis_key" data-key="{{$key}}" name="active_discount[]" value="1" value="{{old('colors_active')}}" onchange="showDiscountParameters('{{ $key }}',this);">
                        <span class="slider round"></span>
                    </label>
                    <i class="tio-checkmark-square-outlined comman topStatus_{{ $key }}" style="font-size: xx-large;color: chartreuse;float: right;"></i>
                    
				</td>
			</tr>
			<tr class="comman {{$key}}">
				<td colspan="2">
					<label>Variant Price</label>
					<input type="number" id="price_{{ $key }}" name="price[]" step="0.01" class="form-control common" placeholder="Variant Price" onchange="changeDisDetailsAfterVerified('{{ $key }}')">
				</td>
				<td colspan="2">
					<label>Variant Image</label>
					<input type="file" name="variant_image[]" class="form-control common">
				</td>
				<td colspan="2">
					<label>Stock Quantity</label>
					<input type="number" id="qty_{{ $key }}" data-key="{{$key}}" name="qty[]" max="1000000" step="1" placeholder="Quantity" class="form-control common QtyCheckingData" onchange="changeDisDetailsAfterVerified('{{ $key }}')">
					<input type="hidden" id="verify_status_{{ $key }}" value="0" name="verify_status[]"/>
				</td>
				
			</tr>
			
			<script type="text/javascript">
				$('.correct_{{ $key }}').hide();
				$('.cross_{{ $key }}').hide();
				if($('#verify_status_{{ $key }}').val() == '1')
		    	{
		    		$('.topStatus_{{ $key }}').show();
		    	}
		    	else
		    	{
		    		$('.topStatus_{{ $key }}').hide();
		    	}
			</script>
	@endif
	@php
	$ind++;
	@endphp
@endforeach
	</tbody>
</table>
<div id="changedsku"></div>
@php
	$sellerItems = DB::table('products')->where(['user_id' => auth('seller')->id(),'added_by' => 'seller'])->get();
@endphp
<script>
	$('.QtyCheckingData').each(function(){
		var total = $('input[name="current_stock"]').val();
		var id = $(this).attr('data-key');
		if(id == 0 && $('#active_dis_'+id).is(':checked')){
			$('#qty_'+id).val(total);
		}else{
			var vl = 0;
			$('.QtyCheckingData').each(function(){
				var l = $(this).val();
				if(l != null){
					vl += (parseInt(vl)+parseInt(l));
				}
			});
			$('#qty_'+id).val(parseInt(total)+parseInt(vl));

		}

	});

	$('.active_dis_key').on('change',function(){
		var va = $(this).attr('data-key');
		if($(this).is(':checked')){
			$('#verify_status_'+va).val(1)
		}else{
			$('#verify_status_'+va).val(0)
		}
	})

	$('.QtyCheckingData').on('keyup',function(){
		var key = $(this).attr('data-key');
		if(key == 0){

		}
	})

	$('.create_dicount_btn').on('click',function(){
		var key = $(this).attr('data-key');
		var id = $(this).attr('data-id');
		$(this).attr('data-id',(parseInt(id)+1));
		var create_html = '<tr><td colspan="6" id="remove_'+key+'_'+id+'">\
							<table>\
								<tbody id="data_combine_'+key+'">\
									<tr class="comman {{ $key }} dataCommbile_1'+key+'">\
									<td>\
										<label>Method</label>\
										<select name="method[]" class="form-control common">\
											<option value="Each">Each</option>\
											<option value="Open">Open</option>\
										</select>\
									</td>\
									<td>\
										<label>Buy Qty.</label>\
										<input type="number" id="qty_'+key+'" name="buyquantity[]" max="1000000" step="1" placeholder="Quantity" class="form-control common" onchange="changeDisDetailsAfterVerified('+key+')">\
									</td>\
									<td>\
										<label>Discount Amount</label>\
										<div class="input-group mb-3">\
										  	<div class="input-group-prepend">\
										    	<span class="input-group-text" id="basic-addon1">BHD</span>\
										  	</div>\
											<input type="number" id="discount_'+key+'" data-key="'+key+'" name="discount[]" placeholder="Discounted Amount" class="form-control common discountedVal" onchange="changeDisDetailsAfterVerified('+key+')">\
										</div>\
									</td>\
									<td>\
										<label>Discounted Percentage</label>\
										<div class="input-group mb-3">\
											<div class="input-group-prepend">\
											    <span class="input-group-text" id="basic-addon1">%</span>\
											</div>\
											<input type="number" id="discount_'+key+'_percent" data-key="{{ $key }}" name="discount_percent[]" placeholder="Discounted Percentage" class="form-control common discountedPercentage" onchange="changeDisDetailsAfterVerified('+key+')">\
										</div>\
									</td>\
									<td>\
										<label>Start Date</label>\
										<input type="text" id="startdate_'+key+'" name="startdate[]" class="form-control startdate common"  placeholder="Start Date" onchange="changeDisDetailsAfterVerified('+key+')">\
									</td>\
									<td>\
										<a href="removeDiscountVl('+key+'_'+id+')" class="btn btn-danger">Remove</a>\
									</td>\
								</tr>\
								<tr  class="comman '+key+' dataCommbile_2'+key+'">\
									<td>\
										<label>Start Time</label>\
										<input type="text" id="starttime_'+key+'" name="starttime[]" class="form-control starttime common" placeholder="Start Time" onchange="changeDisDetailsAfterVerified('+key+')">\
									</td>\
									<td>\
										<label>End Date</label>\
										<input type="text" id="enddate_'+key+'" name="enddate[]" class="form-control enddate common" placeholder="End Date" onchange="changeDisDetailsAfterVerified('+key+')">\
									</td>\
									<td>\
										<label>End Time</label>\
										<input type="text" id="endtime_'+key+'" name="endtime[]" class="form-control endtime common" placeholder="End Time" onchange="changeDisDetailsAfterVerified('+key+')">\
									</td>\
									<td>\
										<label>Free Qty</label>\
										<input type="text" id="freequantity_'+key+'" name="freequantity[]" class="form-control"  placeholder="Free Quantity" onchange="changeDisDetailsAfterVerified('+key+')">\
									</td>\
									<td colspan="2" >\
										<label>Free Item</label>\
										<div class="row">\
											<div class="col-md-8" id="add_free_'+key+'">\
												<select class="form-control freeItemData_'+key+' js-example-responsive" name="item[]" id="item_'+key+'" onchange="changeDisDetailsAfterVerified('+key+')">\
													<option value="">None</option>'+
														'@foreach($sellerItems as $seli)'+
															'<option value="{{$seli->id}}">{{$seli->name}}</option>'+
														'@endforeach'+
												'</select>\
											</div>\
											<div class="col-md-4">\
												<a href="javascript:void(0)" onclick="createFreeItem_data(add_free_'+key+')">Add</a>\
											</div>\
										</div>\
									</td>\
								</tr>\
								<tr  class="comman '+key+' dataCommbile_3'+key+'">\
									<td colspan="6" >\
										<i class="tio-checkmark-circle-outlined correct_'+key+'" style="font-size: xx-large;color: chartreuse;margin-left:1px"></i>\
										<div class="wrong_'+key+'" style="padding-left: 5 px">\
						                    <i class="tio-clear-circle-outlined cross_'+key+'" style="font-size: xx-large;color: salmon;"></i>\
						                    <a href="JavaScript:void(0)" class="verify_'+key+'" onclick="checkDisDates('+key+')" >\
						                    	<svg xmlns="http://www.w3.org/2000/svg"  width="30" height="30" fill="currentColor" class="bi bi-patch-check" viewBox="0 0 16 16" style="font-size: xx-large;color: powderblue;margin-top: -10px;">\
											  	<path fill-rule="evenodd" d="M10.354 6.146a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708 0l-1.5-1.5a.5.5 0 1 1 .708-.708L7 8.793l2.646-2.647a.5.5 0 0 1 .708 0z"/>\
											  	<path d="m10.273 2.513-.921-.944.715-.698.622.637.89-.011a2.89 2.89 0 0 1 2.924 2.924l-.01.89.636.622a2.89 2.89 0 0 1 0 4.134l-.637.622.011.89a2.89 2.89 0 0 1-2.924 2.924l-.89-.01-.622.636a2.89 2.89 0 0 1-4.134 0l-.622-.637-.89.011a2.89 2.89 0 0 1-2.924-2.924l.01-.89-.636-.622a2.89 2.89 0 0 1 0-4.134l.637-.622-.011-.89a2.89 2.89 0 0 1 2.924-2.924l.89.01.622-.636a2.89 2.89 0 0 1 4.134 0l-.715.698a1.89 1.89 0 0 0-2.704 0l-.92.944-1.32-.016a1.89 1.89 0 0 0-1.911 1.912l.016 1.318-.944.921a1.89 1.89 0 0 0 0 2.704l.944.92-.016 1.32a1.89 1.89 0 0 0 1.912 1.911l1.318-.016.921.944a1.89 1.89 0 0 0 2.704 0l.92-.944 1.32.016a1.89 1.89 0 0 0 1.911-1.912l-.016-1.318.944-.921a1.89 1.89 0 0 0 0-2.704l-.944-.92.016-1.32a1.89 1.89 0 0 0-1.912-1.911l-1.318.016z"/>\
											</svg>\
											</a>\
											<span class="verify_'+key+'">Verify discount duration</span>\
										</div>\
										<input type="hidden" id="verify_status_'+key+'" name="verify_status[]"  >\
									</td>\
								</tr>\
							</tbody>\
						</table>\
					</td></tr>';
		$('#create_dis_'+key).append(create_html);
	});
	
	

	$('.comman').hide();
	$(".js-example-responsive").select2({
        width: 'resolve'
    });



	$('.CreateDataCombine').on('click',function(){
		var id = $(this).attr('data-id');
		var key = $(this).attr('data-key');
		var htt = $('#data_combine_'+key).html();
		$(this).append(htt);


	});

	$('.check_all_tag').on('change',function(){
		if($(this).is(':checked')){
			$('.active_dis_key').prop('checked',true);
			$('.comman').css('display','block');
			var total = $('input[name="current_stock"]').val();
            $('#qty_0').val(total);
		}
	});

	$('.QtyCheckingData').focusout(function(){
		var total = $('input[name="current_stock"]').val();
		var key = $(this).attr('data-key');
		var nex = parseInt(key)+1;
		var dfg = 0;
		$('.QtyCheckingData').each(function(){
			var l = $(this).val();
			if(l != ''){
				dfg += (parseInt(l));	
			}
		});
		console.log(dfg);
	  	if(dfg  <  total || dfg == total){
	  		$('#qty_'+nex).val(parseInt(total)-parseInt(dfg));
		}
	})

	$('.status').on('change',function(i) {
		if($(this).is(':checked')){}else{
			$('.check_all_tag').prop('checked',false);
		}
	});

	$('.discountedVal').on('keyup',function(){
		var id = $(this).attr('data-key');
		var val = $(this).val();
		console.log(val);
		var base = $('#price_'+id).val();
		console.log('base '+base);
		var percent = (parseInt(val) / parseInt(base)) * 100;
		console.log(percent);
		$('#discount_'+id+'_percent').val(percent);

	});
	$('.discountedPercentage').on('keyup',function(){
		var id = $(this).attr('data-key');
		var val = $(this).val();
		console.log(val);
		var base = $('#price_'+id).val();
		console.log('base '+base);
		var percent = (parseInt(val) / 100) * parseInt(base);
		console.log(percent);
		$('#discount_'+id).val(percent);

	});

    function assignSku()
    {
    	if($('.str').length > 0)
    	{
			$(".str").each(function(i,obj) {
				let str = obj.value;
				let sku = '{{ $sku }}'+'-'+str;
				$('#sku_'+i).val(sku);
			});
    	}
    }

    // call when request for new elements of str //
    assignSku();

    // call when product name changes //
	$('#en_name').on('change', function () {
		if($('.str').length > 0)
    	{
			$(".str").each(function(i,obj) {
				let str = obj.value;
				let sku = $('#en_name').val()+'-'+str;
				$('#sku_'+i).val(sku);
			});
    	}
	});
	function checkVariant(changedIndex,that,keyIndex)
    {
    	var response = '';
    	var changedElement = $(that).val();

    	var sku=[];
        var oldSkuString = $('#strInput_'+keyIndex).val();
        var skuArrayValue = $('#strInput_'+keyIndex).val().split('-');
        var col = $(that).attr('data-col');
        var row = $(that).attr('data-row');

        for (var i = 0; i < col; i++) {
		    sku[i] = $('#'+String(row)+String(i)+' option:selected').val();
		}
        oldValueOFChnagedElement = '';
        newValueOFChnagedElement = '';
        for (var k = 0; k < skuArrayValue.length; k++) {
            if(k==changedIndex)
            {
            	oldValueOFCHnagedElement = skuArrayValue[k];
            	skuArrayValue[k] = $(that).val();
            	newValueOFChnagedElement = $(that).val();
            }
            
        }
        var newSkuString = sku.join([separator = '-']);
        $.ajax({
			url: '{{route('seller.product.check-variant-exist')}}',
			type: 'POST',
			data: {"_token": "{{ csrf_token() }}","newSkuString": newSkuString,'colors_active':'{{$colors_active}}','oldSkuSrting':oldSkuString},
			success: function (data) {
				console.log({data});
				if(data[0].status)
				{
					$('#strShow_'+keyIndex).val(data[0].showstr);
					$('#strInput_'+keyIndex).val(data[0].originalStr);
                    let productName = $('#en_name').val();
                    console.log(productName);
                    if(productName != '')
                    {
                    	let skuName = productName+'-'+data[0].showstr;
                    	$('#sku_'+keyIndex).val(skuName);
                    }
				}
				else
				{
					toastr.error("This variant already exists.", {
                        CloseButton: true,
                        ProgressBar: true
                    });

					//-- to reset the old Str by assign old str to var and then matsch elements of the str with each option values --//
					var arrayOfResetOldStr = [];
                    var resetOldStr = data[0].matchedStr;
                    arrayOfResetOldStr = resetOldStr.split('-');
                    for (var i = 0; i < col; i++) {
			        	let id ='#'+String(row)+String(i);
					    let val = $(id +' option:selected').val();
					    $(id+" > option").each(function() {
					    	let optionValues = this.value;
					    	var index = jQuery.inArray(optionValues, arrayOfResetOldStr);
			                if (index !== -1) {
			                  $(id).val(optionValues);
			                }
						});
					}
				}
			}
		});

        // now send this string in to  the databasce and check the existance 

    }

    function showDiscountParameters(index, that)
    {
    	var str = index;
    	$('.cross_'+index).hide();
    	$('#verify_status_'+str).val(1);
    	if($('#verify_status_'+str).val() == '1')
    	{
    		$('#topStatus_'+str).show();
    		$('.correct_'+index).show();
    	}
    	else
    	{
    		$('#topStatus_'+str).hide();
    		$('.correct_'+index).hide();
    		if($('#verify_status_'+str).val() == '0')
    		{
    			$('.cross_'+index).show();
    		}
    	}

        if (!$(that).is(':checked')) {
            $('.'+str).hide();
        } else {
            $('.'+str).show();


            var totalss = $('input[name="current_stock"]').val();
            var ss = 0;
			$('.active_dis_key').each(function(){
				var key = $(this).attr('data-key');
				if($(this).is(':checked')){
					if(key != str){
						var l = $('#qty_'+key).val();
						if(l != ''){
							ss += (parseInt(l));	
						}
					}
				}
			});
			console.log('sdfsdf '+ss);
			if(ss < totalss || ss == totalss){
				$('#qty_'+str).val(parseInt(totalss)-parseInt(ss));
			}

            flatpickr("#startdate_"+str,{
                //enableTime: true,
                dateFormat: "Y-m-d",
                minDate: "today",
            });

            flatpickr("#starttime_"+str,{
                enableTime: true,
                noCalendar: true,
                dateFormat: "H:i",
            });

            flatpickr("#enddate_"+str,{           
                //enableTime: true,
                minDate: "today",
                dateFormat: "Y-m-d",
            });
            flatpickr("#endtime_"+str,{
                enableTime: true,
                noCalendar: true,
                dateFormat: "H:i",
            });
        }
    }


 	function checkDisDates(str)
 	{
 		compStartDate="";compEndDate="";meg ="";
 		var price = $('#price_'+str).val();
 		var sku = $('#sku_'+str).val();
 		var qty = $('#qty_'+str).val();

 		var disAmmount = $('#discount_'+str).val();
		var staDat = $('#startdate_'+str).val();
		var staTim = $('#starttime_'+str).val();
		var endDat = $('#enddate_'+str).val();
		var endTim = $('#endtime_'+str).val();
		compStartDate = staDat+' '+staTim;
		compEndDate = endDat+' '+endTim;

		var buyquantity = $('#buyquantity_'+str).val();
		var freequantity = $('#freequantity_'+str).val();
		var item = $('#item_'+str).val();

		errorstatus = '0'
		$('.common').removeClass('showdanger');
		meg = meg + '<td colspan="5"><ul  style="font-size: 12px;padding-left: 13px;padding-top: 5px;color: #ff5e00c7; font-size: 12px;">';

		if (Number(price) == 0 || Number(price) < 0 || price =="") {
			meg = meg + "<li>("+str+"):-Price is required field and must be higher than 0.</li>";
			$('#price_'+str).val('').addClass('showdanger');
			errorstatus = '1'
		}
		if (sku =="") {
			meg = meg + "<li>("+str+"):-Sku is required field.</li>";
			$('#sku_'+str).val('').addClass('showdanger');
			errorstatus = '1'
		}
		if (Number(qty) == 0 || qty < 0 || qty =="") {
			meg = meg + "<li>("+str+"):-Quantity is required field and must be higher than 0.</li>";
			$('#qty_'+str).val('').addClass('showdanger');
			errorstatus = '1'
		}
		if(disAmmount != "")
		{
			if (Number(disAmmount) < 0) {
				meg = meg + "<li>("+str+"):- The Discount Amount is a positive number with value, greater than 0.</li>";
				$('#discount_'+str).val('').addClass('showdanger');
				errorstatus = '1'
			}
			else if (Number(disAmmount) > Number(price)) {
				meg = meg + "<li>("+str+"):-The discounted price should be equal to or less than the variant price.</li>";
				$('#discount_'+str).val('').addClass('showdanger');
				errorstatus = '1'
			}
			else if (staDat == '')
			{
				meg = meg + "<li>("+str+"):-Please fill in the Discount Start Date and time for the Vatriant.</li>";
			    $('#startdate_'+str).addClass('showdanger');
			    errorstatus = '1'
			}
			else if(staTim == '')
			{
				meg = meg + "<li>("+str+"):-Please enter the Discount Start Time.</li>";
			    $('#starttime_'+str).addClass('showdanger');
			    errorstatus = '1'
			}
		}
		

		if(endTim != '')
		{
			if (endDat == '')
			{
				meg = meg + "<li>("+str+"):-Please enter the end date and time also.</li>";
			    $('#enddate_'+str).addClass('showdanger');
			    errorstatus = 1;
			}
		}

		if(endDat != '')
		{
			if (endTim == '')
			{
				meg = meg + "<li>("+str+"):-Please fill in the end time.</li>";
			    $('#endtime_'+str).addClass('showdanger');
			    errorstatus = 1;
			}
		}


		if(compEndDate.length>0){
		     if ( new Date(compStartDate.replace(/-/g,'/')) >= new Date(compEndDate.replace(/-/g,'/')) ) {
		        meg = meg + "<li>("+str+"):-The End Date should be greater than the Start Date.</li>";
		        $('#enddate_'+str).val('').addClass('showdanger');
		        $('#endtime_'+str).val('').addClass('showdanger');
		        errorstatus = '1'
		    }
		}

		if(buyquantity != ''){
			if ( Number(buyquantity) > Number(qty) ) {
		        meg = meg + "<li>("+str+"):-The Buy Quantity should be smaller than Quantity.</li>";
		        $('#buyquantity_'+str).val('').addClass('showdanger');
		        errorstatus = '1'
		    }
		}

		if(freequantity != ''){
			if ( buyquantity == '' ) {
		        meg = meg + "<li>("+str+"):-Please Fill Quantity first.</li>";
		        $('#freequantity_'+str).val('').addClass('showdanger');
		        errorstatus = '1'
		    }
		}

		if(item != ''){
			if ( buyquantity == '' || freequantity == '') {
		        meg = meg + "<li>("+str+"):-Please Fill Buy Quantity and Free Quantity first.</li>";
		        $('#item_'+str).val('').addClass('showdanger');
		        errorstatus = '1'
		    }
		}

		meg = meg + '</ul></td>';
		if(errorstatus == '1')
		{
			$("#verify_status_"+str).val('0');
			toHideOn(str);
			$("#sku-table thead tr.errorblock").html('').html(meg).show();
		}
		else
		{
			$("#verify_status_"+str).val('1');
			toShowOn(str);
			$("#sku-table thead tr.errorblock").html('').hide();
			let Quantity = $('#qty_'+str).val();
			let current_stock = $('#current_stock').val();
			current_stock = Number(current_stock)+Number(Quantity);
			$('#current_stock').val(current_stock);
		}
 	}

 // 	function changeDisDetailsAfterVerified(index)
	// {
	// 	if($('#verify_status_'+index).val() == '1')
 //    	{
 //    		$('#verify_status_'+index).val('0');
	// 		toastr.info("Please Verify again to log this Variant Discount Parameters", {
	// 			CloseButton: true,
	// 			ProgressBar: true
	// 		});
	// 		toHideOn(index);
 //    	}
	// }

	function toHideOn (index)
	{
		if($('#verify_status_'+index).val() == '0')
    	{
			$(".verify_"+index).show();
			$(".cross_"+index).show();
			$('.topStatus_'+index).hide();
			$(".correct_"+index).hide();
    	}
	}

	function toShowOn (index)
	{
		if($('#verify_status_'+index).val() == '1')
    	{
			$(".verify_"+index).hide();
			$(".cross_"+index).hide();
			$('.topStatus_'+index).show();
			$(".correct_"+index).show();
    	}
	}
	

	// 	update_qty();
	// function update_qty()
	// {
	// 	var total_qty = 0;
	// 	var qty_elements = $('input[name^="qty"]');
	// 	alert(qty_elements);
	// 	for(var i=0; i<qty_elements.length; i++)
	// 	{
	// 		total_qty += parseInt(qty_elements.eq(i).val());
	// 	}
	// 	if(qty_elements.length > 0)
	// 	{

	// 		$('input[name="current_stock"]').attr("readonly", true);
	// 		$('input[name="current_stock"]').val(total_qty);
	// 	}
	// 	else{
	// 		$('input[name="current_stock"]').attr("readonly", false);
	// 	}
	// }
	// $('input[name^="qty_"]').on('keyup', function () {
	// 	var total_qty = 0;
	// 	var qty_elements = $('input[name^="qty_"]');
	// 	for(var i=0; i<qty_elements.length; i++)
	// 	{
	// 		total_qty += parseInt(qty_elements.eq(i).val());
	// 	}
	// 	$('input[name="current_stock"]').val(total_qty);
	// });

</script>


