@extends('layouts.back-end.app')

@section('title', \App\CPU\translate('Offer_list'))

@push('css_or_js')
    <meta name="csrf-token" content="{{ csrf_token() }}">
@endpush

@section('content')
    <div class="content container-fluid">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{route('admin.dashboard')}}">{{\App\CPU\translate('Dashboard')}}</a>
                </li>
                <li class="breadcrumb-item" aria-current="page">{{\App\CPU\translate('Offer')}}  </li>
            </ol>
        </nav>

        <div class="row" style="margin-top: 20px">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">

                        <h5>{{ \App\CPU\translate('plan_offer')}}</h5>
                        <!-- <select name="withdraw_status_filter" onchange="status_filter(this.value)" class="custom-select float-right" style="width: 200px">
                            <option value="all" {{session()->has('withdraw_status_filter') && session('withdraw_status_filter') == 'all'?'selected':''}}>{{\App\CPU\translate('All')}}</option>
                            <option value="approved" {{session()->has('withdraw_status_filter') && session('withdraw_status_filter') == 'approved'?'selected':''}}>{{\App\CPU\translate('Approved')}}</option>
                            <option value="denied" {{session()->has('withdraw_status_filter') && session('withdraw_status_filter') == 'denied'?'selected':''}}>{{\App\CPU\translate('Denied')}}</option>
                            <option value="pending" {{session()->has('withdraw_status_filter') && session('withdraw_status_filter') == 'pending'?'selected':''}}>{{\App\CPU\translate('Pending')}}</option>
                        </select> -->

                        
                        <a href="{{route('admin.plan.plan-offer')}}" class="btn btn-primary  float-right">
                            <i class="tio-add-circle"></i>
                            <span class="text">{{\App\CPU\translate('add_new_offer')}}</span>
                        </a>
                    </div>
                    <div class="card-body" style="padding: 0">
                        <div class="table-responsive">
                            <table id="datatable"
                                   style="text-align: {{Session::get('direction') === "rtl" ? 'right' : 'left'}};"
                                   class="table table-hover table-borderless table-thead-bordered table-nowrap table-align-middle card-table"
                                   style="width: 100%">
                                <thead class="thead-light">
                                <tr>
                                    <th>{{\App\CPU\translate('SL#')}}</th>
                                    <th>{{\App\CPU\translate('plan_name')}}</th>
                                    <th>{{\App\CPU\translate('title')}}</th>
                                    <th>{{ \App\CPU\translate('plan_price') }}</th>
                                    <th>{{\App\CPU\translate('offered_price')}}</th>
                                    <th>{{\App\CPU\translate('offer_persentage')}}</th>
                                    <th>{{\App\CPU\translate('start_date')}}</th>
                                    <th>{{\App\CPU\translate('end_date')}}</th>
                                    <th>{{\App\CPU\translate('hold')}}</th>
                                    <th style="width: 5px">{{\App\CPU\translate('Action')}}</th>
                                </tr>
                                </thead>
                                <tbody>
                                @foreach($offers as $key => $offer)
                                    <tr>
                                        <td scope="row">{{$key+1}}</td>
                                        <td>{{Ucfirst($offer->offeredplan->title)}}</td>
                                        <td>{{Ucfirst($offer->offer_title)}}</td>
                                        <td>{{\App\CPU\BackEndHelper::set_plan_currency($offer['offeredplan']['price'],$offer['offeredplan']['currency_id'])}}</td>
                                        <td>{{\App\CPU\BackEndHelper::set_plan_currency($offer['new_ammount'],$offer['offeredplan']['currency_id'])}}</td>
                                        <td>{{(($offer->offeredplan->price-$offer->new_ammount)/$offer->offeredplan->price)*100}}%</td>
                                        <td>{{(!empty($offer->offer_startdate))?date('d/m/Y',strtotime($offer->offer_startdate)):'N/A'}}</td>
                                        <td>{{(!empty($offer->offer_enddate))?date('d/m/Y',strtotime($offer->offer_enddate)):'N/A'}}</td>
                                        <td>
                                            @if($offer->hold==1)
                                                <label class="badge badge-warning">{{\App\CPU\translate('YES')}}</label>
                                            @else
                                                <label class="badge badge-success">NO</label>
                                            @endif
                                        </td>
                                        <td>
                                            <a href="{{route('admin.plan.edit-offer',['id'=>$offer->id])}}"
                                               class="btn btn-primary btn-sm">
                                                {{\App\CPU\translate('edit')}}
                                            </a> | 
                                            <a href="javascript:void(0)"
                                               class="btn btn-primary btn-sm" onclick="Swal.fire({title: 'Do you Delete this Offer?',showDenyButton: true,showCancelButton: true,confirmButtonColor: '#377dff',cancelButtonColor: '#363636',confirmButtonText: `Yes`,denyButtonText: `Don't Logout`,}).then((result) => { if (result.value) 
                                                         {
                                                            deleteOffer('{{$offer->id}}');
                                                         } else{
                                                            Swal.fire('Canceled', '', 'info')
                                                         }
                                                     })">
                                                {{\App\CPU\translate('Delete')}}
                                            </a>
                                        </td>
                                    </tr>
                                @endforeach
                                </tbody>
                            </table>
                            @if(count($offers)==0)
                                <div class="text-center p-4">
                                    <img class="mb-3"
                                         src="{{asset('public/assets/back-end')}}/svg/illustrations/sorry.svg"
                                         alt="Image Description" style="width: 7rem;">
                                    <p class="mb-0">{{\App\CPU\translate('No_data_to_show')}}</p>
                                </div>
                            @endif
                        </div>
                    </div>
                    <div class="card-footer">
                        {{$offers->links()}}
                    </div>
                </div>
            </div>

        </div>
    </div>
@endsection


@push('script_2')
  <script>
      function status_filter(type) {
          $.ajaxSetup({
              headers: {
                  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
              }
          });
          $.post({
              url: '{{route('admin.withdraw.status-filter')}}',
              data: {
                  withdraw_status_filter: type
              },
              beforeSend: function () {
                  $('#loading').show()
              },
              success: function (data) {
                 location.reload();
              },
              complete: function () {
                  $('#loading').hide()
              }
          });
      }

      function deleteOffer(oid){
        $.ajax({
                    url: '{{url("admin/plan/delete-offer")}}/'+oid,
                    type: 'GET',
                    success: function(result){

                        console.log(result);

                      var res = $.parseJSON(result);
                      console.log(res);
                      var message = res.message;
                      console.log(message);
                              //console.log(message);

                            if(res.message == true){
                              toastr.success('{{\App\CPU\translate('Offer deleted successfully!')}}', {
                                CloseButton: true,
                                ProgressBar: true
                              });
                                window.location.replace('{{url("admin/plan/offer-list")}}');
                            }else{
                              toastr.error('{{\App\CPU\translate('Oops Something went wrong!')}}', {
                                CloseButton: true,
                                ProgressBar: true
                              });
                              window.location.replace('{{url("admin/plan/offer-list")}}');
                            }
                        }
                    });
      }
  </script>
@endpush
