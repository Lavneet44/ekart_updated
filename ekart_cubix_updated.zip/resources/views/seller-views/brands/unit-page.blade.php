@extends('layouts.back-end.app-seller')

@section('title', \App\CPU\translate('Units List'))

@push('css_or_js')

@endpush

@section('content')
    <div class="content container-fluid">

        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-2">
            <h1 class="h3 mb-0 text-black-50">{{\App\CPU\translate('Units')}} <span style="color: rgb(252, 59, 10);">({{ $br->total() }})</span></h1>
        </div>

        <div class="row" style="margin-top: 20px">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h1 style="width: 100%;">Units
                            <span class="float-right">
                                <a href="javascript:void(0)" data-toggle="modal" data-target="#parentBrandMOdel" class="btn btn-primary">Select Units</a>
                                <a href="javascript:void(0)" data-toggle="modal" data-target="#addUnitModel" class="btn btn-primary">Add Unit</a>
                            </span>
                        </h1>
                        
                        
                        <!-- End Search -->
                    </div>
                    <div class="card-body" style="padding: 0">
                        <div class="table-responsive">
                            <table style="text-align: {{Session::get('direction') === "rtl" ? 'right' : 'left'}};"
                                class="table table-bordered table-thead-bordered table-nowrap table-align-middle card-table">
                                <thead class="thead-light">
                                <tr>
                                    <th scope="col" style="width: 100px">
                                        {{ \App\CPU\translate('brand')}} {{ \App\CPU\translate('ID')}}
                                    </th>
                                    <th scope="col">{{ \App\CPU\translate('name')}}</th>
                                    <th scope="col">{{ \App\CPU\translate('symbol')}}</th>
                                    <th scope="col" style="width: 100px" class="text-center">
                                        {{ \App\CPU\translate('action')}}
                                    </th>
                                </tr>
                                </thead>
                                <tbody>

                                @foreach($br as $k=>$b)
                                    <tr>
                                        <td class="text-center">{{$br->firstItem()+$k}}</td>
                                        <td>{{$b['name']}}</td>
                                        <td>{{ $b['symbol'] }}</td>
                                        <td>
                                            @if($b['created_by'] == auth('seller')->id())
                                            <a class="btn btn-primary btn-sm "
                                               href="javascript:editData()" data-id="{{ $br['id'] }}" data-name="{{ $br['name'] }}" data-sym="{{ $br['symbol'] }}">
                                                <i class="tio-edit"></i> {{ \App\CPU\translate('Edit')}}
                                            </a>
                                            <!-- <a class="btn btn-danger btn-sm delete"
                                               id="{{$b['id']}}">
                                                <i class="tio-add-to-trash"></i> {{ \App\CPU\translate('Delete')}}
                                            </a> -->
                                            @else
                                            <p>Created By Admin</p>
                                            @endif
                                        </td>
                                    </tr>
                                @endforeach

                                </tbody>
                            </table>

                        </div>
                    </div>
                    <div class="card-footer">
                        {{$br->links()}}
                    </div>
                    @if(count($br)==0)
                        <div class="text-center p-4">
                            <img class="mb-3" src="{{asset('public/assets/back-end')}}/svg/illustrations/sorry.svg" alt="Image Description" style="width: 7rem;">
                            <p class="mb-0">{{ \App\CPU\translate('No_data_to_show')}}</p>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="parentBrandMOdel" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">{{\App\CPU\translate('Select Units')}}</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <form action="{{route('seller.product.seller-seleted-units')}}" method="POST"  enctype="multipart/form-data">
          <div class="modal-body">
                @csrf
                <div class="row">
                    @foreach($units as $key => $value)
                    <div class="col-md-4">
                        <div class="form-group">
                            <input type="checkbox" name="id[]" value="{{ $value->id }}" <?php if($value->selected_seller!=''){ $selected = json_decode($value->selected_seller,true); if(!empty($selected)){ $seller = auth('seller')->id(); if(in_array($seller,$selected)){ echo 'checked'; } } } ?>>
                            <label for="name">{{ \App\CPU\translate($value->name)}}</label>
                        </div>
                    </div>
                    @endforeach
                </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-danger">{{\App\CPU\translate('submit')}}</button>
          </div>
          </form>
        </div>
      </div>
    </div>


    <div class="modal fade" id="addUnitModel" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">{{\App\CPU\translate('Add_Brand')}}</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <form action="{{route('seller.product.add-seller-unit')}}" name="productunitform" id="idproductunitform" method="POST"  enctype="multipart/form-data">
          <div class="modal-body">
                @csrf
                    @php($language=\App\Model\BusinessSetting::where('type','pnc_language')->first())
                    @php($language = $language->value ?? null)
                    @php($default_lang = 'en')

                    @php($default_lang = json_decode($language)[0])
                    <ul class="nav nav-tabs mb-4">
                        @foreach(json_decode($language) as $lang)
                            <li class="nav-item">
                                <a class="nav-link lang_link {{$lang == $default_lang? 'active':''}}"
                                    href="#"
                                    id="{{$lang}}-link">{{\App\CPU\Helpers::get_language_name($lang).'('.strtoupper($lang).')'}}</a>
                            </li>
                        @endforeach
                    </ul>
                    <div class="row">
                        <div class="col-md-12">
                            @foreach(json_decode($language) as $lang)
                                <div class="form-group {{$lang != $default_lang ? 'd-none':''}} lang_form"
                                        id="{{$lang}}-form">
                                    <label for="name">{{ \App\CPU\translate('Units')}} ({{strtoupper($lang)}})</label>
                                    <input type="text" name="name" class="form-control" id="Checkname" value="{{old('name')}}" placeholder="{{\App\CPU\translate('Ex')}} : {{\App\CPU\translate('Kilogram')}}" {{$lang == $default_lang? 'required':''}}>
                                </div>
                                <div class="form-group {{$lang != $default_lang ? 'd-none':''}} lang_form"
                                        id="{{$lang}}-form">
                                    <label for="name">{{ \App\CPU\translate('Units')}} ({{strtoupper($lang)}})</label>
                                    <input type="text" name="symbol" class="form-control" id="symbol" value="{{old('symbol')}}" placeholder="{{\App\CPU\translate('Ex')}} : {{\App\CPU\translate('Kg')}}" {{$lang == $default_lang? 'required':''}}>
                                </div>
                                <input type="hidden" name="lang[]" value="{{$lang}}">
                            @endforeach
                           
                        </div>
                       
                    </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-danger">{{\App\CPU\translate('submit')}}</button>
          </div>
          </form>
        </div>
      </div>
    </div>

    <div class="modal fade" id="editUnitModel" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">{{\App\CPU\translate('Update Unit')}}</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <form action="{{route('seller.product.add-seller-unit')}}" name="productunitform" id="idproductunitform" method="POST"  enctype="multipart/form-data">
          <div class="modal-body">
                @csrf
                    @php($language=\App\Model\BusinessSetting::where('type','pnc_language')->first())
                    @php($language = $language->value ?? null)
                    @php($default_lang = 'en')

                    @php($default_lang = json_decode($language)[0])
                    <ul class="nav nav-tabs mb-4">
                        @foreach(json_decode($language) as $lang)
                            <li class="nav-item">
                                <a class="nav-link lang_link {{$lang == $default_lang? 'active':''}}"
                                    href="#"
                                    id="{{$lang}}-link">{{\App\CPU\Helpers::get_language_name($lang).'('.strtoupper($lang).')'}}</a>
                            </li>
                        @endforeach
                    </ul>
                    <div class="row">
                        <div class="col-md-12">
                            @foreach(json_decode($language) as $lang)
                                <div class="form-group {{$lang != $default_lang ? 'd-none':''}} lang_form"
                                        id="{{$lang}}-form">
                                    <label for="name">{{ \App\CPU\translate('Units')}} ({{strtoupper($lang)}})</label>
                                    <input type="hidden" name="id" id="EditUpdateid">
                                    <input type="text" name="name" class="form-control" id="EditUpdateName" value="{{old('name')}}" placeholder="{{\App\CPU\translate('Ex')}} : {{\App\CPU\translate('Kilogram')}}" {{$lang == $default_lang? 'required':''}}>
                                </div>
                                <div class="form-group {{$lang != $default_lang ? 'd-none':''}} lang_form"
                                        id="{{$lang}}-form">
                                    <label for="name">{{ \App\CPU\translate('Units')}} ({{strtoupper($lang)}})</label>
                                    <input type="text" name="symbol" class="form-control" id="EditUpdateSym" value="{{old('symbol')}}" placeholder="{{\App\CPU\translate('Ex')}} : {{\App\CPU\translate('Kg')}}" {{$lang == $default_lang? 'required':''}}>
                                </div>
                                <input type="hidden" name="lang[]" value="{{$lang}}">
                            @endforeach
                           
                        </div>
                       
                    </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-danger">{{\App\CPU\translate('submit')}}</button>
          </div>
          </form>
        </div>
      </div>
    </div>
@endsection

@push('script')
    <script>

        function editData(){
            var id = $(this).attr('data-id');
            var name = $(this).attr('data-name');
            var sym = $(this).attr('data-sym');
            $('.modal-body #EditUpdateid').val(id);
            $('.modal-body #EditUpdateName').val(name);
            $('.modal-body #EditUpdateSym').val(sym);
            $('#editUnitModel').modal('toggle');
        }
        $(document).on('click', '.delete', function () {
            var id = $(this).attr("id");
            Swal.fire({
                title: '{{ \App\CPU\translate('Are_you_sure_delete_this_brand')}}?',
                text: "{{ \App\CPU\translate('You_will_not_be_able_to_revert_this')}}!",
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: '{{ \App\CPU\translate('Yes')}}, {{ \App\CPU\translate('delete_it')}}!'
            }).then((result) => {
                if (result.value) {
                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                        }
                    });
                    $.ajax({
                        url: "{{route('seller.product.delete-brand')}}",
                        method: 'POST',
                        data: {id: id},
                        success: function () {
                            toastr.success('{{ \App\CPU\translate('Brand_deleted_successfully')}}');
                            location.reload();
                        }
                    });
                }
            })
        });
    </script>
@endpush
