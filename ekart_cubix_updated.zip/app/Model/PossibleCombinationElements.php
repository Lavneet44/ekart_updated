<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class PossibleCombinationElements extends Model
{
    protected $table = 'possible_combination_elements';

}